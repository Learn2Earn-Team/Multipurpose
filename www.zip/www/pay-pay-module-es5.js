function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pay-pay-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/pay/pay.page.html":
  /*!*******************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/pay/pay.page.html ***!
    \*******************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppPagesPayPayPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-menu-button color=\"dark\"></ion-menu-button>\n    </ion-buttons>\n    <ion-title>Digi Pay</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div class=\"main_content_div\">\n    <div class=\"story_div\">\n      <div class=\"chips_div\">\n        <div class=\"inner_div\" *ngFor=\"let item of stories\">\n          <div class=\"story_img\">\n            <img src=\"{{item.img}}\">\n          </div>\n          <ion-label class=\"chip\">{{item.name | slice : 0: 10}}</ion-label>\n        </div>\n      </div>\n    </div>\n\n    <div class=\"travel_div\">\n      <ion-label class=\"head_lbl\">Travel Bills & Recharge</ion-label>\n      <ion-grid fixed>\n        <ion-row>\n          <ion-col size=\"3\" *ngFor=\"let item of travel\">\n\n            <div class=\"image_div\">\n              <img src=\"{{item.img}}\" alt=\"\">\n            </div>\n            <ion-label>{{item.name}}</ion-label>\n          </ion-col>\n        </ion-row>\n      </ion-grid>\n    </div>\n\n    <div class=\"travel_div\">\n      <ion-label class=\"head_lbl\">Frequently paid Business</ion-label>\n      <ion-grid fixed>\n        <ion-row>\n          <ion-col size=\"3\">\n            <img class=\"small_img\" src=\"assets/imgs/pay/business.png\" alt=\"\">\n            <ion-label>News</ion-label>\n          </ion-col>\n        </ion-row>\n      </ion-grid>\n    </div>\n\n  </div>\n</ion-content>";
    /***/
  },

  /***/
  "./src/app/pages/pay/pay-routing.module.ts":
  /*!*************************************************!*\
    !*** ./src/app/pages/pay/pay-routing.module.ts ***!
    \*************************************************/

  /*! exports provided: PayPageRoutingModule */

  /***/
  function srcAppPagesPayPayRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "PayPageRoutingModule", function () {
      return PayPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _pay_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./pay.page */
    "./src/app/pages/pay/pay.page.ts");

    var routes = [{
      path: '',
      component: _pay_page__WEBPACK_IMPORTED_MODULE_3__["PayPage"]
    }];

    var PayPageRoutingModule = function PayPageRoutingModule() {
      _classCallCheck(this, PayPageRoutingModule);
    };

    PayPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], PayPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/pages/pay/pay.module.ts":
  /*!*****************************************!*\
    !*** ./src/app/pages/pay/pay.module.ts ***!
    \*****************************************/

  /*! exports provided: PayPageModule */

  /***/
  function srcAppPagesPayPayModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "PayPageModule", function () {
      return PayPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _pay_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./pay-routing.module */
    "./src/app/pages/pay/pay-routing.module.ts");
    /* harmony import */


    var _pay_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./pay.page */
    "./src/app/pages/pay/pay.page.ts");

    var PayPageModule = function PayPageModule() {
      _classCallCheck(this, PayPageModule);
    };

    PayPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _pay_routing_module__WEBPACK_IMPORTED_MODULE_5__["PayPageRoutingModule"]],
      declarations: [_pay_page__WEBPACK_IMPORTED_MODULE_6__["PayPage"]]
    })], PayPageModule);
    /***/
  },

  /***/
  "./src/app/pages/pay/pay.page.scss":
  /*!*****************************************!*\
    !*** ./src/app/pages/pay/pay.page.scss ***!
    \*****************************************/

  /*! exports provided: default */

  /***/
  function srcAppPagesPayPayPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".main_content_div {\n  width: 100%;\n}\n.main_content_div ion-label {\n  display: block;\n}\n.main_content_div .head_lbl {\n  font-weight: 500;\n  color: #505050;\n  margin-bottom: 10px;\n  font-size: 14px;\n}\n.main_content_div .story_div {\n  padding: 16px;\n  border-bottom: 1px solid lightgray;\n}\n.main_content_div .story_div .chips_div {\n  display: flex;\n  flex-direction: row;\n  overflow: scroll;\n}\n.main_content_div .story_div .chips_div .inner_div {\n  display: flex;\n  align-items: center;\n  flex-direction: column;\n  margin-right: 15px;\n  align-items: center;\n  justify-content: space-between;\n}\n.main_content_div .story_div .chips_div .inner_div .story_img {\n  width: 40px;\n  height: 40px;\n  border-radius: 100%;\n  background: var(--ion-color-primary);\n  position: relative;\n}\n.main_content_div .story_div .chips_div .inner_div .story_img img {\n  width: 23px;\n  position: absolute;\n  top: 50%;\n  left: 50%;\n  transform: translate(-50%, -50%);\n}\n.main_content_div .story_div .chips_div .chip {\n  white-space: nowrap;\n  color: #505050;\n  font-size: 12px;\n  margin-top: 10px;\n}\n.main_content_div .travel_div {\n  padding: 16px;\n  border-bottom: 1px solid lightgray;\n}\n.main_content_div .travel_div ion-grid {\n  padding: 0;\n}\n.main_content_div .travel_div ion-grid ion-col {\n  text-align: center;\n}\n.main_content_div .travel_div ion-grid ion-col .image_div {\n  width: 40px;\n  height: 40px;\n  border-radius: 100%;\n  box-shadow: 0px 3px 6px rgba(17, 116, 192, 0.3);\n  position: relative;\n  display: block;\n  margin: auto;\n}\n.main_content_div .travel_div ion-grid ion-col .image_div img {\n  position: absolute;\n  top: 50%;\n  left: 50%;\n  transform: translate(-50%, -50%);\n  width: 20px;\n}\n.main_content_div .travel_div ion-grid ion-col .small_img {\n  width: 40px;\n}\n.main_content_div .travel_div ion-grid ion-col ion-label {\n  font-size: 12px;\n  margin-top: 10px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvcGF5L0U6XFxJb25pYyBQcm9qZWN0c1xcaW9uaWMtNS10ZW1wbGF0ZS1idW5kbGUtaW9uaWMtNS10aGVtZXMtYnVuZGxlcy1pb25pYy01LXRlbXBsYXRlcy13aXRoLTEwLWFwcHNcXEFwcF9zb3VyY2VfY29kZVxcQXBwc19jb2RlXFxNdWx0aV9wdXJwb3NlL3NyY1xcYXBwXFxwYWdlc1xccGF5XFxwYXkucGFnZS5zY3NzIiwic3JjL2FwcC9wYWdlcy9wYXkvcGF5LnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLFdBQUE7QUNDSjtBRENJO0VBQ0ksY0FBQTtBQ0NSO0FERUk7RUFDSSxnQkFBQTtFQUNBLGNBQUE7RUFDQSxtQkFBQTtFQUNBLGVBQUE7QUNBUjtBREdJO0VBQ0ksYUFBQTtFQUNBLGtDQUFBO0FDRFI7QURHUTtFQUNJLGFBQUE7RUFDQSxtQkFBQTtFQUNBLGdCQUFBO0FDRFo7QURHWTtFQUNJLGFBQUE7RUFDQSxtQkFBQTtFQUNBLHNCQUFBO0VBQ0Esa0JBQUE7RUFDQSxtQkFBQTtFQUNBLDhCQUFBO0FDRGhCO0FER2dCO0VBQ0ksV0FBQTtFQUNBLFlBQUE7RUFDQSxtQkFBQTtFQUNBLG9DQUFBO0VBQ0Esa0JBQUE7QUNEcEI7QURFb0I7RUFDSSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxRQUFBO0VBQ0EsU0FBQTtFQUNBLGdDQUFBO0FDQXhCO0FES1k7RUFDSSxtQkFBQTtFQUNBLGNBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7QUNIaEI7QURPSTtFQUNJLGFBQUE7RUFDQSxrQ0FBQTtBQ0xSO0FETVE7RUFDSSxVQUFBO0FDSlo7QURNWTtFQUNJLGtCQUFBO0FDSmhCO0FETWdCO0VBQ0ksV0FBQTtFQUNBLFlBQUE7RUFDQSxtQkFBQTtFQUVBLCtDQUFBO0VBQ0Esa0JBQUE7RUFDQSxjQUFBO0VBQ0EsWUFBQTtBQ0xwQjtBRE9vQjtFQUNJLGtCQUFBO0VBQ0EsUUFBQTtFQUNBLFNBQUE7RUFDQSxnQ0FBQTtFQUNBLFdBQUE7QUNMeEI7QURTZ0I7RUFDSSxXQUFBO0FDUHBCO0FEU2dCO0VBQ0ksZUFBQTtFQUNBLGdCQUFBO0FDUHBCIiwiZmlsZSI6InNyYy9hcHAvcGFnZXMvcGF5L3BheS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIubWFpbl9jb250ZW50X2RpdntcbiAgICB3aWR0aDogMTAwJTtcblxuICAgIGlvbi1sYWJlbCB7XG4gICAgICAgIGRpc3BsYXk6IGJsb2NrO1xuICAgIH1cblxuICAgIC5oZWFkX2xibCB7XG4gICAgICAgIGZvbnQtd2VpZ2h0OiA1MDA7XG4gICAgICAgIGNvbG9yOiAjNTA1MDUwO1xuICAgICAgICBtYXJnaW4tYm90dG9tOiAxMHB4O1xuICAgICAgICBmb250LXNpemU6IDE0cHg7XG4gICAgfVxuXG4gICAgLnN0b3J5X2RpdntcbiAgICAgICAgcGFkZGluZzogMTZweDtcbiAgICAgICAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkIGxpZ2h0Z3JheTtcbiAgICAgICAgXG4gICAgICAgIC5jaGlwc19kaXZ7XG4gICAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICAgICAgZmxleC1kaXJlY3Rpb246IHJvdztcbiAgICAgICAgICAgIG92ZXJmbG93OiBzY3JvbGw7XG5cbiAgICAgICAgICAgIC5pbm5lcl9kaXZ7XG4gICAgICAgICAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAgICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgICAgICAgICAgICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG4gICAgICAgICAgICAgICAgbWFyZ2luLXJpZ2h0OiAxNXB4O1xuICAgICAgICAgICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAgICAgICAgICAgICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xuXG4gICAgICAgICAgICAgICAgLnN0b3J5X2ltZ3tcbiAgICAgICAgICAgICAgICAgICAgd2lkdGg6IDQwcHg7XG4gICAgICAgICAgICAgICAgICAgIGhlaWdodDogNDBweDtcbiAgICAgICAgICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogMTAwJTtcbiAgICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZDogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xuICAgICAgICAgICAgICAgICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gICAgICAgICAgICAgICAgICAgIGltZ3tcbiAgICAgICAgICAgICAgICAgICAgICAgIHdpZHRoOiAyM3B4O1xuICAgICAgICAgICAgICAgICAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgICAgICAgICAgICAgICAgICAgICAgdG9wOiA1MCU7XG4gICAgICAgICAgICAgICAgICAgICAgICBsZWZ0OiA1MCU7XG4gICAgICAgICAgICAgICAgICAgICAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZSgtNTAlLC01MCUpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAuY2hpcHtcbiAgICAgICAgICAgICAgICB3aGl0ZS1zcGFjZTogbm93cmFwO1xuICAgICAgICAgICAgICAgIGNvbG9yOiAjNTA1MDUwO1xuICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMTJweDtcbiAgICAgICAgICAgICAgICBtYXJnaW4tdG9wOiAxMHB4O1xuICAgICAgICAgICAgfSAgXG4gICAgICAgIH1cbiAgICB9XG4gICAgLnRyYXZlbF9kaXZ7XG4gICAgICAgIHBhZGRpbmc6IDE2cHg7XG4gICAgICAgIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCBsaWdodGdyYXk7XG4gICAgICAgIGlvbi1ncmlke1xuICAgICAgICAgICAgcGFkZGluZzogMDtcblxuICAgICAgICAgICAgaW9uLWNvbHtcbiAgICAgICAgICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG5cbiAgICAgICAgICAgICAgICAuaW1hZ2VfZGl2e1xuICAgICAgICAgICAgICAgICAgICB3aWR0aDogNDBweDtcbiAgICAgICAgICAgICAgICAgICAgaGVpZ2h0OiA0MHB4O1xuICAgICAgICAgICAgICAgICAgICBib3JkZXItcmFkaXVzOiAxMDAlO1xuICAgICAgICAgICAgICAgICAgICAvLyBib3gtc2hhZG93OiAwcHggM3B4IDZweCByZ2JhKDAsMCwwLDAuMyk7XG4gICAgICAgICAgICAgICAgICAgIGJveC1zaGFkb3c6IDBweCAzcHggNnB4IHJnYmEoMTcsIDExNiwgMTkyLCAwLjMpO1xuICAgICAgICAgICAgICAgICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gICAgICAgICAgICAgICAgICAgIGRpc3BsYXk6IGJsb2NrO1xuICAgICAgICAgICAgICAgICAgICBtYXJnaW46IGF1dG87XG5cbiAgICAgICAgICAgICAgICAgICAgaW1ne1xuICAgICAgICAgICAgICAgICAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgICAgICAgICAgICAgICAgICAgICAgdG9wOiA1MCU7XG4gICAgICAgICAgICAgICAgICAgICAgICBsZWZ0OiA1MCU7XG4gICAgICAgICAgICAgICAgICAgICAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZSgtNTAlLC01MCUpO1xuICAgICAgICAgICAgICAgICAgICAgICAgd2lkdGg6IDIwcHg7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAuc21hbGxfaW1ne1xuICAgICAgICAgICAgICAgICAgICB3aWR0aDogNDBweDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgaW9uLWxhYmVsIHtcbiAgICAgICAgICAgICAgICAgICAgZm9udC1zaXplOiAxMnB4O1xuICAgICAgICAgICAgICAgICAgICBtYXJnaW4tdG9wOiAxMHB4O1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cbn0iLCIubWFpbl9jb250ZW50X2RpdiB7XG4gIHdpZHRoOiAxMDAlO1xufVxuLm1haW5fY29udGVudF9kaXYgaW9uLWxhYmVsIHtcbiAgZGlzcGxheTogYmxvY2s7XG59XG4ubWFpbl9jb250ZW50X2RpdiAuaGVhZF9sYmwge1xuICBmb250LXdlaWdodDogNTAwO1xuICBjb2xvcjogIzUwNTA1MDtcbiAgbWFyZ2luLWJvdHRvbTogMTBweDtcbiAgZm9udC1zaXplOiAxNHB4O1xufVxuLm1haW5fY29udGVudF9kaXYgLnN0b3J5X2RpdiB7XG4gIHBhZGRpbmc6IDE2cHg7XG4gIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCBsaWdodGdyYXk7XG59XG4ubWFpbl9jb250ZW50X2RpdiAuc3RvcnlfZGl2IC5jaGlwc19kaXYge1xuICBkaXNwbGF5OiBmbGV4O1xuICBmbGV4LWRpcmVjdGlvbjogcm93O1xuICBvdmVyZmxvdzogc2Nyb2xsO1xufVxuLm1haW5fY29udGVudF9kaXYgLnN0b3J5X2RpdiAuY2hpcHNfZGl2IC5pbm5lcl9kaXYge1xuICBkaXNwbGF5OiBmbGV4O1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICBtYXJnaW4tcmlnaHQ6IDE1cHg7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2Vlbjtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5zdG9yeV9kaXYgLmNoaXBzX2RpdiAuaW5uZXJfZGl2IC5zdG9yeV9pbWcge1xuICB3aWR0aDogNDBweDtcbiAgaGVpZ2h0OiA0MHB4O1xuICBib3JkZXItcmFkaXVzOiAxMDAlO1xuICBiYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5zdG9yeV9kaXYgLmNoaXBzX2RpdiAuaW5uZXJfZGl2IC5zdG9yeV9pbWcgaW1nIHtcbiAgd2lkdGg6IDIzcHg7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgdG9wOiA1MCU7XG4gIGxlZnQ6IDUwJTtcbiAgdHJhbnNmb3JtOiB0cmFuc2xhdGUoLTUwJSwgLTUwJSk7XG59XG4ubWFpbl9jb250ZW50X2RpdiAuc3RvcnlfZGl2IC5jaGlwc19kaXYgLmNoaXAge1xuICB3aGl0ZS1zcGFjZTogbm93cmFwO1xuICBjb2xvcjogIzUwNTA1MDtcbiAgZm9udC1zaXplOiAxMnB4O1xuICBtYXJnaW4tdG9wOiAxMHB4O1xufVxuLm1haW5fY29udGVudF9kaXYgLnRyYXZlbF9kaXYge1xuICBwYWRkaW5nOiAxNnB4O1xuICBib3JkZXItYm90dG9tOiAxcHggc29saWQgbGlnaHRncmF5O1xufVxuLm1haW5fY29udGVudF9kaXYgLnRyYXZlbF9kaXYgaW9uLWdyaWQge1xuICBwYWRkaW5nOiAwO1xufVxuLm1haW5fY29udGVudF9kaXYgLnRyYXZlbF9kaXYgaW9uLWdyaWQgaW9uLWNvbCB7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC50cmF2ZWxfZGl2IGlvbi1ncmlkIGlvbi1jb2wgLmltYWdlX2RpdiB7XG4gIHdpZHRoOiA0MHB4O1xuICBoZWlnaHQ6IDQwcHg7XG4gIGJvcmRlci1yYWRpdXM6IDEwMCU7XG4gIGJveC1zaGFkb3c6IDBweCAzcHggNnB4IHJnYmEoMTcsIDExNiwgMTkyLCAwLjMpO1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIGRpc3BsYXk6IGJsb2NrO1xuICBtYXJnaW46IGF1dG87XG59XG4ubWFpbl9jb250ZW50X2RpdiAudHJhdmVsX2RpdiBpb24tZ3JpZCBpb24tY29sIC5pbWFnZV9kaXYgaW1nIHtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICB0b3A6IDUwJTtcbiAgbGVmdDogNTAlO1xuICB0cmFuc2Zvcm06IHRyYW5zbGF0ZSgtNTAlLCAtNTAlKTtcbiAgd2lkdGg6IDIwcHg7XG59XG4ubWFpbl9jb250ZW50X2RpdiAudHJhdmVsX2RpdiBpb24tZ3JpZCBpb24tY29sIC5zbWFsbF9pbWcge1xuICB3aWR0aDogNDBweDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC50cmF2ZWxfZGl2IGlvbi1ncmlkIGlvbi1jb2wgaW9uLWxhYmVsIHtcbiAgZm9udC1zaXplOiAxMnB4O1xuICBtYXJnaW4tdG9wOiAxMHB4O1xufSJdfQ== */";
    /***/
  },

  /***/
  "./src/app/pages/pay/pay.page.ts":
  /*!***************************************!*\
    !*** ./src/app/pages/pay/pay.page.ts ***!
    \***************************************/

  /*! exports provided: PayPage */

  /***/
  function srcAppPagesPayPayPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "PayPage", function () {
      return PayPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var src_app_services_pay_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! src/app/services/pay.service */
    "./src/app/services/pay.service.ts");

    var PayPage = /*#__PURE__*/function () {
      function PayPage(router, pay) {
        _classCallCheck(this, PayPage);

        this.router = router;
        this.pay = pay;
        this.travel = this.pay.travel;
        this.stories = this.pay.chip;
      }

      _createClass(PayPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {// this.router.navigate(['/login']);
        }
      }]);

      return PayPage;
    }();

    PayPage.ctorParameters = function () {
      return [{
        type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]
      }, {
        type: src_app_services_pay_service__WEBPACK_IMPORTED_MODULE_3__["PayService"]
      }];
    };

    PayPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-pay',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./pay.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/pay/pay.page.html"))["default"],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./pay.page.scss */
      "./src/app/pages/pay/pay.page.scss"))["default"]]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"], src_app_services_pay_service__WEBPACK_IMPORTED_MODULE_3__["PayService"]])], PayPage);
    /***/
  },

  /***/
  "./src/app/services/pay.service.ts":
  /*!*****************************************!*\
    !*** ./src/app/services/pay.service.ts ***!
    \*****************************************/

  /*! exports provided: PayService */

  /***/
  function srcAppServicesPayServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "PayService", function () {
      return PayService;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");

    var PayService = function PayService() {
      _classCallCheck(this, PayService);

      this.travel = [{
        img: 'assets/imgs/pay/flight.png',
        name: 'Flight'
      }, {
        img: 'assets/imgs/pay/train.png',
        name: 'Train'
      }, {
        img: 'assets/imgs/pay/mobile.png',
        name: 'Recharge'
      }, {
        img: 'assets/imgs/pay/doc.png',
        name: 'Postpaid'
      }, {
        img: 'assets/imgs/pay/dth.png',
        name: 'DTH'
      }, {
        img: 'assets/imgs/pay/bulb.png',
        name: 'Electricity'
      }, {
        img: 'assets/imgs/pay/phone.png',
        name: 'Landline'
      }, {
        img: 'assets/imgs/pay/gas.png',
        name: 'Gas'
      }, {
        img: 'assets/imgs/pay/router.png',
        name: 'Broadband'
      }, {
        img: 'assets/imgs/pay/data.png',
        name: 'Data Card'
      }, {
        img: 'assets/imgs/pay/umbrella.png',
        name: 'Insurance'
      }, {
        img: 'assets/imgs/pay/water.png',
        name: 'Water'
      }];
      this.chip = [{
        img: 'assets/imgs/pay/send.png',
        name: 'Send Money'
      }, {
        img: 'assets/imgs/pay/receive.png',
        name: 'Receive Money'
      }, {
        img: 'assets/imgs/pay/bank.png',
        name: 'Bank Transfer'
      }, {
        img: 'assets/imgs/pay/qr.png',
        name: 'ScanQR Code'
      }, {
        img: 'assets/imgs/pay/user.png',
        name: 'To Self'
      }, {
        img: 'assets/imgs/pay/balance.png',
        name: 'check Balance'
      }, {
        img: 'assets/imgs/pay/book.png',
        name: 'Account Passbook'
      }, {
        img: 'assets/imgs/pay/set.png',
        name: 'Account Setting'
      }];
    };

    PayService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
      providedIn: 'root'
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])], PayService);
    /***/
  }
}]);
//# sourceMappingURL=pay-pay-module-es5.js.map