(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["social-social-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/social/social.page.html":
/*!*************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/social/social.page.html ***!
  \*************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar *ngIf=\"currentCat != 'Social'\">\n    <ion-buttons slot=\"start\">\n      <ion-menu-button color=\"dark\"></ion-menu-button>\n    </ion-buttons>\n    <ion-title>Social</ion-title>\n\n    <ion-button slot=\"end\" size=\"small\" fill=\"clear\">\n      <ion-icon name=\"search-outline\"></ion-icon>\n    </ion-button>\n\n    <ion-button (click)=\"goToNotification()\" slot=\"end\" size=\"small\" fill=\"clear\">\n      <ion-icon name=\"notifications-outline\"></ion-icon>\n    </ion-button>\n\n  </ion-toolbar>\n\n  <div class=\"header_div\" *ngIf=\"currentCat == 'Social'\" [class.ios_pad]=\"plt == 'ios'\">\n\n    <ion-buttons slot=\"start\">\n      <ion-menu-button></ion-menu-button>\n    </ion-buttons>\n    <img src=\"assets/imgs/logo.png\" alt=\"\">\n\n    <div class=\"btn_div\">\n\n      <ion-button size=\"small\" fill=\"clear\">\n        <ion-icon name=\"arrow-redo-outline\"></ion-icon>\n      </ion-button>\n\n      <ion-button size=\"small\" fill=\"clear\">\n        <ion-icon name=\"notifications-outline\"></ion-icon>\n      </ion-button>\n\n    </div>\n\n  </div>\n</ion-header>\n\n<ion-content>\n\n  <img src=\"assets/imgs/signs.png\" class=\"add_icon\" (click)=\"goToNewPost()\">\n  <div class=\"main_content_div\">\n\n    <div class=\"search_div\" *ngIf=\"currentCat == 'Social'\">\n      <ion-input type=\"text\" placeholder=\"Search\">\n        <ion-icon name=\"search-outline\"></ion-icon>\n      </ion-input>\n    </div>\n\n    <div class=\"search_div\" *ngIf=\"currentCat == 'Social'\">\n      <div class=\"chips_div\">\n        <div class=\"test\" [class.active]=\"currentCat == i\" *ngFor=\"let item of moviesCat; let i = index\">\n          <ion-label class=\"chip\" (click)=\"selectCat(item)\">{{item}}</ion-label>\n          <span class=\"line_span\" *ngIf=\"currentCat == item\"></span>\n        </div>\n      </div>\n    </div>\n\n    <div class=\"story_div\" *ngIf=\"currentCat != 'Social'\">\n      <div class=\"chips_div\">\n\n        <div class=\"inner_div\">\n          <div class=\"story_img_main\">\n            <div class=\"fill_div\">\n              <img src=\"assets/imgs/mystory.png\" alt=\"\">\n            </div>\n          </div>\n          <ion-label class=\"chip\">For You</ion-label>\n        </div>\n\n        <div class=\"inner_div\" *ngFor=\"let item of stories\">\n          <div class=\"story_img bg_image\" [style.backgroundImage]=\"'url('+ item.img +')'\"></div>\n          <ion-label class=\"chip\">{{item.name | slice : 0: 10}}</ion-label>\n        </div>\n      </div>\n    </div>\n\n    <div class=\"lang_div\" *ngIf=\"currentCat == 'Social'\">\n      <div class=\"chips_div\">\n        <div class=\"test\" [class.active]=\"vCat == i\" *ngFor=\"let item of videoCat; let i = index\">\n          <ion-label class=\"chip\" (click)=\"selectVideoCat(i)\">{{item}}</ion-label>\n        </div>\n      </div>\n    </div>\n\n    <div class=\"lang_div\" *ngIf=\"currentCat != 'Social'\">\n      <div class=\"chips_div\">\n        <div class=\"test\" [class.active]=\"currentLang == i\" *ngFor=\"let item of lang; let i = index\">\n          <ion-label class=\"chip\" (click)=\"selectLang(i)\">{{item}}</ion-label>\n        </div>\n      </div>\n    </div>\n\n    <div class=\"lower_div\">\n\n      <div class=\"news_card\" *ngFor=\"let item of allNews\">\n\n        <div class=\"chip_div\">\n          <div class=\"chip\">\n            <div class=\"round\"></div>\n            <ion-label>New News</ion-label>\n          </div>\n        </div>\n\n        <div class=\"back_image bg_image\" *ngIf=\"item.img\" [style.backgroundImage]=\"'url('+ item.img+')'\"></div>\n\n        <video playsinline webkit-playsinline autoplay *ngIf=\"!item.img\">\n          <source src=\"assets/imgs/video.mp4\" type=\"video/mp4\">\n        </video>\n\n        <div class=\"channel_detail\">\n          <img src=\"{{item.logo}}\">\n          <ion-label class=\"channel_name\">The Times of India</ion-label> •\n          <ion-label class=\"follow_lbl\">Follow</ion-label>\n        </div>\n\n        <ion-label class=\"head_line\">{{item.headline}}</ion-label>\n\n        <ion-label class=\"detail\">{{item.detail}}</ion-label>\n\n        <ion-label class=\"link_lbl\">https://initappz.com/</ion-label>\n\n        <div class=\"like_div\">\n          <img src=\"assets/imgs/like.png\">\n          <ion-label>12</ion-label>\n          <ion-label class=\"share_lbl\">2 Share</ion-label>\n          <ion-label class=\"share_lbl\">222 Views</ion-label>\n        </div>\n\n        <div class=\"share_div\">\n          <div class=\"left_div\">\n            <div class=\"round_div\">\n              <ion-icon name=\"thumbs-up-outline\"></ion-icon>\n            </div>\n            <div class=\"round_div\">\n              <ion-icon name=\"chatbubble-outline\"></ion-icon>\n            </div>\n            <div class=\"round_div\" (click)=\"shareActionSheet()\">\n              <ion-icon name=\"arrow-redo-outline\"></ion-icon>\n            </div>\n          </div>\n          <div class=\"right_div\">\n            <div class=\"round_div\" style=\"margin-right: 0px;\">\n              <ion-icon name=\"bookmark-outline\"></ion-icon>\n            </div>\n            <ion-button (click)=\"presentActionSheet()\" fill=\"clear\" size=\"small\">\n              <ion-icon name=\"ellipsis-vertical\"></ion-icon>\n            </ion-button>\n          </div>\n        </div>\n\n        <ion-label class=\"link_lbl\">10 minutes</ion-label>\n\n      </div>\n\n    </div>\n\n  </div>\n</ion-content>");

/***/ }),

/***/ "./src/app/pages/social/social-routing.module.ts":
/*!*******************************************************!*\
  !*** ./src/app/pages/social/social-routing.module.ts ***!
  \*******************************************************/
/*! exports provided: SocialPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SocialPageRoutingModule", function() { return SocialPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _social_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./social.page */ "./src/app/pages/social/social.page.ts");




const routes = [
    {
        path: '',
        component: _social_page__WEBPACK_IMPORTED_MODULE_3__["SocialPage"]
    }
];
let SocialPageRoutingModule = class SocialPageRoutingModule {
};
SocialPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], SocialPageRoutingModule);



/***/ }),

/***/ "./src/app/pages/social/social.module.ts":
/*!***********************************************!*\
  !*** ./src/app/pages/social/social.module.ts ***!
  \***********************************************/
/*! exports provided: SocialPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SocialPageModule", function() { return SocialPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _social_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./social-routing.module */ "./src/app/pages/social/social-routing.module.ts");
/* harmony import */ var _social_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./social.page */ "./src/app/pages/social/social.page.ts");







let SocialPageModule = class SocialPageModule {
};
SocialPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _social_routing_module__WEBPACK_IMPORTED_MODULE_5__["SocialPageRoutingModule"]
        ],
        declarations: [_social_page__WEBPACK_IMPORTED_MODULE_6__["SocialPage"]]
    })
], SocialPageModule);



/***/ }),

/***/ "./src/app/pages/social/social.page.scss":
/*!***********************************************!*\
  !*** ./src/app/pages/social/social.page.scss ***!
  \***********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-header ion-button {\n  margin: 0;\n}\nion-header ion-button ion-icon {\n  color: black;\n  font-size: 20px;\n}\n.header_div {\n  width: 100%;\n  display: flex;\n  justify-content: space-between;\n  position: relative;\n  padding: 5px;\n}\n.header_div img {\n  width: 100px;\n  position: absolute;\n  left: 50%;\n  transform: translate(-50%);\n}\n.header_div .btn_div {\n  display: flex;\n}\n.header_div ion-button {\n  color: black;\n}\n.add_icon {\n  width: 50px;\n  position: fixed;\n  z-index: 999;\n  bottom: 90px;\n  right: 20px;\n  box-shadow: 0px 3px 6px rgba(0, 0, 0, 0.3);\n  border-radius: 100%;\n}\n.main_content_div .search_div {\n  padding: 10px 16px;\n  border-bottom: 1px solid lightgray;\n}\n.main_content_div .search_div ion-input {\n  border: 1px solid black;\n  border-radius: 25px;\n}\n.main_content_div .search_div ion-input ion-icon {\n  font-size: 20px;\n  padding-left: 10px;\n  padding-right: 5px;\n}\n.main_content_div .search_div .test {\n  display: flex;\n  align-items: center;\n  margin-right: 10px;\n  border-radius: 25px;\n  padding: 5px 15px;\n  flex-direction: column;\n}\n.main_content_div .search_div .test ion-icon {\n  font-size: 26px;\n  color: var(--ion-color-primary);\n}\n.main_content_div .search_div .active ion-label {\n  color: var(--ion-color-primary) !important;\n}\n.main_content_div .search_div .chips_div {\n  display: flex;\n  flex-direction: row;\n  overflow: scroll;\n}\n.main_content_div .search_div .chips_div .chip {\n  white-space: nowrap;\n  color: black;\n  font-size: 13px;\n  font-weight: 500;\n}\n.main_content_div .search_div .chips_div .line_span {\n  margin-top: 7px;\n  width: 20px;\n  height: 2px;\n  background: var(--ion-color-primary);\n}\n.main_content_div .story_div {\n  padding: 16px;\n  border-bottom: 1px solid lightgray;\n}\n.main_content_div .story_div .chips_div {\n  display: flex;\n  flex-direction: row;\n  overflow: scroll;\n}\n.main_content_div .story_div .chips_div .inner_div {\n  display: flex;\n  align-items: center;\n  flex-direction: column;\n  margin-right: 15px;\n  align-items: center;\n  justify-content: space-between;\n}\n.main_content_div .story_div .chips_div .inner_div .story_img_main {\n  width: 60px;\n  height: 60px;\n  border-radius: 100%;\n  border: 2px solid red;\n  position: relative;\n}\n.main_content_div .story_div .chips_div .inner_div .story_img_main .fill_div {\n  width: 50px;\n  height: 50px;\n  border-radius: 100%;\n  background: #3b2a52;\n  position: absolute;\n  top: 50%;\n  left: 50%;\n  transform: translate(-50%, -50%);\n}\n.main_content_div .story_div .chips_div .inner_div .story_img_main .fill_div img {\n  width: 25px;\n  position: absolute;\n  top: 50%;\n  left: 50%;\n  transform: translate(-50%, -50%);\n}\n.main_content_div .story_div .chips_div .inner_div .story_img {\n  width: 60px;\n  height: 60px;\n  border-radius: 100%;\n}\n.main_content_div .story_div .chips_div .chip {\n  white-space: nowrap;\n  color: #505050;\n  font-size: 12px;\n  margin-top: 10px;\n}\n.main_content_div .lang_div {\n  padding: 10px 16px;\n  border-bottom: 1px solid lightgray;\n}\n.main_content_div .lang_div .test {\n  display: flex;\n  align-items: center;\n  margin-right: 10px;\n  border: 1px solid lightgray;\n  background: whitesmoke;\n  border-radius: 25px;\n  padding: 5px 15px;\n}\n.main_content_div .lang_div .active {\n  border: 1px solid var(--ion-color-primary);\n  background: rgba(17, 116, 192, 0.2);\n}\n.main_content_div .lang_div .active ion-label {\n  color: var(--ion-color-primary) !important;\n}\n.main_content_div .lang_div .chips_div {\n  display: flex;\n  flex-direction: row;\n  overflow: scroll;\n}\n.main_content_div .lang_div .chips_div .chip {\n  white-space: nowrap;\n  color: black;\n  font-size: 13px;\n}\n.main_content_div .lower_div .news_card {\n  padding: 16px;\n  border-bottom: 1px solid lightgray;\n}\n.main_content_div .lower_div .news_card .chip_div {\n  text-align: center;\n  margin-bottom: 15px;\n}\n.main_content_div .lower_div .news_card .chip_div .round {\n  width: 15px;\n  height: 15px;\n  background: white;\n  border-radius: 100%;\n  border: 4px solid var(--ion-color-primary);\n}\n.main_content_div .lower_div .news_card .chip_div .chip {\n  border-radius: 25px;\n  border: 1px solid lightgray;\n  width: -webkit-fit-content;\n  width: -moz-fit-content;\n  width: fit-content;\n  padding: 10px;\n  display: flex;\n  align-items: center;\n  margin: auto;\n}\n.main_content_div .lower_div .news_card .chip_div .chip ion-label {\n  font-size: 14px;\n  margin-left: 10px;\n}\n.main_content_div .lower_div .news_card .back_image {\n  width: 100%;\n  height: 180px;\n  border-radius: 10px;\n}\n.main_content_div .lower_div .news_card video {\n  width: 100%;\n  border-radius: 10px;\n}\n.main_content_div .lower_div .news_card .channel_detail {\n  display: flex;\n  margin-top: 15px;\n  align-items: center;\n  margin-bottom: 10px;\n}\n.main_content_div .lower_div .news_card .channel_detail img {\n  width: 25px;\n}\n.main_content_div .lower_div .news_card .channel_detail .channel_name {\n  font-weight: 600;\n  font-size: 15px;\n  margin-left: 10px;\n  margin-right: 10px;\n}\n.main_content_div .lower_div .news_card .channel_detail .follow_lbl {\n  color: var(--ion-color-primary);\n  font-size: 13px;\n  margin-left: 10px;\n}\n.main_content_div .lower_div .news_card .head_line {\n  font-weight: 500;\n}\n.main_content_div .lower_div .news_card .detail {\n  margin-top: 10px;\n  color: gray;\n  font-size: 15px;\n}\n.main_content_div .lower_div .news_card .link_lbl {\n  margin-top: 10px;\n  font-size: 13px;\n  color: gray;\n}\n.main_content_div .lower_div .news_card .like_div {\n  display: flex;\n  font-size: 13px;\n  color: #505050;\n  margin-top: 10px;\n  margin-bottom: 10px;\n}\n.main_content_div .lower_div .news_card .like_div img {\n  width: 20px;\n  height: 20px;\n  margin-right: 10px;\n}\n.main_content_div .lower_div .news_card .like_div .share_lbl {\n  margin-left: 15px;\n}\n.main_content_div .lower_div .news_card .share_div {\n  display: flex;\n  width: 100%;\n  justify-content: space-between;\n}\n.main_content_div .lower_div .news_card .share_div .left_div {\n  display: flex;\n}\n.main_content_div .lower_div .news_card .share_div .right_div {\n  display: flex;\n  align-items: center;\n}\n.main_content_div .lower_div .news_card .share_div .right_div ion-button {\n  margin: 0;\n}\n.main_content_div .lower_div .news_card .share_div .right_div ion-button ion-icon {\n  color: #505050;\n}\n.main_content_div .lower_div .news_card .share_div .round_div {\n  border: 1px solid lightgray;\n  height: 40px;\n  width: 40px;\n  border-radius: 100%;\n  position: relative;\n  margin-right: 10px;\n}\n.main_content_div .lower_div .news_card .share_div .round_div ion-icon {\n  position: absolute;\n  top: 50%;\n  left: 50%;\n  transform: translate(-50%, -50%);\n  font-size: 18px;\n  color: #505050;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvc29jaWFsL0U6XFxJb25pYyBQcm9qZWN0c1xcaW9uaWMtNS10ZW1wbGF0ZS1idW5kbGUtaW9uaWMtNS10aGVtZXMtYnVuZGxlcy1pb25pYy01LXRlbXBsYXRlcy13aXRoLTEwLWFwcHNcXEFwcF9zb3VyY2VfY29kZVxcQXBwc19jb2RlXFxNdWx0aV9wdXJwb3NlL3NyY1xcYXBwXFxwYWdlc1xcc29jaWFsXFxzb2NpYWwucGFnZS5zY3NzIiwic3JjL2FwcC9wYWdlcy9zb2NpYWwvc29jaWFsLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDSTtFQUNJLFNBQUE7QUNBUjtBREVRO0VBQ0ksWUFBQTtFQUNBLGVBQUE7QUNBWjtBREtBO0VBQ0ksV0FBQTtFQUNBLGFBQUE7RUFDQSw4QkFBQTtFQUNBLGtCQUFBO0VBQ0EsWUFBQTtBQ0ZKO0FER0k7RUFDSSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSxTQUFBO0VBQ0EsMEJBQUE7QUNEUjtBREdJO0VBQ0ksYUFBQTtBQ0RSO0FER0k7RUFDSSxZQUFBO0FDRFI7QURLQTtFQUNJLFdBQUE7RUFDQSxlQUFBO0VBQ0EsWUFBQTtFQUNBLFlBQUE7RUFDQSxXQUFBO0VBQ0EsMENBQUE7RUFDQSxtQkFBQTtBQ0ZKO0FETUk7RUFDSSxrQkFBQTtFQUNBLGtDQUFBO0FDSFI7QURLUTtFQUNJLHVCQUFBO0VBQ0EsbUJBQUE7QUNIWjtBRElZO0VBQ0ksZUFBQTtFQUNBLGtCQUFBO0VBQ0Esa0JBQUE7QUNGaEI7QURNUTtFQUNJLGFBQUE7RUFDQSxtQkFBQTtFQUNBLGtCQUFBO0VBQ0EsbUJBQUE7RUFDQSxpQkFBQTtFQUNBLHNCQUFBO0FDSlo7QURNWTtFQUNJLGVBQUE7RUFDQSwrQkFBQTtBQ0poQjtBRFNZO0VBQ0ksMENBQUE7QUNQaEI7QURXUTtFQUNJLGFBQUE7RUFDQSxtQkFBQTtFQUNBLGdCQUFBO0FDVFo7QURVWTtFQUNJLG1CQUFBO0VBQ0EsWUFBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtBQ1JoQjtBRFdZO0VBQ0ksZUFBQTtFQUNBLFdBQUE7RUFDQSxXQUFBO0VBQ0Esb0NBQUE7QUNUaEI7QURhSTtFQUNJLGFBQUE7RUFDQSxrQ0FBQTtBQ1hSO0FEYVE7RUFDSSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSxnQkFBQTtBQ1haO0FEYVk7RUFDSSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSxzQkFBQTtFQUNBLGtCQUFBO0VBQ0EsbUJBQUE7RUFDQSw4QkFBQTtBQ1hoQjtBRFlnQjtFQUNJLFdBQUE7RUFDQSxZQUFBO0VBQ0EsbUJBQUE7RUFDQSxxQkFBQTtFQUNBLGtCQUFBO0FDVnBCO0FEWW9CO0VBQ0ksV0FBQTtFQUNBLFlBQUE7RUFDQSxtQkFBQTtFQUNBLG1CQUFBO0VBQ0Esa0JBQUE7RUFDQSxRQUFBO0VBQ0EsU0FBQTtFQUNBLGdDQUFBO0FDVnhCO0FEWXdCO0VBQ0ksV0FBQTtFQUNBLGtCQUFBO0VBQ0EsUUFBQTtFQUNBLFNBQUE7RUFDQSxnQ0FBQTtBQ1Y1QjtBRGNnQjtFQUNJLFdBQUE7RUFDQSxZQUFBO0VBQ0EsbUJBQUE7QUNacEI7QURnQlk7RUFDSSxtQkFBQTtFQUNBLGNBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7QUNkaEI7QURtQkk7RUFDSSxrQkFBQTtFQUNBLGtDQUFBO0FDakJSO0FEbUJRO0VBQ0ksYUFBQTtFQUNBLG1CQUFBO0VBQ0Esa0JBQUE7RUFDQSwyQkFBQTtFQUNBLHNCQUFBO0VBQ0EsbUJBQUE7RUFDQSxpQkFBQTtBQ2pCWjtBRG9CUTtFQUNJLDBDQUFBO0VBQ0EsbUNBQUE7QUNsQlo7QURvQlk7RUFDSSwwQ0FBQTtBQ2xCaEI7QURzQlE7RUFDSSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSxnQkFBQTtBQ3BCWjtBRHFCWTtFQUNJLG1CQUFBO0VBQ0EsWUFBQTtFQUNBLGVBQUE7QUNuQmhCO0FEeUJRO0VBQ0ksYUFBQTtFQUNBLGtDQUFBO0FDdkJaO0FEeUJZO0VBQ0ksa0JBQUE7RUFDQSxtQkFBQTtBQ3ZCaEI7QUR5QmdCO0VBQ0ksV0FBQTtFQUNBLFlBQUE7RUFDQSxpQkFBQTtFQUNBLG1CQUFBO0VBQ0EsMENBQUE7QUN2QnBCO0FEeUJnQjtFQUNJLG1CQUFBO0VBQ0EsMkJBQUE7RUFDQSwwQkFBQTtFQUFBLHVCQUFBO0VBQUEsa0JBQUE7RUFDQSxhQUFBO0VBQ0EsYUFBQTtFQUNBLG1CQUFBO0VBQ0EsWUFBQTtBQ3ZCcEI7QUR5Qm9CO0VBQ0ksZUFBQTtFQUNBLGlCQUFBO0FDdkJ4QjtBRDJCWTtFQUNJLFdBQUE7RUFDQSxhQUFBO0VBQ0EsbUJBQUE7QUN6QmhCO0FENEJZO0VBQ0ksV0FBQTtFQUNBLG1CQUFBO0FDMUJoQjtBRDZCWTtFQUNJLGFBQUE7RUFDQSxnQkFBQTtFQUNBLG1CQUFBO0VBQ0EsbUJBQUE7QUMzQmhCO0FENEJnQjtFQUNJLFdBQUE7QUMxQnBCO0FENEJnQjtFQUNJLGdCQUFBO0VBQ0EsZUFBQTtFQUNBLGlCQUFBO0VBQ0Esa0JBQUE7QUMxQnBCO0FENEJnQjtFQUNJLCtCQUFBO0VBQ0EsZUFBQTtFQUNBLGlCQUFBO0FDMUJwQjtBRDhCWTtFQUNJLGdCQUFBO0FDNUJoQjtBRDhCWTtFQUNJLGdCQUFBO0VBQ0EsV0FBQTtFQUNBLGVBQUE7QUM1QmhCO0FEb0NZO0VBQ0ksZ0JBQUE7RUFDQSxlQUFBO0VBQ0EsV0FBQTtBQ2xDaEI7QURxQ1k7RUFDSSxhQUFBO0VBQ0EsZUFBQTtFQUNBLGNBQUE7RUFDQSxnQkFBQTtFQUNBLG1CQUFBO0FDbkNoQjtBRG9DZ0I7RUFDSSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0FDbENwQjtBRG9DZ0I7RUFDSSxpQkFBQTtBQ2xDcEI7QURzQ1k7RUFDSSxhQUFBO0VBQ0EsV0FBQTtFQUNBLDhCQUFBO0FDcENoQjtBRHNDZ0I7RUFDSSxhQUFBO0FDcENwQjtBRHVDZ0I7RUFDSSxhQUFBO0VBQ0EsbUJBQUE7QUNyQ3BCO0FEc0NvQjtFQUNJLFNBQUE7QUNwQ3hCO0FEc0N3QjtFQUNJLGNBQUE7QUNwQzVCO0FEeUNnQjtFQUNJLDJCQUFBO0VBQ0EsWUFBQTtFQUNBLFdBQUE7RUFDQSxtQkFBQTtFQUNBLGtCQUFBO0VBQ0Esa0JBQUE7QUN2Q3BCO0FEd0NvQjtFQUNJLGtCQUFBO0VBQ0EsUUFBQTtFQUNBLFNBQUE7RUFDQSxnQ0FBQTtFQUNBLGVBQUE7RUFDQSxjQUFBO0FDdEN4QiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL3NvY2lhbC9zb2NpYWwucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWhlYWRlciB7XG4gICAgaW9uLWJ1dHRvbiB7XG4gICAgICAgIG1hcmdpbjogMDtcblxuICAgICAgICBpb24taWNvbiB7XG4gICAgICAgICAgICBjb2xvcjogYmxhY2s7XG4gICAgICAgICAgICBmb250LXNpemU6IDIwcHg7XG4gICAgICAgIH1cbiAgICB9XG59XG5cbi5oZWFkZXJfZGl2IHtcbiAgICB3aWR0aDogMTAwJTtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gICAgcGFkZGluZzogNXB4O1xuICAgIGltZyB7XG4gICAgICAgIHdpZHRoOiAxMDBweDtcbiAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgICAgICBsZWZ0OiA1MCU7XG4gICAgICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlKC01MCUpO1xuICAgIH1cbiAgICAuYnRuX2RpdiB7XG4gICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgfVxuICAgIGlvbi1idXR0b24ge1xuICAgICAgICBjb2xvcjogYmxhY2s7XG4gICAgfVxufVxuXG4uYWRkX2ljb24ge1xuICAgIHdpZHRoOiA1MHB4O1xuICAgIHBvc2l0aW9uOiBmaXhlZDtcbiAgICB6LWluZGV4OiA5OTk7XG4gICAgYm90dG9tOiA5MHB4O1xuICAgIHJpZ2h0OiAyMHB4O1xuICAgIGJveC1zaGFkb3c6IDBweCAzcHggNnB4IHJnYmEoMCwgMCwgMCwgMC4zKTtcbiAgICBib3JkZXItcmFkaXVzOiAxMDAlO1xufVxuXG4ubWFpbl9jb250ZW50X2RpdiB7XG4gICAgLnNlYXJjaF9kaXYge1xuICAgICAgICBwYWRkaW5nOiAxMHB4IDE2cHg7XG4gICAgICAgIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCBsaWdodGdyYXk7XG5cbiAgICAgICAgaW9uLWlucHV0IHtcbiAgICAgICAgICAgIGJvcmRlcjogMXB4IHNvbGlkIGJsYWNrO1xuICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogMjVweDtcbiAgICAgICAgICAgIGlvbi1pY29uIHtcbiAgICAgICAgICAgICAgICBmb250LXNpemU6IDIwcHg7XG4gICAgICAgICAgICAgICAgcGFkZGluZy1sZWZ0OiAxMHB4O1xuICAgICAgICAgICAgICAgIHBhZGRpbmctcmlnaHQ6IDVweDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIC50ZXN0IHtcbiAgICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgICAgICAgICAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xuICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogMjVweDtcbiAgICAgICAgICAgIHBhZGRpbmc6IDVweCAxNXB4O1xuICAgICAgICAgICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcblxuICAgICAgICAgICAgaW9uLWljb24ge1xuICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMjZweDtcbiAgICAgICAgICAgICAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgLmFjdGl2ZSB7XG4gICAgICAgICAgICBpb24tbGFiZWwge1xuICAgICAgICAgICAgICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSkgIWltcG9ydGFudDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIC5jaGlwc19kaXYge1xuICAgICAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAgICAgIGZsZXgtZGlyZWN0aW9uOiByb3c7XG4gICAgICAgICAgICBvdmVyZmxvdzogc2Nyb2xsO1xuICAgICAgICAgICAgLmNoaXAge1xuICAgICAgICAgICAgICAgIHdoaXRlLXNwYWNlOiBub3dyYXA7XG4gICAgICAgICAgICAgICAgY29sb3I6IGJsYWNrO1xuICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMTNweDtcbiAgICAgICAgICAgICAgICBmb250LXdlaWdodDogNTAwO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAubGluZV9zcGFuIHtcbiAgICAgICAgICAgICAgICBtYXJnaW4tdG9wOiA3cHg7XG4gICAgICAgICAgICAgICAgd2lkdGg6IDIwcHg7XG4gICAgICAgICAgICAgICAgaGVpZ2h0OiAycHg7XG4gICAgICAgICAgICAgICAgYmFja2dyb3VuZDogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuICAgIC5zdG9yeV9kaXYge1xuICAgICAgICBwYWRkaW5nOiAxNnB4O1xuICAgICAgICBib3JkZXItYm90dG9tOiAxcHggc29saWQgbGlnaHRncmF5O1xuXG4gICAgICAgIC5jaGlwc19kaXYge1xuICAgICAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAgICAgIGZsZXgtZGlyZWN0aW9uOiByb3c7XG4gICAgICAgICAgICBvdmVyZmxvdzogc2Nyb2xsO1xuXG4gICAgICAgICAgICAuaW5uZXJfZGl2IHtcbiAgICAgICAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICAgICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAgICAgICAgICAgICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbiAgICAgICAgICAgICAgICBtYXJnaW4tcmlnaHQ6IDE1cHg7XG4gICAgICAgICAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICAgICAgICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XG4gICAgICAgICAgICAgICAgLnN0b3J5X2ltZ19tYWluIHtcbiAgICAgICAgICAgICAgICAgICAgd2lkdGg6IDYwcHg7XG4gICAgICAgICAgICAgICAgICAgIGhlaWdodDogNjBweDtcbiAgICAgICAgICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogMTAwJTtcbiAgICAgICAgICAgICAgICAgICAgYm9yZGVyOiAycHggc29saWQgcmVkO1xuICAgICAgICAgICAgICAgICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XG5cbiAgICAgICAgICAgICAgICAgICAgLmZpbGxfZGl2IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHdpZHRoOiA1MHB4O1xuICAgICAgICAgICAgICAgICAgICAgICAgaGVpZ2h0OiA1MHB4O1xuICAgICAgICAgICAgICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogMTAwJTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGJhY2tncm91bmQ6ICMzYjJhNTI7XG4gICAgICAgICAgICAgICAgICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgICAgICAgICAgICAgICAgICAgICB0b3A6IDUwJTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGxlZnQ6IDUwJTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlKC01MCUsIC01MCUpO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICBpbWcge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHdpZHRoOiAyNXB4O1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0b3A6IDUwJTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZWZ0OiA1MCU7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUoLTUwJSwgLTUwJSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgLnN0b3J5X2ltZyB7XG4gICAgICAgICAgICAgICAgICAgIHdpZHRoOiA2MHB4O1xuICAgICAgICAgICAgICAgICAgICBoZWlnaHQ6IDYwcHg7XG4gICAgICAgICAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDEwMCU7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAuY2hpcCB7XG4gICAgICAgICAgICAgICAgd2hpdGUtc3BhY2U6IG5vd3JhcDtcbiAgICAgICAgICAgICAgICBjb2xvcjogIzUwNTA1MDtcbiAgICAgICAgICAgICAgICBmb250LXNpemU6IDEycHg7XG4gICAgICAgICAgICAgICAgbWFyZ2luLXRvcDogMTBweDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cblxuICAgIC5sYW5nX2RpdiB7XG4gICAgICAgIHBhZGRpbmc6IDEwcHggMTZweDtcbiAgICAgICAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkIGxpZ2h0Z3JheTtcblxuICAgICAgICAudGVzdCB7XG4gICAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICAgICAgICAgIG1hcmdpbi1yaWdodDogMTBweDtcbiAgICAgICAgICAgIGJvcmRlcjogMXB4IHNvbGlkIGxpZ2h0Z3JheTtcbiAgICAgICAgICAgIGJhY2tncm91bmQ6IHdoaXRlc21va2U7XG4gICAgICAgICAgICBib3JkZXItcmFkaXVzOiAyNXB4O1xuICAgICAgICAgICAgcGFkZGluZzogNXB4IDE1cHg7XG4gICAgICAgIH1cblxuICAgICAgICAuYWN0aXZlIHtcbiAgICAgICAgICAgIGJvcmRlcjogMXB4IHNvbGlkIHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcbiAgICAgICAgICAgIGJhY2tncm91bmQ6IHJnYmEoMTcsIDExNiwgMTkyLCAwLjIpO1xuXG4gICAgICAgICAgICBpb24tbGFiZWwge1xuICAgICAgICAgICAgICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSkgIWltcG9ydGFudDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIC5jaGlwc19kaXYge1xuICAgICAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAgICAgIGZsZXgtZGlyZWN0aW9uOiByb3c7XG4gICAgICAgICAgICBvdmVyZmxvdzogc2Nyb2xsO1xuICAgICAgICAgICAgLmNoaXAge1xuICAgICAgICAgICAgICAgIHdoaXRlLXNwYWNlOiBub3dyYXA7XG4gICAgICAgICAgICAgICAgY29sb3I6IGJsYWNrO1xuICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMTNweDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cblxuICAgIC5sb3dlcl9kaXYge1xuICAgICAgICAubmV3c19jYXJkIHtcbiAgICAgICAgICAgIHBhZGRpbmc6IDE2cHg7XG4gICAgICAgICAgICBib3JkZXItYm90dG9tOiAxcHggc29saWQgbGlnaHRncmF5O1xuXG4gICAgICAgICAgICAuY2hpcF9kaXYge1xuICAgICAgICAgICAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICAgICAgICAgICAgICBtYXJnaW4tYm90dG9tOiAxNXB4O1xuXG4gICAgICAgICAgICAgICAgLnJvdW5kIHtcbiAgICAgICAgICAgICAgICAgICAgd2lkdGg6IDE1cHg7XG4gICAgICAgICAgICAgICAgICAgIGhlaWdodDogMTVweDtcbiAgICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZDogd2hpdGU7XG4gICAgICAgICAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDEwMCU7XG4gICAgICAgICAgICAgICAgICAgIGJvcmRlcjogNHB4IHNvbGlkIHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgLmNoaXAge1xuICAgICAgICAgICAgICAgICAgICBib3JkZXItcmFkaXVzOiAyNXB4O1xuICAgICAgICAgICAgICAgICAgICBib3JkZXI6IDFweCBzb2xpZCBsaWdodGdyYXk7XG4gICAgICAgICAgICAgICAgICAgIHdpZHRoOiBmaXQtY29udGVudDtcbiAgICAgICAgICAgICAgICAgICAgcGFkZGluZzogMTBweDtcbiAgICAgICAgICAgICAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAgICAgICAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICAgICAgICAgICAgICAgICAgbWFyZ2luOiBhdXRvO1xuXG4gICAgICAgICAgICAgICAgICAgIGlvbi1sYWJlbCB7XG4gICAgICAgICAgICAgICAgICAgICAgICBmb250LXNpemU6IDE0cHg7XG4gICAgICAgICAgICAgICAgICAgICAgICBtYXJnaW4tbGVmdDogMTBweDtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIC5iYWNrX2ltYWdlIHtcbiAgICAgICAgICAgICAgICB3aWR0aDogMTAwJTtcbiAgICAgICAgICAgICAgICBoZWlnaHQ6IDE4MHB4O1xuICAgICAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDEwcHg7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIHZpZGVvIHtcbiAgICAgICAgICAgICAgICB3aWR0aDogMTAwJTtcbiAgICAgICAgICAgICAgICBib3JkZXItcmFkaXVzOiAxMHB4O1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAuY2hhbm5lbF9kZXRhaWwge1xuICAgICAgICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgICAgICAgICAgbWFyZ2luLXRvcDogMTVweDtcbiAgICAgICAgICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgICAgICAgICAgICAgIG1hcmdpbi1ib3R0b206IDEwcHg7XG4gICAgICAgICAgICAgICAgaW1nIHtcbiAgICAgICAgICAgICAgICAgICAgd2lkdGg6IDI1cHg7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIC5jaGFubmVsX25hbWUge1xuICAgICAgICAgICAgICAgICAgICBmb250LXdlaWdodDogNjAwO1xuICAgICAgICAgICAgICAgICAgICBmb250LXNpemU6IDE1cHg7XG4gICAgICAgICAgICAgICAgICAgIG1hcmdpbi1sZWZ0OiAxMHB4O1xuICAgICAgICAgICAgICAgICAgICBtYXJnaW4tcmlnaHQ6IDEwcHg7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIC5mb2xsb3dfbGJsIHtcbiAgICAgICAgICAgICAgICAgICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcbiAgICAgICAgICAgICAgICAgICAgZm9udC1zaXplOiAxM3B4O1xuICAgICAgICAgICAgICAgICAgICBtYXJnaW4tbGVmdDogMTBweDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIC5oZWFkX2xpbmUge1xuICAgICAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiA1MDA7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICAuZGV0YWlsIHtcbiAgICAgICAgICAgICAgICBtYXJnaW4tdG9wOiAxMHB4O1xuICAgICAgICAgICAgICAgIGNvbG9yOiBncmF5O1xuICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMTVweDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIC8vIC50aW1lX2xibHtcbiAgICAgICAgICAgIC8vICAgICBtYXJnaW4tdG9wOiAxMHB4O1xuICAgICAgICAgICAgLy8gICAgIGZvbnQtc2l6ZTogMTJweDtcbiAgICAgICAgICAgIC8vICAgICBjb2xvcjogZ3JheTtcbiAgICAgICAgICAgIC8vIH1cblxuICAgICAgICAgICAgLmxpbmtfbGJsIHtcbiAgICAgICAgICAgICAgICBtYXJnaW4tdG9wOiAxMHB4O1xuICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMTNweDtcbiAgICAgICAgICAgICAgICBjb2xvcjogZ3JheTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgLmxpa2VfZGl2IHtcbiAgICAgICAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMTNweDtcbiAgICAgICAgICAgICAgICBjb2xvcjogIzUwNTA1MDtcbiAgICAgICAgICAgICAgICBtYXJnaW4tdG9wOiAxMHB4O1xuICAgICAgICAgICAgICAgIG1hcmdpbi1ib3R0b206IDEwcHg7XG4gICAgICAgICAgICAgICAgaW1nIHtcbiAgICAgICAgICAgICAgICAgICAgd2lkdGg6IDIwcHg7XG4gICAgICAgICAgICAgICAgICAgIGhlaWdodDogMjBweDtcbiAgICAgICAgICAgICAgICAgICAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAuc2hhcmVfbGJsIHtcbiAgICAgICAgICAgICAgICAgICAgbWFyZ2luLWxlZnQ6IDE1cHg7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAuc2hhcmVfZGl2IHtcbiAgICAgICAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICAgICAgICAgIHdpZHRoOiAxMDAlO1xuICAgICAgICAgICAgICAgIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcblxuICAgICAgICAgICAgICAgIC5sZWZ0X2RpdiB7XG4gICAgICAgICAgICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgLnJpZ2h0X2RpdiB7XG4gICAgICAgICAgICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgICAgICAgICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAgICAgICAgICAgICAgICAgIGlvbi1idXR0b24ge1xuICAgICAgICAgICAgICAgICAgICAgICAgbWFyZ2luOiAwO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICBpb24taWNvbiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I6ICM1MDUwNTA7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAucm91bmRfZGl2IHtcbiAgICAgICAgICAgICAgICAgICAgYm9yZGVyOiAxcHggc29saWQgbGlnaHRncmF5O1xuICAgICAgICAgICAgICAgICAgICBoZWlnaHQ6IDQwcHg7XG4gICAgICAgICAgICAgICAgICAgIHdpZHRoOiA0MHB4O1xuICAgICAgICAgICAgICAgICAgICBib3JkZXItcmFkaXVzOiAxMDAlO1xuICAgICAgICAgICAgICAgICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gICAgICAgICAgICAgICAgICAgIG1hcmdpbi1yaWdodDogMTBweDtcbiAgICAgICAgICAgICAgICAgICAgaW9uLWljb24ge1xuICAgICAgICAgICAgICAgICAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgICAgICAgICAgICAgICAgICAgICAgdG9wOiA1MCU7XG4gICAgICAgICAgICAgICAgICAgICAgICBsZWZ0OiA1MCU7XG4gICAgICAgICAgICAgICAgICAgICAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZSgtNTAlLCAtNTAlKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMThweDtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yOiAjNTA1MDUwO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxufVxuIiwiaW9uLWhlYWRlciBpb24tYnV0dG9uIHtcbiAgbWFyZ2luOiAwO1xufVxuaW9uLWhlYWRlciBpb24tYnV0dG9uIGlvbi1pY29uIHtcbiAgY29sb3I6IGJsYWNrO1xuICBmb250LXNpemU6IDIwcHg7XG59XG5cbi5oZWFkZXJfZGl2IHtcbiAgd2lkdGg6IDEwMCU7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICBwYWRkaW5nOiA1cHg7XG59XG4uaGVhZGVyX2RpdiBpbWcge1xuICB3aWR0aDogMTAwcHg7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgbGVmdDogNTAlO1xuICB0cmFuc2Zvcm06IHRyYW5zbGF0ZSgtNTAlKTtcbn1cbi5oZWFkZXJfZGl2IC5idG5fZGl2IHtcbiAgZGlzcGxheTogZmxleDtcbn1cbi5oZWFkZXJfZGl2IGlvbi1idXR0b24ge1xuICBjb2xvcjogYmxhY2s7XG59XG5cbi5hZGRfaWNvbiB7XG4gIHdpZHRoOiA1MHB4O1xuICBwb3NpdGlvbjogZml4ZWQ7XG4gIHotaW5kZXg6IDk5OTtcbiAgYm90dG9tOiA5MHB4O1xuICByaWdodDogMjBweDtcbiAgYm94LXNoYWRvdzogMHB4IDNweCA2cHggcmdiYSgwLCAwLCAwLCAwLjMpO1xuICBib3JkZXItcmFkaXVzOiAxMDAlO1xufVxuXG4ubWFpbl9jb250ZW50X2RpdiAuc2VhcmNoX2RpdiB7XG4gIHBhZGRpbmc6IDEwcHggMTZweDtcbiAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkIGxpZ2h0Z3JheTtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5zZWFyY2hfZGl2IGlvbi1pbnB1dCB7XG4gIGJvcmRlcjogMXB4IHNvbGlkIGJsYWNrO1xuICBib3JkZXItcmFkaXVzOiAyNXB4O1xufVxuLm1haW5fY29udGVudF9kaXYgLnNlYXJjaF9kaXYgaW9uLWlucHV0IGlvbi1pY29uIHtcbiAgZm9udC1zaXplOiAyMHB4O1xuICBwYWRkaW5nLWxlZnQ6IDEwcHg7XG4gIHBhZGRpbmctcmlnaHQ6IDVweDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5zZWFyY2hfZGl2IC50ZXN0IHtcbiAgZGlzcGxheTogZmxleDtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xuICBib3JkZXItcmFkaXVzOiAyNXB4O1xuICBwYWRkaW5nOiA1cHggMTVweDtcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5zZWFyY2hfZGl2IC50ZXN0IGlvbi1pY29uIHtcbiAgZm9udC1zaXplOiAyNnB4O1xuICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xufVxuLm1haW5fY29udGVudF9kaXYgLnNlYXJjaF9kaXYgLmFjdGl2ZSBpb24tbGFiZWwge1xuICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpICFpbXBvcnRhbnQ7XG59XG4ubWFpbl9jb250ZW50X2RpdiAuc2VhcmNoX2RpdiAuY2hpcHNfZGl2IHtcbiAgZGlzcGxheTogZmxleDtcbiAgZmxleC1kaXJlY3Rpb246IHJvdztcbiAgb3ZlcmZsb3c6IHNjcm9sbDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5zZWFyY2hfZGl2IC5jaGlwc19kaXYgLmNoaXAge1xuICB3aGl0ZS1zcGFjZTogbm93cmFwO1xuICBjb2xvcjogYmxhY2s7XG4gIGZvbnQtc2l6ZTogMTNweDtcbiAgZm9udC13ZWlnaHQ6IDUwMDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5zZWFyY2hfZGl2IC5jaGlwc19kaXYgLmxpbmVfc3BhbiB7XG4gIG1hcmdpbi10b3A6IDdweDtcbiAgd2lkdGg6IDIwcHg7XG4gIGhlaWdodDogMnB4O1xuICBiYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XG59XG4ubWFpbl9jb250ZW50X2RpdiAuc3RvcnlfZGl2IHtcbiAgcGFkZGluZzogMTZweDtcbiAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkIGxpZ2h0Z3JheTtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5zdG9yeV9kaXYgLmNoaXBzX2RpdiB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGZsZXgtZGlyZWN0aW9uOiByb3c7XG4gIG92ZXJmbG93OiBzY3JvbGw7XG59XG4ubWFpbl9jb250ZW50X2RpdiAuc3RvcnlfZGl2IC5jaGlwc19kaXYgLmlubmVyX2RpdiB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG4gIG1hcmdpbi1yaWdodDogMTVweDtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xufVxuLm1haW5fY29udGVudF9kaXYgLnN0b3J5X2RpdiAuY2hpcHNfZGl2IC5pbm5lcl9kaXYgLnN0b3J5X2ltZ19tYWluIHtcbiAgd2lkdGg6IDYwcHg7XG4gIGhlaWdodDogNjBweDtcbiAgYm9yZGVyLXJhZGl1czogMTAwJTtcbiAgYm9yZGVyOiAycHggc29saWQgcmVkO1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG59XG4ubWFpbl9jb250ZW50X2RpdiAuc3RvcnlfZGl2IC5jaGlwc19kaXYgLmlubmVyX2RpdiAuc3RvcnlfaW1nX21haW4gLmZpbGxfZGl2IHtcbiAgd2lkdGg6IDUwcHg7XG4gIGhlaWdodDogNTBweDtcbiAgYm9yZGVyLXJhZGl1czogMTAwJTtcbiAgYmFja2dyb3VuZDogIzNiMmE1MjtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICB0b3A6IDUwJTtcbiAgbGVmdDogNTAlO1xuICB0cmFuc2Zvcm06IHRyYW5zbGF0ZSgtNTAlLCAtNTAlKTtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5zdG9yeV9kaXYgLmNoaXBzX2RpdiAuaW5uZXJfZGl2IC5zdG9yeV9pbWdfbWFpbiAuZmlsbF9kaXYgaW1nIHtcbiAgd2lkdGg6IDI1cHg7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgdG9wOiA1MCU7XG4gIGxlZnQ6IDUwJTtcbiAgdHJhbnNmb3JtOiB0cmFuc2xhdGUoLTUwJSwgLTUwJSk7XG59XG4ubWFpbl9jb250ZW50X2RpdiAuc3RvcnlfZGl2IC5jaGlwc19kaXYgLmlubmVyX2RpdiAuc3RvcnlfaW1nIHtcbiAgd2lkdGg6IDYwcHg7XG4gIGhlaWdodDogNjBweDtcbiAgYm9yZGVyLXJhZGl1czogMTAwJTtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5zdG9yeV9kaXYgLmNoaXBzX2RpdiAuY2hpcCB7XG4gIHdoaXRlLXNwYWNlOiBub3dyYXA7XG4gIGNvbG9yOiAjNTA1MDUwO1xuICBmb250LXNpemU6IDEycHg7XG4gIG1hcmdpbi10b3A6IDEwcHg7XG59XG4ubWFpbl9jb250ZW50X2RpdiAubGFuZ19kaXYge1xuICBwYWRkaW5nOiAxMHB4IDE2cHg7XG4gIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCBsaWdodGdyYXk7XG59XG4ubWFpbl9jb250ZW50X2RpdiAubGFuZ19kaXYgLnRlc3Qge1xuICBkaXNwbGF5OiBmbGV4O1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBtYXJnaW4tcmlnaHQ6IDEwcHg7XG4gIGJvcmRlcjogMXB4IHNvbGlkIGxpZ2h0Z3JheTtcbiAgYmFja2dyb3VuZDogd2hpdGVzbW9rZTtcbiAgYm9yZGVyLXJhZGl1czogMjVweDtcbiAgcGFkZGluZzogNXB4IDE1cHg7XG59XG4ubWFpbl9jb250ZW50X2RpdiAubGFuZ19kaXYgLmFjdGl2ZSB7XG4gIGJvcmRlcjogMXB4IHNvbGlkIHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcbiAgYmFja2dyb3VuZDogcmdiYSgxNywgMTE2LCAxOTIsIDAuMik7XG59XG4ubWFpbl9jb250ZW50X2RpdiAubGFuZ19kaXYgLmFjdGl2ZSBpb24tbGFiZWwge1xuICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpICFpbXBvcnRhbnQ7XG59XG4ubWFpbl9jb250ZW50X2RpdiAubGFuZ19kaXYgLmNoaXBzX2RpdiB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGZsZXgtZGlyZWN0aW9uOiByb3c7XG4gIG92ZXJmbG93OiBzY3JvbGw7XG59XG4ubWFpbl9jb250ZW50X2RpdiAubGFuZ19kaXYgLmNoaXBzX2RpdiAuY2hpcCB7XG4gIHdoaXRlLXNwYWNlOiBub3dyYXA7XG4gIGNvbG9yOiBibGFjaztcbiAgZm9udC1zaXplOiAxM3B4O1xufVxuLm1haW5fY29udGVudF9kaXYgLmxvd2VyX2RpdiAubmV3c19jYXJkIHtcbiAgcGFkZGluZzogMTZweDtcbiAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkIGxpZ2h0Z3JheTtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5sb3dlcl9kaXYgLm5ld3NfY2FyZCAuY2hpcF9kaXYge1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIG1hcmdpbi1ib3R0b206IDE1cHg7XG59XG4ubWFpbl9jb250ZW50X2RpdiAubG93ZXJfZGl2IC5uZXdzX2NhcmQgLmNoaXBfZGl2IC5yb3VuZCB7XG4gIHdpZHRoOiAxNXB4O1xuICBoZWlnaHQ6IDE1cHg7XG4gIGJhY2tncm91bmQ6IHdoaXRlO1xuICBib3JkZXItcmFkaXVzOiAxMDAlO1xuICBib3JkZXI6IDRweCBzb2xpZCB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XG59XG4ubWFpbl9jb250ZW50X2RpdiAubG93ZXJfZGl2IC5uZXdzX2NhcmQgLmNoaXBfZGl2IC5jaGlwIHtcbiAgYm9yZGVyLXJhZGl1czogMjVweDtcbiAgYm9yZGVyOiAxcHggc29saWQgbGlnaHRncmF5O1xuICB3aWR0aDogZml0LWNvbnRlbnQ7XG4gIHBhZGRpbmc6IDEwcHg7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIG1hcmdpbjogYXV0bztcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5sb3dlcl9kaXYgLm5ld3NfY2FyZCAuY2hpcF9kaXYgLmNoaXAgaW9uLWxhYmVsIHtcbiAgZm9udC1zaXplOiAxNHB4O1xuICBtYXJnaW4tbGVmdDogMTBweDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5sb3dlcl9kaXYgLm5ld3NfY2FyZCAuYmFja19pbWFnZSB7XG4gIHdpZHRoOiAxMDAlO1xuICBoZWlnaHQ6IDE4MHB4O1xuICBib3JkZXItcmFkaXVzOiAxMHB4O1xufVxuLm1haW5fY29udGVudF9kaXYgLmxvd2VyX2RpdiAubmV3c19jYXJkIHZpZGVvIHtcbiAgd2lkdGg6IDEwMCU7XG4gIGJvcmRlci1yYWRpdXM6IDEwcHg7XG59XG4ubWFpbl9jb250ZW50X2RpdiAubG93ZXJfZGl2IC5uZXdzX2NhcmQgLmNoYW5uZWxfZGV0YWlsIHtcbiAgZGlzcGxheTogZmxleDtcbiAgbWFyZ2luLXRvcDogMTVweDtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgbWFyZ2luLWJvdHRvbTogMTBweDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5sb3dlcl9kaXYgLm5ld3NfY2FyZCAuY2hhbm5lbF9kZXRhaWwgaW1nIHtcbiAgd2lkdGg6IDI1cHg7XG59XG4ubWFpbl9jb250ZW50X2RpdiAubG93ZXJfZGl2IC5uZXdzX2NhcmQgLmNoYW5uZWxfZGV0YWlsIC5jaGFubmVsX25hbWUge1xuICBmb250LXdlaWdodDogNjAwO1xuICBmb250LXNpemU6IDE1cHg7XG4gIG1hcmdpbi1sZWZ0OiAxMHB4O1xuICBtYXJnaW4tcmlnaHQ6IDEwcHg7XG59XG4ubWFpbl9jb250ZW50X2RpdiAubG93ZXJfZGl2IC5uZXdzX2NhcmQgLmNoYW5uZWxfZGV0YWlsIC5mb2xsb3dfbGJsIHtcbiAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcbiAgZm9udC1zaXplOiAxM3B4O1xuICBtYXJnaW4tbGVmdDogMTBweDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5sb3dlcl9kaXYgLm5ld3NfY2FyZCAuaGVhZF9saW5lIHtcbiAgZm9udC13ZWlnaHQ6IDUwMDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5sb3dlcl9kaXYgLm5ld3NfY2FyZCAuZGV0YWlsIHtcbiAgbWFyZ2luLXRvcDogMTBweDtcbiAgY29sb3I6IGdyYXk7XG4gIGZvbnQtc2l6ZTogMTVweDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5sb3dlcl9kaXYgLm5ld3NfY2FyZCAubGlua19sYmwge1xuICBtYXJnaW4tdG9wOiAxMHB4O1xuICBmb250LXNpemU6IDEzcHg7XG4gIGNvbG9yOiBncmF5O1xufVxuLm1haW5fY29udGVudF9kaXYgLmxvd2VyX2RpdiAubmV3c19jYXJkIC5saWtlX2RpdiB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGZvbnQtc2l6ZTogMTNweDtcbiAgY29sb3I6ICM1MDUwNTA7XG4gIG1hcmdpbi10b3A6IDEwcHg7XG4gIG1hcmdpbi1ib3R0b206IDEwcHg7XG59XG4ubWFpbl9jb250ZW50X2RpdiAubG93ZXJfZGl2IC5uZXdzX2NhcmQgLmxpa2VfZGl2IGltZyB7XG4gIHdpZHRoOiAyMHB4O1xuICBoZWlnaHQ6IDIwcHg7XG4gIG1hcmdpbi1yaWdodDogMTBweDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5sb3dlcl9kaXYgLm5ld3NfY2FyZCAubGlrZV9kaXYgLnNoYXJlX2xibCB7XG4gIG1hcmdpbi1sZWZ0OiAxNXB4O1xufVxuLm1haW5fY29udGVudF9kaXYgLmxvd2VyX2RpdiAubmV3c19jYXJkIC5zaGFyZV9kaXYge1xuICBkaXNwbGF5OiBmbGV4O1xuICB3aWR0aDogMTAwJTtcbiAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xufVxuLm1haW5fY29udGVudF9kaXYgLmxvd2VyX2RpdiAubmV3c19jYXJkIC5zaGFyZV9kaXYgLmxlZnRfZGl2IHtcbiAgZGlzcGxheTogZmxleDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5sb3dlcl9kaXYgLm5ld3NfY2FyZCAuc2hhcmVfZGl2IC5yaWdodF9kaXYge1xuICBkaXNwbGF5OiBmbGV4O1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xufVxuLm1haW5fY29udGVudF9kaXYgLmxvd2VyX2RpdiAubmV3c19jYXJkIC5zaGFyZV9kaXYgLnJpZ2h0X2RpdiBpb24tYnV0dG9uIHtcbiAgbWFyZ2luOiAwO1xufVxuLm1haW5fY29udGVudF9kaXYgLmxvd2VyX2RpdiAubmV3c19jYXJkIC5zaGFyZV9kaXYgLnJpZ2h0X2RpdiBpb24tYnV0dG9uIGlvbi1pY29uIHtcbiAgY29sb3I6ICM1MDUwNTA7XG59XG4ubWFpbl9jb250ZW50X2RpdiAubG93ZXJfZGl2IC5uZXdzX2NhcmQgLnNoYXJlX2RpdiAucm91bmRfZGl2IHtcbiAgYm9yZGVyOiAxcHggc29saWQgbGlnaHRncmF5O1xuICBoZWlnaHQ6IDQwcHg7XG4gIHdpZHRoOiA0MHB4O1xuICBib3JkZXItcmFkaXVzOiAxMDAlO1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIG1hcmdpbi1yaWdodDogMTBweDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5sb3dlcl9kaXYgLm5ld3NfY2FyZCAuc2hhcmVfZGl2IC5yb3VuZF9kaXYgaW9uLWljb24ge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHRvcDogNTAlO1xuICBsZWZ0OiA1MCU7XG4gIHRyYW5zZm9ybTogdHJhbnNsYXRlKC01MCUsIC01MCUpO1xuICBmb250LXNpemU6IDE4cHg7XG4gIGNvbG9yOiAjNTA1MDUwO1xufSJdfQ== */");

/***/ }),

/***/ "./src/app/pages/social/social.page.ts":
/*!*********************************************!*\
  !*** ./src/app/pages/social/social.page.ts ***!
  \*********************************************/
/*! exports provided: SocialPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SocialPage", function() { return SocialPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var src_app_services_dummy_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/dummy.service */ "./src/app/services/dummy.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");





let SocialPage = class SocialPage {
    constructor(dummy, actionSheetController, route, router) {
        this.dummy = dummy;
        this.actionSheetController = actionSheetController;
        this.route = route;
        this.router = router;
        this.moviesCat = ['Search', 'Shopping', 'Maps', 'Images', 'News', 'Videos', 'Social'];
        this.videoCat = ['English', 'Topics', 'For You', 'All', 'Cricket', 'Live TV', 'BollyWood', 'Business', 'Science'];
        this.plt = localStorage.getItem('platform');
        this.stories = this.dummy.story;
        this.lang = this.dummy.lang;
        this.allNews = this.dummy.news;
        this.route.queryParams.subscribe(data => {
            console.log(data.id);
            this.currentCat = data.id;
        });
    }
    ngOnInit() {
    }
    selectLang(val) {
        this.currentLang = val;
    }
    presentActionSheet() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const actionSheet = yield this.actionSheetController.create({
                mode: 'md',
                buttons: [
                    {
                        text: 'Hide Post',
                        icon: 'eye-off-outline',
                    },
                    {
                        text: 'Follow South China Morning Post',
                        icon: 'person-add-outline',
                    },
                    {
                        text: 'Report Post',
                        icon: 'alert-circle-outline',
                    }
                ]
            });
            yield actionSheet.present();
        });
    }
    shareActionSheet() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const actionSheet = yield this.actionSheetController.create({
                mode: 'md',
                buttons: [
                    {
                        text: 'Post on JdSocial',
                        icon: 'sync-circle-outline',
                    },
                    {
                        text: 'Share on facebook',
                        icon: 'logo-facebook',
                    },
                    {
                        text: 'Send on WhatsApp',
                        icon: 'logo-whatsapp',
                    },
                    {
                        text: 'Copy Link',
                        icon: 'copy-outline',
                    },
                    {
                        text: 'More Options..',
                        icon: 'ellipsis-horizontal-circle-outline',
                    }
                ]
            });
            yield actionSheet.present();
        });
    }
    selectCat(val) {
        const navData = {
            queryParams: {
                id: val
            }
        };
        console.log(val);
        this.currentCat = val;
        if (this.currentCat === 'News') {
            this.router.navigate(['/tabs/news'], navData);
        }
        if (this.currentCat === 'Videos') {
            this.router.navigate(['/tabs/videos'], navData);
        }
        if (this.currentCat === 'Social') {
            this.router.navigate(['/tabs/social'], navData);
        }
    }
    selectVideoCat(val) {
        this.vCat = val;
    }
    goToNewPost() {
        this.router.navigate(['/new-post']);
    }
    goToNotification() {
        this.router.navigate(['/tabs/notification']);
    }
};
SocialPage.ctorParameters = () => [
    { type: src_app_services_dummy_service__WEBPACK_IMPORTED_MODULE_2__["DummyService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ActionSheetController"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["ActivatedRoute"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"] }
];
SocialPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-social',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./social.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/social/social.page.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./social.page.scss */ "./src/app/pages/social/social.page.scss")).default]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [src_app_services_dummy_service__WEBPACK_IMPORTED_MODULE_2__["DummyService"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ActionSheetController"],
        _angular_router__WEBPACK_IMPORTED_MODULE_4__["ActivatedRoute"],
        _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"]])
], SocialPage);



/***/ })

}]);
//# sourceMappingURL=social-social-module-es2015.js.map