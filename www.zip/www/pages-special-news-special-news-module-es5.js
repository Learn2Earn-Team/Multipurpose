function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-special-news-special-news-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/special-news/special-news.page.html":
  /*!*************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/special-news/special-news.page.html ***!
    \*************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppPagesSpecialNewsSpecialNewsPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar>\n    <ion-title>special-news</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n</ion-content>\n";
    /***/
  },

  /***/
  "./src/app/pages/special-news/special-news-routing.module.ts":
  /*!*******************************************************************!*\
    !*** ./src/app/pages/special-news/special-news-routing.module.ts ***!
    \*******************************************************************/

  /*! exports provided: SpecialNewsPageRoutingModule */

  /***/
  function srcAppPagesSpecialNewsSpecialNewsRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "SpecialNewsPageRoutingModule", function () {
      return SpecialNewsPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _special_news_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./special-news.page */
    "./src/app/pages/special-news/special-news.page.ts");

    var routes = [{
      path: '',
      component: _special_news_page__WEBPACK_IMPORTED_MODULE_3__["SpecialNewsPage"]
    }];

    var SpecialNewsPageRoutingModule = function SpecialNewsPageRoutingModule() {
      _classCallCheck(this, SpecialNewsPageRoutingModule);
    };

    SpecialNewsPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], SpecialNewsPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/pages/special-news/special-news.module.ts":
  /*!***********************************************************!*\
    !*** ./src/app/pages/special-news/special-news.module.ts ***!
    \***********************************************************/

  /*! exports provided: SpecialNewsPageModule */

  /***/
  function srcAppPagesSpecialNewsSpecialNewsModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "SpecialNewsPageModule", function () {
      return SpecialNewsPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _special_news_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./special-news-routing.module */
    "./src/app/pages/special-news/special-news-routing.module.ts");
    /* harmony import */


    var _special_news_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./special-news.page */
    "./src/app/pages/special-news/special-news.page.ts");

    var SpecialNewsPageModule = function SpecialNewsPageModule() {
      _classCallCheck(this, SpecialNewsPageModule);
    };

    SpecialNewsPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _special_news_routing_module__WEBPACK_IMPORTED_MODULE_5__["SpecialNewsPageRoutingModule"]],
      declarations: [_special_news_page__WEBPACK_IMPORTED_MODULE_6__["SpecialNewsPage"]]
    })], SpecialNewsPageModule);
    /***/
  },

  /***/
  "./src/app/pages/special-news/special-news.page.scss":
  /*!***********************************************************!*\
    !*** ./src/app/pages/special-news/special-news.page.scss ***!
    \***********************************************************/

  /*! exports provided: default */

  /***/
  function srcAppPagesSpecialNewsSpecialNewsPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL3NwZWNpYWwtbmV3cy9zcGVjaWFsLW5ld3MucGFnZS5zY3NzIn0= */";
    /***/
  },

  /***/
  "./src/app/pages/special-news/special-news.page.ts":
  /*!*********************************************************!*\
    !*** ./src/app/pages/special-news/special-news.page.ts ***!
    \*********************************************************/

  /*! exports provided: SpecialNewsPage */

  /***/
  function srcAppPagesSpecialNewsSpecialNewsPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "SpecialNewsPage", function () {
      return SpecialNewsPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");

    var SpecialNewsPage = /*#__PURE__*/function () {
      function SpecialNewsPage() {
        _classCallCheck(this, SpecialNewsPage);
      }

      _createClass(SpecialNewsPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }]);

      return SpecialNewsPage;
    }();

    SpecialNewsPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-special-news',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./special-news.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/special-news/special-news.page.html"))["default"],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./special-news.page.scss */
      "./src/app/pages/special-news/special-news.page.scss"))["default"]]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])], SpecialNewsPage);
    /***/
  }
}]);
//# sourceMappingURL=pages-special-news-special-news-module-es5.js.map