function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["more-music-more-music-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/more-music/more-music.page.html":
  /*!*********************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/more-music/more-music.page.html ***!
    \*********************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppPagesMoreMusicMoreMusicPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar>\n   <!-- <ion-buttons slot=\"start\">\n     <ion-back-button mode=\"md\"></ion-back-button>\n   </ion-buttons> -->\n\n   <ion-icon class=\"back\" name=\"arrow-back-outline\" (click)=\"goBack()\"></ion-icon>\n\n    <ion-title>Music</ion-title>\n\n    <ion-button slot=\"end\" size=\"small\" fill=\"clear\">\n      <ion-icon name=\"language-outline\"></ion-icon>\n    </ion-button>\n\n    <ion-button slot=\"end\" size=\"small\" fill=\"clear\">\n      <ion-icon name=\"notifications-outline\"></ion-icon>\n    </ion-button>\n\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div class=\"main_content_div\">\n\n    <div class=\"upper_div\">\n      <ion-input placeholder=\"Search\" type=\"text\">\n        <ion-icon name=\"search-outline\"></ion-icon>\n      </ion-input>\n    </div>\n\n    <div class=\"lower_div\">\n\n      <ion-grid fixed>\n        <ion-row>\n          <ion-col size=\"4\" *ngFor=\"let item of songs\" (click)=\"goToMusicVideo()\">\n            <div class=\"main_div\">\n              <div class=\"back_image bg_image\" [style.backgroundImage]=\"'url( '+ item.img +' )'\"></div>\n              <ion-label class=\"name\">{{item.name | slice : 0 : 13}}</ion-label>\n            </div>\n          </ion-col>\n        </ion-row>\n      </ion-grid>\n\n    </div>\n  </div>\n</ion-content>\n";
    /***/
  },

  /***/
  "./src/app/pages/more-music/more-music-routing.module.ts":
  /*!***************************************************************!*\
    !*** ./src/app/pages/more-music/more-music-routing.module.ts ***!
    \***************************************************************/

  /*! exports provided: MoreMusicPageRoutingModule */

  /***/
  function srcAppPagesMoreMusicMoreMusicRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "MoreMusicPageRoutingModule", function () {
      return MoreMusicPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _more_music_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./more-music.page */
    "./src/app/pages/more-music/more-music.page.ts");

    var routes = [{
      path: '',
      component: _more_music_page__WEBPACK_IMPORTED_MODULE_3__["MoreMusicPage"]
    }];

    var MoreMusicPageRoutingModule = function MoreMusicPageRoutingModule() {
      _classCallCheck(this, MoreMusicPageRoutingModule);
    };

    MoreMusicPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], MoreMusicPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/pages/more-music/more-music.module.ts":
  /*!*******************************************************!*\
    !*** ./src/app/pages/more-music/more-music.module.ts ***!
    \*******************************************************/

  /*! exports provided: MoreMusicPageModule */

  /***/
  function srcAppPagesMoreMusicMoreMusicModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "MoreMusicPageModule", function () {
      return MoreMusicPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _more_music_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./more-music-routing.module */
    "./src/app/pages/more-music/more-music-routing.module.ts");
    /* harmony import */


    var _more_music_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./more-music.page */
    "./src/app/pages/more-music/more-music.page.ts");

    var MoreMusicPageModule = function MoreMusicPageModule() {
      _classCallCheck(this, MoreMusicPageModule);
    };

    MoreMusicPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _more_music_routing_module__WEBPACK_IMPORTED_MODULE_5__["MoreMusicPageRoutingModule"]],
      declarations: [_more_music_page__WEBPACK_IMPORTED_MODULE_6__["MoreMusicPage"]]
    })], MoreMusicPageModule);
    /***/
  },

  /***/
  "./src/app/pages/more-music/more-music.page.scss":
  /*!*******************************************************!*\
    !*** ./src/app/pages/more-music/more-music.page.scss ***!
    \*******************************************************/

  /*! exports provided: default */

  /***/
  function srcAppPagesMoreMusicMoreMusicPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "ion-header .back {\n  font-size: 27px;\n  margin-left: 10px;\n}\nion-header ion-button {\n  margin: 0;\n}\nion-header ion-button ion-icon {\n  color: black;\n  font-size: 20px;\n}\n.main_content_div {\n  width: 100%;\n}\n.main_content_div ion-label {\n  display: block;\n}\n.main_content_div .upper_div {\n  padding: 10px 16px;\n  border-bottom: 1px solid lightgray;\n}\n.main_content_div .upper_div ion-input {\n  border: 1px solid black;\n  border-radius: 25px;\n}\n.main_content_div .upper_div ion-input ion-icon {\n  font-size: 20px;\n  padding-left: 10px;\n  padding-right: 5px;\n}\n.main_content_div .lower_div {\n  padding: 10px;\n}\n.main_content_div .lower_div ion-grid {\n  padding: 0;\n}\n.main_content_div .lower_div ion-grid .main_div {\n  width: 100%;\n  box-shadow: 0px 3px 6px rgba(0, 0, 0, 0.3);\n}\n.main_content_div .lower_div ion-grid .main_div .back_image {\n  width: 100%;\n  height: 100px;\n}\n.main_content_div .lower_div ion-grid .main_div .name {\n  padding: 5px;\n  font-size: 13px;\n  text-align: left;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvbW9yZS1tdXNpYy9FOlxcSW9uaWMgUHJvamVjdHNcXGlvbmljLTUtdGVtcGxhdGUtYnVuZGxlLWlvbmljLTUtdGhlbWVzLWJ1bmRsZXMtaW9uaWMtNS10ZW1wbGF0ZXMtd2l0aC0xMC1hcHBzXFxBcHBfc291cmNlX2NvZGVcXEFwcHNfY29kZVxcTXVsdGlfcHVycG9zZS9zcmNcXGFwcFxccGFnZXNcXG1vcmUtbXVzaWNcXG1vcmUtbXVzaWMucGFnZS5zY3NzIiwic3JjL2FwcC9wYWdlcy9tb3JlLW11c2ljL21vcmUtbXVzaWMucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNJO0VBQ0ksZUFBQTtFQUNBLGlCQUFBO0FDQVI7QURFSTtFQUNJLFNBQUE7QUNBUjtBREVRO0VBQ0ksWUFBQTtFQUNBLGVBQUE7QUNBWjtBREtBO0VBQ0ksV0FBQTtBQ0ZKO0FES0k7RUFDSSxjQUFBO0FDSFI7QURNSTtFQUNJLGtCQUFBO0VBQ0Esa0NBQUE7QUNKUjtBREtRO0VBQ0ksdUJBQUE7RUFDQSxtQkFBQTtBQ0haO0FESVk7RUFDSSxlQUFBO0VBQ0Esa0JBQUE7RUFDQSxrQkFBQTtBQ0ZoQjtBRE9JO0VBQ0ksYUFBQTtBQ0xSO0FET1E7RUFDSSxVQUFBO0FDTFo7QURPWTtFQUNJLFdBQUE7RUFFQSwwQ0FBQTtBQ05oQjtBRFFnQjtFQUNJLFdBQUE7RUFDQSxhQUFBO0FDTnBCO0FEV2dCO0VBQ0ksWUFBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtBQ1RwQiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL21vcmUtbXVzaWMvbW9yZS1tdXNpYy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24taGVhZGVye1xuICAgIC5iYWNre1xuICAgICAgICBmb250LXNpemU6IDI3cHg7XG4gICAgICAgIG1hcmdpbi1sZWZ0OiAxMHB4O1xuICAgIH1cbiAgICBpb24tYnV0dG9ue1xuICAgICAgICBtYXJnaW46IDA7XG5cbiAgICAgICAgaW9uLWljb257XG4gICAgICAgICAgICBjb2xvcjogYmxhY2s7XG4gICAgICAgICAgICBmb250LXNpemU6IDIwcHg7XG4gICAgICAgIH1cbiAgICB9XG59XG5cbi5tYWluX2NvbnRlbnRfZGl2e1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIC8vIHBhZGRpbmc6IDE2cHg7XG5cbiAgICBpb24tbGFiZWwge1xuICAgICAgICBkaXNwbGF5OiBibG9jaztcbiAgICB9XG5cbiAgICAudXBwZXJfZGl2e1xuICAgICAgICBwYWRkaW5nOiAxMHB4IDE2cHg7XG4gICAgICAgIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCBsaWdodGdyYXk7XG4gICAgICAgIGlvbi1pbnB1dHtcbiAgICAgICAgICAgIGJvcmRlcjogMXB4IHNvbGlkIGJsYWNrO1xuICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogMjVweDtcbiAgICAgICAgICAgIGlvbi1pY29ue1xuICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMjBweDtcbiAgICAgICAgICAgICAgICBwYWRkaW5nLWxlZnQ6IDEwcHg7XG4gICAgICAgICAgICAgICAgcGFkZGluZy1yaWdodDogNXB4O1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuXG4gICAgLmxvd2VyX2RpdntcbiAgICAgICAgcGFkZGluZzogMTBweDtcblxuICAgICAgICBpb24tZ3JpZHtcbiAgICAgICAgICAgIHBhZGRpbmc6IDA7XG5cbiAgICAgICAgICAgIC5tYWluX2RpdntcbiAgICAgICAgICAgICAgICB3aWR0aDogMTAwJTtcbiAgICAgICAgICAgICAgICAvLyBib3JkZXItcmFkaXVzOiA1cHg7XG4gICAgICAgICAgICAgICAgYm94LXNoYWRvdzogMHB4IDNweCA2cHggcmdiYSgwLDAsMCwwLjMpO1xuXG4gICAgICAgICAgICAgICAgLmJhY2tfaW1hZ2V7XG4gICAgICAgICAgICAgICAgICAgIHdpZHRoOiAxMDAlO1xuICAgICAgICAgICAgICAgICAgICBoZWlnaHQ6IDEwMHB4O1xuICAgICAgICAgICAgICAgICAgICAvLyBib3JkZXItdG9wLWxlZnQtcmFkaXVzOiA1cHg7XG4gICAgICAgICAgICAgICAgICAgIC8vIGJvcmRlci10b3AtcmlnaHQtcmFkaXVzOiA1cHg7XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgLm5hbWV7XG4gICAgICAgICAgICAgICAgICAgIHBhZGRpbmc6IDVweDtcbiAgICAgICAgICAgICAgICAgICAgZm9udC1zaXplOiAxM3B4O1xuICAgICAgICAgICAgICAgICAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cbn0iLCJpb24taGVhZGVyIC5iYWNrIHtcbiAgZm9udC1zaXplOiAyN3B4O1xuICBtYXJnaW4tbGVmdDogMTBweDtcbn1cbmlvbi1oZWFkZXIgaW9uLWJ1dHRvbiB7XG4gIG1hcmdpbjogMDtcbn1cbmlvbi1oZWFkZXIgaW9uLWJ1dHRvbiBpb24taWNvbiB7XG4gIGNvbG9yOiBibGFjaztcbiAgZm9udC1zaXplOiAyMHB4O1xufVxuXG4ubWFpbl9jb250ZW50X2RpdiB7XG4gIHdpZHRoOiAxMDAlO1xufVxuLm1haW5fY29udGVudF9kaXYgaW9uLWxhYmVsIHtcbiAgZGlzcGxheTogYmxvY2s7XG59XG4ubWFpbl9jb250ZW50X2RpdiAudXBwZXJfZGl2IHtcbiAgcGFkZGluZzogMTBweCAxNnB4O1xuICBib3JkZXItYm90dG9tOiAxcHggc29saWQgbGlnaHRncmF5O1xufVxuLm1haW5fY29udGVudF9kaXYgLnVwcGVyX2RpdiBpb24taW5wdXQge1xuICBib3JkZXI6IDFweCBzb2xpZCBibGFjaztcbiAgYm9yZGVyLXJhZGl1czogMjVweDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC51cHBlcl9kaXYgaW9uLWlucHV0IGlvbi1pY29uIHtcbiAgZm9udC1zaXplOiAyMHB4O1xuICBwYWRkaW5nLWxlZnQ6IDEwcHg7XG4gIHBhZGRpbmctcmlnaHQ6IDVweDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5sb3dlcl9kaXYge1xuICBwYWRkaW5nOiAxMHB4O1xufVxuLm1haW5fY29udGVudF9kaXYgLmxvd2VyX2RpdiBpb24tZ3JpZCB7XG4gIHBhZGRpbmc6IDA7XG59XG4ubWFpbl9jb250ZW50X2RpdiAubG93ZXJfZGl2IGlvbi1ncmlkIC5tYWluX2RpdiB7XG4gIHdpZHRoOiAxMDAlO1xuICBib3gtc2hhZG93OiAwcHggM3B4IDZweCByZ2JhKDAsIDAsIDAsIDAuMyk7XG59XG4ubWFpbl9jb250ZW50X2RpdiAubG93ZXJfZGl2IGlvbi1ncmlkIC5tYWluX2RpdiAuYmFja19pbWFnZSB7XG4gIHdpZHRoOiAxMDAlO1xuICBoZWlnaHQ6IDEwMHB4O1xufVxuLm1haW5fY29udGVudF9kaXYgLmxvd2VyX2RpdiBpb24tZ3JpZCAubWFpbl9kaXYgLm5hbWUge1xuICBwYWRkaW5nOiA1cHg7XG4gIGZvbnQtc2l6ZTogMTNweDtcbiAgdGV4dC1hbGlnbjogbGVmdDtcbn0iXX0= */";
    /***/
  },

  /***/
  "./src/app/pages/more-music/more-music.page.ts":
  /*!*****************************************************!*\
    !*** ./src/app/pages/more-music/more-music.page.ts ***!
    \*****************************************************/

  /*! exports provided: MoreMusicPage */

  /***/
  function srcAppPagesMoreMusicMoreMusicPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "MoreMusicPage", function () {
      return MoreMusicPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var src_app_services_music_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! src/app/services/music.service */
    "./src/app/services/music.service.ts");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");

    var MoreMusicPage = /*#__PURE__*/function () {
      function MoreMusicPage(music, router, navCtrl) {
        _classCallCheck(this, MoreMusicPage);

        this.music = music;
        this.router = router;
        this.navCtrl = navCtrl;
        this.songs = this.music.songs;
      }

      _createClass(MoreMusicPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }, {
        key: "goToMusicVideo",
        value: function goToMusicVideo() {
          this.router.navigate(['/tabs/music-video']);
        }
      }, {
        key: "goBack",
        value: function goBack() {
          this.navCtrl.back();
        }
      }]);

      return MoreMusicPage;
    }();

    MoreMusicPage.ctorParameters = function () {
      return [{
        type: src_app_services_music_service__WEBPACK_IMPORTED_MODULE_2__["MusicService"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["NavController"]
      }];
    };

    MoreMusicPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-more-music',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./more-music.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/more-music/more-music.page.html"))["default"],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./more-music.page.scss */
      "./src/app/pages/more-music/more-music.page.scss"))["default"]]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [src_app_services_music_service__WEBPACK_IMPORTED_MODULE_2__["MusicService"], _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["NavController"]])], MoreMusicPage);
    /***/
  }
}]);
//# sourceMappingURL=more-music-more-music-module-es5.js.map