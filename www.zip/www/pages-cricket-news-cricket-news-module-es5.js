function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-cricket-news-cricket-news-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/cricket-news/cricket-news.page.html":
  /*!*************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/cricket-news/cricket-news.page.html ***!
    \*************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppPagesCricketNewsCricketNewsPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button mode=\"md\"></ion-back-button>\n    </ion-buttons>\n\n    <ion-title>Cricbuzz</ion-title>\n\n    <ion-button slot=\"end\" size=\"small\" fill=\"clear\">\n      <ion-icon name=\"notifications-outline\"></ion-icon>\n    </ion-button>\n\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div class=\"main_content_div\">\n\n\n    <div class=\"news_card\">\n\n      <div class=\"chip_div\">\n        <div class=\"chip\">\n          <div class=\"round\"></div>\n          <ion-label>New News</ion-label>\n        </div>\n      </div>\n\n      <video playsinline webkit-playsinline autoplay>\n        <source src=\"assets/imgs/video.mp4\" type=\"video/mp4\">\n      </video>\n\n      <div class=\"channel_detail\">\n        <img src=\"assets/imgs/news_icn3.png\">\n        <ion-label class=\"channel_name\">Cricbuzz</ion-label> • \n        <ion-label class=\"follow_lbl\">Follow</ion-label>\n      </div>\n\n      <ion-label class=\"head_line\">\n        Lorem ipsum dolor sit, amet consectetur adipisicing elit. Et repellat quos nihil autem ratione non.\n      </ion-label>\n\n      <div class=\"like_div\">\n        <img src=\"assets/imgs/like.png\">\n        <ion-label>12</ion-label>\n        <ion-label class=\"share_lbl\">2 Share</ion-label>\n        <ion-label class=\"share_lbl\">222 Views</ion-label>\n      </div>\n\n      <div class=\"share_div\">\n        <div class=\"left_div\">\n          <div class=\"round_div\">\n            <ion-icon name=\"thumbs-up-outline\"></ion-icon>\n          </div>\n          <div class=\"round_div\">\n            <ion-icon name=\"chatbubble-outline\"></ion-icon>\n          </div>\n          <div class=\"round_div\">\n            <ion-icon name=\"arrow-redo-outline\"></ion-icon>\n          </div>\n        </div>\n        <div class=\"right_div\">\n          <div class=\"round_div\" style=\"margin-right: 0px;\">\n            <ion-icon name=\"bookmark-outline\"></ion-icon>\n          </div>\n          <ion-button fill=\"clear\" size=\"small\">\n            <ion-icon name=\"ellipsis-vertical\"></ion-icon>\n          </ion-button>\n        </div>\n      </div>\n\n      <ion-label class=\"link_lbl\">10 minutes</ion-label>\n\n    </div>\n\n  </div>\n</ion-content>\n\n<ion-footer>\n  <div class=\"footer_div\">\n    <ion-input type=\"text\" placeholder=\"Comment..\"></ion-input>\n    <div class=\"blue_div\">\n      <ion-icon name=\"arrow-forward-outline\"></ion-icon>\n    </div>\n  </div>\n</ion-footer>\n";
    /***/
  },

  /***/
  "./src/app/pages/cricket-news/cricket-news-routing.module.ts":
  /*!*******************************************************************!*\
    !*** ./src/app/pages/cricket-news/cricket-news-routing.module.ts ***!
    \*******************************************************************/

  /*! exports provided: CricketNewsPageRoutingModule */

  /***/
  function srcAppPagesCricketNewsCricketNewsRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "CricketNewsPageRoutingModule", function () {
      return CricketNewsPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _cricket_news_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./cricket-news.page */
    "./src/app/pages/cricket-news/cricket-news.page.ts");

    var routes = [{
      path: '',
      component: _cricket_news_page__WEBPACK_IMPORTED_MODULE_3__["CricketNewsPage"]
    }];

    var CricketNewsPageRoutingModule = function CricketNewsPageRoutingModule() {
      _classCallCheck(this, CricketNewsPageRoutingModule);
    };

    CricketNewsPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], CricketNewsPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/pages/cricket-news/cricket-news.module.ts":
  /*!***********************************************************!*\
    !*** ./src/app/pages/cricket-news/cricket-news.module.ts ***!
    \***********************************************************/

  /*! exports provided: CricketNewsPageModule */

  /***/
  function srcAppPagesCricketNewsCricketNewsModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "CricketNewsPageModule", function () {
      return CricketNewsPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _cricket_news_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./cricket-news-routing.module */
    "./src/app/pages/cricket-news/cricket-news-routing.module.ts");
    /* harmony import */


    var _cricket_news_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./cricket-news.page */
    "./src/app/pages/cricket-news/cricket-news.page.ts");

    var CricketNewsPageModule = function CricketNewsPageModule() {
      _classCallCheck(this, CricketNewsPageModule);
    };

    CricketNewsPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _cricket_news_routing_module__WEBPACK_IMPORTED_MODULE_5__["CricketNewsPageRoutingModule"]],
      declarations: [_cricket_news_page__WEBPACK_IMPORTED_MODULE_6__["CricketNewsPage"]]
    })], CricketNewsPageModule);
    /***/
  },

  /***/
  "./src/app/pages/cricket-news/cricket-news.page.scss":
  /*!***********************************************************!*\
    !*** ./src/app/pages/cricket-news/cricket-news.page.scss ***!
    \***********************************************************/

  /*! exports provided: default */

  /***/
  function srcAppPagesCricketNewsCricketNewsPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "ion-header ion-button {\n  margin: 0;\n}\nion-header ion-button ion-icon {\n  color: black;\n  font-size: 20px;\n}\n.main_content_div {\n  width: 100%;\n}\n.main_content_div .news_card {\n  padding: 16px;\n  border-bottom: 1px solid lightgray;\n}\n.main_content_div .news_card .chip_div {\n  text-align: center;\n  margin-bottom: 15px;\n}\n.main_content_div .news_card .chip_div .round {\n  width: 15px;\n  height: 15px;\n  background: white;\n  border-radius: 100%;\n  border: 4px solid var(--ion-color-primary);\n}\n.main_content_div .news_card .chip_div .chip {\n  border-radius: 25px;\n  border: 1px solid lightgray;\n  width: -webkit-fit-content;\n  width: -moz-fit-content;\n  width: fit-content;\n  padding: 10px;\n  display: flex;\n  align-items: center;\n  margin: auto;\n}\n.main_content_div .news_card .chip_div .chip ion-label {\n  font-size: 14px;\n  margin-left: 10px;\n}\n.main_content_div .news_card video {\n  width: 100%;\n  border-radius: 10px;\n}\n.main_content_div .news_card .channel_detail {\n  display: flex;\n  margin-top: 15px;\n  align-items: center;\n  margin-bottom: 10px;\n}\n.main_content_div .news_card .channel_detail img {\n  width: 25px;\n}\n.main_content_div .news_card .channel_detail .channel_name {\n  font-weight: 600;\n  font-size: 15px;\n  margin-left: 10px;\n  margin-right: 10px;\n}\n.main_content_div .news_card .channel_detail .follow_lbl {\n  color: var(--ion-color-primary);\n  font-size: 13px;\n  margin-left: 10px;\n}\n.main_content_div .news_card .head_line {\n  font-weight: 500;\n}\n.main_content_div .news_card .link_lbl {\n  margin-top: 10px;\n  font-size: 13px;\n  color: gray;\n}\n.main_content_div .news_card .like_div {\n  display: flex;\n  font-size: 13px;\n  color: #505050;\n  margin-top: 10px;\n  margin-bottom: 10px;\n}\n.main_content_div .news_card .like_div img {\n  width: 20px;\n  height: 20px;\n  margin-right: 10px;\n}\n.main_content_div .news_card .like_div .share_lbl {\n  margin-left: 15px;\n}\n.main_content_div .news_card .share_div {\n  display: flex;\n  width: 100%;\n  justify-content: space-between;\n}\n.main_content_div .news_card .share_div .left_div {\n  display: flex;\n}\n.main_content_div .news_card .share_div .right_div {\n  display: flex;\n  align-items: center;\n}\n.main_content_div .news_card .share_div .right_div ion-button {\n  margin: 0;\n}\n.main_content_div .news_card .share_div .right_div ion-button ion-icon {\n  color: #505050;\n}\n.main_content_div .news_card .share_div .round_div {\n  border: 1px solid lightgray;\n  height: 40px;\n  width: 40px;\n  border-radius: 100%;\n  position: relative;\n  margin-right: 10px;\n}\n.main_content_div .news_card .share_div .round_div ion-icon {\n  position: absolute;\n  top: 50%;\n  left: 50%;\n  transform: translate(-50%, -50%);\n  font-size: 18px;\n  color: #505050;\n}\n.footer_div {\n  padding: 10px 16px;\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  border-top: 1px solid lightgray;\n}\n.footer_div ion-input {\n  border-radius: 25px;\n  border: 1px solid lightgray;\n  height: 45px;\n  --padding-start: 8px;\n}\n.footer_div .blue_div {\n  margin-left: 15px;\n  height: 45px;\n  width: 45px;\n  border-radius: 100%;\n  background: var(--ion-color-primary);\n  position: relative;\n}\n.footer_div .blue_div ion-icon {\n  font-size: 25px;\n  color: white;\n  position: absolute;\n  top: 50%;\n  left: 50%;\n  transform: translate(-50%, -50%);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvY3JpY2tldC1uZXdzL0U6XFxJb25pYyBQcm9qZWN0c1xcaW9uaWMtNS10ZW1wbGF0ZS1idW5kbGUtaW9uaWMtNS10aGVtZXMtYnVuZGxlcy1pb25pYy01LXRlbXBsYXRlcy13aXRoLTEwLWFwcHNcXEFwcF9zb3VyY2VfY29kZVxcQXBwc19jb2RlXFxNdWx0aV9wdXJwb3NlL3NyY1xcYXBwXFxwYWdlc1xcY3JpY2tldC1uZXdzXFxjcmlja2V0LW5ld3MucGFnZS5zY3NzIiwic3JjL2FwcC9wYWdlcy9jcmlja2V0LW5ld3MvY3JpY2tldC1uZXdzLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDSTtFQUNJLFNBQUE7QUNBUjtBREVRO0VBQ0ksWUFBQTtFQUNBLGVBQUE7QUNBWjtBRElBO0VBQ0ksV0FBQTtBQ0RKO0FER0k7RUFDSSxhQUFBO0VBQ0Esa0NBQUE7QUNEUjtBREdRO0VBQ0ksa0JBQUE7RUFDQSxtQkFBQTtBQ0RaO0FER1k7RUFDSSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGlCQUFBO0VBQ0EsbUJBQUE7RUFDQSwwQ0FBQTtBQ0RoQjtBREdZO0VBQ0ksbUJBQUE7RUFDQSwyQkFBQTtFQUNBLDBCQUFBO0VBQUEsdUJBQUE7RUFBQSxrQkFBQTtFQUNBLGFBQUE7RUFDQSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSxZQUFBO0FDRGhCO0FER2dCO0VBQ0ksZUFBQTtFQUNBLGlCQUFBO0FDRHBCO0FETVE7RUFDSSxXQUFBO0VBQ0EsbUJBQUE7QUNKWjtBRE9RO0VBQ0ksYUFBQTtFQUNBLGdCQUFBO0VBQ0EsbUJBQUE7RUFDQSxtQkFBQTtBQ0xaO0FETVk7RUFDSSxXQUFBO0FDSmhCO0FETVk7RUFDSSxnQkFBQTtFQUNBLGVBQUE7RUFDQSxpQkFBQTtFQUNBLGtCQUFBO0FDSmhCO0FETVk7RUFDSSwrQkFBQTtFQUNBLGVBQUE7RUFDQSxpQkFBQTtBQ0poQjtBRFFRO0VBQ0ksZ0JBQUE7QUNOWjtBRFNRO0VBQ0ksZ0JBQUE7RUFDQSxlQUFBO0VBQ0EsV0FBQTtBQ1BaO0FEVVE7RUFDSSxhQUFBO0VBQ0EsZUFBQTtFQUNBLGNBQUE7RUFDQSxnQkFBQTtFQUNBLG1CQUFBO0FDUlo7QURTWTtFQUNJLFdBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7QUNQaEI7QURTWTtFQUNJLGlCQUFBO0FDUGhCO0FEV1E7RUFDSSxhQUFBO0VBQ0EsV0FBQTtFQUNBLDhCQUFBO0FDVFo7QURXWTtFQUNJLGFBQUE7QUNUaEI7QURZWTtFQUNJLGFBQUE7RUFDQSxtQkFBQTtBQ1ZoQjtBRFdnQjtFQUNJLFNBQUE7QUNUcEI7QURXb0I7RUFDSSxjQUFBO0FDVHhCO0FEY1k7RUFDSSwyQkFBQTtFQUNBLFlBQUE7RUFDQSxXQUFBO0VBQ0EsbUJBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0FDWmhCO0FEYWdCO0VBQ0ksa0JBQUE7RUFDQSxRQUFBO0VBQ0EsU0FBQTtFQUNBLGdDQUFBO0VBQ0EsZUFBQTtFQUNBLGNBQUE7QUNYcEI7QURrQkE7RUFDSSxrQkFBQTtFQUNBLGFBQUE7RUFDQSxtQkFBQTtFQUNBLDhCQUFBO0VBQ0EsK0JBQUE7QUNmSjtBRGlCSTtFQUNJLG1CQUFBO0VBQ0EsMkJBQUE7RUFDQSxZQUFBO0VBQ0Esb0JBQUE7QUNmUjtBRGtCSTtFQUNJLGlCQUFBO0VBQ0EsWUFBQTtFQUNBLFdBQUE7RUFDQSxtQkFBQTtFQUNBLG9DQUFBO0VBQ0Esa0JBQUE7QUNoQlI7QURpQlE7RUFDSSxlQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0EsUUFBQTtFQUNBLFNBQUE7RUFDQSxnQ0FBQTtBQ2ZaIiwiZmlsZSI6InNyYy9hcHAvcGFnZXMvY3JpY2tldC1uZXdzL2NyaWNrZXQtbmV3cy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24taGVhZGVyIHtcbiAgICBpb24tYnV0dG9uIHtcbiAgICAgICAgbWFyZ2luOiAwO1xuXG4gICAgICAgIGlvbi1pY29uIHtcbiAgICAgICAgICAgIGNvbG9yOiBibGFjaztcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogMjBweDtcbiAgICAgICAgfVxuICAgIH1cbn1cbi5tYWluX2NvbnRlbnRfZGl2IHtcbiAgICB3aWR0aDogMTAwJTtcblxuICAgIC5uZXdzX2NhcmQge1xuICAgICAgICBwYWRkaW5nOiAxNnB4O1xuICAgICAgICBib3JkZXItYm90dG9tOiAxcHggc29saWQgbGlnaHRncmF5O1xuXG4gICAgICAgIC5jaGlwX2RpdiB7XG4gICAgICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgICAgICAgICBtYXJnaW4tYm90dG9tOiAxNXB4O1xuXG4gICAgICAgICAgICAucm91bmQge1xuICAgICAgICAgICAgICAgIHdpZHRoOiAxNXB4O1xuICAgICAgICAgICAgICAgIGhlaWdodDogMTVweDtcbiAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiB3aGl0ZTtcbiAgICAgICAgICAgICAgICBib3JkZXItcmFkaXVzOiAxMDAlO1xuICAgICAgICAgICAgICAgIGJvcmRlcjogNHB4IHNvbGlkIHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIC5jaGlwIHtcbiAgICAgICAgICAgICAgICBib3JkZXItcmFkaXVzOiAyNXB4O1xuICAgICAgICAgICAgICAgIGJvcmRlcjogMXB4IHNvbGlkIGxpZ2h0Z3JheTtcbiAgICAgICAgICAgICAgICB3aWR0aDogZml0LWNvbnRlbnQ7XG4gICAgICAgICAgICAgICAgcGFkZGluZzogMTBweDtcbiAgICAgICAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICAgICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAgICAgICAgICAgICAgbWFyZ2luOiBhdXRvO1xuXG4gICAgICAgICAgICAgICAgaW9uLWxhYmVsIHtcbiAgICAgICAgICAgICAgICAgICAgZm9udC1zaXplOiAxNHB4O1xuICAgICAgICAgICAgICAgICAgICBtYXJnaW4tbGVmdDogMTBweDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICB2aWRlbyB7XG4gICAgICAgICAgICB3aWR0aDogMTAwJTtcbiAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDEwcHg7XG4gICAgICAgIH1cblxuICAgICAgICAuY2hhbm5lbF9kZXRhaWwge1xuICAgICAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAgICAgIG1hcmdpbi10b3A6IDE1cHg7XG4gICAgICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgICAgICAgICAgbWFyZ2luLWJvdHRvbTogMTBweDtcbiAgICAgICAgICAgIGltZyB7XG4gICAgICAgICAgICAgICAgd2lkdGg6IDI1cHg7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICAuY2hhbm5lbF9uYW1lIHtcbiAgICAgICAgICAgICAgICBmb250LXdlaWdodDogNjAwO1xuICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMTVweDtcbiAgICAgICAgICAgICAgICBtYXJnaW4tbGVmdDogMTBweDtcbiAgICAgICAgICAgICAgICBtYXJnaW4tcmlnaHQ6IDEwcHg7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICAuZm9sbG93X2xibCB7XG4gICAgICAgICAgICAgICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcbiAgICAgICAgICAgICAgICBmb250LXNpemU6IDEzcHg7XG4gICAgICAgICAgICAgICAgbWFyZ2luLWxlZnQ6IDEwcHg7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICAuaGVhZF9saW5lIHtcbiAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiA1MDA7XG4gICAgICAgIH1cblxuICAgICAgICAubGlua19sYmwge1xuICAgICAgICAgICAgbWFyZ2luLXRvcDogMTBweDtcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogMTNweDtcbiAgICAgICAgICAgIGNvbG9yOiBncmF5O1xuICAgICAgICB9XG5cbiAgICAgICAgLmxpa2VfZGl2IHtcbiAgICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgICAgICBmb250LXNpemU6IDEzcHg7XG4gICAgICAgICAgICBjb2xvcjogIzUwNTA1MDtcbiAgICAgICAgICAgIG1hcmdpbi10b3A6IDEwcHg7XG4gICAgICAgICAgICBtYXJnaW4tYm90dG9tOiAxMHB4O1xuICAgICAgICAgICAgaW1nIHtcbiAgICAgICAgICAgICAgICB3aWR0aDogMjBweDtcbiAgICAgICAgICAgICAgICBoZWlnaHQ6IDIwcHg7XG4gICAgICAgICAgICAgICAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgLnNoYXJlX2xibCB7XG4gICAgICAgICAgICAgICAgbWFyZ2luLWxlZnQ6IDE1cHg7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICAuc2hhcmVfZGl2IHtcbiAgICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgICAgICB3aWR0aDogMTAwJTtcbiAgICAgICAgICAgIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcblxuICAgICAgICAgICAgLmxlZnRfZGl2IHtcbiAgICAgICAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAucmlnaHRfZGl2IHtcbiAgICAgICAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICAgICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAgICAgICAgICAgICAgaW9uLWJ1dHRvbiB7XG4gICAgICAgICAgICAgICAgICAgIG1hcmdpbjogMDtcblxuICAgICAgICAgICAgICAgICAgICBpb24taWNvbiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb2xvcjogIzUwNTA1MDtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgLnJvdW5kX2RpdiB7XG4gICAgICAgICAgICAgICAgYm9yZGVyOiAxcHggc29saWQgbGlnaHRncmF5O1xuICAgICAgICAgICAgICAgIGhlaWdodDogNDBweDtcbiAgICAgICAgICAgICAgICB3aWR0aDogNDBweDtcbiAgICAgICAgICAgICAgICBib3JkZXItcmFkaXVzOiAxMDAlO1xuICAgICAgICAgICAgICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgICAgICAgICAgICAgICBtYXJnaW4tcmlnaHQ6IDEwcHg7XG4gICAgICAgICAgICAgICAgaW9uLWljb24ge1xuICAgICAgICAgICAgICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgICAgICAgICAgICAgICAgIHRvcDogNTAlO1xuICAgICAgICAgICAgICAgICAgICBsZWZ0OiA1MCU7XG4gICAgICAgICAgICAgICAgICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlKC01MCUsIC01MCUpO1xuICAgICAgICAgICAgICAgICAgICBmb250LXNpemU6IDE4cHg7XG4gICAgICAgICAgICAgICAgICAgIGNvbG9yOiAjNTA1MDUwO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cbn1cblxuLmZvb3Rlcl9kaXYge1xuICAgIHBhZGRpbmc6IDEwcHggMTZweDtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xuICAgIGJvcmRlci10b3A6IDFweCBzb2xpZCBsaWdodGdyYXk7XG5cbiAgICBpb24taW5wdXQge1xuICAgICAgICBib3JkZXItcmFkaXVzOiAyNXB4O1xuICAgICAgICBib3JkZXI6IDFweCBzb2xpZCBsaWdodGdyYXk7XG4gICAgICAgIGhlaWdodDogNDVweDtcbiAgICAgICAgLS1wYWRkaW5nLXN0YXJ0OiA4cHg7XG4gICAgfVxuXG4gICAgLmJsdWVfZGl2IHtcbiAgICAgICAgbWFyZ2luLWxlZnQ6IDE1cHg7XG4gICAgICAgIGhlaWdodDogNDVweDtcbiAgICAgICAgd2lkdGg6IDQ1cHg7XG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDEwMCU7XG4gICAgICAgIGJhY2tncm91bmQ6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcbiAgICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xuICAgICAgICBpb24taWNvbiB7XG4gICAgICAgICAgICBmb250LXNpemU6IDI1cHg7XG4gICAgICAgICAgICBjb2xvcjogd2hpdGU7XG4gICAgICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgICAgICAgICB0b3A6IDUwJTtcbiAgICAgICAgICAgIGxlZnQ6IDUwJTtcbiAgICAgICAgICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlKC01MCUsIC01MCUpO1xuICAgICAgICB9XG4gICAgfVxufVxuIiwiaW9uLWhlYWRlciBpb24tYnV0dG9uIHtcbiAgbWFyZ2luOiAwO1xufVxuaW9uLWhlYWRlciBpb24tYnV0dG9uIGlvbi1pY29uIHtcbiAgY29sb3I6IGJsYWNrO1xuICBmb250LXNpemU6IDIwcHg7XG59XG5cbi5tYWluX2NvbnRlbnRfZGl2IHtcbiAgd2lkdGg6IDEwMCU7XG59XG4ubWFpbl9jb250ZW50X2RpdiAubmV3c19jYXJkIHtcbiAgcGFkZGluZzogMTZweDtcbiAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkIGxpZ2h0Z3JheTtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5uZXdzX2NhcmQgLmNoaXBfZGl2IHtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBtYXJnaW4tYm90dG9tOiAxNXB4O1xufVxuLm1haW5fY29udGVudF9kaXYgLm5ld3NfY2FyZCAuY2hpcF9kaXYgLnJvdW5kIHtcbiAgd2lkdGg6IDE1cHg7XG4gIGhlaWdodDogMTVweDtcbiAgYmFja2dyb3VuZDogd2hpdGU7XG4gIGJvcmRlci1yYWRpdXM6IDEwMCU7XG4gIGJvcmRlcjogNHB4IHNvbGlkIHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5uZXdzX2NhcmQgLmNoaXBfZGl2IC5jaGlwIHtcbiAgYm9yZGVyLXJhZGl1czogMjVweDtcbiAgYm9yZGVyOiAxcHggc29saWQgbGlnaHRncmF5O1xuICB3aWR0aDogZml0LWNvbnRlbnQ7XG4gIHBhZGRpbmc6IDEwcHg7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIG1hcmdpbjogYXV0bztcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5uZXdzX2NhcmQgLmNoaXBfZGl2IC5jaGlwIGlvbi1sYWJlbCB7XG4gIGZvbnQtc2l6ZTogMTRweDtcbiAgbWFyZ2luLWxlZnQ6IDEwcHg7XG59XG4ubWFpbl9jb250ZW50X2RpdiAubmV3c19jYXJkIHZpZGVvIHtcbiAgd2lkdGg6IDEwMCU7XG4gIGJvcmRlci1yYWRpdXM6IDEwcHg7XG59XG4ubWFpbl9jb250ZW50X2RpdiAubmV3c19jYXJkIC5jaGFubmVsX2RldGFpbCB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIG1hcmdpbi10b3A6IDE1cHg7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIG1hcmdpbi1ib3R0b206IDEwcHg7XG59XG4ubWFpbl9jb250ZW50X2RpdiAubmV3c19jYXJkIC5jaGFubmVsX2RldGFpbCBpbWcge1xuICB3aWR0aDogMjVweDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5uZXdzX2NhcmQgLmNoYW5uZWxfZGV0YWlsIC5jaGFubmVsX25hbWUge1xuICBmb250LXdlaWdodDogNjAwO1xuICBmb250LXNpemU6IDE1cHg7XG4gIG1hcmdpbi1sZWZ0OiAxMHB4O1xuICBtYXJnaW4tcmlnaHQ6IDEwcHg7XG59XG4ubWFpbl9jb250ZW50X2RpdiAubmV3c19jYXJkIC5jaGFubmVsX2RldGFpbCAuZm9sbG93X2xibCB7XG4gIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XG4gIGZvbnQtc2l6ZTogMTNweDtcbiAgbWFyZ2luLWxlZnQ6IDEwcHg7XG59XG4ubWFpbl9jb250ZW50X2RpdiAubmV3c19jYXJkIC5oZWFkX2xpbmUge1xuICBmb250LXdlaWdodDogNTAwO1xufVxuLm1haW5fY29udGVudF9kaXYgLm5ld3NfY2FyZCAubGlua19sYmwge1xuICBtYXJnaW4tdG9wOiAxMHB4O1xuICBmb250LXNpemU6IDEzcHg7XG4gIGNvbG9yOiBncmF5O1xufVxuLm1haW5fY29udGVudF9kaXYgLm5ld3NfY2FyZCAubGlrZV9kaXYge1xuICBkaXNwbGF5OiBmbGV4O1xuICBmb250LXNpemU6IDEzcHg7XG4gIGNvbG9yOiAjNTA1MDUwO1xuICBtYXJnaW4tdG9wOiAxMHB4O1xuICBtYXJnaW4tYm90dG9tOiAxMHB4O1xufVxuLm1haW5fY29udGVudF9kaXYgLm5ld3NfY2FyZCAubGlrZV9kaXYgaW1nIHtcbiAgd2lkdGg6IDIwcHg7XG4gIGhlaWdodDogMjBweDtcbiAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xufVxuLm1haW5fY29udGVudF9kaXYgLm5ld3NfY2FyZCAubGlrZV9kaXYgLnNoYXJlX2xibCB7XG4gIG1hcmdpbi1sZWZ0OiAxNXB4O1xufVxuLm1haW5fY29udGVudF9kaXYgLm5ld3NfY2FyZCAuc2hhcmVfZGl2IHtcbiAgZGlzcGxheTogZmxleDtcbiAgd2lkdGg6IDEwMCU7XG4gIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2Vlbjtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5uZXdzX2NhcmQgLnNoYXJlX2RpdiAubGVmdF9kaXYge1xuICBkaXNwbGF5OiBmbGV4O1xufVxuLm1haW5fY29udGVudF9kaXYgLm5ld3NfY2FyZCAuc2hhcmVfZGl2IC5yaWdodF9kaXYge1xuICBkaXNwbGF5OiBmbGV4O1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xufVxuLm1haW5fY29udGVudF9kaXYgLm5ld3NfY2FyZCAuc2hhcmVfZGl2IC5yaWdodF9kaXYgaW9uLWJ1dHRvbiB7XG4gIG1hcmdpbjogMDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5uZXdzX2NhcmQgLnNoYXJlX2RpdiAucmlnaHRfZGl2IGlvbi1idXR0b24gaW9uLWljb24ge1xuICBjb2xvcjogIzUwNTA1MDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5uZXdzX2NhcmQgLnNoYXJlX2RpdiAucm91bmRfZGl2IHtcbiAgYm9yZGVyOiAxcHggc29saWQgbGlnaHRncmF5O1xuICBoZWlnaHQ6IDQwcHg7XG4gIHdpZHRoOiA0MHB4O1xuICBib3JkZXItcmFkaXVzOiAxMDAlO1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIG1hcmdpbi1yaWdodDogMTBweDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5uZXdzX2NhcmQgLnNoYXJlX2RpdiAucm91bmRfZGl2IGlvbi1pY29uIHtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICB0b3A6IDUwJTtcbiAgbGVmdDogNTAlO1xuICB0cmFuc2Zvcm06IHRyYW5zbGF0ZSgtNTAlLCAtNTAlKTtcbiAgZm9udC1zaXplOiAxOHB4O1xuICBjb2xvcjogIzUwNTA1MDtcbn1cblxuLmZvb3Rlcl9kaXYge1xuICBwYWRkaW5nOiAxMHB4IDE2cHg7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcbiAgYm9yZGVyLXRvcDogMXB4IHNvbGlkIGxpZ2h0Z3JheTtcbn1cbi5mb290ZXJfZGl2IGlvbi1pbnB1dCB7XG4gIGJvcmRlci1yYWRpdXM6IDI1cHg7XG4gIGJvcmRlcjogMXB4IHNvbGlkIGxpZ2h0Z3JheTtcbiAgaGVpZ2h0OiA0NXB4O1xuICAtLXBhZGRpbmctc3RhcnQ6IDhweDtcbn1cbi5mb290ZXJfZGl2IC5ibHVlX2RpdiB7XG4gIG1hcmdpbi1sZWZ0OiAxNXB4O1xuICBoZWlnaHQ6IDQ1cHg7XG4gIHdpZHRoOiA0NXB4O1xuICBib3JkZXItcmFkaXVzOiAxMDAlO1xuICBiYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbn1cbi5mb290ZXJfZGl2IC5ibHVlX2RpdiBpb24taWNvbiB7XG4gIGZvbnQtc2l6ZTogMjVweDtcbiAgY29sb3I6IHdoaXRlO1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHRvcDogNTAlO1xuICBsZWZ0OiA1MCU7XG4gIHRyYW5zZm9ybTogdHJhbnNsYXRlKC01MCUsIC01MCUpO1xufSJdfQ== */";
    /***/
  },

  /***/
  "./src/app/pages/cricket-news/cricket-news.page.ts":
  /*!*********************************************************!*\
    !*** ./src/app/pages/cricket-news/cricket-news.page.ts ***!
    \*********************************************************/

  /*! exports provided: CricketNewsPage */

  /***/
  function srcAppPagesCricketNewsCricketNewsPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "CricketNewsPage", function () {
      return CricketNewsPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");

    var CricketNewsPage = /*#__PURE__*/function () {
      function CricketNewsPage() {
        _classCallCheck(this, CricketNewsPage);
      }

      _createClass(CricketNewsPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }]);

      return CricketNewsPage;
    }();

    CricketNewsPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-cricket-news',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./cricket-news.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/cricket-news/cricket-news.page.html"))["default"],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./cricket-news.page.scss */
      "./src/app/pages/cricket-news/cricket-news.page.scss"))["default"]]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])], CricketNewsPage);
    /***/
  }
}]);
//# sourceMappingURL=pages-cricket-news-cricket-news-module-es5.js.map