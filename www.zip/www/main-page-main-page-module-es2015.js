(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main-page-main-page-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/main-page/main-page.page.html":
/*!*******************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/main-page/main-page.page.html ***!
  \*******************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <div class=\"header_div\" [class.ios_pad]=\"plt == 'ios'\">\n\n    <ion-buttons slot=\"start\">\n      <ion-menu-button></ion-menu-button>\n    </ion-buttons>\n    <img src=\"assets/imgs/logo.png\" alt=\"\">\n\n    <div class=\"btn_div\">\n\n      <ion-button (click)=\"shareActionSheet()\" size=\"small\" fill=\"clear\">\n        <ion-icon name=\"arrow-redo-outline\"></ion-icon>\n      </ion-button>\n\n      <ion-button size=\"small\" fill=\"clear\">\n        <ion-icon name=\"notifications-outline\"></ion-icon>\n      </ion-button>\n\n    </div>\n\n  </div>\n</ion-header>\n\n<ion-content>\n  <div class=\"main_content_div\">\n\n    <div class=\"search_div\">\n      <ion-input type=\"text\" placeholder=\"Search\">\n        <ion-icon name=\"search-outline\"></ion-icon>\n      </ion-input>\n    </div>\n\n    <div class=\"search_div\">\n      <div class=\"chips_div\">\n        <div class=\"test\" [class.active]=\"id == i\" *ngFor=\"let item of moviesCat; let i = index\">\n          <ion-label class=\"chip\" (click)=\"selectCat(item)\">{{item}}</ion-label>\n          <span class=\"line_span\" *ngIf=\"id == item\"></span>\n        </div>\n      </div>\n    </div>\n\n    <div *ngIf=\"id == 'Search'\">\n      <div class=\"search_card\" *ngFor=\"let item of clinic\">\n\n        <div class=\"search_flex\">\n\n          <div class=\"back_image bg_image\" [style.backgroundImage]=\"'url( '+ item.img +' )'\"></div>\n\n          <div class=\"search_detail\">\n            <ion-label class=\"heal_lbl\">{{item.name}}</ion-label>\n            <ion-label class=\"small\">Jail Road • <span>3.2</span></ion-label>\n\n            <div class=\"inner_flex\">\n              <ion-label class=\"rate\">3.2 KM</ion-label>\n\n              <div>\n                <!-- <ion-rating \n                [rate]=\"rate\"\n                [(ngModel)] = \"rate\"\n                readonly=\"false\"\n                size=\"small\"\n                (rateChange)=\"onRateChange($event)\">\n                </ion-rating> -->\n                <ion-icon name=\"star\"></ion-icon>\n                <ion-icon name=\"star\"></ion-icon>\n                <ion-icon name=\"star\"></ion-icon>\n                <ion-icon name=\"star\"></ion-icon>\n                <ion-icon name=\"star\"></ion-icon>\n              </div>\n\n              <ion-label class=\"light\">13 Ratings</ion-label>\n\n            </div>\n          </div>\n        </div>\n\n        <div class=\"btn_flex\">\n          <div class=\"btns1\">\n            <ion-button class=\"b1\" expand=\"block\" shape=\"round\" fill=\"clear\">\n              <ion-icon slot=\"start\" name=\"call\"></ion-icon>\n              <ion-label>Call Now</ion-label>\n            </ion-button>\n          </div>\n          <div class=\"btns2\">\n            <ion-button class=\"b2\" expand=\"block\" shape=\"round\">\n              <ion-label>Get Best Deal</ion-label>\n            </ion-button>\n          </div>\n        </div>\n\n      </div>\n    </div>\n\n    <div *ngIf=\"id == 'Shopping'\">\n\n      <div class=\"category_div\">\n\n      </div>\n\n      <div class=\"slider_div\">\n        <ion-slides mode=\"ios\" pager=\"ios\">\n          <ion-slide *ngFor=\"let item of slider\">\n            <div class=\"slide_image bg_image\" [style.backgroundImage]=\"'url( '+ item.img +' )'\"></div>\n          </ion-slide>\n        </ion-slides>\n      </div>\n\n      <div class=\"product_div\">\n        <ion-label class=\"header_lbl\">Electronics</ion-label>\n        <ion-grid fixed>\n          <ion-row>\n            <ion-col size=\"4\" *ngFor=\"let item of (products | slice : 0 : 3)\">\n              <img src=\"{{item.img}}\">\n              <ion-label>{{item.name}}</ion-label>\n            </ion-col>\n          </ion-row>\n        </ion-grid>\n      </div>\n\n      <div class=\"product_div\">\n        <ion-label class=\"header_lbl\">Fashion</ion-label>\n        <ion-grid fixed>\n          <ion-row>\n            <ion-col size=\"4\" *ngFor=\"let item of (products | slice : 3 : 6)\">\n              <img src=\"{{item.img}}\">\n              <ion-label>{{item.name}}</ion-label>\n            </ion-col>\n          </ion-row>\n        </ion-grid>\n      </div>\n\n      <div class=\"cover_div\">\n        <div class=\"cover_image bg_image\" [style.backgroundImage]=\"'url(assets/imgs/shop/fit.jpg)'\"></div>\n        <ion-grid fixed>\n          <ion-row>\n            <ion-col size=\"4\">\n              <img src=\"assets/imgs/shop/fit1.png\">\n            </ion-col>\n            <ion-col size=\"4\">\n              <img src=\"assets/imgs/shop/fit2.jpg\">\n            </ion-col>\n            <ion-col size=\"4\">\n              <img src=\"assets/imgs/shop/fit3.gif\">\n            </ion-col>\n          </ion-row>\n        </ion-grid>\n      </div>\n\n      <div class=\"product_div\">\n        <ion-label class=\"header_lbl\">Luxurious Product For Your Beauty Routine</ion-label>\n        <ion-grid fixed>\n          <ion-row>\n            <ion-col size=\"6\" *ngFor=\"let item of beauty\">\n              <div class=\"pro_div bg_image\" [style.backgroundImage]=\"'url( '+ item.img +' )'\"></div>\n              <ion-label class=\"left_lbl\">{{item.name}}</ion-label>\n            </ion-col>\n          </ion-row>\n        </ion-grid>\n\n        <ion-label class=\"light_lbl\">Explore range of Products</ion-label>\n      </div>\n\n      <div class=\"product_div\">\n        <ion-label class=\"blue_lbl\">Explore More</ion-label>\n      </div>\n\n      <div class=\"product_div\">\n        <ion-label class=\"header_lbl\">Home</ion-label>\n        <ion-grid fixed>\n          <ion-row>\n            <ion-col size=\"4\" *ngFor=\"let item of (products | slice : 6 )\">\n              <img src=\"{{item.img}}\">\n              <ion-label>{{item.name}}</ion-label>\n            </ion-col>\n          </ion-row>\n        </ion-grid>\n      </div>\n\n      <div class=\"today_deals\">\n        <ion-label class=\"header_lbl\">Home</ion-label>\n\n        <img class=\"main_img\" src=\"assets/imgs/shop/deal1.jpg\" alt=\"\">\n\n        <ion-label class=\"deal_detail\">\n          Samsung Wired gaming Earphone with Dual Driver and Mic\n        </ion-label>\n        <ion-label class=\"deal_detail\">₹ 1799.00</ion-label>\n\n        <div class=\"deal_slider\">\n          <ion-slides mode=\"ios\" [options]=\"slideOpts\">\n            <ion-slide *ngFor=\"let item of deal\">\n              <div>\n                <img src=\"{{item.img}}\" alt=\"\">\n              </div>\n            </ion-slide>\n          </ion-slides>\n        </div>\n      </div>\n\n      <div class=\"product_div\">\n        <ion-label class=\"blue_lbl\">Explore More</ion-label>\n      </div>\n\n      <div class=\"feature_div\">\n        <ion-label class=\"header_lbl\">Featured Categories</ion-label>\n\n        <ion-slides mode=\"ios\" [options]=\"slideOpts2\">\n          <ion-slide *ngFor=\"let item of featureCat\">\n            <div class=\"back_image bg_image\" [style.backgroundImage]=\"'url( '+ item.img +' )'\">\n              <div class=\"overlay\">\n                <ion-label>{{item.name}}</ion-label>\n              </div>\n            </div>\n          </ion-slide>\n        </ion-slides>\n\n      </div>\n\n    </div>\n\n    <div *ngIf=\"id == 'Images'\">\n      <div class=\"images_div\">\n\n        <div class=\"masonry\">\n          <div class=\"item\" *ngFor=\"let item of images\">\n            <!-- <div class=\"overlay\"> -->\n            <img src=\"{{item.img}}\">\n            <ion-label>{{item.name}}</ion-label>\n            <!-- </div> -->\n          </div>\n        </div>\n\n      </div>\n    </div>\n\n  </div>\n</ion-content>");

/***/ }),

/***/ "./src/app/pages/main-page/main-page-routing.module.ts":
/*!*************************************************************!*\
  !*** ./src/app/pages/main-page/main-page-routing.module.ts ***!
  \*************************************************************/
/*! exports provided: MainPagePageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MainPagePageRoutingModule", function() { return MainPagePageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _main_page_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./main-page.page */ "./src/app/pages/main-page/main-page.page.ts");




const routes = [
    {
        path: '',
        component: _main_page_page__WEBPACK_IMPORTED_MODULE_3__["MainPagePage"]
    }
];
let MainPagePageRoutingModule = class MainPagePageRoutingModule {
};
MainPagePageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], MainPagePageRoutingModule);



/***/ }),

/***/ "./src/app/pages/main-page/main-page.module.ts":
/*!*****************************************************!*\
  !*** ./src/app/pages/main-page/main-page.module.ts ***!
  \*****************************************************/
/*! exports provided: MainPagePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MainPagePageModule", function() { return MainPagePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _main_page_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./main-page-routing.module */ "./src/app/pages/main-page/main-page-routing.module.ts");
/* harmony import */ var _main_page_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./main-page.page */ "./src/app/pages/main-page/main-page.page.ts");
/* harmony import */ var ionic_rating__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ionic-rating */ "./node_modules/ionic-rating/fesm2015/ionic-rating.js");








let MainPagePageModule = class MainPagePageModule {
};
MainPagePageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            ionic_rating__WEBPACK_IMPORTED_MODULE_7__["IonicRatingModule"],
            _main_page_routing_module__WEBPACK_IMPORTED_MODULE_5__["MainPagePageRoutingModule"]
        ],
        declarations: [_main_page_page__WEBPACK_IMPORTED_MODULE_6__["MainPagePage"]]
    })
], MainPagePageModule);



/***/ }),

/***/ "./src/app/pages/main-page/main-page.page.scss":
/*!*****************************************************!*\
  !*** ./src/app/pages/main-page/main-page.page.scss ***!
  \*****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".header_div {\n  width: 100%;\n  display: flex;\n  justify-content: space-between;\n  position: relative;\n  padding: 5px;\n}\n.header_div img {\n  width: 100px;\n  position: absolute;\n  left: 50%;\n  transform: translate(-50%);\n}\n.header_div .btn_div {\n  display: flex;\n}\n.header_div ion-button {\n  color: black;\n}\n.main_content_div {\n  width: 100%;\n}\n.main_content_div ion-label {\n  display: block;\n}\n.main_content_div .search_card {\n  padding: 16px;\n  border-bottom: 1px solid lightgray;\n}\n.main_content_div .search_card .search_flex {\n  display: flex;\n}\n.main_content_div .search_card .search_flex .back_image {\n  width: 90px;\n  height: 90px;\n  border-radius: 5px;\n  min-width: 90px;\n}\n.main_content_div .search_card .search_flex .search_detail {\n  padding-left: 10px;\n}\n.main_content_div .search_card .search_flex .search_detail .heal_lbl {\n  font-weight: 500;\n  font-size: 15px;\n  margin-bottom: 5px;\n}\n.main_content_div .search_card .search_flex .search_detail .small {\n  font-size: 13px;\n  color: gray;\n}\n.main_content_div .search_card .search_flex .search_detail .small span {\n  color: black;\n  font-weight: 500;\n  font-size: 14px;\n}\n.main_content_div .search_card .search_flex .search_detail .inner_flex {\n  display: flex;\n  margin-top: 7px;\n}\n.main_content_div .search_card .search_flex .search_detail .inner_flex .rate {\n  font-size: 14px;\n  font-weight: 600;\n  margin-right: 10px;\n}\n.main_content_div .search_card .search_flex .search_detail .inner_flex ion-icon {\n  margin-left: 3px;\n  color: gray;\n}\n.main_content_div .search_card .search_flex .search_detail .inner_flex .light {\n  font-size: 13px;\n  color: gray;\n  margin-left: 7px;\n}\n.main_content_div .search_card .btn_flex {\n  display: flex;\n  margin-top: 10px;\n  height: 35px;\n}\n.main_content_div .search_card .btn_flex .btns1 {\n  width: 100%;\n  overflow: hidden;\n  margin-right: 10px;\n  border-right: 1px solid var(--ion-color-primary);\n}\n.main_content_div .search_card .btn_flex .btns2 {\n  width: 100%;\n  overflow: hidden;\n}\n.main_content_div .search_card .btn_flex .b1 {\n  margin-right: -20px;\n  margin-top: 0px;\n  margin-bottom: 0px;\n  height: 35px;\n  border: 1px solid var(--ion-color-primary);\n  border-radius: 25px;\n}\n.main_content_div .search_card .btn_flex .b1 ion-icon {\n  font-size: 16px;\n}\n.main_content_div .search_card .btn_flex .b1 ion-label {\n  font-size: 14px;\n}\n.main_content_div .search_card .btn_flex .b2 {\n  margin-left: -20px;\n  margin-top: 0px;\n  margin-bottom: 0px;\n  height: 35px;\n}\n.main_content_div .search_card .btn_flex .b2 ion-label {\n  font-size: 14px;\n  padding-left: 16px;\n}\n.main_content_div .search_div {\n  padding: 10px 16px;\n  border-bottom: 1px solid lightgray;\n}\n.main_content_div .search_div ion-input {\n  border: 1px solid black;\n  border-radius: 25px;\n}\n.main_content_div .search_div ion-input ion-icon {\n  font-size: 20px;\n  padding-left: 10px;\n  padding-right: 5px;\n}\n.main_content_div .search_div .test {\n  display: flex;\n  align-items: center;\n  margin-right: 10px;\n  border-radius: 25px;\n  padding: 5px 15px;\n  flex-direction: column;\n}\n.main_content_div .search_div .test ion-icon {\n  font-size: 26px;\n  color: var(--ion-color-primary);\n}\n.main_content_div .search_div .active ion-label {\n  color: var(--ion-color-primary) !important;\n}\n.main_content_div .search_div .chips_div {\n  display: flex;\n  flex-direction: row;\n  overflow: scroll;\n}\n.main_content_div .search_div .chips_div .chip {\n  white-space: nowrap;\n  color: black;\n  font-size: 13px;\n  font-weight: 500;\n}\n.main_content_div .search_div .chips_div .line_span {\n  margin-top: 7px;\n  width: 20px;\n  height: 2px;\n  background: var(--ion-color-primary);\n}\n.main_content_div .category_div {\n  padding: 10px 16px;\n}\n.main_content_div .slider_div {\n  padding: 0px 16px;\n}\n.main_content_div .slider_div ion-slide {\n  margin-right: 10px;\n}\n.main_content_div .slider_div .slide_image {\n  width: 100%;\n  height: 170px;\n  border-radius: 5px;\n}\n.main_content_div .product_div {\n  padding: 16px;\n  border-bottom: 1px solid lightgray;\n}\n.main_content_div .product_div .header_lbl {\n  font-size: 15px;\n  font-weight: 500;\n  margin-bottom: 10px;\n}\n.main_content_div .product_div ion-grid {\n  padding: 0;\n}\n.main_content_div .product_div ion-grid ion-col {\n  text-align: center;\n}\n.main_content_div .product_div ion-grid ion-col img {\n  width: 70px;\n  height: 70px;\n}\n.main_content_div .product_div ion-grid ion-col ion-label {\n  font-size: 13px;\n  margin-top: 5px;\n}\n.main_content_div .product_div ion-grid ion-col .pro_div {\n  width: 100%;\n  height: 120px;\n  border-radius: 5px;\n}\n.main_content_div .product_div ion-grid ion-col .left_lbl {\n  text-align: left;\n  text-transform: uppercase;\n  color: gray;\n  font-size: 11px;\n  font-weight: 500;\n}\n.main_content_div .product_div .light_lbl {\n  color: gray;\n  font-size: 12px;\n  margin-top: 15px;\n}\n.main_content_div .product_div .blue_lbl {\n  font-size: 13px;\n  color: var(--ion-color-primary);\n  text-align: center;\n}\n.main_content_div .cover_div {\n  padding: 16px;\n  border-bottom: 1px solid lightgray;\n}\n.main_content_div .cover_div .cover_image {\n  height: 230px;\n  width: 100%;\n  border-radius: 5px;\n}\n.main_content_div .cover_div ion-grid {\n  padding: 0;\n}\n.main_content_div .cover_div ion-grid ion-col {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n}\n.main_content_div .cover_div ion-grid ion-col img {\n  width: 80px;\n}\n.main_content_div .today_deals {\n  padding: 16px;\n  border-bottom: 1px solid lightgray;\n}\n.main_content_div .today_deals .header_lbl {\n  font-size: 15px;\n  font-weight: 500;\n  margin-bottom: 10px;\n}\n.main_content_div .today_deals .main_img {\n  width: 70%;\n  display: block;\n  margin: auto;\n}\n.main_content_div .today_deals .deal_detail {\n  font-weight: 500;\n  font-size: 14px;\n  margin-bottom: 8px;\n}\n.main_content_div .today_deals .deal_slider {\n  margin-top: 20px;\n}\n.main_content_div .today_deals .deal_slider div {\n  width: 90%;\n  border: 1px solid lightgray;\n  padding: 5px;\n}\n.main_content_div .feature_div {\n  padding: 16px;\n}\n.main_content_div .feature_div .header_lbl {\n  font-size: 15px;\n  font-weight: 500;\n  margin-bottom: 10px;\n}\n.main_content_div .feature_div ion-slide {\n  margin-right: 15px;\n}\n.main_content_div .feature_div .back_image {\n  height: 150px;\n  width: 100%;\n  border-radius: 7px;\n}\n.main_content_div .feature_div .back_image .overlay {\n  height: 150px;\n  width: 100%;\n  border-radius: 7px;\n  background: rgba(0, 0, 0, 0.3);\n  background: linear-gradient(rgba(255, 255, 255, 0.1), rgba(0, 0, 0, 0.5));\n  position: relative;\n}\n.main_content_div .feature_div .back_image .overlay ion-label {\n  position: absolute;\n  bottom: 0;\n  color: white;\n  font-weight: 500;\n  font-size: 14px;\n  text-align: left;\n  padding: 7px;\n}\n.main_content_div .images_div {\n  padding: 10px;\n}\n.main_content_div .images_div .masonry {\n  /* Masonry container */\n  -moz-column-count: 4;\n  column-count: 2;\n  -moz-column-gap: 1em;\n  column-gap: 1em;\n  margin: 0px;\n  padding: 0;\n  -moz-column-gap: 1.5em;\n  column-gap: 3px;\n  font-size: 0.85em;\n  text-align: center;\n}\n.main_content_div .images_div .item {\n  display: inline-block;\n  background: #fff;\n  padding: 5px;\n  margin: 5px;\n  width: 95%;\n  box-sizing: border-box;\n  -moz-box-sizing: border-box;\n  -webkit-box-sizing: border-box;\n  border-radius: 10px;\n  text-align: left;\n  position: relative;\n}\n.main_content_div .images_div .item ion-label {\n  position: absolute;\n  bottom: 10px;\n  color: white;\n  font-weight: 600;\n  font-size: 15px;\n  padding: 7px;\n}\n.main_content_div .images_div .item .overlay {\n  height: 100%;\n  width: 100%;\n  border-radius: 10px;\n  background: rgba(0, 0, 0, 0.3);\n}\n.main_content_div .images_div .item img {\n  width: 100%;\n  border-radius: 10px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvbWFpbi1wYWdlL0U6XFxJb25pYyBQcm9qZWN0c1xcaW9uaWMtNS10ZW1wbGF0ZS1idW5kbGUtaW9uaWMtNS10aGVtZXMtYnVuZGxlcy1pb25pYy01LXRlbXBsYXRlcy13aXRoLTEwLWFwcHNcXEFwcF9zb3VyY2VfY29kZVxcQXBwc19jb2RlXFxNdWx0aV9wdXJwb3NlL3NyY1xcYXBwXFxwYWdlc1xcbWFpbi1wYWdlXFxtYWluLXBhZ2UucGFnZS5zY3NzIiwic3JjL2FwcC9wYWdlcy9tYWluLXBhZ2UvbWFpbi1wYWdlLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLFdBQUE7RUFDQSxhQUFBO0VBQ0EsOEJBQUE7RUFDQSxrQkFBQTtFQUNBLFlBQUE7QUNDSjtBREFJO0VBQ0ksWUFBQTtFQUNBLGtCQUFBO0VBQ0EsU0FBQTtFQUNBLDBCQUFBO0FDRVI7QURBSTtFQUNJLGFBQUE7QUNFUjtBREFJO0VBQ0ksWUFBQTtBQ0VSO0FERUE7RUFDSSxXQUFBO0FDQ0o7QURDSTtFQUNJLGNBQUE7QUNDUjtBREVJO0VBQ0ksYUFBQTtFQUNBLGtDQUFBO0FDQVI7QURDUTtFQUNJLGFBQUE7QUNDWjtBRENZO0VBQ0ksV0FBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLGVBQUE7QUNDaEI7QURFWTtFQUNJLGtCQUFBO0FDQWhCO0FERWdCO0VBQ0ksZ0JBQUE7RUFDQSxlQUFBO0VBQ0Esa0JBQUE7QUNBcEI7QURHZ0I7RUFDSSxlQUFBO0VBQ0EsV0FBQTtBQ0RwQjtBREdvQjtFQUNJLFlBQUE7RUFDQSxnQkFBQTtFQUNBLGVBQUE7QUNEeEI7QURLZ0I7RUFDSSxhQUFBO0VBQ0EsZUFBQTtBQ0hwQjtBRElvQjtFQUNJLGVBQUE7RUFDQSxnQkFBQTtFQUNBLGtCQUFBO0FDRnhCO0FES29CO0VBQ0ksZ0JBQUE7RUFDQSxXQUFBO0FDSHhCO0FES29CO0VBQ0ksZUFBQTtFQUNBLFdBQUE7RUFDQSxnQkFBQTtBQ0h4QjtBRFFRO0VBQ0ksYUFBQTtFQUNBLGdCQUFBO0VBQ0EsWUFBQTtBQ05aO0FEUVk7RUFDSSxXQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQkFBQTtFQUNBLGdEQUFBO0FDTmhCO0FEUVk7RUFDSSxXQUFBO0VBQ0EsZ0JBQUE7QUNOaEI7QURRWTtFQUNJLG1CQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0VBQ0EsWUFBQTtFQUNBLDBDQUFBO0VBQ0EsbUJBQUE7QUNOaEI7QURRZ0I7RUFDSSxlQUFBO0FDTnBCO0FEUWdCO0VBQ0ksZUFBQTtBQ05wQjtBRFVZO0VBQ0ksa0JBQUE7RUFDQSxlQUFBO0VBQ0Esa0JBQUE7RUFDQSxZQUFBO0FDUmhCO0FEVWdCO0VBQ0ksZUFBQTtFQUNBLGtCQUFBO0FDUnBCO0FEZ0JJO0VBQ0ksa0JBQUE7RUFDQSxrQ0FBQTtBQ2RSO0FEZ0JRO0VBQ0ksdUJBQUE7RUFDQSxtQkFBQTtBQ2RaO0FEZVk7RUFDSSxlQUFBO0VBQ0Esa0JBQUE7RUFDQSxrQkFBQTtBQ2JoQjtBRGlCUTtFQUNJLGFBQUE7RUFDQSxtQkFBQTtFQUNBLGtCQUFBO0VBQ0EsbUJBQUE7RUFDQSxpQkFBQTtFQUNBLHNCQUFBO0FDZlo7QURpQlk7RUFDSSxlQUFBO0VBQ0EsK0JBQUE7QUNmaEI7QURvQlk7RUFDSSwwQ0FBQTtBQ2xCaEI7QURzQlE7RUFDSSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSxnQkFBQTtBQ3BCWjtBRHFCWTtFQUNJLG1CQUFBO0VBQ0EsWUFBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtBQ25CaEI7QURzQlk7RUFDSSxlQUFBO0VBQ0EsV0FBQTtFQUNBLFdBQUE7RUFDQSxvQ0FBQTtBQ3BCaEI7QUR5Qkk7RUFDSSxrQkFBQTtBQ3ZCUjtBRDBCSTtFQUNJLGlCQUFBO0FDeEJSO0FEeUJRO0VBQ0ksa0JBQUE7QUN2Qlo7QUQwQlE7RUFDSSxXQUFBO0VBQ0EsYUFBQTtFQUNBLGtCQUFBO0FDeEJaO0FENEJJO0VBQ0ksYUFBQTtFQUNBLGtDQUFBO0FDMUJSO0FENEJRO0VBQ0ksZUFBQTtFQUNBLGdCQUFBO0VBQ0EsbUJBQUE7QUMxQlo7QUQ0QlE7RUFDSSxVQUFBO0FDMUJaO0FENEJZO0VBQ0ksa0JBQUE7QUMxQmhCO0FENEJnQjtFQUNJLFdBQUE7RUFDQSxZQUFBO0FDMUJwQjtBRDRCZ0I7RUFDSSxlQUFBO0VBQ0EsZUFBQTtBQzFCcEI7QUQ2QmdCO0VBQ0ksV0FBQTtFQUNBLGFBQUE7RUFDQSxrQkFBQTtBQzNCcEI7QUQ4QmdCO0VBQ0ksZ0JBQUE7RUFDQSx5QkFBQTtFQUNBLFdBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7QUM1QnBCO0FEaUNRO0VBQ0ksV0FBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtBQy9CWjtBRGlDUTtFQUNJLGVBQUE7RUFDQSwrQkFBQTtFQUNBLGtCQUFBO0FDL0JaO0FEbUNJO0VBQ0ksYUFBQTtFQUNBLGtDQUFBO0FDakNSO0FEbUNRO0VBQ0ksYUFBQTtFQUNBLFdBQUE7RUFDQSxrQkFBQTtBQ2pDWjtBRG1DUTtFQUNJLFVBQUE7QUNqQ1o7QURrQ1k7RUFDSSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSx1QkFBQTtBQ2hDaEI7QURpQ2dCO0VBQ0ksV0FBQTtBQy9CcEI7QURxQ0k7RUFDSSxhQUFBO0VBQ0Esa0NBQUE7QUNuQ1I7QURxQ1E7RUFDSSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSxtQkFBQTtBQ25DWjtBRHNDUTtFQUNJLFVBQUE7RUFDQSxjQUFBO0VBQ0EsWUFBQTtBQ3BDWjtBRHVDUTtFQUNJLGdCQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0FDckNaO0FEd0NRO0VBQ0ksZ0JBQUE7QUN0Q1o7QUR1Q1k7RUFDSSxVQUFBO0VBQ0EsMkJBQUE7RUFDQSxZQUFBO0FDckNoQjtBRDBDSTtFQUNJLGFBQUE7QUN4Q1I7QUQwQ1E7RUFDSSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSxtQkFBQTtBQ3hDWjtBRDJDUTtFQUNJLGtCQUFBO0FDekNaO0FENENRO0VBQ0ksYUFBQTtFQUNBLFdBQUE7RUFDQSxrQkFBQTtBQzFDWjtBRDRDWTtFQUNJLGFBQUE7RUFDQSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSw4QkFBQTtFQUNBLHlFQUFBO0VBQ0Esa0JBQUE7QUMxQ2hCO0FENENnQjtFQUNJLGtCQUFBO0VBQ0EsU0FBQTtFQUNBLFlBQUE7RUFDQSxnQkFBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtFQUNBLFlBQUE7QUMxQ3BCO0FEa0RJO0VBQ0ksYUFBQTtBQ2hEUjtBRGtEUTtFQUFXLHNCQUFBO0VBRVAsb0JBQUE7RUFDQSxlQUFBO0VBRUEsb0JBQUE7RUFDQSxlQUFBO0VBQ0EsV0FBQTtFQUNBLFVBQUE7RUFDQSxzQkFBQTtFQUVBLGVBQUE7RUFDQSxpQkFBQTtFQUNBLGtCQUFBO0FDL0NaO0FEaURRO0VBQ0kscUJBQUE7RUFDQSxnQkFBQTtFQUNBLFlBQUE7RUFDQSxXQUFBO0VBQ0EsVUFBQTtFQUNBLHNCQUFBO0VBQ0EsMkJBQUE7RUFDQSw4QkFBQTtFQUNBLG1CQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQkFBQTtBQy9DWjtBRGlEWTtFQUNJLGtCQUFBO0VBQ0EsWUFBQTtFQUNBLFlBQUE7RUFDQSxnQkFBQTtFQUNBLGVBQUE7RUFDQSxZQUFBO0FDL0NoQjtBRGtEWTtFQUNJLFlBQUE7RUFDQSxXQUFBO0VBQ0EsbUJBQUE7RUFDQSw4QkFBQTtBQ2hEaEI7QURvRFk7RUFDSSxXQUFBO0VBQ0EsbUJBQUE7QUNsRGhCIiwiZmlsZSI6InNyYy9hcHAvcGFnZXMvbWFpbi1wYWdlL21haW4tcGFnZS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuaGVhZGVyX2RpdntcbiAgICB3aWR0aDogMTAwJTtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gICAgcGFkZGluZzogNXB4O1xuICAgIGltZ3tcbiAgICAgICAgd2lkdGg6IDEwMHB4O1xuICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgICAgIGxlZnQ6IDUwJTtcbiAgICAgICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUoLTUwJSk7XG4gICAgfVxuICAgIC5idG5fZGl2e1xuICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgIH1cbiAgICBpb24tYnV0dG9ue1xuICAgICAgICBjb2xvcjogYmxhY2s7XG4gICAgfVxufVxuXG4ubWFpbl9jb250ZW50X2RpdntcbiAgICB3aWR0aDogMTAwJTtcblxuICAgIGlvbi1sYWJlbCB7XG4gICAgICAgIGRpc3BsYXk6IGJsb2NrO1xuICAgIH1cblxuICAgIC5zZWFyY2hfY2FyZHtcbiAgICAgICAgcGFkZGluZzogMTZweDtcbiAgICAgICAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkIGxpZ2h0Z3JheTtcbiAgICAgICAgLnNlYXJjaF9mbGV4e1xuICAgICAgICAgICAgZGlzcGxheTogZmxleDtcblxuICAgICAgICAgICAgLmJhY2tfaW1hZ2V7XG4gICAgICAgICAgICAgICAgd2lkdGg6IDkwcHg7XG4gICAgICAgICAgICAgICAgaGVpZ2h0OiA5MHB4O1xuICAgICAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDVweDtcbiAgICAgICAgICAgICAgICBtaW4td2lkdGg6IDkwcHg7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIC5zZWFyY2hfZGV0YWlse1xuICAgICAgICAgICAgICAgIHBhZGRpbmctbGVmdDogMTBweDtcblxuICAgICAgICAgICAgICAgIC5oZWFsX2xibHtcbiAgICAgICAgICAgICAgICAgICAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgICAgICAgICAgICAgICAgICAgZm9udC1zaXplOiAxNXB4O1xuICAgICAgICAgICAgICAgICAgICBtYXJnaW4tYm90dG9tOiA1cHg7XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgLnNtYWxse1xuICAgICAgICAgICAgICAgICAgICBmb250LXNpemU6IDEzcHg7XG4gICAgICAgICAgICAgICAgICAgIGNvbG9yOiBncmF5O1xuXG4gICAgICAgICAgICAgICAgICAgIHNwYW57XG4gICAgICAgICAgICAgICAgICAgICAgICBjb2xvcjogYmxhY2s7XG4gICAgICAgICAgICAgICAgICAgICAgICBmb250LXdlaWdodDogNTAwO1xuICAgICAgICAgICAgICAgICAgICAgICAgZm9udC1zaXplOiAxNHB4O1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgLmlubmVyX2ZsZXh7XG4gICAgICAgICAgICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgICAgICAgICAgICAgIG1hcmdpbi10b3A6IDdweDtcbiAgICAgICAgICAgICAgICAgICAgLnJhdGV7XG4gICAgICAgICAgICAgICAgICAgICAgICBmb250LXNpemU6IDE0cHg7XG4gICAgICAgICAgICAgICAgICAgICAgICBmb250LXdlaWdodDogNjAwO1xuICAgICAgICAgICAgICAgICAgICAgICAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xuICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgaW9uLWljb257XG4gICAgICAgICAgICAgICAgICAgICAgICBtYXJnaW4tbGVmdDogM3B4O1xuICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I6IGdyYXk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgLmxpZ2h0e1xuICAgICAgICAgICAgICAgICAgICAgICAgZm9udC1zaXplOiAxM3B4O1xuICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I6IGdyYXk7XG4gICAgICAgICAgICAgICAgICAgICAgICBtYXJnaW4tbGVmdDogN3B4O1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIC5idG5fZmxleHtcbiAgICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgICAgICBtYXJnaW4tdG9wOiAxMHB4O1xuICAgICAgICAgICAgaGVpZ2h0OiAzNXB4O1xuXG4gICAgICAgICAgICAuYnRuczF7XG4gICAgICAgICAgICAgICAgd2lkdGg6IDEwMCU7XG4gICAgICAgICAgICAgICAgb3ZlcmZsb3c6IGhpZGRlbjtcbiAgICAgICAgICAgICAgICBtYXJnaW4tcmlnaHQ6IDEwcHg7XG4gICAgICAgICAgICAgICAgYm9yZGVyLXJpZ2h0OiAxcHggc29saWQgdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgLmJ0bnMye1xuICAgICAgICAgICAgICAgIHdpZHRoOiAxMDAlO1xuICAgICAgICAgICAgICAgIG92ZXJmbG93OiBoaWRkZW47XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICAuYjF7ICAgICAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICBtYXJnaW4tcmlnaHQ6IC0yMHB4O1xuICAgICAgICAgICAgICAgIG1hcmdpbi10b3A6IDBweDtcbiAgICAgICAgICAgICAgICBtYXJnaW4tYm90dG9tOiAwcHg7XG4gICAgICAgICAgICAgICAgaGVpZ2h0OiAzNXB4O1xuICAgICAgICAgICAgICAgIGJvcmRlcjogMXB4IHNvbGlkIHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcbiAgICAgICAgICAgICAgICBib3JkZXItcmFkaXVzOiAyNXB4O1xuXG4gICAgICAgICAgICAgICAgaW9uLWljb257XG4gICAgICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMTZweDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgaW9uLWxhYmVsIHtcbiAgICAgICAgICAgICAgICAgICAgZm9udC1zaXplOiAxNHB4O1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIFxuICAgICAgICAgICAgLmIyeyAgICAgICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgbWFyZ2luLWxlZnQ6IC0yMHB4O1xuICAgICAgICAgICAgICAgIG1hcmdpbi10b3A6IDBweDtcbiAgICAgICAgICAgICAgICBtYXJnaW4tYm90dG9tOiAwcHg7XG4gICAgICAgICAgICAgICAgaGVpZ2h0OiAzNXB4O1xuXG4gICAgICAgICAgICAgICAgaW9uLWxhYmVsIHtcbiAgICAgICAgICAgICAgICAgICAgZm9udC1zaXplOiAxNHB4O1xuICAgICAgICAgICAgICAgICAgICBwYWRkaW5nLWxlZnQ6IDE2cHg7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuXG4gICAgLy8gU2hvcHBpbmdcblxuICAgIC5zZWFyY2hfZGl2e1xuICAgICAgICBwYWRkaW5nOiAxMHB4IDE2cHg7XG4gICAgICAgIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCBsaWdodGdyYXk7XG4gICAgXG4gICAgICAgIGlvbi1pbnB1dHtcbiAgICAgICAgICAgIGJvcmRlcjogMXB4IHNvbGlkIGJsYWNrO1xuICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogMjVweDtcbiAgICAgICAgICAgIGlvbi1pY29ue1xuICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMjBweDtcbiAgICAgICAgICAgICAgICBwYWRkaW5nLWxlZnQ6IDEwcHg7XG4gICAgICAgICAgICAgICAgcGFkZGluZy1yaWdodDogNXB4O1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgLnRlc3R7XG4gICAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICAgICAgICAgIG1hcmdpbi1yaWdodDogMTBweDtcbiAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDI1cHg7XG4gICAgICAgICAgICBwYWRkaW5nOiA1cHggMTVweDtcbiAgICAgICAgICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG5cbiAgICAgICAgICAgIGlvbi1pY29ue1xuICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMjZweDtcbiAgICAgICAgICAgICAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgXG4gICAgICAgIC5hY3RpdmV7IFxuICAgICAgICAgICAgaW9uLWxhYmVsIHtcbiAgICAgICAgICAgICAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpICFpbXBvcnRhbnQ7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICBcbiAgICAgICAgLmNoaXBzX2RpdntcbiAgICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgICAgICBmbGV4LWRpcmVjdGlvbjogcm93O1xuICAgICAgICAgICAgb3ZlcmZsb3c6IHNjcm9sbDtcbiAgICAgICAgICAgIC5jaGlwe1xuICAgICAgICAgICAgICAgIHdoaXRlLXNwYWNlOiBub3dyYXA7XG4gICAgICAgICAgICAgICAgY29sb3I6IGJsYWNrO1xuICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMTNweDtcbiAgICAgICAgICAgICAgICBmb250LXdlaWdodDogNTAwO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAubGluZV9zcGFue1xuICAgICAgICAgICAgICAgIG1hcmdpbi10b3A6IDdweDtcbiAgICAgICAgICAgICAgICB3aWR0aDogMjBweDtcbiAgICAgICAgICAgICAgICBoZWlnaHQ6IDJweDtcbiAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0gIFxuICAgIH1cblxuICAgIC5jYXRlZ29yeV9kaXZ7XG4gICAgICAgIHBhZGRpbmc6IDEwcHggMTZweDtcbiAgICB9XG5cbiAgICAuc2xpZGVyX2RpdntcbiAgICAgICAgcGFkZGluZzogMHB4IDE2cHg7XG4gICAgICAgIGlvbi1zbGlkZXtcbiAgICAgICAgICAgIG1hcmdpbi1yaWdodDogMTBweDtcbiAgICAgICAgfVxuXG4gICAgICAgIC5zbGlkZV9pbWFnZXtcbiAgICAgICAgICAgIHdpZHRoOiAxMDAlO1xuICAgICAgICAgICAgaGVpZ2h0OiAxNzBweDtcbiAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDVweDtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIC5wcm9kdWN0X2RpdntcbiAgICAgICAgcGFkZGluZzogMTZweDtcbiAgICAgICAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkIGxpZ2h0Z3JheTtcblxuICAgICAgICAuaGVhZGVyX2xibHtcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogMTVweDtcbiAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiA1MDA7XG4gICAgICAgICAgICBtYXJnaW4tYm90dG9tOiAxMHB4O1xuICAgICAgICB9XG4gICAgICAgIGlvbi1ncmlke1xuICAgICAgICAgICAgcGFkZGluZzogMDtcblxuICAgICAgICAgICAgaW9uLWNvbHtcbiAgICAgICAgICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgaW1nIHtcbiAgICAgICAgICAgICAgICAgICAgd2lkdGg6IDcwcHg7XG4gICAgICAgICAgICAgICAgICAgIGhlaWdodDogNzBweDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgaW9uLWxhYmVsIHtcbiAgICAgICAgICAgICAgICAgICAgZm9udC1zaXplOiAxM3B4O1xuICAgICAgICAgICAgICAgICAgICBtYXJnaW4tdG9wOiA1cHg7XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgLnByb19kaXZ7XG4gICAgICAgICAgICAgICAgICAgIHdpZHRoOiAxMDAlO1xuICAgICAgICAgICAgICAgICAgICBoZWlnaHQ6IDEyMHB4O1xuICAgICAgICAgICAgICAgICAgICBib3JkZXItcmFkaXVzOiA1cHg7XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgLmxlZnRfbGJse1xuICAgICAgICAgICAgICAgICAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgICAgICAgICAgICAgICAgICB0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlO1xuICAgICAgICAgICAgICAgICAgICBjb2xvcjogZ3JheTtcbiAgICAgICAgICAgICAgICAgICAgZm9udC1zaXplOiAxMXB4O1xuICAgICAgICAgICAgICAgICAgICBmb250LXdlaWdodDogNTAwO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIC5saWdodF9sYmx7XG4gICAgICAgICAgICBjb2xvcjogZ3JheTtcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogMTJweDtcbiAgICAgICAgICAgIG1hcmdpbi10b3A6IDE1cHg7XG4gICAgICAgIH1cbiAgICAgICAgLmJsdWVfbGJse1xuICAgICAgICAgICAgZm9udC1zaXplOiAxM3B4O1xuICAgICAgICAgICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcbiAgICAgICAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIC5jb3Zlcl9kaXZ7XG4gICAgICAgIHBhZGRpbmc6IDE2cHg7XG4gICAgICAgIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCBsaWdodGdyYXk7XG5cbiAgICAgICAgLmNvdmVyX2ltYWdle1xuICAgICAgICAgICAgaGVpZ2h0OiAyMzBweDtcbiAgICAgICAgICAgIHdpZHRoOiAxMDAlO1xuICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogNXB4O1xuICAgICAgICB9XG4gICAgICAgIGlvbi1ncmlke1xuICAgICAgICAgICAgcGFkZGluZzogMDtcbiAgICAgICAgICAgIGlvbi1jb2x7XG4gICAgICAgICAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAgICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgICAgICAgICAgICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICAgICAgICAgICAgICAgIGltZ3tcbiAgICAgICAgICAgICAgICAgICAgd2lkdGg6IDgwcHg7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuXG4gICAgLnRvZGF5X2RlYWxze1xuICAgICAgICBwYWRkaW5nOiAxNnB4O1xuICAgICAgICBib3JkZXItYm90dG9tOiAxcHggc29saWQgbGlnaHRncmF5O1xuXG4gICAgICAgIC5oZWFkZXJfbGJse1xuICAgICAgICAgICAgZm9udC1zaXplOiAxNXB4O1xuICAgICAgICAgICAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgICAgICAgICAgIG1hcmdpbi1ib3R0b206IDEwcHg7XG4gICAgICAgIH1cblxuICAgICAgICAubWFpbl9pbWd7XG4gICAgICAgICAgICB3aWR0aDogNzAlO1xuICAgICAgICAgICAgZGlzcGxheTogYmxvY2s7XG4gICAgICAgICAgICBtYXJnaW46IGF1dG87XG4gICAgICAgIH1cblxuICAgICAgICAuZGVhbF9kZXRhaWx7XG4gICAgICAgICAgICBmb250LXdlaWdodDogNTAwO1xuICAgICAgICAgICAgZm9udC1zaXplOiAxNHB4O1xuICAgICAgICAgICAgbWFyZ2luLWJvdHRvbTogOHB4O1xuICAgICAgICB9XG5cbiAgICAgICAgLmRlYWxfc2xpZGVye1xuICAgICAgICAgICAgbWFyZ2luLXRvcDogMjBweDtcbiAgICAgICAgICAgIGRpdntcbiAgICAgICAgICAgICAgICB3aWR0aDogOTAlO1xuICAgICAgICAgICAgICAgIGJvcmRlcjogMXB4IHNvbGlkIGxpZ2h0Z3JheTtcbiAgICAgICAgICAgICAgICBwYWRkaW5nOiA1cHg7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAuZmVhdHVyZV9kaXZ7XG4gICAgICAgIHBhZGRpbmc6IDE2cHg7XG5cbiAgICAgICAgLmhlYWRlcl9sYmx7XG4gICAgICAgICAgICBmb250LXNpemU6IDE1cHg7XG4gICAgICAgICAgICBmb250LXdlaWdodDogNTAwO1xuICAgICAgICAgICAgbWFyZ2luLWJvdHRvbTogMTBweDtcbiAgICAgICAgfVxuXG4gICAgICAgIGlvbi1zbGlkZXtcbiAgICAgICAgICAgIG1hcmdpbi1yaWdodDogMTVweDtcbiAgICAgICAgfVxuXG4gICAgICAgIC5iYWNrX2ltYWdle1xuICAgICAgICAgICAgaGVpZ2h0OiAxNTBweDtcbiAgICAgICAgICAgIHdpZHRoOiAxMDAlO1xuICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogN3B4O1xuXG4gICAgICAgICAgICAub3ZlcmxheXtcbiAgICAgICAgICAgICAgICBoZWlnaHQ6IDE1MHB4O1xuICAgICAgICAgICAgICAgIHdpZHRoOiAxMDAlO1xuICAgICAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDdweDtcbiAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiByZ2JhKDAsMCwwLDAuMyk7XG4gICAgICAgICAgICAgICAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KHJnYmEoMjU1LDI1NSwyNTUsMC4xKSwgcmdiYSgwLDAsMCwwLjUpKTtcbiAgICAgICAgICAgICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XG5cbiAgICAgICAgICAgICAgICBpb24tbGFiZWwge1xuICAgICAgICAgICAgICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgICAgICAgICAgICAgICAgIGJvdHRvbTogMDtcbiAgICAgICAgICAgICAgICAgICAgY29sb3I6IHdoaXRlO1xuICAgICAgICAgICAgICAgICAgICBmb250LXdlaWdodDogNTAwO1xuICAgICAgICAgICAgICAgICAgICBmb250LXNpemU6IDE0cHg7XG4gICAgICAgICAgICAgICAgICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgICAgICAgICAgICAgICAgIHBhZGRpbmc6IDdweDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAvLyBJbWFnZXNcblxuICAgIC5pbWFnZXNfZGl2e1xuICAgICAgICBwYWRkaW5nOiAxMHB4O1xuXG4gICAgICAgIC5tYXNvbnJ5IHsgLyogTWFzb25yeSBjb250YWluZXIgKi9cbiAgICAgICAgICAgIC13ZWJraXQtY29sdW1uLWNvdW50OiA0O1xuICAgICAgICAgICAgLW1vei1jb2x1bW4tY291bnQ6NDtcbiAgICAgICAgICAgIGNvbHVtbi1jb3VudDogMjtcbiAgICAgICAgICAgIC13ZWJraXQtY29sdW1uLWdhcDogMWVtO1xuICAgICAgICAgICAgLW1vei1jb2x1bW4tZ2FwOiAxZW07XG4gICAgICAgICAgICBjb2x1bW4tZ2FwOiAxZW07XG4gICAgICAgICAgICBtYXJnaW46IDBweDtcbiAgICAgICAgICAgIHBhZGRpbmc6IDA7XG4gICAgICAgICAgICAtbW96LWNvbHVtbi1nYXA6IDEuNWVtO1xuICAgICAgICAgICAgLXdlYmtpdC1jb2x1bW4tZ2FwOiAxLjVlbTtcbiAgICAgICAgICAgIGNvbHVtbi1nYXA6IDNweDtcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogLjg1ZW07XG4gICAgICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgICAgIH1cbiAgICAgICAgLml0ZW0ge1xuICAgICAgICAgICAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xuICAgICAgICAgICAgYmFja2dyb3VuZDogI2ZmZjtcbiAgICAgICAgICAgIHBhZGRpbmc6IDVweDtcbiAgICAgICAgICAgIG1hcmdpbjogNXB4O1xuICAgICAgICAgICAgd2lkdGg6IDk1JTtcbiAgICAgICAgICAgIGJveC1zaXppbmc6IGJvcmRlci1ib3g7XG4gICAgICAgICAgICAtbW96LWJveC1zaXppbmc6IGJvcmRlci1ib3g7XG4gICAgICAgICAgICAtd2Via2l0LWJveC1zaXppbmc6IGJvcmRlci1ib3g7XG4gICAgICAgICAgICBib3JkZXItcmFkaXVzOiAxMHB4O1xuICAgICAgICAgICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgICAgICAgICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcblxuICAgICAgICAgICAgaW9uLWxhYmVsIHtcbiAgICAgICAgICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgICAgICAgICAgICAgYm90dG9tOiAxMHB4O1xuICAgICAgICAgICAgICAgIGNvbG9yOiB3aGl0ZTtcbiAgICAgICAgICAgICAgICBmb250LXdlaWdodDogNjAwO1xuICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMTVweDtcbiAgICAgICAgICAgICAgICBwYWRkaW5nOiA3cHg7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIC5vdmVybGF5e1xuICAgICAgICAgICAgICAgIGhlaWdodDogMTAwJTtcbiAgICAgICAgICAgICAgICB3aWR0aDogMTAwJTtcbiAgICAgICAgICAgICAgICBib3JkZXItcmFkaXVzOiAxMHB4O1xuICAgICAgICAgICAgICAgIGJhY2tncm91bmQ6IHJnYmEoMCwwLDAsMC4zKTtcbiAgICAgICAgICAgICAgICAvLyBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQocmdiYSgyNTUsMjU1LDI1NSwwLjEpLCByZ2JhKDAsMCwwLDAuNSkpO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBpbWd7XG4gICAgICAgICAgICAgICAgd2lkdGg6IDEwMCU7XG4gICAgICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogMTBweDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cbn0iLCIuaGVhZGVyX2RpdiB7XG4gIHdpZHRoOiAxMDAlO1xuICBkaXNwbGF5OiBmbGV4O1xuICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgcGFkZGluZzogNXB4O1xufVxuLmhlYWRlcl9kaXYgaW1nIHtcbiAgd2lkdGg6IDEwMHB4O1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIGxlZnQ6IDUwJTtcbiAgdHJhbnNmb3JtOiB0cmFuc2xhdGUoLTUwJSk7XG59XG4uaGVhZGVyX2RpdiAuYnRuX2RpdiB7XG4gIGRpc3BsYXk6IGZsZXg7XG59XG4uaGVhZGVyX2RpdiBpb24tYnV0dG9uIHtcbiAgY29sb3I6IGJsYWNrO1xufVxuXG4ubWFpbl9jb250ZW50X2RpdiB7XG4gIHdpZHRoOiAxMDAlO1xufVxuLm1haW5fY29udGVudF9kaXYgaW9uLWxhYmVsIHtcbiAgZGlzcGxheTogYmxvY2s7XG59XG4ubWFpbl9jb250ZW50X2RpdiAuc2VhcmNoX2NhcmQge1xuICBwYWRkaW5nOiAxNnB4O1xuICBib3JkZXItYm90dG9tOiAxcHggc29saWQgbGlnaHRncmF5O1xufVxuLm1haW5fY29udGVudF9kaXYgLnNlYXJjaF9jYXJkIC5zZWFyY2hfZmxleCB7XG4gIGRpc3BsYXk6IGZsZXg7XG59XG4ubWFpbl9jb250ZW50X2RpdiAuc2VhcmNoX2NhcmQgLnNlYXJjaF9mbGV4IC5iYWNrX2ltYWdlIHtcbiAgd2lkdGg6IDkwcHg7XG4gIGhlaWdodDogOTBweDtcbiAgYm9yZGVyLXJhZGl1czogNXB4O1xuICBtaW4td2lkdGg6IDkwcHg7XG59XG4ubWFpbl9jb250ZW50X2RpdiAuc2VhcmNoX2NhcmQgLnNlYXJjaF9mbGV4IC5zZWFyY2hfZGV0YWlsIHtcbiAgcGFkZGluZy1sZWZ0OiAxMHB4O1xufVxuLm1haW5fY29udGVudF9kaXYgLnNlYXJjaF9jYXJkIC5zZWFyY2hfZmxleCAuc2VhcmNoX2RldGFpbCAuaGVhbF9sYmwge1xuICBmb250LXdlaWdodDogNTAwO1xuICBmb250LXNpemU6IDE1cHg7XG4gIG1hcmdpbi1ib3R0b206IDVweDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5zZWFyY2hfY2FyZCAuc2VhcmNoX2ZsZXggLnNlYXJjaF9kZXRhaWwgLnNtYWxsIHtcbiAgZm9udC1zaXplOiAxM3B4O1xuICBjb2xvcjogZ3JheTtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5zZWFyY2hfY2FyZCAuc2VhcmNoX2ZsZXggLnNlYXJjaF9kZXRhaWwgLnNtYWxsIHNwYW4ge1xuICBjb2xvcjogYmxhY2s7XG4gIGZvbnQtd2VpZ2h0OiA1MDA7XG4gIGZvbnQtc2l6ZTogMTRweDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5zZWFyY2hfY2FyZCAuc2VhcmNoX2ZsZXggLnNlYXJjaF9kZXRhaWwgLmlubmVyX2ZsZXgge1xuICBkaXNwbGF5OiBmbGV4O1xuICBtYXJnaW4tdG9wOiA3cHg7XG59XG4ubWFpbl9jb250ZW50X2RpdiAuc2VhcmNoX2NhcmQgLnNlYXJjaF9mbGV4IC5zZWFyY2hfZGV0YWlsIC5pbm5lcl9mbGV4IC5yYXRlIHtcbiAgZm9udC1zaXplOiAxNHB4O1xuICBmb250LXdlaWdodDogNjAwO1xuICBtYXJnaW4tcmlnaHQ6IDEwcHg7XG59XG4ubWFpbl9jb250ZW50X2RpdiAuc2VhcmNoX2NhcmQgLnNlYXJjaF9mbGV4IC5zZWFyY2hfZGV0YWlsIC5pbm5lcl9mbGV4IGlvbi1pY29uIHtcbiAgbWFyZ2luLWxlZnQ6IDNweDtcbiAgY29sb3I6IGdyYXk7XG59XG4ubWFpbl9jb250ZW50X2RpdiAuc2VhcmNoX2NhcmQgLnNlYXJjaF9mbGV4IC5zZWFyY2hfZGV0YWlsIC5pbm5lcl9mbGV4IC5saWdodCB7XG4gIGZvbnQtc2l6ZTogMTNweDtcbiAgY29sb3I6IGdyYXk7XG4gIG1hcmdpbi1sZWZ0OiA3cHg7XG59XG4ubWFpbl9jb250ZW50X2RpdiAuc2VhcmNoX2NhcmQgLmJ0bl9mbGV4IHtcbiAgZGlzcGxheTogZmxleDtcbiAgbWFyZ2luLXRvcDogMTBweDtcbiAgaGVpZ2h0OiAzNXB4O1xufVxuLm1haW5fY29udGVudF9kaXYgLnNlYXJjaF9jYXJkIC5idG5fZmxleCAuYnRuczEge1xuICB3aWR0aDogMTAwJTtcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcbiAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xuICBib3JkZXItcmlnaHQ6IDFweCBzb2xpZCB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XG59XG4ubWFpbl9jb250ZW50X2RpdiAuc2VhcmNoX2NhcmQgLmJ0bl9mbGV4IC5idG5zMiB7XG4gIHdpZHRoOiAxMDAlO1xuICBvdmVyZmxvdzogaGlkZGVuO1xufVxuLm1haW5fY29udGVudF9kaXYgLnNlYXJjaF9jYXJkIC5idG5fZmxleCAuYjEge1xuICBtYXJnaW4tcmlnaHQ6IC0yMHB4O1xuICBtYXJnaW4tdG9wOiAwcHg7XG4gIG1hcmdpbi1ib3R0b206IDBweDtcbiAgaGVpZ2h0OiAzNXB4O1xuICBib3JkZXI6IDFweCBzb2xpZCB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XG4gIGJvcmRlci1yYWRpdXM6IDI1cHg7XG59XG4ubWFpbl9jb250ZW50X2RpdiAuc2VhcmNoX2NhcmQgLmJ0bl9mbGV4IC5iMSBpb24taWNvbiB7XG4gIGZvbnQtc2l6ZTogMTZweDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5zZWFyY2hfY2FyZCAuYnRuX2ZsZXggLmIxIGlvbi1sYWJlbCB7XG4gIGZvbnQtc2l6ZTogMTRweDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5zZWFyY2hfY2FyZCAuYnRuX2ZsZXggLmIyIHtcbiAgbWFyZ2luLWxlZnQ6IC0yMHB4O1xuICBtYXJnaW4tdG9wOiAwcHg7XG4gIG1hcmdpbi1ib3R0b206IDBweDtcbiAgaGVpZ2h0OiAzNXB4O1xufVxuLm1haW5fY29udGVudF9kaXYgLnNlYXJjaF9jYXJkIC5idG5fZmxleCAuYjIgaW9uLWxhYmVsIHtcbiAgZm9udC1zaXplOiAxNHB4O1xuICBwYWRkaW5nLWxlZnQ6IDE2cHg7XG59XG4ubWFpbl9jb250ZW50X2RpdiAuc2VhcmNoX2RpdiB7XG4gIHBhZGRpbmc6IDEwcHggMTZweDtcbiAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkIGxpZ2h0Z3JheTtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5zZWFyY2hfZGl2IGlvbi1pbnB1dCB7XG4gIGJvcmRlcjogMXB4IHNvbGlkIGJsYWNrO1xuICBib3JkZXItcmFkaXVzOiAyNXB4O1xufVxuLm1haW5fY29udGVudF9kaXYgLnNlYXJjaF9kaXYgaW9uLWlucHV0IGlvbi1pY29uIHtcbiAgZm9udC1zaXplOiAyMHB4O1xuICBwYWRkaW5nLWxlZnQ6IDEwcHg7XG4gIHBhZGRpbmctcmlnaHQ6IDVweDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5zZWFyY2hfZGl2IC50ZXN0IHtcbiAgZGlzcGxheTogZmxleDtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xuICBib3JkZXItcmFkaXVzOiAyNXB4O1xuICBwYWRkaW5nOiA1cHggMTVweDtcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5zZWFyY2hfZGl2IC50ZXN0IGlvbi1pY29uIHtcbiAgZm9udC1zaXplOiAyNnB4O1xuICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xufVxuLm1haW5fY29udGVudF9kaXYgLnNlYXJjaF9kaXYgLmFjdGl2ZSBpb24tbGFiZWwge1xuICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpICFpbXBvcnRhbnQ7XG59XG4ubWFpbl9jb250ZW50X2RpdiAuc2VhcmNoX2RpdiAuY2hpcHNfZGl2IHtcbiAgZGlzcGxheTogZmxleDtcbiAgZmxleC1kaXJlY3Rpb246IHJvdztcbiAgb3ZlcmZsb3c6IHNjcm9sbDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5zZWFyY2hfZGl2IC5jaGlwc19kaXYgLmNoaXAge1xuICB3aGl0ZS1zcGFjZTogbm93cmFwO1xuICBjb2xvcjogYmxhY2s7XG4gIGZvbnQtc2l6ZTogMTNweDtcbiAgZm9udC13ZWlnaHQ6IDUwMDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5zZWFyY2hfZGl2IC5jaGlwc19kaXYgLmxpbmVfc3BhbiB7XG4gIG1hcmdpbi10b3A6IDdweDtcbiAgd2lkdGg6IDIwcHg7XG4gIGhlaWdodDogMnB4O1xuICBiYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XG59XG4ubWFpbl9jb250ZW50X2RpdiAuY2F0ZWdvcnlfZGl2IHtcbiAgcGFkZGluZzogMTBweCAxNnB4O1xufVxuLm1haW5fY29udGVudF9kaXYgLnNsaWRlcl9kaXYge1xuICBwYWRkaW5nOiAwcHggMTZweDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5zbGlkZXJfZGl2IGlvbi1zbGlkZSB7XG4gIG1hcmdpbi1yaWdodDogMTBweDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5zbGlkZXJfZGl2IC5zbGlkZV9pbWFnZSB7XG4gIHdpZHRoOiAxMDAlO1xuICBoZWlnaHQ6IDE3MHB4O1xuICBib3JkZXItcmFkaXVzOiA1cHg7XG59XG4ubWFpbl9jb250ZW50X2RpdiAucHJvZHVjdF9kaXYge1xuICBwYWRkaW5nOiAxNnB4O1xuICBib3JkZXItYm90dG9tOiAxcHggc29saWQgbGlnaHRncmF5O1xufVxuLm1haW5fY29udGVudF9kaXYgLnByb2R1Y3RfZGl2IC5oZWFkZXJfbGJsIHtcbiAgZm9udC1zaXplOiAxNXB4O1xuICBmb250LXdlaWdodDogNTAwO1xuICBtYXJnaW4tYm90dG9tOiAxMHB4O1xufVxuLm1haW5fY29udGVudF9kaXYgLnByb2R1Y3RfZGl2IGlvbi1ncmlkIHtcbiAgcGFkZGluZzogMDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5wcm9kdWN0X2RpdiBpb24tZ3JpZCBpb24tY29sIHtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xufVxuLm1haW5fY29udGVudF9kaXYgLnByb2R1Y3RfZGl2IGlvbi1ncmlkIGlvbi1jb2wgaW1nIHtcbiAgd2lkdGg6IDcwcHg7XG4gIGhlaWdodDogNzBweDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5wcm9kdWN0X2RpdiBpb24tZ3JpZCBpb24tY29sIGlvbi1sYWJlbCB7XG4gIGZvbnQtc2l6ZTogMTNweDtcbiAgbWFyZ2luLXRvcDogNXB4O1xufVxuLm1haW5fY29udGVudF9kaXYgLnByb2R1Y3RfZGl2IGlvbi1ncmlkIGlvbi1jb2wgLnByb19kaXYge1xuICB3aWR0aDogMTAwJTtcbiAgaGVpZ2h0OiAxMjBweDtcbiAgYm9yZGVyLXJhZGl1czogNXB4O1xufVxuLm1haW5fY29udGVudF9kaXYgLnByb2R1Y3RfZGl2IGlvbi1ncmlkIGlvbi1jb2wgLmxlZnRfbGJsIHtcbiAgdGV4dC1hbGlnbjogbGVmdDtcbiAgdGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTtcbiAgY29sb3I6IGdyYXk7XG4gIGZvbnQtc2l6ZTogMTFweDtcbiAgZm9udC13ZWlnaHQ6IDUwMDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5wcm9kdWN0X2RpdiAubGlnaHRfbGJsIHtcbiAgY29sb3I6IGdyYXk7XG4gIGZvbnQtc2l6ZTogMTJweDtcbiAgbWFyZ2luLXRvcDogMTVweDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5wcm9kdWN0X2RpdiAuYmx1ZV9sYmwge1xuICBmb250LXNpemU6IDEzcHg7XG4gIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5jb3Zlcl9kaXYge1xuICBwYWRkaW5nOiAxNnB4O1xuICBib3JkZXItYm90dG9tOiAxcHggc29saWQgbGlnaHRncmF5O1xufVxuLm1haW5fY29udGVudF9kaXYgLmNvdmVyX2RpdiAuY292ZXJfaW1hZ2Uge1xuICBoZWlnaHQ6IDIzMHB4O1xuICB3aWR0aDogMTAwJTtcbiAgYm9yZGVyLXJhZGl1czogNXB4O1xufVxuLm1haW5fY29udGVudF9kaXYgLmNvdmVyX2RpdiBpb24tZ3JpZCB7XG4gIHBhZGRpbmc6IDA7XG59XG4ubWFpbl9jb250ZW50X2RpdiAuY292ZXJfZGl2IGlvbi1ncmlkIGlvbi1jb2wge1xuICBkaXNwbGF5OiBmbGV4O1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5jb3Zlcl9kaXYgaW9uLWdyaWQgaW9uLWNvbCBpbWcge1xuICB3aWR0aDogODBweDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC50b2RheV9kZWFscyB7XG4gIHBhZGRpbmc6IDE2cHg7XG4gIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCBsaWdodGdyYXk7XG59XG4ubWFpbl9jb250ZW50X2RpdiAudG9kYXlfZGVhbHMgLmhlYWRlcl9sYmwge1xuICBmb250LXNpemU6IDE1cHg7XG4gIGZvbnQtd2VpZ2h0OiA1MDA7XG4gIG1hcmdpbi1ib3R0b206IDEwcHg7XG59XG4ubWFpbl9jb250ZW50X2RpdiAudG9kYXlfZGVhbHMgLm1haW5faW1nIHtcbiAgd2lkdGg6IDcwJTtcbiAgZGlzcGxheTogYmxvY2s7XG4gIG1hcmdpbjogYXV0bztcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC50b2RheV9kZWFscyAuZGVhbF9kZXRhaWwge1xuICBmb250LXdlaWdodDogNTAwO1xuICBmb250LXNpemU6IDE0cHg7XG4gIG1hcmdpbi1ib3R0b206IDhweDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC50b2RheV9kZWFscyAuZGVhbF9zbGlkZXIge1xuICBtYXJnaW4tdG9wOiAyMHB4O1xufVxuLm1haW5fY29udGVudF9kaXYgLnRvZGF5X2RlYWxzIC5kZWFsX3NsaWRlciBkaXYge1xuICB3aWR0aDogOTAlO1xuICBib3JkZXI6IDFweCBzb2xpZCBsaWdodGdyYXk7XG4gIHBhZGRpbmc6IDVweDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5mZWF0dXJlX2RpdiB7XG4gIHBhZGRpbmc6IDE2cHg7XG59XG4ubWFpbl9jb250ZW50X2RpdiAuZmVhdHVyZV9kaXYgLmhlYWRlcl9sYmwge1xuICBmb250LXNpemU6IDE1cHg7XG4gIGZvbnQtd2VpZ2h0OiA1MDA7XG4gIG1hcmdpbi1ib3R0b206IDEwcHg7XG59XG4ubWFpbl9jb250ZW50X2RpdiAuZmVhdHVyZV9kaXYgaW9uLXNsaWRlIHtcbiAgbWFyZ2luLXJpZ2h0OiAxNXB4O1xufVxuLm1haW5fY29udGVudF9kaXYgLmZlYXR1cmVfZGl2IC5iYWNrX2ltYWdlIHtcbiAgaGVpZ2h0OiAxNTBweDtcbiAgd2lkdGg6IDEwMCU7XG4gIGJvcmRlci1yYWRpdXM6IDdweDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5mZWF0dXJlX2RpdiAuYmFja19pbWFnZSAub3ZlcmxheSB7XG4gIGhlaWdodDogMTUwcHg7XG4gIHdpZHRoOiAxMDAlO1xuICBib3JkZXItcmFkaXVzOiA3cHg7XG4gIGJhY2tncm91bmQ6IHJnYmEoMCwgMCwgMCwgMC4zKTtcbiAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KHJnYmEoMjU1LCAyNTUsIDI1NSwgMC4xKSwgcmdiYSgwLCAwLCAwLCAwLjUpKTtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xufVxuLm1haW5fY29udGVudF9kaXYgLmZlYXR1cmVfZGl2IC5iYWNrX2ltYWdlIC5vdmVybGF5IGlvbi1sYWJlbCB7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgYm90dG9tOiAwO1xuICBjb2xvcjogd2hpdGU7XG4gIGZvbnQtd2VpZ2h0OiA1MDA7XG4gIGZvbnQtc2l6ZTogMTRweDtcbiAgdGV4dC1hbGlnbjogbGVmdDtcbiAgcGFkZGluZzogN3B4O1xufVxuLm1haW5fY29udGVudF9kaXYgLmltYWdlc19kaXYge1xuICBwYWRkaW5nOiAxMHB4O1xufVxuLm1haW5fY29udGVudF9kaXYgLmltYWdlc19kaXYgLm1hc29ucnkge1xuICAvKiBNYXNvbnJ5IGNvbnRhaW5lciAqL1xuICAtd2Via2l0LWNvbHVtbi1jb3VudDogNDtcbiAgLW1vei1jb2x1bW4tY291bnQ6IDQ7XG4gIGNvbHVtbi1jb3VudDogMjtcbiAgLXdlYmtpdC1jb2x1bW4tZ2FwOiAxZW07XG4gIC1tb3otY29sdW1uLWdhcDogMWVtO1xuICBjb2x1bW4tZ2FwOiAxZW07XG4gIG1hcmdpbjogMHB4O1xuICBwYWRkaW5nOiAwO1xuICAtbW96LWNvbHVtbi1nYXA6IDEuNWVtO1xuICAtd2Via2l0LWNvbHVtbi1nYXA6IDEuNWVtO1xuICBjb2x1bW4tZ2FwOiAzcHg7XG4gIGZvbnQtc2l6ZTogMC44NWVtO1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG59XG4ubWFpbl9jb250ZW50X2RpdiAuaW1hZ2VzX2RpdiAuaXRlbSB7XG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbiAgYmFja2dyb3VuZDogI2ZmZjtcbiAgcGFkZGluZzogNXB4O1xuICBtYXJnaW46IDVweDtcbiAgd2lkdGg6IDk1JTtcbiAgYm94LXNpemluZzogYm9yZGVyLWJveDtcbiAgLW1vei1ib3gtc2l6aW5nOiBib3JkZXItYm94O1xuICAtd2Via2l0LWJveC1zaXppbmc6IGJvcmRlci1ib3g7XG4gIGJvcmRlci1yYWRpdXM6IDEwcHg7XG4gIHRleHQtYWxpZ246IGxlZnQ7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5pbWFnZXNfZGl2IC5pdGVtIGlvbi1sYWJlbCB7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgYm90dG9tOiAxMHB4O1xuICBjb2xvcjogd2hpdGU7XG4gIGZvbnQtd2VpZ2h0OiA2MDA7XG4gIGZvbnQtc2l6ZTogMTVweDtcbiAgcGFkZGluZzogN3B4O1xufVxuLm1haW5fY29udGVudF9kaXYgLmltYWdlc19kaXYgLml0ZW0gLm92ZXJsYXkge1xuICBoZWlnaHQ6IDEwMCU7XG4gIHdpZHRoOiAxMDAlO1xuICBib3JkZXItcmFkaXVzOiAxMHB4O1xuICBiYWNrZ3JvdW5kOiByZ2JhKDAsIDAsIDAsIDAuMyk7XG59XG4ubWFpbl9jb250ZW50X2RpdiAuaW1hZ2VzX2RpdiAuaXRlbSBpbWcge1xuICB3aWR0aDogMTAwJTtcbiAgYm9yZGVyLXJhZGl1czogMTBweDtcbn0iXX0= */");

/***/ }),

/***/ "./src/app/pages/main-page/main-page.page.ts":
/*!***************************************************!*\
  !*** ./src/app/pages/main-page/main-page.page.ts ***!
  \***************************************************/
/*! exports provided: MainPagePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MainPagePage", function() { return MainPagePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var src_app_services_shop_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/shop.service */ "./src/app/services/shop.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var src_app_services_search_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/search.service */ "./src/app/services/search.service.ts");






let MainPagePage = class MainPagePage {
    constructor(shop, router, route, actionSheetController, search) {
        this.shop = shop;
        this.router = router;
        this.route = route;
        this.actionSheetController = actionSheetController;
        this.search = search;
        this.moviesCat = ['Search', 'Shopping', 'Maps', 'Images', 'News', 'Videos', 'Social'];
        this.slideOpts = {
            slidesPerView: 3.5,
        };
        this.slideOpts2 = {
            slidesPerView: 3,
        };
        this.plt = localStorage.getItem('platform');
        this.route.queryParams.subscribe(data => {
            console.log(data.id);
            this.id = data.id;
        });
        this.slider = this.shop.slider;
        this.products = this.shop.products;
        this.beauty = this.shop.beauty;
        this.deal = this.shop.deals;
        this.featureCat = this.shop.featureCat;
        this.images = this.shop.images;
        this.clinic = this.search.clinic;
    }
    ngOnInit() {
    }
    selectCat(val) {
        const navData = {
            queryParams: {
                id: val
            }
        };
        console.log(val);
        this.currentCat = val;
        this.id = val;
        if (this.currentCat === 'News') {
            this.router.navigate(['/tabs/news'], navData);
        }
        if (this.currentCat === 'Videos') {
            this.router.navigate(['/tabs/videos'], navData);
        }
        if (this.currentCat === 'Social') {
            this.router.navigate(['/tabs/social'], navData);
        }
        if (this.currentCat === 'Maps') {
            this.router.navigate(['/tabs/maps'], navData);
        }
    }
    shareActionSheet() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const actionSheet = yield this.actionSheetController.create({
                mode: 'md',
                buttons: [
                    {
                        text: 'Post on JdSocial',
                        icon: 'sync-circle-outline',
                    },
                    {
                        text: 'Share on facebook',
                        icon: 'logo-facebook',
                    },
                    {
                        text: 'Send on WhatsApp',
                        icon: 'logo-whatsapp',
                    },
                    {
                        text: 'Copy Link',
                        icon: 'copy-outline',
                    },
                    {
                        text: 'More Options..',
                        icon: 'ellipsis-horizontal-circle-outline',
                    }
                ]
            });
            yield actionSheet.present();
        });
    }
};
MainPagePage.ctorParameters = () => [
    { type: src_app_services_shop_service__WEBPACK_IMPORTED_MODULE_2__["ShopService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ActionSheetController"] },
    { type: src_app_services_search_service__WEBPACK_IMPORTED_MODULE_5__["SearchService"] }
];
MainPagePage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-main-page',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./main-page.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/main-page/main-page.page.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./main-page.page.scss */ "./src/app/pages/main-page/main-page.page.scss")).default]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [src_app_services_shop_service__WEBPACK_IMPORTED_MODULE_2__["ShopService"],
        _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"],
        _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ActionSheetController"],
        src_app_services_search_service__WEBPACK_IMPORTED_MODULE_5__["SearchService"]])
], MainPagePage);



/***/ }),

/***/ "./src/app/services/shop.service.ts":
/*!******************************************!*\
  !*** ./src/app/services/shop.service.ts ***!
  \******************************************/
/*! exports provided: ShopService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ShopService", function() { return ShopService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let ShopService = class ShopService {
    constructor() {
        this.slider = [
            {
                img: 'assets/imgs/shop/slide1.jpg'
            },
            {
                img: 'assets/imgs/shop/slide2.jpg'
            },
            {
                img: 'assets/imgs/shop/slide3.jpg'
            },
            {
                img: 'assets/imgs/shop/slide4.jpg'
            },
        ];
        this.products = [
            {
                img: 'assets/imgs/shop/1.jpeg',
                name: 'Mobile'
            },
            {
                img: 'assets/imgs/shop/2.png',
                name: 'Headphones'
            },
            {
                img: 'assets/imgs/shop/3.jpeg',
                name: 'Laptops'
            },
            {
                img: 'assets/imgs/shop/4.jpg',
                name: 'Purse'
            },
            {
                img: 'assets/imgs/shop/5.jpg',
                name: 'Sunglasses'
            },
            {
                img: 'assets/imgs/shop/6.jpg',
                name: 'Bags'
            },
            {
                img: 'assets/imgs/shop/7.jpeg',
                name: 'Chairs'
            },
            {
                img: 'assets/imgs/shop/8.jpeg',
                name: 'Sofa'
            },
            {
                img: 'assets/imgs/shop/9.jpg',
                name: 'Beds'
            },
        ];
        this.beauty = [
            {
                img: 'assets/imgs/shop/b2.jpeg',
                name: 'Face Cream'
            },
            {
                img: 'assets/imgs/shop/b3.jpeg',
                name: 'Night Cream'
            },
            {
                img: 'assets/imgs/shop/b4.jpeg',
                name: 'Hair oils'
            },
            {
                img: 'assets/imgs/shop/b6.jpeg',
                name: 'Shampoo'
            }
        ];
        this.deals = [
            {
                img: 'assets/imgs/shop/deal2.jpg'
            },
            {
                img: 'assets/imgs/shop/deal3.png'
            },
            {
                img: 'assets/imgs/shop/deal4.jpg'
            },
            {
                img: 'assets/imgs/shop/deal5.jpg'
            },
            {
                img: 'assets/imgs/shop/deal1.jpg'
            },
        ];
        this.featureCat = [
            {
                img: 'assets/imgs/shop/c1.jpg',
                name: 'Sports & Accessories'
            },
            {
                img: 'assets/imgs/shop/c2.jpg',
                name: 'Furnishing'
            },
            {
                img: 'assets/imgs/shop/c3.jpg',
                name: 'Personal Care'
            },
            {
                img: 'assets/imgs/shop/c4.jpg',
                name: 'Home Decoratives'
            },
            {
                img: 'assets/imgs/shop/c5.jpg',
                name: 'Kitchen Appliances'
            },
            {
                img: 'assets/imgs/shop/c6.jpg',
                name: 'Gardening Accessories'
            },
            {
                img: 'assets/imgs/shop/c7.jpeg',
                name: 'Sports ware'
            },
        ];
        this.images = [
            {
                img: 'assets/imgs/shop/i1.jpg',
                name: 'Hollywood'
            },
            {
                img: 'assets/imgs/shop/i2.jpg',
                name: 'Exercise'
            },
            {
                img: 'assets/imgs/shop/i3.jpg',
                name: 'Cricket'
            },
            {
                img: 'assets/imgs/shop/i4.jpg',
                name: 'Travel'
            },
            {
                img: 'assets/imgs/shop/i5.jpg',
                name: 'Lifestyle'
            },
            {
                img: 'assets/imgs/shop/i6.jpg',
                name: 'Automobile'
            },
            {
                img: 'assets/imgs/shop/i7.jpg',
                name: 'Bollywood'
            },
            {
                img: 'assets/imgs/shop/i8.jpg',
                name: 'Yoga'
            }
        ];
    }
};
ShopService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
], ShopService);



/***/ })

}]);
//# sourceMappingURL=main-page-main-page-module-es2015.js.map