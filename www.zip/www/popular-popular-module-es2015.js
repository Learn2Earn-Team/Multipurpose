(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["popular-popular-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/popular/popular.page.html":
/*!***************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/popular/popular.page.html ***!
  \***************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar>\n    <!-- <ion-buttons slot=\"start\">\n      <ion-menu-button color=\"dark\"></ion-menu-button>\n    </ion-buttons> -->\n\n    <ion-icon class=\"back\" name=\"arrow-back-outline\" (click)=\"goBack()\"></ion-icon>\n    \n    <ion-title>Popular</ion-title>\n\n    <ion-button (click)=\"openActionSheet()\" slot=\"end\" size=\"small\" fill=\"clear\">\n      <ion-icon name=\"ellipsis-vertical\"></ion-icon>\n    </ion-button>\n\n    <ion-button slot=\"end\" size=\"small\" fill=\"clear\">\n      <ion-icon name=\"arrow-redo-outline\"></ion-icon>\n    </ion-button>\n\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div class=\"main_content_div\">\n\n    <div class=\"search_div\">\n      <ion-input type=\"text\" placeholder=\"Search\">\n        <ion-icon name=\"search-outline\"></ion-icon>\n      </ion-input>\n    </div>\n\n    <div class=\"search_div\">\n      <div class=\"chips_div\">\n        <div class=\"test\">\n          <ion-icon name=\"funnel-outline\"></ion-icon>\n        </div>\n        <div class=\"test\" [class.active]=\"currentCat == i\" *ngFor=\"let item of moviesCat; let i = index\">\n          <ion-label class=\"chip\" (click)=\"selectCat(i)\">{{item}}</ion-label>\n          <ion-icon name=\"caret-down-outline\"></ion-icon>\n        </div>\n      </div>\n    </div>\n\n    <div class=\"lower_div\">\n      <ion-grid>\n        <ion-row>\n          <ion-col size=\"4\" *ngFor=\"let item of movies\" (click)=\"goToMovieDetail()\">\n            <div class=\"image_div bg_image\" [style.backgroundImage]=\"'url( '+ item.img +' )'\">\n              <div class=\"white_div\">\n                <ion-icon name=\"thumbs-up-sharp\"></ion-icon>\n                <ion-label>{{item.per}}%</ion-label>\n              </div>\n            </div>\n          </ion-col>\n        </ion-row>\n      </ion-grid>\n    </div>\n\n  </div>\n</ion-content>\n");

/***/ }),

/***/ "./src/app/pages/popular/popular-routing.module.ts":
/*!*********************************************************!*\
  !*** ./src/app/pages/popular/popular-routing.module.ts ***!
  \*********************************************************/
/*! exports provided: PopularPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PopularPageRoutingModule", function() { return PopularPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _popular_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./popular.page */ "./src/app/pages/popular/popular.page.ts");




const routes = [
    {
        path: '',
        component: _popular_page__WEBPACK_IMPORTED_MODULE_3__["PopularPage"]
    }
];
let PopularPageRoutingModule = class PopularPageRoutingModule {
};
PopularPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], PopularPageRoutingModule);



/***/ }),

/***/ "./src/app/pages/popular/popular.module.ts":
/*!*************************************************!*\
  !*** ./src/app/pages/popular/popular.module.ts ***!
  \*************************************************/
/*! exports provided: PopularPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PopularPageModule", function() { return PopularPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _popular_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./popular-routing.module */ "./src/app/pages/popular/popular-routing.module.ts");
/* harmony import */ var _popular_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./popular.page */ "./src/app/pages/popular/popular.page.ts");







let PopularPageModule = class PopularPageModule {
};
PopularPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _popular_routing_module__WEBPACK_IMPORTED_MODULE_5__["PopularPageRoutingModule"]
        ],
        declarations: [_popular_page__WEBPACK_IMPORTED_MODULE_6__["PopularPage"]]
    })
], PopularPageModule);



/***/ }),

/***/ "./src/app/pages/popular/popular.page.scss":
/*!*************************************************!*\
  !*** ./src/app/pages/popular/popular.page.scss ***!
  \*************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-header .back {\n  font-size: 27px;\n  margin-left: 10px;\n}\nion-header ion-button {\n  margin: 0;\n}\nion-header ion-button ion-icon {\n  color: black;\n  font-size: 20px;\n}\n.main_content_div {\n  width: 100%;\n}\n.main_content_div ion-label {\n  display: block;\n}\n.main_content_div .search_div {\n  padding: 10px 16px;\n  border-bottom: 1px solid lightgray;\n}\n.main_content_div .search_div ion-input {\n  border: 1px solid black;\n  border-radius: 25px;\n}\n.main_content_div .search_div ion-input ion-icon {\n  font-size: 20px;\n  padding-left: 10px;\n  padding-right: 5px;\n}\n.main_content_div .search_div .test {\n  display: flex;\n  align-items: center;\n  margin-right: 10px;\n  border: 1px solid lightgray;\n  background: whitesmoke;\n  border-radius: 25px;\n  padding: 5px 15px;\n}\n.main_content_div .search_div .test ion-icon {\n  font-size: 13px;\n}\n.main_content_div .search_div .active {\n  border: 1px solid var(--ion-color-primary);\n  background: rgba(17, 116, 192, 0.2);\n}\n.main_content_div .search_div .active ion-label {\n  color: var(--ion-color-primary) !important;\n}\n.main_content_div .search_div .active ion-icon {\n  color: var(--ion-color-primary);\n}\n.main_content_div .search_div .chips_div {\n  display: flex;\n  flex-direction: row;\n  overflow: scroll;\n}\n.main_content_div .search_div .chips_div .chip {\n  white-space: nowrap;\n  color: black;\n  font-size: 13px;\n  margin-right: 7px;\n}\n.main_content_div .lower_div {\n  padding: 10px;\n}\n.main_content_div .lower_div ion-grid {\n  padding: 0;\n}\n.main_content_div .lower_div .image_div {\n  width: 100%;\n  height: 150px;\n  border-radius: 5px;\n  position: relative;\n}\n.main_content_div .lower_div .image_div .white_div {\n  background: white;\n  border-radius: 25px;\n  display: flex;\n  position: absolute;\n  bottom: 10px;\n  right: 10px;\n  padding: 3px 6px;\n}\n.main_content_div .lower_div .image_div .white_div ion-icon {\n  color: #FF6B01;\n  font-size: 15px;\n  margin-right: 5px;\n}\n.main_content_div .lower_div .image_div .white_div ion-label {\n  font-size: 12px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvcG9wdWxhci9FOlxcSW9uaWMgUHJvamVjdHNcXGlvbmljLTUtdGVtcGxhdGUtYnVuZGxlLWlvbmljLTUtdGhlbWVzLWJ1bmRsZXMtaW9uaWMtNS10ZW1wbGF0ZXMtd2l0aC0xMC1hcHBzXFxBcHBfc291cmNlX2NvZGVcXEFwcHNfY29kZVxcTXVsdGlfcHVycG9zZS9zcmNcXGFwcFxccGFnZXNcXHBvcHVsYXJcXHBvcHVsYXIucGFnZS5zY3NzIiwic3JjL2FwcC9wYWdlcy9wb3B1bGFyL3BvcHVsYXIucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNJO0VBQ0ksZUFBQTtFQUNBLGlCQUFBO0FDQVI7QURFSTtFQUNJLFNBQUE7QUNBUjtBREVRO0VBQ0ksWUFBQTtFQUNBLGVBQUE7QUNBWjtBREtBO0VBQ0ksV0FBQTtBQ0ZKO0FESUk7RUFDSSxjQUFBO0FDRlI7QURLSTtFQUNJLGtCQUFBO0VBQ0Esa0NBQUE7QUNIUjtBREtRO0VBQ0ksdUJBQUE7RUFDQSxtQkFBQTtBQ0haO0FESVk7RUFDSSxlQUFBO0VBQ0Esa0JBQUE7RUFDQSxrQkFBQTtBQ0ZoQjtBRE1RO0VBQ0ksYUFBQTtFQUNBLG1CQUFBO0VBQ0Esa0JBQUE7RUFDQSwyQkFBQTtFQUNBLHNCQUFBO0VBQ0EsbUJBQUE7RUFDQSxpQkFBQTtBQ0paO0FETVk7RUFDSSxlQUFBO0FDSmhCO0FEUVE7RUFDSSwwQ0FBQTtFQUNBLG1DQUFBO0FDTlo7QURRWTtFQUNJLDBDQUFBO0FDTmhCO0FEU1k7RUFDSSwrQkFBQTtBQ1BoQjtBRFdRO0VBQ0ksYUFBQTtFQUNBLG1CQUFBO0VBQ0EsZ0JBQUE7QUNUWjtBRFVZO0VBQ0ksbUJBQUE7RUFDQSxZQUFBO0VBQ0EsZUFBQTtFQUNBLGlCQUFBO0FDUmhCO0FEYUk7RUFDSSxhQUFBO0FDWFI7QURhUTtFQUNJLFVBQUE7QUNYWjtBRGNRO0VBQ0ksV0FBQTtFQUNBLGFBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0FDWlo7QURjWTtFQUNJLGlCQUFBO0VBQ0EsbUJBQUE7RUFDQSxhQUFBO0VBQ0Esa0JBQUE7RUFDQSxZQUFBO0VBQ0EsV0FBQTtFQUNBLGdCQUFBO0FDWmhCO0FEYWdCO0VBQ0ksY0FBQTtFQUNBLGVBQUE7RUFDQSxpQkFBQTtBQ1hwQjtBRGNnQjtFQUNJLGVBQUE7QUNacEIiLCJmaWxlIjoic3JjL2FwcC9wYWdlcy9wb3B1bGFyL3BvcHVsYXIucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWhlYWRlcntcbiAgICAuYmFja3tcbiAgICAgICAgZm9udC1zaXplOiAyN3B4O1xuICAgICAgICBtYXJnaW4tbGVmdDogMTBweDtcbiAgICB9XG4gICAgaW9uLWJ1dHRvbntcbiAgICAgICAgbWFyZ2luOiAwO1xuXG4gICAgICAgIGlvbi1pY29ue1xuICAgICAgICAgICAgY29sb3I6IGJsYWNrO1xuICAgICAgICAgICAgZm9udC1zaXplOiAyMHB4O1xuICAgICAgICB9XG4gICAgfVxufVxuXG4ubWFpbl9jb250ZW50X2RpdntcbiAgICB3aWR0aDogMTAwJTtcblxuICAgIGlvbi1sYWJlbCB7XG4gICAgICAgIGRpc3BsYXk6IGJsb2NrO1xuICAgIH1cblxuICAgIC5zZWFyY2hfZGl2e1xuICAgICAgICBwYWRkaW5nOiAxMHB4IDE2cHg7XG4gICAgICAgIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCBsaWdodGdyYXk7XG4gICAgXG4gICAgICAgIGlvbi1pbnB1dHtcbiAgICAgICAgICAgIGJvcmRlcjogMXB4IHNvbGlkIGJsYWNrO1xuICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogMjVweDtcbiAgICAgICAgICAgIGlvbi1pY29ue1xuICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMjBweDtcbiAgICAgICAgICAgICAgICBwYWRkaW5nLWxlZnQ6IDEwcHg7XG4gICAgICAgICAgICAgICAgcGFkZGluZy1yaWdodDogNXB4O1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgLnRlc3R7XG4gICAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICAgICAgICAgIG1hcmdpbi1yaWdodDogMTBweDtcbiAgICAgICAgICAgIGJvcmRlcjogMXB4IHNvbGlkIGxpZ2h0Z3JheTtcbiAgICAgICAgICAgIGJhY2tncm91bmQ6IHdoaXRlc21va2U7XG4gICAgICAgICAgICBib3JkZXItcmFkaXVzOiAyNXB4O1xuICAgICAgICAgICAgcGFkZGluZzogNXB4IDE1cHg7XG5cbiAgICAgICAgICAgIGlvbi1pY29ue1xuICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMTNweDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIFxuICAgICAgICAuYWN0aXZle1xuICAgICAgICAgICAgYm9yZGVyOiAxcHggc29saWQgdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xuICAgICAgICAgICAgYmFja2dyb3VuZDogcmdiYSgxNywxMTYsMTkyLDAuMik7XG4gICAgICAgICAgICBcbiAgICAgICAgICAgIGlvbi1sYWJlbCB7XG4gICAgICAgICAgICAgICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KSAhaW1wb3J0YW50O1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBpb24taWNvbntcbiAgICAgICAgICAgICAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgXG4gICAgICAgIC5jaGlwc19kaXZ7XG4gICAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICAgICAgZmxleC1kaXJlY3Rpb246IHJvdztcbiAgICAgICAgICAgIG92ZXJmbG93OiBzY3JvbGw7XG4gICAgICAgICAgICAuY2hpcHtcbiAgICAgICAgICAgICAgICB3aGl0ZS1zcGFjZTogbm93cmFwO1xuICAgICAgICAgICAgICAgIGNvbG9yOiBibGFjaztcbiAgICAgICAgICAgICAgICBmb250LXNpemU6IDEzcHg7XG4gICAgICAgICAgICAgICAgbWFyZ2luLXJpZ2h0OiA3cHg7XG4gICAgICAgICAgICB9ICBcbiAgICAgICAgfSAgXG4gICAgfVxuXG4gICAgLmxvd2VyX2RpdntcbiAgICAgICAgcGFkZGluZzogMTBweDtcblxuICAgICAgICBpb24tZ3JpZHtcbiAgICAgICAgICAgIHBhZGRpbmc6IDA7XG4gICAgICAgIH1cblxuICAgICAgICAuaW1hZ2VfZGl2e1xuICAgICAgICAgICAgd2lkdGg6IDEwMCU7XG4gICAgICAgICAgICBoZWlnaHQ6IDE1MHB4O1xuICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogNXB4O1xuICAgICAgICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xuXG4gICAgICAgICAgICAud2hpdGVfZGl2e1xuICAgICAgICAgICAgICAgIGJhY2tncm91bmQ6IHdoaXRlO1xuICAgICAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDI1cHg7XG4gICAgICAgICAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAgICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgICAgICAgICAgICAgYm90dG9tOiAxMHB4O1xuICAgICAgICAgICAgICAgIHJpZ2h0OiAxMHB4O1xuICAgICAgICAgICAgICAgIHBhZGRpbmc6IDNweCA2cHg7XG4gICAgICAgICAgICAgICAgaW9uLWljb257XG4gICAgICAgICAgICAgICAgICAgIGNvbG9yOiAjRkY2QjAxO1xuICAgICAgICAgICAgICAgICAgICBmb250LXNpemU6IDE1cHg7XG4gICAgICAgICAgICAgICAgICAgIG1hcmdpbi1yaWdodDogNXB4O1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIGlvbi1sYWJlbCB7XG4gICAgICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMTJweDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG59IiwiaW9uLWhlYWRlciAuYmFjayB7XG4gIGZvbnQtc2l6ZTogMjdweDtcbiAgbWFyZ2luLWxlZnQ6IDEwcHg7XG59XG5pb24taGVhZGVyIGlvbi1idXR0b24ge1xuICBtYXJnaW46IDA7XG59XG5pb24taGVhZGVyIGlvbi1idXR0b24gaW9uLWljb24ge1xuICBjb2xvcjogYmxhY2s7XG4gIGZvbnQtc2l6ZTogMjBweDtcbn1cblxuLm1haW5fY29udGVudF9kaXYge1xuICB3aWR0aDogMTAwJTtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IGlvbi1sYWJlbCB7XG4gIGRpc3BsYXk6IGJsb2NrO1xufVxuLm1haW5fY29udGVudF9kaXYgLnNlYXJjaF9kaXYge1xuICBwYWRkaW5nOiAxMHB4IDE2cHg7XG4gIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCBsaWdodGdyYXk7XG59XG4ubWFpbl9jb250ZW50X2RpdiAuc2VhcmNoX2RpdiBpb24taW5wdXQge1xuICBib3JkZXI6IDFweCBzb2xpZCBibGFjaztcbiAgYm9yZGVyLXJhZGl1czogMjVweDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5zZWFyY2hfZGl2IGlvbi1pbnB1dCBpb24taWNvbiB7XG4gIGZvbnQtc2l6ZTogMjBweDtcbiAgcGFkZGluZy1sZWZ0OiAxMHB4O1xuICBwYWRkaW5nLXJpZ2h0OiA1cHg7XG59XG4ubWFpbl9jb250ZW50X2RpdiAuc2VhcmNoX2RpdiAudGVzdCB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIG1hcmdpbi1yaWdodDogMTBweDtcbiAgYm9yZGVyOiAxcHggc29saWQgbGlnaHRncmF5O1xuICBiYWNrZ3JvdW5kOiB3aGl0ZXNtb2tlO1xuICBib3JkZXItcmFkaXVzOiAyNXB4O1xuICBwYWRkaW5nOiA1cHggMTVweDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5zZWFyY2hfZGl2IC50ZXN0IGlvbi1pY29uIHtcbiAgZm9udC1zaXplOiAxM3B4O1xufVxuLm1haW5fY29udGVudF9kaXYgLnNlYXJjaF9kaXYgLmFjdGl2ZSB7XG4gIGJvcmRlcjogMXB4IHNvbGlkIHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcbiAgYmFja2dyb3VuZDogcmdiYSgxNywgMTE2LCAxOTIsIDAuMik7XG59XG4ubWFpbl9jb250ZW50X2RpdiAuc2VhcmNoX2RpdiAuYWN0aXZlIGlvbi1sYWJlbCB7XG4gIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSkgIWltcG9ydGFudDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5zZWFyY2hfZGl2IC5hY3RpdmUgaW9uLWljb24ge1xuICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xufVxuLm1haW5fY29udGVudF9kaXYgLnNlYXJjaF9kaXYgLmNoaXBzX2RpdiB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGZsZXgtZGlyZWN0aW9uOiByb3c7XG4gIG92ZXJmbG93OiBzY3JvbGw7XG59XG4ubWFpbl9jb250ZW50X2RpdiAuc2VhcmNoX2RpdiAuY2hpcHNfZGl2IC5jaGlwIHtcbiAgd2hpdGUtc3BhY2U6IG5vd3JhcDtcbiAgY29sb3I6IGJsYWNrO1xuICBmb250LXNpemU6IDEzcHg7XG4gIG1hcmdpbi1yaWdodDogN3B4O1xufVxuLm1haW5fY29udGVudF9kaXYgLmxvd2VyX2RpdiB7XG4gIHBhZGRpbmc6IDEwcHg7XG59XG4ubWFpbl9jb250ZW50X2RpdiAubG93ZXJfZGl2IGlvbi1ncmlkIHtcbiAgcGFkZGluZzogMDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5sb3dlcl9kaXYgLmltYWdlX2RpdiB7XG4gIHdpZHRoOiAxMDAlO1xuICBoZWlnaHQ6IDE1MHB4O1xuICBib3JkZXItcmFkaXVzOiA1cHg7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5sb3dlcl9kaXYgLmltYWdlX2RpdiAud2hpdGVfZGl2IHtcbiAgYmFja2dyb3VuZDogd2hpdGU7XG4gIGJvcmRlci1yYWRpdXM6IDI1cHg7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgYm90dG9tOiAxMHB4O1xuICByaWdodDogMTBweDtcbiAgcGFkZGluZzogM3B4IDZweDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5sb3dlcl9kaXYgLmltYWdlX2RpdiAud2hpdGVfZGl2IGlvbi1pY29uIHtcbiAgY29sb3I6ICNGRjZCMDE7XG4gIGZvbnQtc2l6ZTogMTVweDtcbiAgbWFyZ2luLXJpZ2h0OiA1cHg7XG59XG4ubWFpbl9jb250ZW50X2RpdiAubG93ZXJfZGl2IC5pbWFnZV9kaXYgLndoaXRlX2RpdiBpb24tbGFiZWwge1xuICBmb250LXNpemU6IDEycHg7XG59Il19 */");

/***/ }),

/***/ "./src/app/pages/popular/popular.page.ts":
/*!***********************************************!*\
  !*** ./src/app/pages/popular/popular.page.ts ***!
  \***********************************************/
/*! exports provided: PopularPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PopularPage", function() { return PopularPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var src_app_services_dummy_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/dummy.service */ "./src/app/services/dummy.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");





let PopularPage = class PopularPage {
    constructor(dummy, actionSheetController, router, navCtrl) {
        this.dummy = dummy;
        this.actionSheetController = actionSheetController;
        this.router = router;
        this.navCtrl = navCtrl;
        this.moviesCat = ['Movies', 'Languages', 'Ratings', 'Genre', 'Year', 'Platform'];
        this.movies = this.dummy.movies;
    }
    ngOnInit() {
    }
    selectCat(val) {
        this.currentCat = val;
    }
    openActionSheet() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const actionSheet = yield this.actionSheetController.create({
                mode: 'md',
                buttons: [
                    {
                        text: 'About Movies Online',
                        icon: 'caret-forward-circle-outline',
                    },
                    {
                        text: 'How to Use',
                        icon: 'help-circle-outline',
                    },
                    {
                        text: 'FAQs',
                        icon: 'alert-circle-outline',
                    },
                    {
                        text: 'Blogs',
                        icon: 'document-text-outline',
                    }
                ]
            });
            yield actionSheet.present();
        });
    }
    goToMovieDetail() {
        this.router.navigate(['/tabs/movie-details']);
    }
    goBack() {
        this.navCtrl.back();
    }
};
PopularPage.ctorParameters = () => [
    { type: src_app_services_dummy_service__WEBPACK_IMPORTED_MODULE_2__["DummyService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ActionSheetController"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["NavController"] }
];
PopularPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-popular',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./popular.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/popular/popular.page.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./popular.page.scss */ "./src/app/pages/popular/popular.page.scss")).default]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [src_app_services_dummy_service__WEBPACK_IMPORTED_MODULE_2__["DummyService"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ActionSheetController"],
        _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"], _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["NavController"]])
], PopularPage);



/***/ })

}]);
//# sourceMappingURL=popular-popular-module-es2015.js.map