function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["music-list-music-list-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/music-list/music-list.page.html":
  /*!*********************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/music-list/music-list.page.html ***!
    \*********************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppPagesMusicListMusicListPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar>\n   <!-- <ion-buttons slot=\"start\">\n     <ion-back-button mode=\"md\"></ion-back-button>\n   </ion-buttons> -->\n\n   <ion-icon class=\"back\" name=\"arrow-back-outline\" (click)=\"goBack()\"></ion-icon>\n\n    <ion-title>Music</ion-title>\n\n    <ion-button slot=\"end\" size=\"small\" fill=\"clear\">\n      <ion-icon name=\"language-outline\"></ion-icon>\n    </ion-button>\n\n    <ion-button slot=\"end\" size=\"small\" fill=\"clear\">\n      <ion-icon name=\"notifications-outline\"></ion-icon>\n    </ion-button>\n\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div class=\"main_content_div\">\n\n    <div class=\"upper_div\">\n      <ion-input placeholder=\"Search\" type=\"text\">\n        <ion-icon name=\"search-outline\"></ion-icon>\n      </ion-input>\n    </div>\n\n    <div class=\"lower_div\">\n\n      <div class=\"main_slider\">\n        <div class=\"head_flex\">\n          <ion-label class=\"head_lbl\">Trending Songs Hindi</ion-label>\n          <ion-label class=\"small_lbl\" (click)=\"goToMoreMusic()\">View More</ion-label>\n        </div>\n\n        <div class=\"slider_class\">\n          <ion-slides mode=\"ios\" [options]=\"slideOpts\">\n            <ion-slide *ngFor=\"let item of (songs | slice : 0 : 7)\" (click)=\"goToMusicVideo()\">\n              <div class=\"inner_slider\">\n                <div class=\"image_div bg_image\" [style.backgroundImage]=\"'url( '+ item.img +' )'\" ></div>\n                <ion-label class=\"name\">{{item.name | slice: 0: 15}}</ion-label>\n              </div>\n            </ion-slide>\n          </ion-slides>\n        </div>\n      </div>\n\n      <div class=\"main_slider\">\n        <div class=\"head_flex\">\n          <ion-label class=\"head_lbl\">Trending Songs Punjabi</ion-label>\n          <ion-label class=\"small_lbl\" (click)=\"goToMoreMusic()\">View More</ion-label>\n        </div>\n\n        <div class=\"slider_class\">\n          <ion-slides mode=\"ios\" [options]=\"slideOpts\">\n            <ion-slide *ngFor=\"let item of (songs | slice : 7 )\" (click)=\"goToMusicVideo()\">\n              <div class=\"inner_slider\">\n                <div class=\"image_div bg_image\" [style.backgroundImage]=\"'url( '+ item.img +' )'\" ></div>\n                <ion-label class=\"name\">Hello</ion-label>\n              </div>\n            </ion-slide>\n          </ion-slides>\n        </div>\n      </div>\n\n      <div class=\"main_slider\">\n        <div class=\"head_flex\">\n          <ion-label class=\"head_lbl\">New Realese Hindi</ion-label>\n          <ion-label class=\"small_lbl\" (click)=\"goToMoreMusic()\">View More</ion-label>\n        </div>\n\n        <div class=\"slider_class\">\n          <ion-slides mode=\"ios\" [options]=\"slideOpts\">\n            <ion-slide *ngFor=\"let item of (songs | slice : 4: 11)\" (click)=\"goToMusicVideo()\">\n              <div class=\"inner_slider\">\n                <div class=\"image_div bg_image\" [style.backgroundImage]=\"'url( '+ item.img +' )'\" ></div>\n                <ion-label class=\"name\">Hello</ion-label>\n              </div>\n            </ion-slide>\n          </ion-slides>\n        </div>\n      </div>\n\n      <div class=\"main_slider\">\n        <div class=\"head_flex\">\n          <ion-label class=\"head_lbl\">New Realese Punjabi</ion-label>\n          <ion-label class=\"small_lbl\" (click)=\"goToMoreMusic()\">View More</ion-label>\n        </div>\n\n        <div class=\"slider_class\">\n          <ion-slides mode=\"ios\" [options]=\"slideOpts\">\n            <ion-slide *ngFor=\"let item of (songs | slice : 7: 12)\" (click)=\"goToMusicVideo()\">\n              <div class=\"inner_slider\">\n                <div class=\"image_div bg_image\" [style.backgroundImage]=\"'url( '+ item.img +' )'\" ></div>\n                <ion-label class=\"name\">Hello</ion-label>\n              </div>\n            </ion-slide>\n          </ion-slides>\n        </div>\n      </div>\n\n\n      <div class=\"main_slider\">\n        <div class=\"head_flex\">\n          <ion-label class=\"head_lbl\">Popular in Hindi</ion-label>\n          <ion-label class=\"small_lbl\" (click)=\"goToMoreMusic()\">View More</ion-label>\n        </div>\n\n        <div class=\"slider_class\">\n          <ion-slides mode=\"ios\" [options]=\"slideOpts\">\n            <ion-slide *ngFor=\"let item of (songs | slice : 0: 7)\" (click)=\"goToMusicVideo()\">\n              <div class=\"inner_slider\">\n                <div class=\"image_div bg_image\" [style.backgroundImage]=\"'url( '+ item.img +' )'\" ></div>\n                <ion-label class=\"name\">Hello</ion-label>\n              </div>\n            </ion-slide>\n          </ion-slides>\n        </div>\n      </div>\n\n    </div>\n\n  </div>\n</ion-content>\n";
    /***/
  },

  /***/
  "./src/app/pages/music-list/music-list-routing.module.ts":
  /*!***************************************************************!*\
    !*** ./src/app/pages/music-list/music-list-routing.module.ts ***!
    \***************************************************************/

  /*! exports provided: MusicListPageRoutingModule */

  /***/
  function srcAppPagesMusicListMusicListRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "MusicListPageRoutingModule", function () {
      return MusicListPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _music_list_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./music-list.page */
    "./src/app/pages/music-list/music-list.page.ts");

    var routes = [{
      path: '',
      component: _music_list_page__WEBPACK_IMPORTED_MODULE_3__["MusicListPage"]
    }];

    var MusicListPageRoutingModule = function MusicListPageRoutingModule() {
      _classCallCheck(this, MusicListPageRoutingModule);
    };

    MusicListPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], MusicListPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/pages/music-list/music-list.module.ts":
  /*!*******************************************************!*\
    !*** ./src/app/pages/music-list/music-list.module.ts ***!
    \*******************************************************/

  /*! exports provided: MusicListPageModule */

  /***/
  function srcAppPagesMusicListMusicListModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "MusicListPageModule", function () {
      return MusicListPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _music_list_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./music-list-routing.module */
    "./src/app/pages/music-list/music-list-routing.module.ts");
    /* harmony import */


    var _music_list_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./music-list.page */
    "./src/app/pages/music-list/music-list.page.ts");

    var MusicListPageModule = function MusicListPageModule() {
      _classCallCheck(this, MusicListPageModule);
    };

    MusicListPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _music_list_routing_module__WEBPACK_IMPORTED_MODULE_5__["MusicListPageRoutingModule"]],
      declarations: [_music_list_page__WEBPACK_IMPORTED_MODULE_6__["MusicListPage"]]
    })], MusicListPageModule);
    /***/
  },

  /***/
  "./src/app/pages/music-list/music-list.page.scss":
  /*!*******************************************************!*\
    !*** ./src/app/pages/music-list/music-list.page.scss ***!
    \*******************************************************/

  /*! exports provided: default */

  /***/
  function srcAppPagesMusicListMusicListPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "ion-header .back {\n  font-size: 27px;\n  margin-left: 10px;\n}\nion-header ion-button {\n  margin: 0;\n}\nion-header ion-button ion-icon {\n  color: black;\n  font-size: 20px;\n}\n.main_content_div {\n  width: 100%;\n}\n.main_content_div ion-label {\n  display: block;\n}\n.main_content_div .upper_div {\n  padding: 10px 16px;\n  border-bottom: 1px solid lightgray;\n}\n.main_content_div .upper_div ion-input {\n  border: 1px solid black;\n  border-radius: 25px;\n}\n.main_content_div .upper_div ion-input ion-icon {\n  font-size: 20px;\n  padding-left: 10px;\n  padding-right: 5px;\n}\n.main_content_div .lower_div {\n  padding: 16px;\n}\n.main_content_div .lower_div .main_slider .head_flex {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n}\n.main_content_div .lower_div .main_slider .head_flex .head_lbl {\n  font-weight: 500;\n  font-size: 15px;\n}\n.main_content_div .lower_div .main_slider .head_flex .small_lbl {\n  font-size: 13px;\n  color: gray;\n}\n.main_content_div .lower_div .main_slider .slider_class ion-slide {\n  height: 170px;\n  margin-right: 10px;\n  margin-left: 5px;\n}\n.main_content_div .lower_div .main_slider .slider_class .inner_slider {\n  width: 100%;\n  height: 130px;\n  box-shadow: 0px 3px 6px rgba(0, 0, 0, 0.3);\n  border-radius: 5px;\n}\n.main_content_div .lower_div .main_slider .slider_class .image_div {\n  width: 100%;\n  height: 100px;\n  border-top-left-radius: 5px;\n  border-top-right-radius: 5px;\n  position: relative;\n}\n.main_content_div .lower_div .main_slider .slider_class .name {\n  padding: 5px;\n  font-size: 13px;\n  text-align: left;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvbXVzaWMtbGlzdC9FOlxcSW9uaWMgUHJvamVjdHNcXGlvbmljLTUtdGVtcGxhdGUtYnVuZGxlLWlvbmljLTUtdGhlbWVzLWJ1bmRsZXMtaW9uaWMtNS10ZW1wbGF0ZXMtd2l0aC0xMC1hcHBzXFxBcHBfc291cmNlX2NvZGVcXEFwcHNfY29kZVxcTXVsdGlfcHVycG9zZS9zcmNcXGFwcFxccGFnZXNcXG11c2ljLWxpc3RcXG11c2ljLWxpc3QucGFnZS5zY3NzIiwic3JjL2FwcC9wYWdlcy9tdXNpYy1saXN0L211c2ljLWxpc3QucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNJO0VBQ0ksZUFBQTtFQUNBLGlCQUFBO0FDQVI7QURFSTtFQUNJLFNBQUE7QUNBUjtBREVRO0VBQ0ksWUFBQTtFQUNBLGVBQUE7QUNBWjtBREtBO0VBQ0ksV0FBQTtBQ0ZKO0FES0k7RUFDSSxjQUFBO0FDSFI7QURNSTtFQUNJLGtCQUFBO0VBQ0Esa0NBQUE7QUNKUjtBREtRO0VBQ0ksdUJBQUE7RUFDQSxtQkFBQTtBQ0haO0FESVk7RUFDSSxlQUFBO0VBQ0Esa0JBQUE7RUFDQSxrQkFBQTtBQ0ZoQjtBRE9JO0VBQ0ksYUFBQTtBQ0xSO0FEWVk7RUFDSSxhQUFBO0VBQ0EsOEJBQUE7RUFDQSxtQkFBQTtBQ1ZoQjtBRGFnQjtFQUNJLGdCQUFBO0VBQ0EsZUFBQTtBQ1hwQjtBRGNnQjtFQUNJLGVBQUE7RUFDQSxXQUFBO0FDWnBCO0FEa0JnQjtFQUNJLGFBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0FDaEJwQjtBRG1CZ0I7RUFDSSxXQUFBO0VBQ0EsYUFBQTtFQUNBLDBDQUFBO0VBQ0Esa0JBQUE7QUNqQnBCO0FEb0JnQjtFQUNJLFdBQUE7RUFDQSxhQUFBO0VBQ0EsMkJBQUE7RUFDQSw0QkFBQTtFQUNBLGtCQUFBO0FDbEJwQjtBRG9CZ0I7RUFDSSxZQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0FDbEJwQiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL211c2ljLWxpc3QvbXVzaWMtbGlzdC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24taGVhZGVye1xuICAgIC5iYWNre1xuICAgICAgICBmb250LXNpemU6IDI3cHg7XG4gICAgICAgIG1hcmdpbi1sZWZ0OiAxMHB4O1xuICAgIH1cbiAgICBpb24tYnV0dG9ue1xuICAgICAgICBtYXJnaW46IDA7XG5cbiAgICAgICAgaW9uLWljb257XG4gICAgICAgICAgICBjb2xvcjogYmxhY2s7XG4gICAgICAgICAgICBmb250LXNpemU6IDIwcHg7XG4gICAgICAgIH1cbiAgICB9XG59XG5cbi5tYWluX2NvbnRlbnRfZGl2e1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIC8vIHBhZGRpbmc6IDE2cHg7XG5cbiAgICBpb24tbGFiZWwge1xuICAgICAgICBkaXNwbGF5OiBibG9jaztcbiAgICB9XG5cbiAgICAudXBwZXJfZGl2e1xuICAgICAgICBwYWRkaW5nOiAxMHB4IDE2cHg7XG4gICAgICAgIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCBsaWdodGdyYXk7XG4gICAgICAgIGlvbi1pbnB1dHtcbiAgICAgICAgICAgIGJvcmRlcjogMXB4IHNvbGlkIGJsYWNrO1xuICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogMjVweDtcbiAgICAgICAgICAgIGlvbi1pY29ue1xuICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMjBweDtcbiAgICAgICAgICAgICAgICBwYWRkaW5nLWxlZnQ6IDEwcHg7XG4gICAgICAgICAgICAgICAgcGFkZGluZy1yaWdodDogNXB4O1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuXG4gICAgLmxvd2VyX2RpdntcbiAgICAgICAgcGFkZGluZzogMTZweDtcblxuICAgICAgICAubWFpbl9zbGlkZXJ7XG5cbiAgICAgICAgICAgIC8vIHBhZGRpbmctdG9wOiAxMHB4O1xuICAgICAgICAgICAgLy8gcGFkZGluZy1ib3R0b206IDEwcHg7XG4gICAgICAgICAgICBcbiAgICAgICAgICAgIC5oZWFkX2ZsZXh7XG4gICAgICAgICAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAgICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XG4gICAgICAgICAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICAgICAgICAgICAgICAvLyBwYWRkaW5nLWJvdHRvbTogMjBweDtcblxuICAgICAgICAgICAgICAgIC5oZWFkX2xibHtcbiAgICAgICAgICAgICAgICAgICAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgICAgICAgICAgICAgICAgICAgZm9udC1zaXplOiAxNXB4O1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIC5zbWFsbF9sYmx7XG4gICAgICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMTNweDtcbiAgICAgICAgICAgICAgICAgICAgY29sb3I6IGdyYXk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAuc2xpZGVyX2NsYXNze1xuXG4gICAgICAgICAgICAgICAgaW9uLXNsaWRle1xuICAgICAgICAgICAgICAgICAgICBoZWlnaHQ6IDE3MHB4O1xuICAgICAgICAgICAgICAgICAgICBtYXJnaW4tcmlnaHQ6IDEwcHg7XG4gICAgICAgICAgICAgICAgICAgIG1hcmdpbi1sZWZ0OiA1cHg7XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgLmlubmVyX3NsaWRlcntcbiAgICAgICAgICAgICAgICAgICAgd2lkdGg6IDEwMCU7XG4gICAgICAgICAgICAgICAgICAgIGhlaWdodDogMTMwcHg7XG4gICAgICAgICAgICAgICAgICAgIGJveC1zaGFkb3c6IDBweCAzcHggNnB4IHJnYmEoMCwwLDAsMC4zKTtcbiAgICAgICAgICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogNXB4O1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIC5pbWFnZV9kaXZ7XG4gICAgICAgICAgICAgICAgICAgIHdpZHRoOiAxMDAlO1xuICAgICAgICAgICAgICAgICAgICBoZWlnaHQ6IDEwMHB4O1xuICAgICAgICAgICAgICAgICAgICBib3JkZXItdG9wLWxlZnQtcmFkaXVzOiA1cHg7XG4gICAgICAgICAgICAgICAgICAgIGJvcmRlci10b3AtcmlnaHQtcmFkaXVzOiA1cHg7XG4gICAgICAgICAgICAgICAgICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgLm5hbWV7XG4gICAgICAgICAgICAgICAgICAgIHBhZGRpbmc6IDVweDtcbiAgICAgICAgICAgICAgICAgICAgZm9udC1zaXplOiAxM3B4O1xuICAgICAgICAgICAgICAgICAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cbn0iLCJpb24taGVhZGVyIC5iYWNrIHtcbiAgZm9udC1zaXplOiAyN3B4O1xuICBtYXJnaW4tbGVmdDogMTBweDtcbn1cbmlvbi1oZWFkZXIgaW9uLWJ1dHRvbiB7XG4gIG1hcmdpbjogMDtcbn1cbmlvbi1oZWFkZXIgaW9uLWJ1dHRvbiBpb24taWNvbiB7XG4gIGNvbG9yOiBibGFjaztcbiAgZm9udC1zaXplOiAyMHB4O1xufVxuXG4ubWFpbl9jb250ZW50X2RpdiB7XG4gIHdpZHRoOiAxMDAlO1xufVxuLm1haW5fY29udGVudF9kaXYgaW9uLWxhYmVsIHtcbiAgZGlzcGxheTogYmxvY2s7XG59XG4ubWFpbl9jb250ZW50X2RpdiAudXBwZXJfZGl2IHtcbiAgcGFkZGluZzogMTBweCAxNnB4O1xuICBib3JkZXItYm90dG9tOiAxcHggc29saWQgbGlnaHRncmF5O1xufVxuLm1haW5fY29udGVudF9kaXYgLnVwcGVyX2RpdiBpb24taW5wdXQge1xuICBib3JkZXI6IDFweCBzb2xpZCBibGFjaztcbiAgYm9yZGVyLXJhZGl1czogMjVweDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC51cHBlcl9kaXYgaW9uLWlucHV0IGlvbi1pY29uIHtcbiAgZm9udC1zaXplOiAyMHB4O1xuICBwYWRkaW5nLWxlZnQ6IDEwcHg7XG4gIHBhZGRpbmctcmlnaHQ6IDVweDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5sb3dlcl9kaXYge1xuICBwYWRkaW5nOiAxNnB4O1xufVxuLm1haW5fY29udGVudF9kaXYgLmxvd2VyX2RpdiAubWFpbl9zbGlkZXIgLmhlYWRfZmxleCB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5sb3dlcl9kaXYgLm1haW5fc2xpZGVyIC5oZWFkX2ZsZXggLmhlYWRfbGJsIHtcbiAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgZm9udC1zaXplOiAxNXB4O1xufVxuLm1haW5fY29udGVudF9kaXYgLmxvd2VyX2RpdiAubWFpbl9zbGlkZXIgLmhlYWRfZmxleCAuc21hbGxfbGJsIHtcbiAgZm9udC1zaXplOiAxM3B4O1xuICBjb2xvcjogZ3JheTtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5sb3dlcl9kaXYgLm1haW5fc2xpZGVyIC5zbGlkZXJfY2xhc3MgaW9uLXNsaWRlIHtcbiAgaGVpZ2h0OiAxNzBweDtcbiAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xuICBtYXJnaW4tbGVmdDogNXB4O1xufVxuLm1haW5fY29udGVudF9kaXYgLmxvd2VyX2RpdiAubWFpbl9zbGlkZXIgLnNsaWRlcl9jbGFzcyAuaW5uZXJfc2xpZGVyIHtcbiAgd2lkdGg6IDEwMCU7XG4gIGhlaWdodDogMTMwcHg7XG4gIGJveC1zaGFkb3c6IDBweCAzcHggNnB4IHJnYmEoMCwgMCwgMCwgMC4zKTtcbiAgYm9yZGVyLXJhZGl1czogNXB4O1xufVxuLm1haW5fY29udGVudF9kaXYgLmxvd2VyX2RpdiAubWFpbl9zbGlkZXIgLnNsaWRlcl9jbGFzcyAuaW1hZ2VfZGl2IHtcbiAgd2lkdGg6IDEwMCU7XG4gIGhlaWdodDogMTAwcHg7XG4gIGJvcmRlci10b3AtbGVmdC1yYWRpdXM6IDVweDtcbiAgYm9yZGVyLXRvcC1yaWdodC1yYWRpdXM6IDVweDtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xufVxuLm1haW5fY29udGVudF9kaXYgLmxvd2VyX2RpdiAubWFpbl9zbGlkZXIgLnNsaWRlcl9jbGFzcyAubmFtZSB7XG4gIHBhZGRpbmc6IDVweDtcbiAgZm9udC1zaXplOiAxM3B4O1xuICB0ZXh0LWFsaWduOiBsZWZ0O1xufSJdfQ== */";
    /***/
  },

  /***/
  "./src/app/pages/music-list/music-list.page.ts":
  /*!*****************************************************!*\
    !*** ./src/app/pages/music-list/music-list.page.ts ***!
    \*****************************************************/

  /*! exports provided: MusicListPage */

  /***/
  function srcAppPagesMusicListMusicListPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "MusicListPage", function () {
      return MusicListPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var src_app_services_music_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! src/app/services/music.service */
    "./src/app/services/music.service.ts");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");

    var MusicListPage = /*#__PURE__*/function () {
      function MusicListPage(music, router, navCtrl) {
        _classCallCheck(this, MusicListPage);

        this.music = music;
        this.router = router;
        this.navCtrl = navCtrl;
        this.slideOpts = {
          slidesPerView: 3
        };
        this.songs = this.music.songs;
      }

      _createClass(MusicListPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }, {
        key: "goToMoreMusic",
        value: function goToMoreMusic() {
          this.router.navigate(['/tabs/more-music']);
        }
      }, {
        key: "goToMusicVideo",
        value: function goToMusicVideo() {
          this.router.navigate(['/tabs/music-video']);
        }
      }, {
        key: "goBack",
        value: function goBack() {
          this.navCtrl.back();
        }
      }]);

      return MusicListPage;
    }();

    MusicListPage.ctorParameters = function () {
      return [{
        type: src_app_services_music_service__WEBPACK_IMPORTED_MODULE_2__["MusicService"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["NavController"]
      }];
    };

    MusicListPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-music-list',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./music-list.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/music-list/music-list.page.html"))["default"],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./music-list.page.scss */
      "./src/app/pages/music-list/music-list.page.scss"))["default"]]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [src_app_services_music_service__WEBPACK_IMPORTED_MODULE_2__["MusicService"], _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["NavController"]])], MusicListPage);
    /***/
  }
}]);
//# sourceMappingURL=music-list-music-list-module-es5.js.map