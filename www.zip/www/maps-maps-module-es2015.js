(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["maps-maps-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/maps/maps.page.html":
/*!*********************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/maps/maps.page.html ***!
  \*********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<!-- <ion-header>\n  <ion-toolbar>\n    <ion-title>maps</ion-title>\n  </ion-toolbar>\n</ion-header> -->\n\n<ion-content>\n  <div class=\"main_content_div\">\n    <div #map id=\"map\" class=\"map\">\n      \n    </div>\n    \n    <div class=\"content_div\">\n      <div class=\"explore_div\">\n\n        <ion-label class=\"head_lbl\">Explore Nearby</ion-label>\n        <ion-grid fixed>\n          <ion-row>\n            <ion-col size=\"3\">\n              <img src=\"assets/imgs/search/res.png\" alt=\"\">\n              <ion-label>Restaurant</ion-label>\n            </ion-col>\n            <ion-col size=\"3\">\n              <img src=\"assets/imgs/search/cafe.png\" alt=\"\">\n              <ion-label>Cafes</ion-label>\n            </ion-col>\n            <ion-col size=\"3\">\n              <img src=\"assets/imgs/search/delivery.png\" alt=\"\">\n              <ion-label>Home Delivery</ion-label>\n            </ion-col>\n            <ion-col size=\"3\">\n              <img src=\"assets/imgs/search/more.png\" alt=\"\">\n              <ion-label>More</ion-label>\n            </ion-col>\n          </ion-row>\n        </ion-grid>\n      </div>\n\n      <div class=\"main_slider\">\n        <div class=\"head_flex\">\n          <ion-label class=\"head_lbl\">Namkeen Retailers</ion-label>\n          <ion-label class=\"small_lbl\" >View More</ion-label>\n        </div>\n\n        <div class=\"slider_class\">\n          <ion-slides mode=\"ios\" [options]=\"slideOpts\">\n            <ion-slide *ngFor=\"let item of (product | slice : 0: 6)\" >\n              <div class=\"image_div bg_image\" [style.backgroundImage]=\"'url( '+ item.img +' )'\">\n                <div class=\"overlay\">\n                  <div class=\"detail_div\">\n                     <ion-label>{{item.name}}</ion-label>\n                     <div style=\"display: flex;\">\n                      <ion-label>3.4</ion-label><ion-icon name=\"star\"></ion-icon>\n                     </div>\n                  </div>\n                </div>\n              </div>\n            </ion-slide>\n          </ion-slides>\n        </div>\n      </div>\n\n      <div class=\"main_slider\">\n        <div class=\"head_flex\">\n          <ion-label class=\"head_lbl\">Ice Cream Parlour</ion-label>\n          <ion-label class=\"small_lbl\" >View More</ion-label>\n        </div>\n\n        <div class=\"slider_class\">\n          <ion-slides mode=\"ios\" [options]=\"slideOpts\">\n            <ion-slide *ngFor=\"let item of (product | slice : 7)\" >\n              <div class=\"image_div bg_image\" [style.backgroundImage]=\"'url( '+ item.img +' )'\">\n                <div class=\"overlay\">\n                  <div class=\"detail_div\">\n                     <ion-label>{{item.name}}</ion-label>\n                     <div style=\"display: flex;\">\n                      <ion-label>3.4</ion-label><ion-icon name=\"star\"></ion-icon>\n                     </div>\n                  </div>\n                </div>\n              </div>\n            </ion-slide>\n          </ion-slides>\n        </div>\n      </div>\n\n      <div class=\"main_slider\">\n        <div class=\"head_flex\">\n          <ion-label class=\"head_lbl\">Restaurants</ion-label>\n          <ion-label class=\"small_lbl\" >View More</ion-label>\n        </div>\n\n        <div class=\"slider_class\">\n          <ion-slides mode=\"ios\" [options]=\"slideOpts\">\n            <ion-slide *ngFor=\"let item of (product | slice : 0: 6)\" >\n              <div class=\"image_div bg_image\" [style.backgroundImage]=\"'url( '+ item.img +' )'\">\n                <div class=\"overlay\">\n                  <div class=\"detail_div\">\n                     <ion-label>{{item.name}}</ion-label>\n                     <div style=\"display: flex;\">\n                      <ion-label>3.4</ion-label><ion-icon name=\"star\"></ion-icon>\n                     </div>\n                  </div>\n                </div>\n              </div>\n            </ion-slide>\n          </ion-slides>\n        </div>\n      </div>\n\n      <div class=\"main_slider\">\n        <div class=\"head_flex\">\n          <ion-label class=\"head_lbl\">Ice Cream Retailers</ion-label>\n          <ion-label class=\"small_lbl\" >View More</ion-label>\n        </div>\n\n        <div class=\"slider_class\">\n          <ion-slides mode=\"ios\" [options]=\"slideOpts\">\n            <ion-slide *ngFor=\"let item of (product | slice : 7)\" >\n              <div class=\"image_div bg_image\" [style.backgroundImage]=\"'url( '+ item.img +' )'\">\n                <div class=\"overlay\">\n                  <div class=\"detail_div\">\n                     <ion-label>{{item.name}}</ion-label>\n                     <div style=\"display: flex;\">\n                      <ion-label>3.4</ion-label><ion-icon name=\"star\"></ion-icon>\n                     </div>\n                  </div>\n                </div>\n              </div>\n            </ion-slide>\n          </ion-slides>\n        </div>\n      </div>\n\n    </div>\n\n  </div>\n</ion-content>\n");

/***/ }),

/***/ "./src/app/pages/maps/maps-routing.module.ts":
/*!***************************************************!*\
  !*** ./src/app/pages/maps/maps-routing.module.ts ***!
  \***************************************************/
/*! exports provided: MapsPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MapsPageRoutingModule", function() { return MapsPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _maps_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./maps.page */ "./src/app/pages/maps/maps.page.ts");




const routes = [
    {
        path: '',
        component: _maps_page__WEBPACK_IMPORTED_MODULE_3__["MapsPage"]
    }
];
let MapsPageRoutingModule = class MapsPageRoutingModule {
};
MapsPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], MapsPageRoutingModule);



/***/ }),

/***/ "./src/app/pages/maps/maps.module.ts":
/*!*******************************************!*\
  !*** ./src/app/pages/maps/maps.module.ts ***!
  \*******************************************/
/*! exports provided: MapsPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MapsPageModule", function() { return MapsPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _maps_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./maps-routing.module */ "./src/app/pages/maps/maps-routing.module.ts");
/* harmony import */ var _maps_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./maps.page */ "./src/app/pages/maps/maps.page.ts");







let MapsPageModule = class MapsPageModule {
};
MapsPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _maps_routing_module__WEBPACK_IMPORTED_MODULE_5__["MapsPageRoutingModule"]
        ],
        declarations: [_maps_page__WEBPACK_IMPORTED_MODULE_6__["MapsPage"]]
    })
], MapsPageModule);



/***/ }),

/***/ "./src/app/pages/maps/maps.page.scss":
/*!*******************************************!*\
  !*** ./src/app/pages/maps/maps.page.scss ***!
  \*******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".main_content_div ion-label {\n  display: block;\n}\n.main_content_div .head_lbl {\n  font-weight: 600;\n  margin-bottom: 10px;\n}\n.main_content_div .map {\n  width: 100%;\n  height: 60vh;\n}\n.main_content_div .content_div .explore_div {\n  padding: 16px;\n  border-bottom: 1px solid lightgray;\n}\n.main_content_div .content_div .explore_div ion-grid {\n  padding: 0;\n}\n.main_content_div .content_div .explore_div ion-grid ion-col {\n  text-align: center;\n}\n.main_content_div .content_div .explore_div ion-grid ion-col img {\n  width: 40px;\n}\n.main_content_div .content_div .explore_div ion-grid ion-col ion-label {\n  font-size: 12px;\n  margin-top: 5px;\n}\n.main_content_div .content_div .main_slider {\n  padding: 16px;\n  border-bottom: 1px solid lightgray;\n}\n.main_content_div .content_div .main_slider .head_flex {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  padding-bottom: 8px;\n}\n.main_content_div .content_div .main_slider .head_flex .head_lbl {\n  font-weight: 600;\n}\n.main_content_div .content_div .main_slider .head_flex .small_lbl {\n  font-size: 13px;\n  color: gray;\n}\n.main_content_div .content_div .main_slider .slider_class ion-slide {\n  height: 150px;\n  margin-right: 10px;\n}\n.main_content_div .content_div .main_slider .slider_class .image_div {\n  width: 100%;\n  height: 150px;\n  border-radius: 5px;\n  position: relative;\n}\n.main_content_div .content_div .main_slider .slider_class .image_div .overlay {\n  width: 100%;\n  height: 150px;\n  background: linear-gradient(rgba(255, 255, 255, 0), rgba(0, 0, 0, 0.6));\n  position: relative;\n}\n.main_content_div .content_div .main_slider .slider_class .image_div .overlay .detail_div {\n  padding: 5px;\n  position: absolute;\n  bottom: 0;\n}\n.main_content_div .content_div .main_slider .slider_class .image_div .overlay ion-label {\n  color: white;\n  font-size: 14px;\n  font-weight: 500;\n  text-align: left;\n}\n.main_content_div .content_div .main_slider .slider_class .image_div .overlay ion-icon {\n  font-size: 15px;\n  color: orangered;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvbWFwcy9FOlxcSW9uaWMgUHJvamVjdHNcXGlvbmljLTUtdGVtcGxhdGUtYnVuZGxlLWlvbmljLTUtdGhlbWVzLWJ1bmRsZXMtaW9uaWMtNS10ZW1wbGF0ZXMtd2l0aC0xMC1hcHBzXFxBcHBfc291cmNlX2NvZGVcXEFwcHNfY29kZVxcTXVsdGlfcHVycG9zZS9zcmNcXGFwcFxccGFnZXNcXG1hcHNcXG1hcHMucGFnZS5zY3NzIiwic3JjL2FwcC9wYWdlcy9tYXBzL21hcHMucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUVJO0VBQ0ksY0FBQTtBQ0RSO0FESUk7RUFDSSxnQkFBQTtFQUNBLG1CQUFBO0FDRlI7QURJSTtFQUNJLFdBQUE7RUFDQSxZQUFBO0FDRlI7QURNUTtFQUNJLGFBQUE7RUFDQSxrQ0FBQTtBQ0paO0FES1k7RUFDSSxVQUFBO0FDSGhCO0FES2dCO0VBQ0ksa0JBQUE7QUNIcEI7QURLb0I7RUFDSSxXQUFBO0FDSHhCO0FES29CO0VBQ0ksZUFBQTtFQUNBLGVBQUE7QUNIeEI7QURTUTtFQUNJLGFBQUE7RUFHQSxrQ0FBQTtBQ1RaO0FEV1k7RUFDSSxhQUFBO0VBQ0EsOEJBQUE7RUFDQSxtQkFBQTtFQUNBLG1CQUFBO0FDVGhCO0FEV2dCO0VBQ0ksZ0JBQUE7QUNUcEI7QURZZ0I7RUFDSSxlQUFBO0VBQ0EsV0FBQTtBQ1ZwQjtBRGdCZ0I7RUFDSSxhQUFBO0VBQ0Esa0JBQUE7QUNkcEI7QURpQmdCO0VBQ0ksV0FBQTtFQUNBLGFBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0FDZnBCO0FEaUJvQjtFQUNJLFdBQUE7RUFDQSxhQUFBO0VBQ0EsdUVBQUE7RUFDQSxrQkFBQTtBQ2Z4QjtBRGlCd0I7RUFDSSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSxTQUFBO0FDZjVCO0FEaUJ3QjtFQUNJLFlBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSxnQkFBQTtBQ2Y1QjtBRGtCd0I7RUFDSSxlQUFBO0VBQ0EsZ0JBQUE7QUNoQjVCIiwiZmlsZSI6InNyYy9hcHAvcGFnZXMvbWFwcy9tYXBzLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5tYWluX2NvbnRlbnRfZGl2e1xuXG4gICAgaW9uLWxhYmVsIHtcbiAgICAgICAgZGlzcGxheTogYmxvY2s7XG4gICAgfVxuXG4gICAgLmhlYWRfbGJse1xuICAgICAgICBmb250LXdlaWdodDogNjAwO1xuICAgICAgICBtYXJnaW4tYm90dG9tOiAxMHB4O1xuICAgIH1cbiAgICAubWFwe1xuICAgICAgICB3aWR0aDogMTAwJTtcbiAgICAgICAgaGVpZ2h0OiA2MHZoO1xuICAgIH1cblxuICAgIC5jb250ZW50X2RpdntcbiAgICAgICAgLmV4cGxvcmVfZGl2e1xuICAgICAgICAgICAgcGFkZGluZzogMTZweDtcbiAgICAgICAgICAgIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCBsaWdodGdyYXk7XG4gICAgICAgICAgICBpb24tZ3JpZHtcbiAgICAgICAgICAgICAgICBwYWRkaW5nOiAwO1xuXG4gICAgICAgICAgICAgICAgaW9uLWNvbHtcbiAgICAgICAgICAgICAgICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgICAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICAgICAgaW1ne1xuICAgICAgICAgICAgICAgICAgICAgICAgd2lkdGg6IDQwcHg7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgaW9uLWxhYmVsIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMTJweDtcbiAgICAgICAgICAgICAgICAgICAgICAgIG1hcmdpbi10b3A6IDVweDtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIC5tYWluX3NsaWRlcntcbiAgICAgICAgICAgIHBhZGRpbmc6IDE2cHg7XG4gICAgICAgICAgICAvLyBwYWRkaW5nLXRvcDogMTBweDtcbiAgICAgICAgICAgIC8vIHBhZGRpbmctYm90dG9tOiAxMHB4O1xuICAgICAgICAgICAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkIGxpZ2h0Z3JheTtcbiAgICAgICAgICAgIFxuICAgICAgICAgICAgLmhlYWRfZmxleHtcbiAgICAgICAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICAgICAgICAgIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcbiAgICAgICAgICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgICAgICAgICAgICAgIHBhZGRpbmctYm90dG9tOiA4cHg7XG5cbiAgICAgICAgICAgICAgICAuaGVhZF9sYmx7XG4gICAgICAgICAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiA2MDA7XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgLnNtYWxsX2xibHtcbiAgICAgICAgICAgICAgICAgICAgZm9udC1zaXplOiAxM3B4O1xuICAgICAgICAgICAgICAgICAgICBjb2xvcjogZ3JheTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIC5zbGlkZXJfY2xhc3N7XG5cbiAgICAgICAgICAgICAgICBpb24tc2xpZGV7XG4gICAgICAgICAgICAgICAgICAgIGhlaWdodDogMTUwcHg7XG4gICAgICAgICAgICAgICAgICAgIG1hcmdpbi1yaWdodDogMTBweDtcbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAuaW1hZ2VfZGl2e1xuICAgICAgICAgICAgICAgICAgICB3aWR0aDogMTAwJTtcbiAgICAgICAgICAgICAgICAgICAgaGVpZ2h0OiAxNTBweDtcbiAgICAgICAgICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogNXB4O1xuICAgICAgICAgICAgICAgICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XG5cbiAgICAgICAgICAgICAgICAgICAgLm92ZXJsYXl7XG4gICAgICAgICAgICAgICAgICAgICAgICB3aWR0aDogMTAwJTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGhlaWdodDogMTUwcHg7XG4gICAgICAgICAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQocmdiYSgyNTUsMjU1LDI1NSwwKSwgcmdiYSgwLDAsMCwwLjYpKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgLmRldGFpbF9kaXZ7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFkZGluZzogNXB4O1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBib3R0b206IDA7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICBpb24tbGFiZWwge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yOiB3aGl0ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250LXNpemU6IDE0cHg7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICBpb24taWNvbntcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250LXNpemU6IDE1cHg7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I6IG9yYW5nZXJlZDtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cbn0iLCIubWFpbl9jb250ZW50X2RpdiBpb24tbGFiZWwge1xuICBkaXNwbGF5OiBibG9jaztcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5oZWFkX2xibCB7XG4gIGZvbnQtd2VpZ2h0OiA2MDA7XG4gIG1hcmdpbi1ib3R0b206IDEwcHg7XG59XG4ubWFpbl9jb250ZW50X2RpdiAubWFwIHtcbiAgd2lkdGg6IDEwMCU7XG4gIGhlaWdodDogNjB2aDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5jb250ZW50X2RpdiAuZXhwbG9yZV9kaXYge1xuICBwYWRkaW5nOiAxNnB4O1xuICBib3JkZXItYm90dG9tOiAxcHggc29saWQgbGlnaHRncmF5O1xufVxuLm1haW5fY29udGVudF9kaXYgLmNvbnRlbnRfZGl2IC5leHBsb3JlX2RpdiBpb24tZ3JpZCB7XG4gIHBhZGRpbmc6IDA7XG59XG4ubWFpbl9jb250ZW50X2RpdiAuY29udGVudF9kaXYgLmV4cGxvcmVfZGl2IGlvbi1ncmlkIGlvbi1jb2wge1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG59XG4ubWFpbl9jb250ZW50X2RpdiAuY29udGVudF9kaXYgLmV4cGxvcmVfZGl2IGlvbi1ncmlkIGlvbi1jb2wgaW1nIHtcbiAgd2lkdGg6IDQwcHg7XG59XG4ubWFpbl9jb250ZW50X2RpdiAuY29udGVudF9kaXYgLmV4cGxvcmVfZGl2IGlvbi1ncmlkIGlvbi1jb2wgaW9uLWxhYmVsIHtcbiAgZm9udC1zaXplOiAxMnB4O1xuICBtYXJnaW4tdG9wOiA1cHg7XG59XG4ubWFpbl9jb250ZW50X2RpdiAuY29udGVudF9kaXYgLm1haW5fc2xpZGVyIHtcbiAgcGFkZGluZzogMTZweDtcbiAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkIGxpZ2h0Z3JheTtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5jb250ZW50X2RpdiAubWFpbl9zbGlkZXIgLmhlYWRfZmxleCB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgcGFkZGluZy1ib3R0b206IDhweDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5jb250ZW50X2RpdiAubWFpbl9zbGlkZXIgLmhlYWRfZmxleCAuaGVhZF9sYmwge1xuICBmb250LXdlaWdodDogNjAwO1xufVxuLm1haW5fY29udGVudF9kaXYgLmNvbnRlbnRfZGl2IC5tYWluX3NsaWRlciAuaGVhZF9mbGV4IC5zbWFsbF9sYmwge1xuICBmb250LXNpemU6IDEzcHg7XG4gIGNvbG9yOiBncmF5O1xufVxuLm1haW5fY29udGVudF9kaXYgLmNvbnRlbnRfZGl2IC5tYWluX3NsaWRlciAuc2xpZGVyX2NsYXNzIGlvbi1zbGlkZSB7XG4gIGhlaWdodDogMTUwcHg7XG4gIG1hcmdpbi1yaWdodDogMTBweDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5jb250ZW50X2RpdiAubWFpbl9zbGlkZXIgLnNsaWRlcl9jbGFzcyAuaW1hZ2VfZGl2IHtcbiAgd2lkdGg6IDEwMCU7XG4gIGhlaWdodDogMTUwcHg7XG4gIGJvcmRlci1yYWRpdXM6IDVweDtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xufVxuLm1haW5fY29udGVudF9kaXYgLmNvbnRlbnRfZGl2IC5tYWluX3NsaWRlciAuc2xpZGVyX2NsYXNzIC5pbWFnZV9kaXYgLm92ZXJsYXkge1xuICB3aWR0aDogMTAwJTtcbiAgaGVpZ2h0OiAxNTBweDtcbiAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KHJnYmEoMjU1LCAyNTUsIDI1NSwgMCksIHJnYmEoMCwgMCwgMCwgMC42KSk7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5jb250ZW50X2RpdiAubWFpbl9zbGlkZXIgLnNsaWRlcl9jbGFzcyAuaW1hZ2VfZGl2IC5vdmVybGF5IC5kZXRhaWxfZGl2IHtcbiAgcGFkZGluZzogNXB4O1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIGJvdHRvbTogMDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5jb250ZW50X2RpdiAubWFpbl9zbGlkZXIgLnNsaWRlcl9jbGFzcyAuaW1hZ2VfZGl2IC5vdmVybGF5IGlvbi1sYWJlbCB7XG4gIGNvbG9yOiB3aGl0ZTtcbiAgZm9udC1zaXplOiAxNHB4O1xuICBmb250LXdlaWdodDogNTAwO1xuICB0ZXh0LWFsaWduOiBsZWZ0O1xufVxuLm1haW5fY29udGVudF9kaXYgLmNvbnRlbnRfZGl2IC5tYWluX3NsaWRlciAuc2xpZGVyX2NsYXNzIC5pbWFnZV9kaXYgLm92ZXJsYXkgaW9uLWljb24ge1xuICBmb250LXNpemU6IDE1cHg7XG4gIGNvbG9yOiBvcmFuZ2VyZWQ7XG59Il19 */");

/***/ }),

/***/ "./src/app/pages/maps/maps.page.ts":
/*!*****************************************!*\
  !*** ./src/app/pages/maps/maps.page.ts ***!
  \*****************************************/
/*! exports provided: MapsPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MapsPage", function() { return MapsPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var src_app_services_search_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/search.service */ "./src/app/services/search.service.ts");



let MapsPage = class MapsPage {
    constructor(search) {
        this.search = search;
        this.latOri = -14.5931473;
        this.longOri = -56.1224024;
        this.latDest = -15.5931473;
        this.longDest = -56.1224024;
        this.slideOpts = {
            slidesPerView: 3,
        };
        this.product = this.search.product;
    }
    ngOnInit() {
        this.loadMap();
    }
    loadMap() {
        const latLng = new google.maps.LatLng(-34.9290, 138.6010);
        const mapOptions = {
            center: latLng,
            zoom: 15,
            mapTypeId: google.maps.MapTypeId.ROADMAP
        };
        this.map = new google.maps.Map(this.mapElement.nativeElement, mapOptions);
    }
};
MapsPage.ctorParameters = () => [
    { type: src_app_services_search_service__WEBPACK_IMPORTED_MODULE_2__["SearchService"] }
];
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('map', { static: true }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"])
], MapsPage.prototype, "mapElement", void 0);
MapsPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-maps',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./maps.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/maps/maps.page.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./maps.page.scss */ "./src/app/pages/maps/maps.page.scss")).default]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [src_app_services_search_service__WEBPACK_IMPORTED_MODULE_2__["SearchService"]])
], MapsPage);



/***/ })

}]);
//# sourceMappingURL=maps-maps-module-es2015.js.map