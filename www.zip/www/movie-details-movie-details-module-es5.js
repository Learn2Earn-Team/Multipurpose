function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["movie-details-movie-details-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/movie-details/movie-details.page.html":
  /*!***************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/movie-details/movie-details.page.html ***!
    \***************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppPagesMovieDetailsMovieDetailsPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar>\n    <!-- <ion-buttons slot=\"start\">\n      <ion-menu-button color=\"dark\"></ion-menu-button>\n    </ion-buttons> -->\n\n    <ion-icon class=\"back\" name=\"arrow-back-outline\" (click)=\"goBack()\"></ion-icon>\n    \n    <ion-title>Baaghi</ion-title>\n\n    <ion-button slot=\"end\" size=\"small\" fill=\"clear\">\n      <ion-icon name=\"arrow-redo-outline\"></ion-icon>\n    </ion-button>\n\n    <ion-button slot=\"end\" size=\"small\" fill=\"clear\">\n      <ion-icon name=\"search-outline\"></ion-icon>\n    </ion-button>\n\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div class=\"main_content_div\">\n\n    <div class=\"movie_detail\">\n      <img src=\"assets/imgs/image8.jpeg\">\n\n      <ion-label class=\"detail_lbl\">\n        <span style=\"color: var(--ion-color-success)\">3.0/10</span> •\n        <span>145 min</span> •\n        <span>Hindi</span> •\n        <span>U/A</span> •\n        <span>Action & Advanture</span> •\n        <span>Mystery & Thriller</span>\n      </ion-label>\n    </div>\n\n    <div class=\"btn_div\">\n      <ion-button expand=\"block\" color=\"danger\">\n        <ion-icon name=\"caret-forward-outline\"></ion-icon>\n        Play\n      </ion-button>\n\n      <ion-button class=\"icn_btn\">\n        <ion-icon name=\"chevron-down-outline\"></ion-icon>\n      </ion-button>\n\n      <ion-label class=\"desc\">\n        Lorem ipsum dolor sit, amet consectetur adipisicing elit. \n        At consequuntur architecto soluta commodi dolorum, officiis unde \n        rerum quae illo sit!\n      </ion-label>\n\n      <ion-label class=\"desc\">\n        Cast - Tiger Shroff, Shradha Kapoor, Ritesh Deshmukh and Ankita Lokhande\n      </ion-label>\n\n      <ion-label class=\"desc\">\n        Director - Ahmed Khan\n      </ion-label>\n\n      <ion-grid fixed>\n        <ion-row>\n\n          <ion-col size=\"3\">\n            <ion-icon name=\"add\"></ion-icon>\n            <ion-label>My List</ion-label>\n          </ion-col>\n\n          <ion-col size=\"3\">\n            <ion-icon name=\"star-outline\"></ion-icon>\n            <ion-label>Rate</ion-label>\n          </ion-col>\n\n          <ion-col size=\"3\">\n            <ion-icon name=\"arrow-redo-outline\"></ion-icon>\n            <ion-label>Share</ion-label>\n          </ion-col>\n\n          <ion-col size=\"3\">\n            <ion-icon name=\"caret-forward-outline\"></ion-icon>\n            <ion-label>Trailer</ion-label>\n          </ion-col>\n\n        </ion-row>\n      </ion-grid>\n\n      <div class=\"rate_flex\">\n        <div class=\"back\"></div>\n        <ion-label>30 users have rated this</ion-label>\n      </div>\n\n    </div>\n\n    <div class=\"video_div\">\n      <ion-label class=\"head_lbl\">Video</ion-label>\n\n      <div>\n        <video playsinline webkit-playsinline autoplay>\n          <source src=\"assets/imgs/video.mp4\" type=\"video/mp4\">\n        </video>\n        <div class=\"video_detail\">\n          Baaghi 3 | Tiger Shroff | Shradha Kapoor | Ritesh Deshmukh | Sajid Nadiadwala | Ahmed Khan\n        </div>\n      </div>\n    </div>\n\n    <div class=\"main_slider\">\n      <div class=\"head_flex\">\n        <ion-label class=\"head_lbl\">More Movies Online</ion-label>\n        <ion-label class=\"small_lbl\">View More</ion-label>\n      </div>\n\n      <div class=\"slider_class\">\n        <ion-slides mode=\"ios\" [options]=\"slideOpts\">\n          <ion-slide *ngFor=\"let item of (movies | slice : 0: 7)\">\n            <div class=\"image_div bg_image\" [style.backgroundImage]=\"'url( '+ item.img +' )'\"></div>\n          </ion-slide>\n        </ion-slides>\n      </div>\n    </div>\n\n    <div class=\"main_slider\">\n      <div class=\"head_flex\">\n        <ion-label class=\"head_lbl\">Critic Reviews</ion-label>\n      </div>\n\n      <div class=\"critic_slider\">\n        <ion-slides mode=\"ios\" [options]=\"slideOpts2\">\n          <ion-slide *ngFor=\"let item of review\">\n\n            <div class=\"slider_box\">\n\n              <div class=\"user_detail\">\n                <div class=\"user_image bg_image\" [style.backgroundImage]=\"'url( '+ item.user +' )'\"></div>\n\n                <div class=\"user_personal\">\n                  <ion-label class=\"username\">{{item.name}}</ion-label>\n                  <ion-label class=\"light_lbl\">News 18</ion-label>\n                  <div class=\"rate_div\">\n                    <ion-label>{{item.review}}</ion-label>\n                    <ion-icon name=\"star\"></ion-icon>\n                  </div>\n                </div>\n              </div>\n\n              <ion-label class=\"review\">\n                Lorem, ipsum dolor sit amet consectetur adipisicing elit. \n                Nam amet repudiandae nostrum ipsum quibusdam excepturi laborum \n                repellendus ratione aliquam harum sed facere quisquam architecto \n                aperiam explicabo debitis impedit, deleniti temporibus?\n              </ion-label>\n\n            </div>\n\n          </ion-slide>\n        </ion-slides>\n      </div>\n\n    </div>\n\n    <div class=\"summary\">\n      <ion-label class=\"head_lbl\">Baaghi 3 movie summary</ion-label>\n\n      <ion-label class=\"movie_summary\">\n        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Iusto perferendis, aliquam maiores iure repellat velit autem debitis dignissimos nemo! Accusantium tenetur repudiandae qui quaerat minima ex ut tempore, voluptatum assumenda?\n      </ion-label>\n\n      <ion-label class=\"movie_summary\">Total Rating Count : 1490</ion-label>\n    </div>\n\n\n  </div>\n</ion-content>\n";
    /***/
  },

  /***/
  "./src/app/pages/movie-details/movie-details-routing.module.ts":
  /*!*********************************************************************!*\
    !*** ./src/app/pages/movie-details/movie-details-routing.module.ts ***!
    \*********************************************************************/

  /*! exports provided: MovieDetailsPageRoutingModule */

  /***/
  function srcAppPagesMovieDetailsMovieDetailsRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "MovieDetailsPageRoutingModule", function () {
      return MovieDetailsPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _movie_details_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./movie-details.page */
    "./src/app/pages/movie-details/movie-details.page.ts");

    var routes = [{
      path: '',
      component: _movie_details_page__WEBPACK_IMPORTED_MODULE_3__["MovieDetailsPage"]
    }];

    var MovieDetailsPageRoutingModule = function MovieDetailsPageRoutingModule() {
      _classCallCheck(this, MovieDetailsPageRoutingModule);
    };

    MovieDetailsPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], MovieDetailsPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/pages/movie-details/movie-details.module.ts":
  /*!*************************************************************!*\
    !*** ./src/app/pages/movie-details/movie-details.module.ts ***!
    \*************************************************************/

  /*! exports provided: MovieDetailsPageModule */

  /***/
  function srcAppPagesMovieDetailsMovieDetailsModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "MovieDetailsPageModule", function () {
      return MovieDetailsPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _movie_details_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./movie-details-routing.module */
    "./src/app/pages/movie-details/movie-details-routing.module.ts");
    /* harmony import */


    var _movie_details_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./movie-details.page */
    "./src/app/pages/movie-details/movie-details.page.ts");

    var MovieDetailsPageModule = function MovieDetailsPageModule() {
      _classCallCheck(this, MovieDetailsPageModule);
    };

    MovieDetailsPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _movie_details_routing_module__WEBPACK_IMPORTED_MODULE_5__["MovieDetailsPageRoutingModule"]],
      declarations: [_movie_details_page__WEBPACK_IMPORTED_MODULE_6__["MovieDetailsPage"]]
    })], MovieDetailsPageModule);
    /***/
  },

  /***/
  "./src/app/pages/movie-details/movie-details.page.scss":
  /*!*************************************************************!*\
    !*** ./src/app/pages/movie-details/movie-details.page.scss ***!
    \*************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppPagesMovieDetailsMovieDetailsPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "ion-header .back {\n  font-size: 27px;\n  margin-left: 10px;\n}\nion-header ion-button {\n  margin: 0;\n}\nion-header ion-button ion-icon {\n  color: black;\n  font-size: 20px;\n}\n.main_content_div {\n  width: 100%;\n  padding: 16px;\n}\n.main_content_div ion-label {\n  display: block;\n}\n.main_content_div .movie_detail {\n  text-align: center;\n}\n.main_content_div .movie_detail .detail_lbl {\n  margin-top: 15px;\n  font-size: 14px;\n  padding-left: 10px;\n  padding-right: 10px;\n}\n.main_content_div .movie_detail .detail_lbl span {\n  padding-left: 10px;\n  padding-right: 10px;\n}\n.main_content_div .btn_div {\n  margin-top: 20px;\n  position: relative;\n}\n.main_content_div .btn_div ion-button {\n  --border-radius: 0px;\n  height: 40px;\n}\n.main_content_div .btn_div .icn_btn {\n  --background: #b83d3d;\n  height: 40px;\n  --border-radius: 0px;\n  position: absolute;\n  right: 0px;\n  top: -4px;\n}\n.main_content_div .btn_div .icn_btn ion-icon {\n  font-size: 20px;\n}\n.main_content_div .btn_div .desc {\n  color: #707070;\n  font-size: 14px;\n  margin-top: 20px;\n}\n.main_content_div .btn_div ion-grid {\n  padding: 0;\n  margin-top: 15px;\n}\n.main_content_div .btn_div ion-grid ion-col {\n  text-align: center;\n}\n.main_content_div .btn_div ion-grid ion-col ion-icon {\n  font-size: 20px;\n}\n.main_content_div .btn_div ion-grid ion-col ion-label {\n  font-size: 13px;\n}\n.main_content_div .btn_div .rate_flex {\n  display: flex;\n  align-items: center;\n  margin-top: 15px;\n}\n.main_content_div .btn_div .rate_flex .back {\n  height: 20px;\n  width: 20px;\n  border-radius: 100%;\n  background: black;\n}\n.main_content_div .btn_div .rate_flex ion-label {\n  font-size: 14px;\n  margin-left: 15px;\n}\n.main_content_div .video_div {\n  padding-top: 16px;\n}\n.main_content_div .video_div .head_lbl {\n  font-weight: 500;\n  font-size: 15px;\n  margin-bottom: 10px;\n}\n.main_content_div .video_div video {\n  width: 100%;\n}\n.main_content_div .video_div .video_detail {\n  box-shadow: 0px 3px 6px rgba(0, 0, 0, 0.2);\n  padding: 10px;\n  font-size: 13px;\n}\n.main_content_div .main_slider {\n  padding-top: 16px;\n  padding-bottom: 16px;\n}\n.main_content_div .main_slider .head_flex {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  padding-bottom: 15px;\n}\n.main_content_div .main_slider .head_flex .head_lbl {\n  font-weight: 500;\n  font-size: 15px;\n}\n.main_content_div .main_slider .head_flex .small_lbl {\n  font-size: 13px;\n  color: gray;\n}\n.main_content_div .main_slider .slider_class ion-slide {\n  height: 150px;\n  margin-right: 10px;\n}\n.main_content_div .main_slider .slider_class .image_div {\n  width: 100%;\n  height: 150px;\n  border-radius: 5px;\n  position: relative;\n}\n.main_content_div .main_slider .critic_slider ion-slides {\n  padding-bottom: 10px;\n}\n.main_content_div .main_slider .critic_slider ion-slide {\n  margin-right: 10px;\n  margin-left: 5px;\n}\n.main_content_div .main_slider .critic_slider .slider_box {\n  box-shadow: 0px 3px 6px rgba(0, 0, 0, 0.3);\n  padding: 10px;\n  border-radius: 5px;\n  width: 100%;\n}\n.main_content_div .main_slider .critic_slider .slider_box .user_detail {\n  display: flex;\n}\n.main_content_div .main_slider .critic_slider .slider_box .user_detail .user_image {\n  height: 40px;\n  width: 40px;\n  border-radius: 100%;\n  min-width: 40px;\n}\n.main_content_div .main_slider .critic_slider .slider_box .user_detail .user_personal {\n  padding-left: 15px;\n  display: flex;\n  flex-direction: column;\n  justify-content: flex-start;\n  align-items: flex-start;\n}\n.main_content_div .main_slider .critic_slider .slider_box .user_detail .user_personal .username {\n  font-weight: 500;\n  font-size: 14px;\n  margin-bottom: 5px;\n}\n.main_content_div .main_slider .critic_slider .slider_box .user_detail .user_personal .light_lbl {\n  color: gray;\n  font-size: 12px;\n  margin-bottom: 5px;\n}\n.main_content_div .main_slider .critic_slider .slider_box .user_detail .user_personal .rate_div {\n  display: flex;\n  border: 1px solid lightgray;\n  border-radius: 25px;\n  padding: 2px 5px;\n}\n.main_content_div .main_slider .critic_slider .slider_box .user_detail .user_personal .rate_div ion-label {\n  font-size: 12px;\n}\n.main_content_div .main_slider .critic_slider .slider_box .user_detail .user_personal .rate_div ion-icon {\n  font-size: 12px;\n  margin-top: 1px;\n  color: var(--ion-color-warning);\n  padding-left: 5px;\n}\n.main_content_div .main_slider .critic_slider .slider_box .review {\n  font-size: 14px;\n  color: gray;\n  text-align: left;\n  margin-top: 5px;\n}\n.main_content_div .summary .head_lbl {\n  font-weight: 500;\n  font-size: 15px;\n  margin-bottom: 10px;\n}\n.main_content_div .summary .movie_summary {\n  font-size: 14px;\n  color: gray;\n  margin-bottom: 10px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvbW92aWUtZGV0YWlscy9FOlxcSW9uaWMgUHJvamVjdHNcXGlvbmljLTUtdGVtcGxhdGUtYnVuZGxlLWlvbmljLTUtdGhlbWVzLWJ1bmRsZXMtaW9uaWMtNS10ZW1wbGF0ZXMtd2l0aC0xMC1hcHBzXFxBcHBfc291cmNlX2NvZGVcXEFwcHNfY29kZVxcTXVsdGlfcHVycG9zZS9zcmNcXGFwcFxccGFnZXNcXG1vdmllLWRldGFpbHNcXG1vdmllLWRldGFpbHMucGFnZS5zY3NzIiwic3JjL2FwcC9wYWdlcy9tb3ZpZS1kZXRhaWxzL21vdmllLWRldGFpbHMucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNJO0VBQ0ksZUFBQTtFQUNBLGlCQUFBO0FDQVI7QURFSTtFQUNJLFNBQUE7QUNBUjtBREVRO0VBQ0ksWUFBQTtFQUNBLGVBQUE7QUNBWjtBREtBO0VBQ0ksV0FBQTtFQUNBLGFBQUE7QUNGSjtBRElJO0VBQ0ksY0FBQTtBQ0ZSO0FES0k7RUFDSSxrQkFBQTtBQ0hSO0FES1E7RUFDSSxnQkFBQTtFQUNBLGVBQUE7RUFDQSxrQkFBQTtFQUNBLG1CQUFBO0FDSFo7QURLWTtFQUNJLGtCQUFBO0VBQ0EsbUJBQUE7QUNIaEI7QURRSTtFQUNJLGdCQUFBO0VBQ0Esa0JBQUE7QUNOUjtBRFFRO0VBQ0ksb0JBQUE7RUFDQSxZQUFBO0FDTlo7QURTUTtFQUNJLHFCQUFBO0VBQ0EsWUFBQTtFQUNBLG9CQUFBO0VBQ0Esa0JBQUE7RUFDQSxVQUFBO0VBQ0EsU0FBQTtBQ1BaO0FEU1k7RUFDSSxlQUFBO0FDUGhCO0FEV1E7RUFDSSxjQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0FDVFo7QURZUTtFQUNJLFVBQUE7RUFDQSxnQkFBQTtBQ1ZaO0FEWVk7RUFDSSxrQkFBQTtBQ1ZoQjtBRFlnQjtFQUNJLGVBQUE7QUNWcEI7QURZZ0I7RUFDSSxlQUFBO0FDVnBCO0FEZVE7RUFDSSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSxnQkFBQTtBQ2JaO0FEY1k7RUFDSSxZQUFBO0VBQ0EsV0FBQTtFQUNBLG1CQUFBO0VBQ0EsaUJBQUE7QUNaaEI7QURlWTtFQUNJLGVBQUE7RUFDQSxpQkFBQTtBQ2JoQjtBRGtCSTtFQUNJLGlCQUFBO0FDaEJSO0FEa0JRO0VBQ0ksZ0JBQUE7RUFDQSxlQUFBO0VBQ0EsbUJBQUE7QUNoQlo7QURtQlE7RUFDSSxXQUFBO0FDakJaO0FEbUJRO0VBQ0ksMENBQUE7RUFDQSxhQUFBO0VBQ0EsZUFBQTtBQ2pCWjtBRHFCSTtFQUVJLGlCQUFBO0VBQ0Esb0JBQUE7QUNwQlI7QURzQlE7RUFDSSxhQUFBO0VBQ0EsOEJBQUE7RUFDQSxtQkFBQTtFQUNBLG9CQUFBO0FDcEJaO0FEc0JZO0VBQ0ksZ0JBQUE7RUFDQSxlQUFBO0FDcEJoQjtBRHVCWTtFQUNJLGVBQUE7RUFDQSxXQUFBO0FDckJoQjtBRDJCWTtFQUNJLGFBQUE7RUFDQSxrQkFBQTtBQ3pCaEI7QUQ0Qlk7RUFDSSxXQUFBO0VBQ0EsYUFBQTtFQUNBLGtCQUFBO0VBQ0Esa0JBQUE7QUMxQmhCO0FEZ0NZO0VBQ0ksb0JBQUE7QUM5QmhCO0FEZ0NZO0VBQ0ksa0JBQUE7RUFDQSxnQkFBQTtBQzlCaEI7QURpQ1k7RUFDSSwwQ0FBQTtFQUNBLGFBQUE7RUFDQSxrQkFBQTtFQUNBLFdBQUE7QUMvQmhCO0FEaUNnQjtFQUNJLGFBQUE7QUMvQnBCO0FEZ0NvQjtFQUNJLFlBQUE7RUFDQSxXQUFBO0VBQ0EsbUJBQUE7RUFDQSxlQUFBO0FDOUJ4QjtBRGdDb0I7RUFDSSxrQkFBQTtFQUNBLGFBQUE7RUFDQSxzQkFBQTtFQUNBLDJCQUFBO0VBQ0EsdUJBQUE7QUM5QnhCO0FEK0J3QjtFQUNJLGdCQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0FDN0I1QjtBRCtCd0I7RUFDSSxXQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0FDN0I1QjtBRCtCd0I7RUFDSSxhQUFBO0VBQ0EsMkJBQUE7RUFDQSxtQkFBQTtFQUNBLGdCQUFBO0FDN0I1QjtBRCtCNEI7RUFDSSxlQUFBO0FDN0JoQztBRCtCNEI7RUFDSSxlQUFBO0VBQ0EsZUFBQTtFQUNBLCtCQUFBO0VBQ0EsaUJBQUE7QUM3QmhDO0FEa0NnQjtFQUNJLGVBQUE7RUFDQSxXQUFBO0VBQ0EsZ0JBQUE7RUFDQSxlQUFBO0FDaENwQjtBRHdDUTtFQUNJLGdCQUFBO0VBQ0EsZUFBQTtFQUNBLG1CQUFBO0FDdENaO0FEd0NRO0VBQ0ksZUFBQTtFQUNBLFdBQUE7RUFDQSxtQkFBQTtBQ3RDWiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL21vdmllLWRldGFpbHMvbW92aWUtZGV0YWlscy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24taGVhZGVye1xuICAgIC5iYWNre1xuICAgICAgICBmb250LXNpemU6IDI3cHg7XG4gICAgICAgIG1hcmdpbi1sZWZ0OiAxMHB4O1xuICAgIH1cbiAgICBpb24tYnV0dG9ue1xuICAgICAgICBtYXJnaW46IDA7XG5cbiAgICAgICAgaW9uLWljb257XG4gICAgICAgICAgICBjb2xvcjogYmxhY2s7XG4gICAgICAgICAgICBmb250LXNpemU6IDIwcHg7XG4gICAgICAgIH1cbiAgICB9XG59XG5cbi5tYWluX2NvbnRlbnRfZGl2e1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIHBhZGRpbmc6IDE2cHg7XG5cbiAgICBpb24tbGFiZWwge1xuICAgICAgICBkaXNwbGF5OiBibG9jaztcbiAgICB9XG5cbiAgICAubW92aWVfZGV0YWlse1xuICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG5cbiAgICAgICAgLmRldGFpbF9sYmx7XG4gICAgICAgICAgICBtYXJnaW4tdG9wOiAxNXB4O1xuICAgICAgICAgICAgZm9udC1zaXplOiAxNHB4O1xuICAgICAgICAgICAgcGFkZGluZy1sZWZ0OiAxMHB4O1xuICAgICAgICAgICAgcGFkZGluZy1yaWdodDogMTBweDtcblxuICAgICAgICAgICAgc3BhbntcbiAgICAgICAgICAgICAgICBwYWRkaW5nLWxlZnQ6IDEwcHg7XG4gICAgICAgICAgICAgICAgcGFkZGluZy1yaWdodDogMTBweDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cblxuICAgIC5idG5fZGl2e1xuICAgICAgICBtYXJnaW4tdG9wOiAyMHB4O1xuICAgICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XG5cbiAgICAgICAgaW9uLWJ1dHRvbntcbiAgICAgICAgICAgIC0tYm9yZGVyLXJhZGl1czogMHB4O1xuICAgICAgICAgICAgaGVpZ2h0OiA0MHB4O1xuICAgICAgICB9XG5cbiAgICAgICAgLmljbl9idG57XG4gICAgICAgICAgICAtLWJhY2tncm91bmQ6ICNiODNkM2Q7XG4gICAgICAgICAgICBoZWlnaHQ6IDQwcHg7XG4gICAgICAgICAgICAtLWJvcmRlci1yYWRpdXM6IDBweDtcbiAgICAgICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICAgICAgICAgIHJpZ2h0OiAwcHg7XG4gICAgICAgICAgICB0b3A6IC00cHg7XG5cbiAgICAgICAgICAgIGlvbi1pY29ue1xuICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMjBweDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIC5kZXNje1xuICAgICAgICAgICAgY29sb3I6ICM3MDcwNzA7XG4gICAgICAgICAgICBmb250LXNpemU6IDE0cHg7XG4gICAgICAgICAgICBtYXJnaW4tdG9wOiAyMHB4O1xuICAgICAgICB9XG5cbiAgICAgICAgaW9uLWdyaWR7XG4gICAgICAgICAgICBwYWRkaW5nOiAwO1xuICAgICAgICAgICAgbWFyZ2luLXRvcDogMTVweDtcblxuICAgICAgICAgICAgaW9uLWNvbHtcbiAgICAgICAgICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG5cbiAgICAgICAgICAgICAgICBpb24taWNvbntcbiAgICAgICAgICAgICAgICAgICAgZm9udC1zaXplOiAyMHB4O1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBpb24tbGFiZWwge1xuICAgICAgICAgICAgICAgICAgICBmb250LXNpemU6IDEzcHg7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgLnJhdGVfZmxleHtcbiAgICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgICAgICAgICAgbWFyZ2luLXRvcDogMTVweDtcbiAgICAgICAgICAgIC5iYWNre1xuICAgICAgICAgICAgICAgIGhlaWdodDogMjBweDtcbiAgICAgICAgICAgICAgICB3aWR0aDogMjBweDtcbiAgICAgICAgICAgICAgICBib3JkZXItcmFkaXVzOiAxMDAlO1xuICAgICAgICAgICAgICAgIGJhY2tncm91bmQ6IGJsYWNrO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBpb24tbGFiZWwge1xuICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMTRweDtcbiAgICAgICAgICAgICAgICBtYXJnaW4tbGVmdDogMTVweDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cblxuICAgIC52aWRlb19kaXZ7XG4gICAgICAgIHBhZGRpbmctdG9wOiAxNnB4O1xuXG4gICAgICAgIC5oZWFkX2xibHtcbiAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiA1MDA7XG4gICAgICAgICAgICBmb250LXNpemU6IDE1cHg7XG4gICAgICAgICAgICBtYXJnaW4tYm90dG9tOiAxMHB4O1xuICAgICAgICB9XG5cbiAgICAgICAgdmlkZW97XG4gICAgICAgICAgICB3aWR0aDogMTAwJTtcbiAgICAgICAgfVxuICAgICAgICAudmlkZW9fZGV0YWlse1xuICAgICAgICAgICAgYm94LXNoYWRvdzogMHB4IDNweCA2cHggcmdiYSgwLDAsMCwwLjIpO1xuICAgICAgICAgICAgcGFkZGluZzogMTBweDtcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogMTNweDtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIC5tYWluX3NsaWRlcntcblxuICAgICAgICBwYWRkaW5nLXRvcDogMTZweDtcbiAgICAgICAgcGFkZGluZy1ib3R0b206IDE2cHg7XG4gICAgICAgIFxuICAgICAgICAuaGVhZF9mbGV4e1xuICAgICAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAgICAgIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcbiAgICAgICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAgICAgICAgICBwYWRkaW5nLWJvdHRvbTogMTVweDtcblxuICAgICAgICAgICAgLmhlYWRfbGJse1xuICAgICAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiA1MDA7XG4gICAgICAgICAgICAgICAgZm9udC1zaXplOiAxNXB4O1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAuc21hbGxfbGJse1xuICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMTNweDtcbiAgICAgICAgICAgICAgICBjb2xvcjogZ3JheTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIC5zbGlkZXJfY2xhc3N7XG5cbiAgICAgICAgICAgIGlvbi1zbGlkZXtcbiAgICAgICAgICAgICAgICBoZWlnaHQ6IDE1MHB4O1xuICAgICAgICAgICAgICAgIG1hcmdpbi1yaWdodDogMTBweDtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgLmltYWdlX2RpdntcbiAgICAgICAgICAgICAgICB3aWR0aDogMTAwJTtcbiAgICAgICAgICAgICAgICBoZWlnaHQ6IDE1MHB4O1xuICAgICAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDVweDtcbiAgICAgICAgICAgICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICAuY3JpdGljX3NsaWRlcntcblxuICAgICAgICAgICAgaW9uLXNsaWRlc3tcbiAgICAgICAgICAgICAgICBwYWRkaW5nLWJvdHRvbTogMTBweDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlvbi1zbGlkZXtcbiAgICAgICAgICAgICAgICBtYXJnaW4tcmlnaHQ6IDEwcHg7XG4gICAgICAgICAgICAgICAgbWFyZ2luLWxlZnQ6IDVweDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIFxuICAgICAgICAgICAgLnNsaWRlcl9ib3h7XG4gICAgICAgICAgICAgICAgYm94LXNoYWRvdzogMHB4IDNweCA2cHggcmdiYSgwLDAsMCwwLjMpO1xuICAgICAgICAgICAgICAgIHBhZGRpbmc6IDEwcHg7XG4gICAgICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogNXB4O1xuICAgICAgICAgICAgICAgIHdpZHRoOiAxMDAlO1xuXG4gICAgICAgICAgICAgICAgLnVzZXJfZGV0YWlse1xuICAgICAgICAgICAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICAgICAgICAgICAgICAudXNlcl9pbWFnZXtcbiAgICAgICAgICAgICAgICAgICAgICAgIGhlaWdodDogNDBweDtcbiAgICAgICAgICAgICAgICAgICAgICAgIHdpZHRoOiA0MHB4O1xuICAgICAgICAgICAgICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogMTAwJTtcbiAgICAgICAgICAgICAgICAgICAgICAgIG1pbi13aWR0aDogNDBweDtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAudXNlcl9wZXJzb25hbHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHBhZGRpbmctbGVmdDogMTVweDtcbiAgICAgICAgICAgICAgICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgICAgICAgICAgICAgICAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICAgICAgICAgICAgICAgICAgICAgICAganVzdGlmeS1jb250ZW50OiBmbGV4LXN0YXJ0O1xuICAgICAgICAgICAgICAgICAgICAgICAgYWxpZ24taXRlbXM6IGZsZXgtc3RhcnQ7XG4gICAgICAgICAgICAgICAgICAgICAgICAudXNlcm5hbWV7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250LXNpemU6IDE0cHg7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbWFyZ2luLWJvdHRvbTogNXB4O1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgLmxpZ2h0X2xibHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2xvcjogZ3JheTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250LXNpemU6IDEycHg7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbWFyZ2luLWJvdHRvbTogNXB4O1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgLnJhdGVfZGl2e1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYm9yZGVyOiAxcHggc29saWQgbGlnaHRncmF5O1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDI1cHg7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFkZGluZzogMnB4IDVweDtcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlvbi1sYWJlbCB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMTJweDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaW9uLWljb257XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMTJweDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWFyZ2luLXRvcDogMXB4O1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2xvciA6IHZhcigtLWlvbi1jb2xvci13YXJuaW5nKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFkZGluZy1sZWZ0OiA1cHg7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIC5yZXZpZXd7XG4gICAgICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMTRweDtcbiAgICAgICAgICAgICAgICAgICAgY29sb3I6IGdyYXk7XG4gICAgICAgICAgICAgICAgICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgICAgICAgICAgICAgICAgIG1hcmdpbi10b3A6IDVweDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAuc3VtbWFyeXtcblxuICAgICAgICAuaGVhZF9sYmx7XG4gICAgICAgICAgICBmb250LXdlaWdodDogNTAwO1xuICAgICAgICAgICAgZm9udC1zaXplOiAxNXB4O1xuICAgICAgICAgICAgbWFyZ2luLWJvdHRvbTogMTBweDtcbiAgICAgICAgfVxuICAgICAgICAubW92aWVfc3VtbWFyeXtcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogMTRweDtcbiAgICAgICAgICAgIGNvbG9yOiBncmF5O1xuICAgICAgICAgICAgbWFyZ2luLWJvdHRvbTogMTBweDtcbiAgICAgICAgfVxuICAgIH1cbn0iLCJpb24taGVhZGVyIC5iYWNrIHtcbiAgZm9udC1zaXplOiAyN3B4O1xuICBtYXJnaW4tbGVmdDogMTBweDtcbn1cbmlvbi1oZWFkZXIgaW9uLWJ1dHRvbiB7XG4gIG1hcmdpbjogMDtcbn1cbmlvbi1oZWFkZXIgaW9uLWJ1dHRvbiBpb24taWNvbiB7XG4gIGNvbG9yOiBibGFjaztcbiAgZm9udC1zaXplOiAyMHB4O1xufVxuXG4ubWFpbl9jb250ZW50X2RpdiB7XG4gIHdpZHRoOiAxMDAlO1xuICBwYWRkaW5nOiAxNnB4O1xufVxuLm1haW5fY29udGVudF9kaXYgaW9uLWxhYmVsIHtcbiAgZGlzcGxheTogYmxvY2s7XG59XG4ubWFpbl9jb250ZW50X2RpdiAubW92aWVfZGV0YWlsIHtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xufVxuLm1haW5fY29udGVudF9kaXYgLm1vdmllX2RldGFpbCAuZGV0YWlsX2xibCB7XG4gIG1hcmdpbi10b3A6IDE1cHg7XG4gIGZvbnQtc2l6ZTogMTRweDtcbiAgcGFkZGluZy1sZWZ0OiAxMHB4O1xuICBwYWRkaW5nLXJpZ2h0OiAxMHB4O1xufVxuLm1haW5fY29udGVudF9kaXYgLm1vdmllX2RldGFpbCAuZGV0YWlsX2xibCBzcGFuIHtcbiAgcGFkZGluZy1sZWZ0OiAxMHB4O1xuICBwYWRkaW5nLXJpZ2h0OiAxMHB4O1xufVxuLm1haW5fY29udGVudF9kaXYgLmJ0bl9kaXYge1xuICBtYXJnaW4tdG9wOiAyMHB4O1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG59XG4ubWFpbl9jb250ZW50X2RpdiAuYnRuX2RpdiBpb24tYnV0dG9uIHtcbiAgLS1ib3JkZXItcmFkaXVzOiAwcHg7XG4gIGhlaWdodDogNDBweDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5idG5fZGl2IC5pY25fYnRuIHtcbiAgLS1iYWNrZ3JvdW5kOiAjYjgzZDNkO1xuICBoZWlnaHQ6IDQwcHg7XG4gIC0tYm9yZGVyLXJhZGl1czogMHB4O1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHJpZ2h0OiAwcHg7XG4gIHRvcDogLTRweDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5idG5fZGl2IC5pY25fYnRuIGlvbi1pY29uIHtcbiAgZm9udC1zaXplOiAyMHB4O1xufVxuLm1haW5fY29udGVudF9kaXYgLmJ0bl9kaXYgLmRlc2Mge1xuICBjb2xvcjogIzcwNzA3MDtcbiAgZm9udC1zaXplOiAxNHB4O1xuICBtYXJnaW4tdG9wOiAyMHB4O1xufVxuLm1haW5fY29udGVudF9kaXYgLmJ0bl9kaXYgaW9uLWdyaWQge1xuICBwYWRkaW5nOiAwO1xuICBtYXJnaW4tdG9wOiAxNXB4O1xufVxuLm1haW5fY29udGVudF9kaXYgLmJ0bl9kaXYgaW9uLWdyaWQgaW9uLWNvbCB7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5idG5fZGl2IGlvbi1ncmlkIGlvbi1jb2wgaW9uLWljb24ge1xuICBmb250LXNpemU6IDIwcHg7XG59XG4ubWFpbl9jb250ZW50X2RpdiAuYnRuX2RpdiBpb24tZ3JpZCBpb24tY29sIGlvbi1sYWJlbCB7XG4gIGZvbnQtc2l6ZTogMTNweDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5idG5fZGl2IC5yYXRlX2ZsZXgge1xuICBkaXNwbGF5OiBmbGV4O1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBtYXJnaW4tdG9wOiAxNXB4O1xufVxuLm1haW5fY29udGVudF9kaXYgLmJ0bl9kaXYgLnJhdGVfZmxleCAuYmFjayB7XG4gIGhlaWdodDogMjBweDtcbiAgd2lkdGg6IDIwcHg7XG4gIGJvcmRlci1yYWRpdXM6IDEwMCU7XG4gIGJhY2tncm91bmQ6IGJsYWNrO1xufVxuLm1haW5fY29udGVudF9kaXYgLmJ0bl9kaXYgLnJhdGVfZmxleCBpb24tbGFiZWwge1xuICBmb250LXNpemU6IDE0cHg7XG4gIG1hcmdpbi1sZWZ0OiAxNXB4O1xufVxuLm1haW5fY29udGVudF9kaXYgLnZpZGVvX2RpdiB7XG4gIHBhZGRpbmctdG9wOiAxNnB4O1xufVxuLm1haW5fY29udGVudF9kaXYgLnZpZGVvX2RpdiAuaGVhZF9sYmwge1xuICBmb250LXdlaWdodDogNTAwO1xuICBmb250LXNpemU6IDE1cHg7XG4gIG1hcmdpbi1ib3R0b206IDEwcHg7XG59XG4ubWFpbl9jb250ZW50X2RpdiAudmlkZW9fZGl2IHZpZGVvIHtcbiAgd2lkdGg6IDEwMCU7XG59XG4ubWFpbl9jb250ZW50X2RpdiAudmlkZW9fZGl2IC52aWRlb19kZXRhaWwge1xuICBib3gtc2hhZG93OiAwcHggM3B4IDZweCByZ2JhKDAsIDAsIDAsIDAuMik7XG4gIHBhZGRpbmc6IDEwcHg7XG4gIGZvbnQtc2l6ZTogMTNweDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5tYWluX3NsaWRlciB7XG4gIHBhZGRpbmctdG9wOiAxNnB4O1xuICBwYWRkaW5nLWJvdHRvbTogMTZweDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5tYWluX3NsaWRlciAuaGVhZF9mbGV4IHtcbiAgZGlzcGxheTogZmxleDtcbiAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBwYWRkaW5nLWJvdHRvbTogMTVweDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5tYWluX3NsaWRlciAuaGVhZF9mbGV4IC5oZWFkX2xibCB7XG4gIGZvbnQtd2VpZ2h0OiA1MDA7XG4gIGZvbnQtc2l6ZTogMTVweDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5tYWluX3NsaWRlciAuaGVhZF9mbGV4IC5zbWFsbF9sYmwge1xuICBmb250LXNpemU6IDEzcHg7XG4gIGNvbG9yOiBncmF5O1xufVxuLm1haW5fY29udGVudF9kaXYgLm1haW5fc2xpZGVyIC5zbGlkZXJfY2xhc3MgaW9uLXNsaWRlIHtcbiAgaGVpZ2h0OiAxNTBweDtcbiAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xufVxuLm1haW5fY29udGVudF9kaXYgLm1haW5fc2xpZGVyIC5zbGlkZXJfY2xhc3MgLmltYWdlX2RpdiB7XG4gIHdpZHRoOiAxMDAlO1xuICBoZWlnaHQ6IDE1MHB4O1xuICBib3JkZXItcmFkaXVzOiA1cHg7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5tYWluX3NsaWRlciAuY3JpdGljX3NsaWRlciBpb24tc2xpZGVzIHtcbiAgcGFkZGluZy1ib3R0b206IDEwcHg7XG59XG4ubWFpbl9jb250ZW50X2RpdiAubWFpbl9zbGlkZXIgLmNyaXRpY19zbGlkZXIgaW9uLXNsaWRlIHtcbiAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xuICBtYXJnaW4tbGVmdDogNXB4O1xufVxuLm1haW5fY29udGVudF9kaXYgLm1haW5fc2xpZGVyIC5jcml0aWNfc2xpZGVyIC5zbGlkZXJfYm94IHtcbiAgYm94LXNoYWRvdzogMHB4IDNweCA2cHggcmdiYSgwLCAwLCAwLCAwLjMpO1xuICBwYWRkaW5nOiAxMHB4O1xuICBib3JkZXItcmFkaXVzOiA1cHg7XG4gIHdpZHRoOiAxMDAlO1xufVxuLm1haW5fY29udGVudF9kaXYgLm1haW5fc2xpZGVyIC5jcml0aWNfc2xpZGVyIC5zbGlkZXJfYm94IC51c2VyX2RldGFpbCB7XG4gIGRpc3BsYXk6IGZsZXg7XG59XG4ubWFpbl9jb250ZW50X2RpdiAubWFpbl9zbGlkZXIgLmNyaXRpY19zbGlkZXIgLnNsaWRlcl9ib3ggLnVzZXJfZGV0YWlsIC51c2VyX2ltYWdlIHtcbiAgaGVpZ2h0OiA0MHB4O1xuICB3aWR0aDogNDBweDtcbiAgYm9yZGVyLXJhZGl1czogMTAwJTtcbiAgbWluLXdpZHRoOiA0MHB4O1xufVxuLm1haW5fY29udGVudF9kaXYgLm1haW5fc2xpZGVyIC5jcml0aWNfc2xpZGVyIC5zbGlkZXJfYm94IC51c2VyX2RldGFpbCAudXNlcl9wZXJzb25hbCB7XG4gIHBhZGRpbmctbGVmdDogMTVweDtcbiAgZGlzcGxheTogZmxleDtcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbiAganVzdGlmeS1jb250ZW50OiBmbGV4LXN0YXJ0O1xuICBhbGlnbi1pdGVtczogZmxleC1zdGFydDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5tYWluX3NsaWRlciAuY3JpdGljX3NsaWRlciAuc2xpZGVyX2JveCAudXNlcl9kZXRhaWwgLnVzZXJfcGVyc29uYWwgLnVzZXJuYW1lIHtcbiAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgZm9udC1zaXplOiAxNHB4O1xuICBtYXJnaW4tYm90dG9tOiA1cHg7XG59XG4ubWFpbl9jb250ZW50X2RpdiAubWFpbl9zbGlkZXIgLmNyaXRpY19zbGlkZXIgLnNsaWRlcl9ib3ggLnVzZXJfZGV0YWlsIC51c2VyX3BlcnNvbmFsIC5saWdodF9sYmwge1xuICBjb2xvcjogZ3JheTtcbiAgZm9udC1zaXplOiAxMnB4O1xuICBtYXJnaW4tYm90dG9tOiA1cHg7XG59XG4ubWFpbl9jb250ZW50X2RpdiAubWFpbl9zbGlkZXIgLmNyaXRpY19zbGlkZXIgLnNsaWRlcl9ib3ggLnVzZXJfZGV0YWlsIC51c2VyX3BlcnNvbmFsIC5yYXRlX2RpdiB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGJvcmRlcjogMXB4IHNvbGlkIGxpZ2h0Z3JheTtcbiAgYm9yZGVyLXJhZGl1czogMjVweDtcbiAgcGFkZGluZzogMnB4IDVweDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5tYWluX3NsaWRlciAuY3JpdGljX3NsaWRlciAuc2xpZGVyX2JveCAudXNlcl9kZXRhaWwgLnVzZXJfcGVyc29uYWwgLnJhdGVfZGl2IGlvbi1sYWJlbCB7XG4gIGZvbnQtc2l6ZTogMTJweDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5tYWluX3NsaWRlciAuY3JpdGljX3NsaWRlciAuc2xpZGVyX2JveCAudXNlcl9kZXRhaWwgLnVzZXJfcGVyc29uYWwgLnJhdGVfZGl2IGlvbi1pY29uIHtcbiAgZm9udC1zaXplOiAxMnB4O1xuICBtYXJnaW4tdG9wOiAxcHg7XG4gIGNvbG9yOiB2YXIoLS1pb24tY29sb3Itd2FybmluZyk7XG4gIHBhZGRpbmctbGVmdDogNXB4O1xufVxuLm1haW5fY29udGVudF9kaXYgLm1haW5fc2xpZGVyIC5jcml0aWNfc2xpZGVyIC5zbGlkZXJfYm94IC5yZXZpZXcge1xuICBmb250LXNpemU6IDE0cHg7XG4gIGNvbG9yOiBncmF5O1xuICB0ZXh0LWFsaWduOiBsZWZ0O1xuICBtYXJnaW4tdG9wOiA1cHg7XG59XG4ubWFpbl9jb250ZW50X2RpdiAuc3VtbWFyeSAuaGVhZF9sYmwge1xuICBmb250LXdlaWdodDogNTAwO1xuICBmb250LXNpemU6IDE1cHg7XG4gIG1hcmdpbi1ib3R0b206IDEwcHg7XG59XG4ubWFpbl9jb250ZW50X2RpdiAuc3VtbWFyeSAubW92aWVfc3VtbWFyeSB7XG4gIGZvbnQtc2l6ZTogMTRweDtcbiAgY29sb3I6IGdyYXk7XG4gIG1hcmdpbi1ib3R0b206IDEwcHg7XG59Il19 */";
    /***/
  },

  /***/
  "./src/app/pages/movie-details/movie-details.page.ts":
  /*!***********************************************************!*\
    !*** ./src/app/pages/movie-details/movie-details.page.ts ***!
    \***********************************************************/

  /*! exports provided: MovieDetailsPage */

  /***/
  function srcAppPagesMovieDetailsMovieDetailsPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "MovieDetailsPage", function () {
      return MovieDetailsPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var src_app_services_dummy_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! src/app/services/dummy.service */
    "./src/app/services/dummy.service.ts");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");

    var MovieDetailsPage = /*#__PURE__*/function () {
      function MovieDetailsPage(dummy, navCtrl) {
        _classCallCheck(this, MovieDetailsPage);

        this.dummy = dummy;
        this.navCtrl = navCtrl;
        this.slideOpts = {
          slidesPerView: 3
        };
        this.slideOpts2 = {
          slidesPerView: 1.3
        };
        this.movies = this.dummy.movies;
        this.review = this.dummy.users;
      }

      _createClass(MovieDetailsPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }, {
        key: "goBack",
        value: function goBack() {
          this.navCtrl.back();
        }
      }]);

      return MovieDetailsPage;
    }();

    MovieDetailsPage.ctorParameters = function () {
      return [{
        type: src_app_services_dummy_service__WEBPACK_IMPORTED_MODULE_2__["DummyService"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["NavController"]
      }];
    };

    MovieDetailsPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-movie-details',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./movie-details.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/movie-details/movie-details.page.html"))["default"],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./movie-details.page.scss */
      "./src/app/pages/movie-details/movie-details.page.scss"))["default"]]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [src_app_services_dummy_service__WEBPACK_IMPORTED_MODULE_2__["DummyService"], _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["NavController"]])], MovieDetailsPage);
    /***/
  }
}]);
//# sourceMappingURL=movie-details-movie-details-module-es5.js.map