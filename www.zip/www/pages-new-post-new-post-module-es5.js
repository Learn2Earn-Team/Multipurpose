function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-new-post-new-post-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/new-post/new-post.page.html":
  /*!*****************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/new-post/new-post.page.html ***!
    \*****************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppPagesNewPostNewPostPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button mode=\"md\"></ion-back-button>\n    </ion-buttons>\n    <ion-title>Status</ion-title>\n    <ion-button slot=\"end\" fill=\"clear\" size=\"small\" color=\"dark\">\n      POST\n    </ion-button>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div class=\"main_content_div\">\n    <div class=\"flex_div\">\n      <div class=\"user_img bg_image\" [style.backgroundImage]=\"'url(assets/imgs/users/user1.jpg)'\"></div>\n      <ion-label>John Doe</ion-label>\n    </div>\n\n    <div class=\"text_div\">\n      <ion-textarea placeholder=\"Write what's on your mind\" autoGrow=\"true\"></ion-textarea>\n    </div>\n\n  </div>\n</ion-content>\n\n<ion-footer>\n  <div class=\"bottom_footer\">\n    <div>\n      <ion-label class=\"gray_lbl\">Add to your post</ion-label>\n    </div>\n    <div>\n      <ion-icon name=\"images\" class=\"orange\" ></ion-icon>\n      <ion-icon name=\"location\" color=\"danger\" ></ion-icon>\n      <ion-icon name=\"camera\" color=\"primary\"  ></ion-icon>\n    </div>\n  </div>\n</ion-footer>\n\n";
    /***/
  },

  /***/
  "./src/app/pages/new-post/new-post-routing.module.ts":
  /*!***********************************************************!*\
    !*** ./src/app/pages/new-post/new-post-routing.module.ts ***!
    \***********************************************************/

  /*! exports provided: NewPostPageRoutingModule */

  /***/
  function srcAppPagesNewPostNewPostRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "NewPostPageRoutingModule", function () {
      return NewPostPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _new_post_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./new-post.page */
    "./src/app/pages/new-post/new-post.page.ts");

    var routes = [{
      path: '',
      component: _new_post_page__WEBPACK_IMPORTED_MODULE_3__["NewPostPage"]
    }];

    var NewPostPageRoutingModule = function NewPostPageRoutingModule() {
      _classCallCheck(this, NewPostPageRoutingModule);
    };

    NewPostPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], NewPostPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/pages/new-post/new-post.module.ts":
  /*!***************************************************!*\
    !*** ./src/app/pages/new-post/new-post.module.ts ***!
    \***************************************************/

  /*! exports provided: NewPostPageModule */

  /***/
  function srcAppPagesNewPostNewPostModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "NewPostPageModule", function () {
      return NewPostPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _new_post_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./new-post-routing.module */
    "./src/app/pages/new-post/new-post-routing.module.ts");
    /* harmony import */


    var _new_post_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./new-post.page */
    "./src/app/pages/new-post/new-post.page.ts");

    var NewPostPageModule = function NewPostPageModule() {
      _classCallCheck(this, NewPostPageModule);
    };

    NewPostPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _new_post_routing_module__WEBPACK_IMPORTED_MODULE_5__["NewPostPageRoutingModule"]],
      declarations: [_new_post_page__WEBPACK_IMPORTED_MODULE_6__["NewPostPage"]]
    })], NewPostPageModule);
    /***/
  },

  /***/
  "./src/app/pages/new-post/new-post.page.scss":
  /*!***************************************************!*\
    !*** ./src/app/pages/new-post/new-post.page.scss ***!
    \***************************************************/

  /*! exports provided: default */

  /***/
  function srcAppPagesNewPostNewPostPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "ion-header ion-button {\n  font-size: 14px;\n  margin: 0px;\n}\n\n.main_content_div {\n  padding: 16px;\n}\n\n.main_content_div .flex_div {\n  width: 100%;\n  display: flex;\n  align-items: center;\n}\n\n.main_content_div .flex_div .user_img {\n  height: 45px;\n  width: 45px;\n  min-width: 45px;\n  border-radius: 100%;\n  border: 3px solid white;\n  box-shadow: 0px 3px 6px rgba(0, 0, 0, 0.3);\n  background-position: top;\n}\n\n.main_content_div .flex_div ion-label {\n  margin-left: 10px;\n}\n\n.main_content_div .text_div {\n  width: 100%;\n  padding-left: 10px;\n}\n\nion-footer .bottom_footer {\n  padding-left: 16px;\n  padding-right: 16px;\n  position: relative;\n  height: 50px;\n  display: flex;\n  align-items: center;\n  border-top: 1px solid lightgray;\n  justify-content: space-between;\n}\n\nion-footer .bottom_footer .gray_lbl {\n  color: gray;\n  font-size: 14px;\n}\n\nion-footer .bottom_footer .orange {\n  color: orangered;\n}\n\nion-footer .bottom_footer ion-icon {\n  font-size: 22px;\n  margin-left: 15px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvbmV3LXBvc3QvRTpcXElvbmljIFByb2plY3RzXFxpb25pYy01LXRlbXBsYXRlLWJ1bmRsZS1pb25pYy01LXRoZW1lcy1idW5kbGVzLWlvbmljLTUtdGVtcGxhdGVzLXdpdGgtMTAtYXBwc1xcQXBwX3NvdXJjZV9jb2RlXFxBcHBzX2NvZGVcXE11bHRpX3B1cnBvc2Uvc3JjXFxhcHBcXHBhZ2VzXFxuZXctcG9zdFxcbmV3LXBvc3QucGFnZS5zY3NzIiwic3JjL2FwcC9wYWdlcy9uZXctcG9zdC9uZXctcG9zdC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0k7RUFDSSxlQUFBO0VBQ0EsV0FBQTtBQ0FSOztBREdBO0VBQ0ksYUFBQTtBQ0FKOztBRENJO0VBQ0ksV0FBQTtFQUNBLGFBQUE7RUFDQSxtQkFBQTtBQ0NSOztBRENRO0VBQ0ksWUFBQTtFQUNBLFdBQUE7RUFDQSxlQUFBO0VBQ0EsbUJBQUE7RUFDQSx1QkFBQTtFQUNBLDBDQUFBO0VBQ0Esd0JBQUE7QUNDWjs7QURFUTtFQUNJLGlCQUFBO0FDQVo7O0FER0k7RUFDSSxXQUFBO0VBQ0Esa0JBQUE7QUNEUjs7QURLSTtFQUNJLGtCQUFBO0VBQ0EsbUJBQUE7RUFDQSxrQkFBQTtFQUNBLFlBQUE7RUFDQSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSwrQkFBQTtFQUNBLDhCQUFBO0FDRlI7O0FESVE7RUFDSSxXQUFBO0VBQ0EsZUFBQTtBQ0ZaOztBREtRO0VBQ0ksZ0JBQUE7QUNIWjs7QURNUTtFQUNJLGVBQUE7RUFDQSxpQkFBQTtBQ0paIiwiZmlsZSI6InNyYy9hcHAvcGFnZXMvbmV3LXBvc3QvbmV3LXBvc3QucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWhlYWRlcntcbiAgICBpb24tYnV0dG9ue1xuICAgICAgICBmb250LXNpemU6IDE0cHg7XG4gICAgICAgIG1hcmdpbjogMHB4O1xuICAgIH1cbn1cbi5tYWluX2NvbnRlbnRfZGl2e1xuICAgIHBhZGRpbmc6IDE2cHg7XG4gICAgLmZsZXhfZGl2e1xuICAgICAgICB3aWR0aDogMTAwJTtcbiAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcblxuICAgICAgICAudXNlcl9pbWd7XG4gICAgICAgICAgICBoZWlnaHQ6IDQ1cHg7XG4gICAgICAgICAgICB3aWR0aDogNDVweDtcbiAgICAgICAgICAgIG1pbi13aWR0aDogNDVweDtcbiAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDEwMCU7XG4gICAgICAgICAgICBib3JkZXI6IDNweCBzb2xpZCB3aGl0ZTtcbiAgICAgICAgICAgIGJveC1zaGFkb3c6IDBweCAzcHggNnB4IHJnYmEoMCwwLDAsMC4zKTtcbiAgICAgICAgICAgIGJhY2tncm91bmQtcG9zaXRpb246IHRvcDtcbiAgICAgICAgfVxuXG4gICAgICAgIGlvbi1sYWJlbCB7XG4gICAgICAgICAgICBtYXJnaW4tbGVmdDogMTBweDtcbiAgICAgICAgfVxuICAgIH1cbiAgICAudGV4dF9kaXZ7XG4gICAgICAgIHdpZHRoOiAxMDAlO1xuICAgICAgICBwYWRkaW5nLWxlZnQ6IDEwcHg7XG4gICAgfVxufVxuaW9uLWZvb3RlcntcbiAgICAuYm90dG9tX2Zvb3RlcntcbiAgICAgICAgcGFkZGluZy1sZWZ0OiAxNnB4O1xuICAgICAgICBwYWRkaW5nLXJpZ2h0OiAxNnB4O1xuICAgICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gICAgICAgIGhlaWdodDogNTBweDtcbiAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICAgICAgYm9yZGVyLXRvcDogMXB4IHNvbGlkIGxpZ2h0Z3JheTtcbiAgICAgICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xuXG4gICAgICAgIC5ncmF5X2xibHtcbiAgICAgICAgICAgIGNvbG9yOiBncmF5O1xuICAgICAgICAgICAgZm9udC1zaXplOiAxNHB4O1xuICAgICAgICB9XG5cbiAgICAgICAgLm9yYW5nZXtcbiAgICAgICAgICAgIGNvbG9yOiBvcmFuZ2VyZWQ7XG4gICAgICAgIH1cblxuICAgICAgICBpb24taWNvbntcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogMjJweDtcbiAgICAgICAgICAgIG1hcmdpbi1sZWZ0OiAxNXB4O1xuICAgICAgICB9XG4gICAgfVxufSIsImlvbi1oZWFkZXIgaW9uLWJ1dHRvbiB7XG4gIGZvbnQtc2l6ZTogMTRweDtcbiAgbWFyZ2luOiAwcHg7XG59XG5cbi5tYWluX2NvbnRlbnRfZGl2IHtcbiAgcGFkZGluZzogMTZweDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5mbGV4X2RpdiB7XG4gIHdpZHRoOiAxMDAlO1xuICBkaXNwbGF5OiBmbGV4O1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xufVxuLm1haW5fY29udGVudF9kaXYgLmZsZXhfZGl2IC51c2VyX2ltZyB7XG4gIGhlaWdodDogNDVweDtcbiAgd2lkdGg6IDQ1cHg7XG4gIG1pbi13aWR0aDogNDVweDtcbiAgYm9yZGVyLXJhZGl1czogMTAwJTtcbiAgYm9yZGVyOiAzcHggc29saWQgd2hpdGU7XG4gIGJveC1zaGFkb3c6IDBweCAzcHggNnB4IHJnYmEoMCwgMCwgMCwgMC4zKTtcbiAgYmFja2dyb3VuZC1wb3NpdGlvbjogdG9wO1xufVxuLm1haW5fY29udGVudF9kaXYgLmZsZXhfZGl2IGlvbi1sYWJlbCB7XG4gIG1hcmdpbi1sZWZ0OiAxMHB4O1xufVxuLm1haW5fY29udGVudF9kaXYgLnRleHRfZGl2IHtcbiAgd2lkdGg6IDEwMCU7XG4gIHBhZGRpbmctbGVmdDogMTBweDtcbn1cblxuaW9uLWZvb3RlciAuYm90dG9tX2Zvb3RlciB7XG4gIHBhZGRpbmctbGVmdDogMTZweDtcbiAgcGFkZGluZy1yaWdodDogMTZweDtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICBoZWlnaHQ6IDUwcHg7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIGJvcmRlci10b3A6IDFweCBzb2xpZCBsaWdodGdyYXk7XG4gIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2Vlbjtcbn1cbmlvbi1mb290ZXIgLmJvdHRvbV9mb290ZXIgLmdyYXlfbGJsIHtcbiAgY29sb3I6IGdyYXk7XG4gIGZvbnQtc2l6ZTogMTRweDtcbn1cbmlvbi1mb290ZXIgLmJvdHRvbV9mb290ZXIgLm9yYW5nZSB7XG4gIGNvbG9yOiBvcmFuZ2VyZWQ7XG59XG5pb24tZm9vdGVyIC5ib3R0b21fZm9vdGVyIGlvbi1pY29uIHtcbiAgZm9udC1zaXplOiAyMnB4O1xuICBtYXJnaW4tbGVmdDogMTVweDtcbn0iXX0= */";
    /***/
  },

  /***/
  "./src/app/pages/new-post/new-post.page.ts":
  /*!*************************************************!*\
    !*** ./src/app/pages/new-post/new-post.page.ts ***!
    \*************************************************/

  /*! exports provided: NewPostPage */

  /***/
  function srcAppPagesNewPostNewPostPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "NewPostPage", function () {
      return NewPostPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");

    var NewPostPage = /*#__PURE__*/function () {
      function NewPostPage() {
        _classCallCheck(this, NewPostPage);
      }

      _createClass(NewPostPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }]);

      return NewPostPage;
    }();

    NewPostPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-new-post',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./new-post.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/new-post/new-post.page.html"))["default"],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./new-post.page.scss */
      "./src/app/pages/new-post/new-post.page.scss"))["default"]]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])], NewPostPage);
    /***/
  }
}]);
//# sourceMappingURL=pages-new-post-new-post-module-es5.js.map