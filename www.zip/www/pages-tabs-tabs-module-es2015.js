(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-tabs-tabs-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/tabs/tabs.page.html":
/*!*********************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/tabs/tabs.page.html ***!
  \*********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-tabs (ionTabsWillChange)=\"tabChange($event)\">\n\n  <ion-tab-bar slot=\"bottom\">\n    <ion-tab-button tab=\"home\">\n      <ion-icon name=\"home-outline\"></ion-icon>\n      <ion-label>Home</ion-label>\n    </ion-tab-button>\n\n    <ion-tab-button tab=\"social\">\n      <ion-icon name=\"people-outline\"></ion-icon>\n      <ion-label>Social</ion-label>\n    </ion-tab-button>\n\n    <ion-tab-button tab=\"videos\">\n      <ion-icon name=\"logo-youtube\"></ion-icon>\n      <ion-label>Videos</ion-label>\n    </ion-tab-button>\n\n    <ion-tab-button tab=\"tab4\">\n      <ion-icon name=\"wallet-outline\"></ion-icon>\n      <ion-label>Pay</ion-label>\n    </ion-tab-button>\n\n    <ion-tab-button tab=\"news\">\n      <ion-icon name=\"newspaper-outline\"></ion-icon>\n      <ion-label>News</ion-label>\n    </ion-tab-button>\n\n    <ion-tab-button (click)=\"onClick(6)\">\n      <ion-icon name=\"ellipsis-horizontal-sharp\"></ion-icon>\n      <ion-label>More</ion-label>\n    </ion-tab-button>\n  </ion-tab-bar>\n\n</ion-tabs>\n");

/***/ }),

/***/ "./src/app/pages/tabs/tabs-routing.module.ts":
/*!***************************************************!*\
  !*** ./src/app/pages/tabs/tabs-routing.module.ts ***!
  \***************************************************/
/*! exports provided: TabsPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TabsPageRoutingModule", function() { return TabsPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _tabs_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./tabs.page */ "./src/app/pages/tabs/tabs.page.ts");




const routes = [
    {
        path: 'tabs',
        component: _tabs_page__WEBPACK_IMPORTED_MODULE_3__["TabsPage"],
        children: [
            {
                path: 'home',
                loadChildren: () => __webpack_require__.e(/*! import() | home-home-module */ "home-home-module").then(__webpack_require__.bind(null, /*! ../home/home.module */ "./src/app/pages/home/home.module.ts")).then(m => m.HomePageModule)
            },
            {
                path: 'social',
                loadChildren: () => __webpack_require__.e(/*! import() | social-social-module */ "social-social-module").then(__webpack_require__.bind(null, /*! ../social/social.module */ "./src/app/pages/social/social.module.ts")).then(m => m.SocialPageModule)
            },
            {
                path: 'videos',
                loadChildren: () => __webpack_require__.e(/*! import() | videos-videos-module */ "videos-videos-module").then(__webpack_require__.bind(null, /*! ../videos/videos.module */ "./src/app/pages/videos/videos.module.ts")).then(m => m.VideosPageModule)
            },
            {
                path: 'tab4',
                loadChildren: () => __webpack_require__.e(/*! import() | pay-pay-module */ "pay-pay-module").then(__webpack_require__.bind(null, /*! ../pay/pay.module */ "./src/app/pages/pay/pay.module.ts")).then(m => m.PayPageModule)
            },
            {
                path: 'news',
                loadChildren: () => Promise.all(/*! import() | news-news-module */[__webpack_require__.e("common"), __webpack_require__.e("news-news-module")]).then(__webpack_require__.bind(null, /*! ../news/news.module */ "./src/app/pages/news/news.module.ts")).then(m => m.NewsPageModule)
            },
            {
                path: 'live-tv',
                loadChildren: () => __webpack_require__.e(/*! import() | live-tv-live-tv-module */ "live-tv-live-tv-module").then(__webpack_require__.bind(null, /*! ../live-tv/live-tv.module */ "./src/app/pages/live-tv/live-tv.module.ts")).then(m => m.LiveTvPageModule)
            },
            {
                path: 'music',
                loadChildren: () => Promise.all(/*! import() | music-music-module */[__webpack_require__.e("common"), __webpack_require__.e("music-music-module")]).then(__webpack_require__.bind(null, /*! ../music/music.module */ "./src/app/pages/music/music.module.ts")).then(m => m.MusicPageModule)
            },
            {
                path: 'music-list',
                loadChildren: () => Promise.all(/*! import() | music-list-music-list-module */[__webpack_require__.e("common"), __webpack_require__.e("music-list-music-list-module")]).then(__webpack_require__.bind(null, /*! ../music-list/music-list.module */ "./src/app/pages/music-list/music-list.module.ts")).then(m => m.MusicListPageModule)
            },
            {
                path: 'more-music',
                loadChildren: () => Promise.all(/*! import() | more-music-more-music-module */[__webpack_require__.e("common"), __webpack_require__.e("more-music-more-music-module")]).then(__webpack_require__.bind(null, /*! ../more-music/more-music.module */ "./src/app/pages/more-music/more-music.module.ts")).then(m => m.MoreMusicPageModule)
            },
            {
                path: 'music-video',
                loadChildren: () => Promise.all(/*! import() | music-video-music-video-module */[__webpack_require__.e("common"), __webpack_require__.e("music-video-music-video-module")]).then(__webpack_require__.bind(null, /*! ../music-video/music-video.module */ "./src/app/pages/music-video/music-video.module.ts")).then(m => m.MusicVideoPageModule)
            },
            {
                path: 'cricket',
                loadChildren: () => Promise.all(/*! import() | cricket-cricket-module */[__webpack_require__.e("common"), __webpack_require__.e("cricket-cricket-module")]).then(__webpack_require__.bind(null, /*! ../cricket/cricket.module */ "./src/app/pages/cricket/cricket.module.ts")).then(m => m.CricketPageModule)
            },
            {
                path: 'movies',
                loadChildren: () => __webpack_require__.e(/*! import() | movies-movies-module */ "movies-movies-module").then(__webpack_require__.bind(null, /*! ../movies/movies.module */ "./src/app/pages/movies/movies.module.ts")).then(m => m.MoviesPageModule)
            },
            {
                path: 'popular',
                loadChildren: () => __webpack_require__.e(/*! import() | popular-popular-module */ "popular-popular-module").then(__webpack_require__.bind(null, /*! ../popular/popular.module */ "./src/app/pages/popular/popular.module.ts")).then(m => m.PopularPageModule)
            },
            {
                path: 'movie-details',
                loadChildren: () => __webpack_require__.e(/*! import() | movie-details-movie-details-module */ "movie-details-movie-details-module").then(__webpack_require__.bind(null, /*! ../movie-details/movie-details.module */ "./src/app/pages/movie-details/movie-details.module.ts")).then(m => m.MovieDetailsPageModule)
            },
            {
                path: 'main-page',
                loadChildren: () => Promise.all(/*! import() | main-page-main-page-module */[__webpack_require__.e("common"), __webpack_require__.e("main-page-main-page-module")]).then(__webpack_require__.bind(null, /*! ../main-page/main-page.module */ "./src/app/pages/main-page/main-page.module.ts")).then(m => m.MainPagePageModule)
            },
            {
                path: 'notification',
                loadChildren: () => __webpack_require__.e(/*! import() | notification-notification-module */ "notification-notification-module").then(__webpack_require__.bind(null, /*! ../notification/notification.module */ "./src/app/pages/notification/notification.module.ts")).then(m => m.NotificationPageModule)
            },
            {
                path: 'maps',
                loadChildren: () => Promise.all(/*! import() | maps-maps-module */[__webpack_require__.e("common"), __webpack_require__.e("maps-maps-module")]).then(__webpack_require__.bind(null, /*! ../maps/maps.module */ "./src/app/pages/maps/maps.module.ts")).then(m => m.MapsPageModule)
            },
            {
                path: '',
                redirectTo: '/tabs/home',
                pathMatch: 'full'
            }
        ]
    },
    {
        path: '',
        redirectTo: '/tabs/home',
        pathMatch: 'full'
    }
];
let TabsPageRoutingModule = class TabsPageRoutingModule {
};
TabsPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })
], TabsPageRoutingModule);



/***/ }),

/***/ "./src/app/pages/tabs/tabs.module.ts":
/*!*******************************************!*\
  !*** ./src/app/pages/tabs/tabs.module.ts ***!
  \*******************************************/
/*! exports provided: TabsPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TabsPageModule", function() { return TabsPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _tabs_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./tabs-routing.module */ "./src/app/pages/tabs/tabs-routing.module.ts");
/* harmony import */ var _tabs_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./tabs.page */ "./src/app/pages/tabs/tabs.page.ts");







let TabsPageModule = class TabsPageModule {
};
TabsPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
        imports: [
            _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["IonicModule"],
            _angular_common__WEBPACK_IMPORTED_MODULE_3__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"],
            _tabs_routing_module__WEBPACK_IMPORTED_MODULE_5__["TabsPageRoutingModule"]
        ],
        declarations: [_tabs_page__WEBPACK_IMPORTED_MODULE_6__["TabsPage"]]
    })
], TabsPageModule);



/***/ }),

/***/ "./src/app/pages/tabs/tabs.page.scss":
/*!*******************************************!*\
  !*** ./src/app/pages/tabs/tabs.page.scss ***!
  \*******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-icon {\n  font-size: 17px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvdGFicy9FOlxcSW9uaWMgUHJvamVjdHNcXGlvbmljLTUtdGVtcGxhdGUtYnVuZGxlLWlvbmljLTUtdGhlbWVzLWJ1bmRsZXMtaW9uaWMtNS10ZW1wbGF0ZXMtd2l0aC0xMC1hcHBzXFxBcHBfc291cmNlX2NvZGVcXEFwcHNfY29kZVxcTXVsdGlfcHVycG9zZS9zcmNcXGFwcFxccGFnZXNcXHRhYnNcXHRhYnMucGFnZS5zY3NzIiwic3JjL2FwcC9wYWdlcy90YWJzL3RhYnMucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksZUFBQTtBQ0NKIiwiZmlsZSI6InNyYy9hcHAvcGFnZXMvdGFicy90YWJzLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1pY29ue1xuICAgIGZvbnQtc2l6ZTogMTdweDtcbn0iLCJpb24taWNvbiB7XG4gIGZvbnQtc2l6ZTogMTdweDtcbn0iXX0= */");

/***/ }),

/***/ "./src/app/pages/tabs/tabs.page.ts":
/*!*****************************************!*\
  !*** ./src/app/pages/tabs/tabs.page.ts ***!
  \*****************************************/
/*! exports provided: TabsPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TabsPage", function() { return TabsPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _more_modal_more_modal_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../more-modal/more-modal.page */ "./src/app/pages/more-modal/more-modal.page.ts");




let TabsPage = class TabsPage {
    constructor(modalController) {
        this.modalController = modalController;
    }
    tabChange(event) {
        console.log(event);
    }
    onClick(val) {
        console.log(val);
        this.presentModal();
    }
    presentModal() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const modal = yield this.modalController.create({
                component: _more_modal_more_modal_page__WEBPACK_IMPORTED_MODULE_3__["MoreModalPage"],
                cssClass: 'custom_modal'
            });
            return yield modal.present();
        });
    }
};
TabsPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"] }
];
TabsPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-tabs',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./tabs.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/tabs/tabs.page.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./tabs.page.scss */ "./src/app/pages/tabs/tabs.page.scss")).default]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"]])
], TabsPage);



/***/ })

}]);
//# sourceMappingURL=pages-tabs-tabs-module-es2015.js.map