function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"], {
  /***/
  "./$$_lazy_route_resource lazy recursive":
  /*!******************************************************!*\
    !*** ./$$_lazy_route_resource lazy namespace object ***!
    \******************************************************/

  /*! no static exports found */

  /***/
  function $$_lazy_route_resourceLazyRecursive(module, exports) {
    function webpackEmptyAsyncContext(req) {
      // Here Promise.resolve().then() is used instead of new Promise() to prevent
      // uncaught exception popping up in devtools
      return Promise.resolve().then(function () {
        var e = new Error("Cannot find module '" + req + "'");
        e.code = 'MODULE_NOT_FOUND';
        throw e;
      });
    }

    webpackEmptyAsyncContext.keys = function () {
      return [];
    };

    webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
    module.exports = webpackEmptyAsyncContext;
    webpackEmptyAsyncContext.id = "./$$_lazy_route_resource lazy recursive";
    /***/
  },

  /***/
  "./node_modules/@ionic/core/dist/esm lazy recursive ^\\.\\/.*\\.entry\\.js$ include: \\.entry\\.js$ exclude: \\.system\\.entry\\.js$":
  /*!*****************************************************************************************************************************************!*\
    !*** ./node_modules/@ionic/core/dist/esm lazy ^\.\/.*\.entry\.js$ include: \.entry\.js$ exclude: \.system\.entry\.js$ namespace object ***!
    \*****************************************************************************************************************************************/

  /*! no static exports found */

  /***/
  function node_modulesIonicCoreDistEsmLazyRecursiveEntryJs$IncludeEntryJs$ExcludeSystemEntryJs$(module, exports, __webpack_require__) {
    var map = {
      "./ion-action-sheet-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-action-sheet-ios.entry.js", "common", 0],
      "./ion-action-sheet-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-action-sheet-md.entry.js", "common", 1],
      "./ion-alert-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-alert-ios.entry.js", "common", 2],
      "./ion-alert-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-alert-md.entry.js", "common", 3],
      "./ion-app_8-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-app_8-ios.entry.js", "common", 4],
      "./ion-app_8-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-app_8-md.entry.js", "common", 5],
      "./ion-avatar_3-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-avatar_3-ios.entry.js", "common", 6],
      "./ion-avatar_3-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-avatar_3-md.entry.js", "common", 7],
      "./ion-back-button-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-back-button-ios.entry.js", "common", 8],
      "./ion-back-button-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-back-button-md.entry.js", "common", 9],
      "./ion-backdrop-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-backdrop-ios.entry.js", 10],
      "./ion-backdrop-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-backdrop-md.entry.js", 11],
      "./ion-button_2-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-button_2-ios.entry.js", "common", 12],
      "./ion-button_2-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-button_2-md.entry.js", "common", 13],
      "./ion-card_5-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-card_5-ios.entry.js", "common", 14],
      "./ion-card_5-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-card_5-md.entry.js", "common", 15],
      "./ion-checkbox-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-checkbox-ios.entry.js", "common", 16],
      "./ion-checkbox-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-checkbox-md.entry.js", "common", 17],
      "./ion-chip-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-chip-ios.entry.js", "common", 18],
      "./ion-chip-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-chip-md.entry.js", "common", 19],
      "./ion-col_3.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-col_3.entry.js", 20],
      "./ion-datetime_3-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-datetime_3-ios.entry.js", "common", 21],
      "./ion-datetime_3-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-datetime_3-md.entry.js", "common", 22],
      "./ion-fab_3-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-fab_3-ios.entry.js", "common", 23],
      "./ion-fab_3-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-fab_3-md.entry.js", "common", 24],
      "./ion-img.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-img.entry.js", 25],
      "./ion-infinite-scroll_2-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-infinite-scroll_2-ios.entry.js", 26],
      "./ion-infinite-scroll_2-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-infinite-scroll_2-md.entry.js", 27],
      "./ion-input-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-input-ios.entry.js", "common", 28],
      "./ion-input-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-input-md.entry.js", "common", 29],
      "./ion-item-option_3-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-item-option_3-ios.entry.js", "common", 30],
      "./ion-item-option_3-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-item-option_3-md.entry.js", "common", 31],
      "./ion-item_8-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-item_8-ios.entry.js", "common", 32],
      "./ion-item_8-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-item_8-md.entry.js", "common", 33],
      "./ion-loading-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-loading-ios.entry.js", "common", 34],
      "./ion-loading-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-loading-md.entry.js", "common", 35],
      "./ion-menu_3-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-menu_3-ios.entry.js", "common", 36],
      "./ion-menu_3-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-menu_3-md.entry.js", "common", 37],
      "./ion-modal-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-modal-ios.entry.js", "common", 38],
      "./ion-modal-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-modal-md.entry.js", "common", 39],
      "./ion-nav_2.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-nav_2.entry.js", "common", 40],
      "./ion-popover-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-popover-ios.entry.js", "common", 41],
      "./ion-popover-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-popover-md.entry.js", "common", 42],
      "./ion-progress-bar-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-progress-bar-ios.entry.js", "common", 43],
      "./ion-progress-bar-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-progress-bar-md.entry.js", "common", 44],
      "./ion-radio_2-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-radio_2-ios.entry.js", "common", 45],
      "./ion-radio_2-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-radio_2-md.entry.js", "common", 46],
      "./ion-range-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-range-ios.entry.js", "common", 47],
      "./ion-range-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-range-md.entry.js", "common", 48],
      "./ion-refresher_2-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-refresher_2-ios.entry.js", "common", 49],
      "./ion-refresher_2-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-refresher_2-md.entry.js", "common", 50],
      "./ion-reorder_2-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-reorder_2-ios.entry.js", "common", 51],
      "./ion-reorder_2-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-reorder_2-md.entry.js", "common", 52],
      "./ion-ripple-effect.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-ripple-effect.entry.js", 53],
      "./ion-route_4.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-route_4.entry.js", "common", 54],
      "./ion-searchbar-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-searchbar-ios.entry.js", "common", 55],
      "./ion-searchbar-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-searchbar-md.entry.js", "common", 56],
      "./ion-segment_2-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-segment_2-ios.entry.js", "common", 57],
      "./ion-segment_2-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-segment_2-md.entry.js", "common", 58],
      "./ion-select_3-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-select_3-ios.entry.js", "common", 59],
      "./ion-select_3-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-select_3-md.entry.js", "common", 60],
      "./ion-slide_2-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-slide_2-ios.entry.js", 61],
      "./ion-slide_2-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-slide_2-md.entry.js", 62],
      "./ion-spinner.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-spinner.entry.js", "common", 63],
      "./ion-split-pane-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-split-pane-ios.entry.js", 64],
      "./ion-split-pane-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-split-pane-md.entry.js", 65],
      "./ion-tab-bar_2-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-tab-bar_2-ios.entry.js", "common", 66],
      "./ion-tab-bar_2-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-tab-bar_2-md.entry.js", "common", 67],
      "./ion-tab_2.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-tab_2.entry.js", "common", 68],
      "./ion-text.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-text.entry.js", "common", 69],
      "./ion-textarea-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-textarea-ios.entry.js", "common", 70],
      "./ion-textarea-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-textarea-md.entry.js", "common", 71],
      "./ion-toast-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-toast-ios.entry.js", "common", 72],
      "./ion-toast-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-toast-md.entry.js", "common", 73],
      "./ion-toggle-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-toggle-ios.entry.js", "common", 74],
      "./ion-toggle-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-toggle-md.entry.js", "common", 75],
      "./ion-virtual-scroll.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-virtual-scroll.entry.js", 76]
    };

    function webpackAsyncContext(req) {
      if (!__webpack_require__.o(map, req)) {
        return Promise.resolve().then(function () {
          var e = new Error("Cannot find module '" + req + "'");
          e.code = 'MODULE_NOT_FOUND';
          throw e;
        });
      }

      var ids = map[req],
          id = ids[0];
      return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(function () {
        return __webpack_require__(id);
      });
    }

    webpackAsyncContext.keys = function webpackAsyncContextKeys() {
      return Object.keys(map);
    };

    webpackAsyncContext.id = "./node_modules/@ionic/core/dist/esm lazy recursive ^\\.\\/.*\\.entry\\.js$ include: \\.entry\\.js$ exclude: \\.system\\.entry\\.js$";
    module.exports = webpackAsyncContext;
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html":
  /*!**************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html ***!
    \**************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppAppComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-app>\n\n  <ion-menu type=\"push\" contentId=\"main\">\n    <ion-header class=\"ion-no-border\">\n      <ion-toolbar>\n        <ion-button (click)=\"close()\" fill=\"clear\">\n          <ion-icon name=\"close\" color=\"dark\"></ion-icon>\n        </ion-button>\n      </ion-toolbar>\n    </ion-header>\n\n    <ion-content>\n      <div class=\"main_menu_div\">\n\n        <div class=\"user_detail_div\">\n          <div class=\"user_per\">\n            <ion-label class=\"username\">John Doe</ion-label>\n            <ion-label class=\"light\">Manage profile & settings</ion-label>\n          </div>\n          <div class=\"back_image bg_image\" [style.backgroundImage]=\"'url(assets/imgs/users/user1.jpg)'\"></div>\n        </div>\n\n        <div class=\"chip_div\">\n          <ion-chip mode=\"ios\" outline=\"true\">\n            <ion-label>Saved</ion-label>\n          </ion-chip>\n          <ion-chip mode=\"ios\" outline=\"true\">\n            <ion-label>Favourites</ion-label>\n          </ion-chip>\n          <ion-chip mode=\"ios\" outline=\"true\">\n            <ion-label>Interest</ion-label>\n          </ion-chip>\n          <ion-chip mode=\"ios\" outline=\"true\">\n            <ion-label>Friends</ion-label>\n          </ion-chip>\n        </div>\n\n        <div class=\"list_div\">\n\n          <div class=\"single_list\">\n            <div class=\"round_div\">\n              <ion-icon name=\"cube-outline\"></ion-icon>\n            </div>\n            <ion-label>3D Notification</ion-label>\n            <ion-toggle mode=\"md\"></ion-toggle>\n          </div>\n\n          <div class=\"single_list\">\n            <div class=\"round_div\">\n              <img src=\"assets/imgs/india.png\">\n            </div>\n            <ion-label>Country and Language</ion-label>\n            <ion-label class=\"abs_lbl\">Change</ion-label>\n          </div>\n\n          <div class=\"single_list\">\n            <div class=\"round_div\">\n              <ion-icon name=\"mail-outline\"></ion-icon>\n            </div>\n            <ion-label>Feedback</ion-label>\n          </div>\n\n          <div class=\"single_list\">\n            <div class=\"round_div\">\n              <ion-icon name=\"repeat-outline\"></ion-icon>\n            </div>\n            <ion-label>My Transactions</ion-label>\n          </div>\n\n          <div class=\"single_list\">\n            <div class=\"round_div\">\n              <ion-icon name=\"trending-up-outline\"></ion-icon>\n            </div>\n            <ion-label>List a Business</ion-label>\n          </div>\n\n          <div class=\"single_list\">\n            <div class=\"round_div\">\n              <ion-icon name=\"volume-medium-outline\"></ion-icon>\n            </div>\n            <ion-label>Advertise</ion-label>\n          </div>\n\n          <div class=\"single_list\">\n            <div class=\"round_div\">\n              <img src=\"assets/imgs/upi2.png\">\n            </div>\n            <ion-label>UPI</ion-label>\n          </div>\n\n          <div class=\"single_list\">\n            <div class=\"round_div\">\n              <ion-icon name=\"document-text-outline\"></ion-icon>\n            </div>\n            <ion-label>Edit News Font Size</ion-label>\n            <ion-label class=\"abs_lbl\">Medium</ion-label>\n          </div>\n\n          <div class=\"single_list\">\n            <div class=\"round_div\">\n              <ion-icon name=\"settings-outline\"></ion-icon>\n            </div>\n            <ion-label>Settings</ion-label>\n          </div>\n\n          <div class=\"single_list\">\n            <div class=\"round_div\">\n              <ion-icon name=\"shield-checkmark-outline\"></ion-icon>\n            </div>\n            <ion-label>Privacy</ion-label>\n          </div>\n\n          <div class=\"single_list\">\n            <div class=\"round_div\">\n              <ion-icon name=\"star-outline\"></ion-icon>\n            </div>\n            <ion-label>Rate Us</ion-label>\n          </div>\n\n          <div class=\"single_list\">\n            <div class=\"round_div\">\n              <ion-icon name=\"ellipsis-horizontal-outline\"></ion-icon>\n            </div>\n            <ion-label>Others</ion-label>\n          </div>\n\n          <div class=\"single_list\">\n            <div class=\"round_div\">\n              <ion-icon name=\"help-outline\"></ion-icon>\n            </div>\n            <ion-label>Help and Support</ion-label>\n          </div>\n\n          <div class=\"single_list\">\n            <div class=\"round_div\">\n              <ion-icon name=\"alert-circle-outline\"></ion-icon>\n            </div>\n            <ion-label>About Us</ion-label>\n          </div>\n\n          <div class=\"single_list\">\n            <div class=\"round_div\">\n              <ion-icon name=\"person-outline\"></ion-icon>\n            </div>\n            <ion-label>Refer & Earn</ion-label>\n          </div>\n\n          <div class=\"single_list\">\n            <div class=\"round_div\">\n              <ion-icon name=\"newspaper-outline\"></ion-icon>\n            </div>\n            <ion-label>Send Feedback</ion-label>\n          </div>\n\n          <div class=\"single_list\">\n            <div class=\"round_div\">\n              <ion-icon name=\"exit-outline\"></ion-icon>\n            </div>\n            <ion-label>Logout</ion-label>\n          </div>\n\n        </div>\n\n      </div>\n    </ion-content>\n  </ion-menu>\n\n  <ion-router-outlet id=\"main\"></ion-router-outlet>\n</ion-app>\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/choose-language/choose-language.page.html":
  /*!*******************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/choose-language/choose-language.page.html ***!
    \*******************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppPagesChooseLanguageChooseLanguagePageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar>\n   <ion-button (click)=\"close()\" fill=\"clear\">\n    <ion-icon color=\"dark\" name=\"arrow-back-outline\"></ion-icon>\n   </ion-button>\n    <ion-title>Change Language</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div class=\"main_content_div\">\n\n    <ion-list lines=\"none\">\n      <ion-radio-group name=\"auto\" value=\"tesla\">\n\n        <ion-item>\n          <ion-label>English</ion-label>\n          <ion-radio slot=\"end\" mode=\"md\" value=\"English\"></ion-radio>\n        </ion-item>\n\n        <ion-item>\n          <ion-label>Hindi</ion-label>\n          <ion-radio slot=\"end\" mode=\"md\" value=\"Hindi\"></ion-radio>\n        </ion-item>\n        \n        <ion-item>\n          <ion-label>Marathi</ion-label>\n          <ion-radio slot=\"end\" mode=\"md\" value=\"Marathi\"></ion-radio>\n        </ion-item>\n\n      </ion-radio-group>\n    </ion-list>\n\n  </div>\n</ion-content>\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/more-modal/more-modal.page.html":
  /*!*********************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/more-modal/more-modal.page.html ***!
    \*********************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppPagesMoreModalMoreModalPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-content>\n  <div class=\"main_content_div\">\n\n    <ion-grid>\n      <ion-row>\n        <ion-col size=\"3\" *ngFor=\"let item of moreCat\" (click)=\"goToPage(item)\">\n          <div class=\"inner_col\">\n            <img src=\"{{item.img}}\">\n            <ion-label>{{item.name}}</ion-label>\n          </div>\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n\n  </div>\n</ion-content>\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/movie-cat/movie-cat.page.html":
  /*!*******************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/movie-cat/movie-cat.page.html ***!
    \*******************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppPagesMovieCatMovieCatPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<div class=\"main_content_div\">\n  <div class=\"abs_div\">\n    <ion-label *ngFor=\"let item of allGenres\">{{item}}</ion-label>\n\n    <ion-button (click)=\"close()\" fill=\"clear\">\n      <ion-icon name=\"close-sharp\"></ion-icon>\n    </ion-button>\n    \n  </div>\n</div>";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/movie-ganres/movie-ganres.page.html":
  /*!*************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/movie-ganres/movie-ganres.page.html ***!
    \*************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppPagesMovieGanresMovieGanresPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<div class=\"main_content_div\">\n  <div class=\"abs_div\">\n    <ion-label *ngFor=\"let item of allGenres\">{{item}}</ion-label>\n\n    <ion-button (click)=\"close()\" fill=\"clear\">\n      <ion-icon name=\"close-sharp\"></ion-icon>\n    </ion-button>\n    \n  </div>\n</div>";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/movie-lang/movie-lang.page.html":
  /*!*********************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/movie-lang/movie-lang.page.html ***!
    \*********************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppPagesMovieLangMovieLangPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<div class=\"main_content_div\">\n  <div class=\"abs_div\">\n    <ion-label *ngFor=\"let item of lang\">{{item}}</ion-label>\n\n    <ion-button (click)=\"close()\" fill=\"clear\">\n      <ion-icon name=\"close-sharp\"></ion-icon>\n    </ion-button>\n    \n  </div>\n</div>\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/movie-plarform/movie-plarform.page.html":
  /*!*****************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/movie-plarform/movie-plarform.page.html ***!
    \*****************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppPagesMoviePlarformMoviePlarformPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<div class=\"main_content_div\">\n  <div class=\"abs_div\">\n    <ion-label *ngFor=\"let item of platform\">{{item}}</ion-label>\n\n    <ion-button (click)=\"close()\" fill=\"clear\">\n      <ion-icon name=\"close-sharp\"></ion-icon>\n    </ion-button>\n    \n  </div>\n</div>";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/movie-rating/movie-rating.page.html":
  /*!*************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/movie-rating/movie-rating.page.html ***!
    \*************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppPagesMovieRatingMovieRatingPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<div class=\"main_content_div\">\n  <div class=\"abs_div\">\n    <ion-label *ngFor=\"let item of rating\">{{item}}</ion-label>\n\n    <ion-button (click)=\"close()\" fill=\"clear\">\n      <ion-icon name=\"close-sharp\"></ion-icon>\n    </ion-button>\n    \n  </div>\n</div>";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/movie-year/movie-year.page.html":
  /*!*********************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/movie-year/movie-year.page.html ***!
    \*********************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppPagesMovieYearMovieYearPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<div class=\"main_content_div\">\n  <div class=\"abs_div\">\n\n\n    <ion-label *ngFor=\"let item of year\">{{item}}</ion-label>\n\n    <ion-button (click)=\"close()\" fill=\"clear\">\n      <ion-icon name=\"close-sharp\"></ion-icon>\n    </ion-button>\n    \n  </div>\n</div>";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/notification-modal/notification-modal.page.html":
  /*!*************************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/notification-modal/notification-modal.page.html ***!
    \*************************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppPagesNotificationModalNotificationModalPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<div class=\"main_content_modal\">\n\n  <div class=\"white_div\">\n    <div class=\"back_image bg_image\" [style.backgroundImage]=\"'url(assets/imgs/news_icn1.png)'\"></div>\n\n    <div class=\"lbl_div\">\n      <ion-label class=\"head_lbl\">Lorem ipsum dolor sit amet consectetur adipisicing elit</ion-label>\n    </div>\n    <div class=\"flex_div\">\n      <ion-icon name=\"remove-circle-outline\"></ion-icon>\n      <ion-label>Hide this notification</ion-label>\n    </div>\n  </div>\n</div>\n";
    /***/
  },

  /***/
  "./node_modules/tslib/tslib.es6.js":
  /*!*****************************************!*\
    !*** ./node_modules/tslib/tslib.es6.js ***!
    \*****************************************/

  /*! exports provided: __extends, __assign, __rest, __decorate, __param, __metadata, __awaiter, __generator, __exportStar, __values, __read, __spread, __spreadArrays, __await, __asyncGenerator, __asyncDelegator, __asyncValues, __makeTemplateObject, __importStar, __importDefault, __classPrivateFieldGet, __classPrivateFieldSet */

  /***/
  function node_modulesTslibTslibEs6Js(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__extends", function () {
      return __extends;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__assign", function () {
      return _assign;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__rest", function () {
      return __rest;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__decorate", function () {
      return __decorate;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__param", function () {
      return __param;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__metadata", function () {
      return __metadata;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__awaiter", function () {
      return __awaiter;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__generator", function () {
      return __generator;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__exportStar", function () {
      return __exportStar;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__values", function () {
      return __values;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__read", function () {
      return __read;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__spread", function () {
      return __spread;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__spreadArrays", function () {
      return __spreadArrays;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__await", function () {
      return __await;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__asyncGenerator", function () {
      return __asyncGenerator;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__asyncDelegator", function () {
      return __asyncDelegator;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__asyncValues", function () {
      return __asyncValues;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__makeTemplateObject", function () {
      return __makeTemplateObject;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__importStar", function () {
      return __importStar;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__importDefault", function () {
      return __importDefault;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__classPrivateFieldGet", function () {
      return __classPrivateFieldGet;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__classPrivateFieldSet", function () {
      return __classPrivateFieldSet;
    });
    /*! *****************************************************************************
    Copyright (c) Microsoft Corporation.
    
    Permission to use, copy, modify, and/or distribute this software for any
    purpose with or without fee is hereby granted.
    
    THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
    REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
    AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
    INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
    LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
    OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
    PERFORMANCE OF THIS SOFTWARE.
    ***************************************************************************** */

    /* global Reflect, Promise */


    var _extendStatics = function extendStatics(d, b) {
      _extendStatics = Object.setPrototypeOf || {
        __proto__: []
      } instanceof Array && function (d, b) {
        d.__proto__ = b;
      } || function (d, b) {
        for (var p in b) {
          if (b.hasOwnProperty(p)) d[p] = b[p];
        }
      };

      return _extendStatics(d, b);
    };

    function __extends(d, b) {
      _extendStatics(d, b);

      function __() {
        this.constructor = d;
      }

      d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    }

    var _assign = function __assign() {
      _assign = Object.assign || function __assign(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];

          for (var p in s) {
            if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
          }
        }

        return t;
      };

      return _assign.apply(this, arguments);
    };

    function __rest(s, e) {
      var t = {};

      for (var p in s) {
        if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
      }

      if (s != null && typeof Object.getOwnPropertySymbols === "function") for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
      }
      return t;
    }

    function __decorate(decorators, target, key, desc) {
      var c = arguments.length,
          r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc,
          d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);else for (var i = decorators.length - 1; i >= 0; i--) {
        if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      }
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    }

    function __param(paramIndex, decorator) {
      return function (target, key) {
        decorator(target, key, paramIndex);
      };
    }

    function __metadata(metadataKey, metadataValue) {
      if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(metadataKey, metadataValue);
    }

    function __awaiter(thisArg, _arguments, P, generator) {
      function adopt(value) {
        return value instanceof P ? value : new P(function (resolve) {
          resolve(value);
        });
      }

      return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) {
          try {
            step(generator.next(value));
          } catch (e) {
            reject(e);
          }
        }

        function rejected(value) {
          try {
            step(generator["throw"](value));
          } catch (e) {
            reject(e);
          }
        }

        function step(result) {
          result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }

        step((generator = generator.apply(thisArg, _arguments || [])).next());
      });
    }

    function __generator(thisArg, body) {
      var _ = {
        label: 0,
        sent: function sent() {
          if (t[0] & 1) throw t[1];
          return t[1];
        },
        trys: [],
        ops: []
      },
          f,
          y,
          t,
          g;
      return g = {
        next: verb(0),
        "throw": verb(1),
        "return": verb(2)
      }, typeof Symbol === "function" && (g[Symbol.iterator] = function () {
        return this;
      }), g;

      function verb(n) {
        return function (v) {
          return step([n, v]);
        };
      }

      function step(op) {
        if (f) throw new TypeError("Generator is already executing.");

        while (_) {
          try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];

            switch (op[0]) {
              case 0:
              case 1:
                t = op;
                break;

              case 4:
                _.label++;
                return {
                  value: op[1],
                  done: false
                };

              case 5:
                _.label++;
                y = op[1];
                op = [0];
                continue;

              case 7:
                op = _.ops.pop();

                _.trys.pop();

                continue;

              default:
                if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
                  _ = 0;
                  continue;
                }

                if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
                  _.label = op[1];
                  break;
                }

                if (op[0] === 6 && _.label < t[1]) {
                  _.label = t[1];
                  t = op;
                  break;
                }

                if (t && _.label < t[2]) {
                  _.label = t[2];

                  _.ops.push(op);

                  break;
                }

                if (t[2]) _.ops.pop();

                _.trys.pop();

                continue;
            }

            op = body.call(thisArg, _);
          } catch (e) {
            op = [6, e];
            y = 0;
          } finally {
            f = t = 0;
          }
        }

        if (op[0] & 5) throw op[1];
        return {
          value: op[0] ? op[1] : void 0,
          done: true
        };
      }
    }

    function __exportStar(m, exports) {
      for (var p in m) {
        if (!exports.hasOwnProperty(p)) exports[p] = m[p];
      }
    }

    function __values(o) {
      var s = typeof Symbol === "function" && Symbol.iterator,
          m = s && o[s],
          i = 0;
      if (m) return m.call(o);
      if (o && typeof o.length === "number") return {
        next: function next() {
          if (o && i >= o.length) o = void 0;
          return {
            value: o && o[i++],
            done: !o
          };
        }
      };
      throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
    }

    function __read(o, n) {
      var m = typeof Symbol === "function" && o[Symbol.iterator];
      if (!m) return o;
      var i = m.call(o),
          r,
          ar = [],
          e;

      try {
        while ((n === void 0 || n-- > 0) && !(r = i.next()).done) {
          ar.push(r.value);
        }
      } catch (error) {
        e = {
          error: error
        };
      } finally {
        try {
          if (r && !r.done && (m = i["return"])) m.call(i);
        } finally {
          if (e) throw e.error;
        }
      }

      return ar;
    }

    function __spread() {
      for (var ar = [], i = 0; i < arguments.length; i++) {
        ar = ar.concat(__read(arguments[i]));
      }

      return ar;
    }

    function __spreadArrays() {
      for (var s = 0, i = 0, il = arguments.length; i < il; i++) {
        s += arguments[i].length;
      }

      for (var r = Array(s), k = 0, i = 0; i < il; i++) {
        for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++) {
          r[k] = a[j];
        }
      }

      return r;
    }

    ;

    function __await(v) {
      return this instanceof __await ? (this.v = v, this) : new __await(v);
    }

    function __asyncGenerator(thisArg, _arguments, generator) {
      if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
      var g = generator.apply(thisArg, _arguments || []),
          i,
          q = [];
      return i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () {
        return this;
      }, i;

      function verb(n) {
        if (g[n]) i[n] = function (v) {
          return new Promise(function (a, b) {
            q.push([n, v, a, b]) > 1 || resume(n, v);
          });
        };
      }

      function resume(n, v) {
        try {
          step(g[n](v));
        } catch (e) {
          settle(q[0][3], e);
        }
      }

      function step(r) {
        r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r);
      }

      function fulfill(value) {
        resume("next", value);
      }

      function reject(value) {
        resume("throw", value);
      }

      function settle(f, v) {
        if (f(v), q.shift(), q.length) resume(q[0][0], q[0][1]);
      }
    }

    function __asyncDelegator(o) {
      var i, p;
      return i = {}, verb("next"), verb("throw", function (e) {
        throw e;
      }), verb("return"), i[Symbol.iterator] = function () {
        return this;
      }, i;

      function verb(n, f) {
        i[n] = o[n] ? function (v) {
          return (p = !p) ? {
            value: __await(o[n](v)),
            done: n === "return"
          } : f ? f(v) : v;
        } : f;
      }
    }

    function __asyncValues(o) {
      if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
      var m = o[Symbol.asyncIterator],
          i;
      return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () {
        return this;
      }, i);

      function verb(n) {
        i[n] = o[n] && function (v) {
          return new Promise(function (resolve, reject) {
            v = o[n](v), settle(resolve, reject, v.done, v.value);
          });
        };
      }

      function settle(resolve, reject, d, v) {
        Promise.resolve(v).then(function (v) {
          resolve({
            value: v,
            done: d
          });
        }, reject);
      }
    }

    function __makeTemplateObject(cooked, raw) {
      if (Object.defineProperty) {
        Object.defineProperty(cooked, "raw", {
          value: raw
        });
      } else {
        cooked.raw = raw;
      }

      return cooked;
    }

    ;

    function __importStar(mod) {
      if (mod && mod.__esModule) return mod;
      var result = {};
      if (mod != null) for (var k in mod) {
        if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
      }
      result["default"] = mod;
      return result;
    }

    function __importDefault(mod) {
      return mod && mod.__esModule ? mod : {
        "default": mod
      };
    }

    function __classPrivateFieldGet(receiver, privateMap) {
      if (!privateMap.has(receiver)) {
        throw new TypeError("attempted to get private field on non-instance");
      }

      return privateMap.get(receiver);
    }

    function __classPrivateFieldSet(receiver, privateMap, value) {
      if (!privateMap.has(receiver)) {
        throw new TypeError("attempted to set private field on non-instance");
      }

      privateMap.set(receiver, value);
      return value;
    }
    /***/

  },

  /***/
  "./src/app/app-routing.module.ts":
  /*!***************************************!*\
    !*** ./src/app/app-routing.module.ts ***!
    \***************************************/

  /*! exports provided: AppRoutingModule */

  /***/
  function srcAppAppRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function () {
      return AppRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");

    var routes = [{
      path: '',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | pages-tabs-tabs-module */
        "pages-tabs-tabs-module").then(__webpack_require__.bind(null,
        /*! ./pages/tabs/tabs.module */
        "./src/app/pages/tabs/tabs.module.ts")).then(function (m) {
          return m.TabsPageModule;
        });
      }
    }, {
      path: 'home',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | pages-home-home-module */
        "home-home-module").then(__webpack_require__.bind(null,
        /*! ./pages/home/home.module */
        "./src/app/pages/home/home.module.ts")).then(function (m) {
          return m.HomePageModule;
        });
      }
    }, {
      path: 'social',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | pages-social-social-module */
        "social-social-module").then(__webpack_require__.bind(null,
        /*! ./pages/social/social.module */
        "./src/app/pages/social/social.module.ts")).then(function (m) {
          return m.SocialPageModule;
        });
      }
    }, {
      path: 'movies',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | pages-movies-movies-module */
        "movies-movies-module").then(__webpack_require__.bind(null,
        /*! ./pages/movies/movies.module */
        "./src/app/pages/movies/movies.module.ts")).then(function (m) {
          return m.MoviesPageModule;
        });
      }
    }, {
      path: 'pay',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | pages-pay-pay-module */
        "pay-pay-module").then(__webpack_require__.bind(null,
        /*! ./pages/pay/pay.module */
        "./src/app/pages/pay/pay.module.ts")).then(function (m) {
          return m.PayPageModule;
        });
      }
    }, {
      path: 'news',
      loadChildren: function loadChildren() {
        return Promise.all(
        /*! import() | pages-news-news-module */
        [__webpack_require__.e("common"), __webpack_require__.e("news-news-module")]).then(__webpack_require__.bind(null,
        /*! ./pages/news/news.module */
        "./src/app/pages/news/news.module.ts")).then(function (m) {
          return m.NewsPageModule;
        });
      }
    }, {
      path: 'more',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | pages-more-more-module */
        "pages-more-more-module").then(__webpack_require__.bind(null,
        /*! ./pages/more/more.module */
        "./src/app/pages/more/more.module.ts")).then(function (m) {
          return m.MorePageModule;
        });
      }
    }, {
      path: 'more-modal',
      loadChildren: function loadChildren() {
        return Promise.resolve().then(__webpack_require__.bind(null,
        /*! ./pages/more-modal/more-modal.module */
        "./src/app/pages/more-modal/more-modal.module.ts")).then(function (m) {
          return m.MoreModalPageModule;
        });
      }
    }, {
      path: 'videos',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | pages-videos-videos-module */
        "videos-videos-module").then(__webpack_require__.bind(null,
        /*! ./pages/videos/videos.module */
        "./src/app/pages/videos/videos.module.ts")).then(function (m) {
          return m.VideosPageModule;
        });
      }
    }, {
      path: 'choose-language',
      loadChildren: function loadChildren() {
        return Promise.resolve().then(__webpack_require__.bind(null,
        /*! ./pages/choose-language/choose-language.module */
        "./src/app/pages/choose-language/choose-language.module.ts")).then(function (m) {
          return m.ChooseLanguagePageModule;
        });
      }
    }, {
      path: 'login',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | pages-login-login-module */
        "pages-login-login-module").then(__webpack_require__.bind(null,
        /*! ./pages/login/login.module */
        "./src/app/pages/login/login.module.ts")).then(function (m) {
          return m.LoginPageModule;
        });
      }
    }, {
      path: 'live-tv',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | pages-live-tv-live-tv-module */
        "live-tv-live-tv-module").then(__webpack_require__.bind(null,
        /*! ./pages/live-tv/live-tv.module */
        "./src/app/pages/live-tv/live-tv.module.ts")).then(function (m) {
          return m.LiveTvPageModule;
        });
      }
    }, {
      path: 'music',
      loadChildren: function loadChildren() {
        return Promise.all(
        /*! import() | pages-music-music-module */
        [__webpack_require__.e("common"), __webpack_require__.e("music-music-module")]).then(__webpack_require__.bind(null,
        /*! ./pages/music/music.module */
        "./src/app/pages/music/music.module.ts")).then(function (m) {
          return m.MusicPageModule;
        });
      }
    }, {
      path: 'music-list',
      loadChildren: function loadChildren() {
        return Promise.all(
        /*! import() | pages-music-list-music-list-module */
        [__webpack_require__.e("common"), __webpack_require__.e("music-list-music-list-module")]).then(__webpack_require__.bind(null,
        /*! ./pages/music-list/music-list.module */
        "./src/app/pages/music-list/music-list.module.ts")).then(function (m) {
          return m.MusicListPageModule;
        });
      }
    }, {
      path: 'more-music',
      loadChildren: function loadChildren() {
        return Promise.all(
        /*! import() | pages-more-music-more-music-module */
        [__webpack_require__.e("common"), __webpack_require__.e("more-music-more-music-module")]).then(__webpack_require__.bind(null,
        /*! ./pages/more-music/more-music.module */
        "./src/app/pages/more-music/more-music.module.ts")).then(function (m) {
          return m.MoreMusicPageModule;
        });
      }
    }, {
      path: 'music-video',
      loadChildren: function loadChildren() {
        return Promise.all(
        /*! import() | pages-music-video-music-video-module */
        [__webpack_require__.e("common"), __webpack_require__.e("music-video-music-video-module")]).then(__webpack_require__.bind(null,
        /*! ./pages/music-video/music-video.module */
        "./src/app/pages/music-video/music-video.module.ts")).then(function (m) {
          return m.MusicVideoPageModule;
        });
      }
    }, {
      path: 'cricket',
      loadChildren: function loadChildren() {
        return Promise.all(
        /*! import() | pages-cricket-cricket-module */
        [__webpack_require__.e("common"), __webpack_require__.e("cricket-cricket-module")]).then(__webpack_require__.bind(null,
        /*! ./pages/cricket/cricket.module */
        "./src/app/pages/cricket/cricket.module.ts")).then(function (m) {
          return m.CricketPageModule;
        });
      }
    }, {
      path: 'cricket-news',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | pages-cricket-news-cricket-news-module */
        "pages-cricket-news-cricket-news-module").then(__webpack_require__.bind(null,
        /*! ./pages/cricket-news/cricket-news.module */
        "./src/app/pages/cricket-news/cricket-news.module.ts")).then(function (m) {
          return m.CricketNewsPageModule;
        });
      }
    }, {
      path: 'main-page',
      loadChildren: function loadChildren() {
        return Promise.all(
        /*! import() | pages-main-page-main-page-module */
        [__webpack_require__.e("common"), __webpack_require__.e("main-page-main-page-module")]).then(__webpack_require__.bind(null,
        /*! ./pages/main-page/main-page.module */
        "./src/app/pages/main-page/main-page.module.ts")).then(function (m) {
          return m.MainPagePageModule;
        });
      }
    }, {
      path: 'popular',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | pages-popular-popular-module */
        "popular-popular-module").then(__webpack_require__.bind(null,
        /*! ./pages/popular/popular.module */
        "./src/app/pages/popular/popular.module.ts")).then(function (m) {
          return m.PopularPageModule;
        });
      }
    }, {
      path: 'movie-details',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | pages-movie-details-movie-details-module */
        "movie-details-movie-details-module").then(__webpack_require__.bind(null,
        /*! ./pages/movie-details/movie-details.module */
        "./src/app/pages/movie-details/movie-details.module.ts")).then(function (m) {
          return m.MovieDetailsPageModule;
        });
      }
    }, {
      path: 'special-news',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | pages-special-news-special-news-module */
        "pages-special-news-special-news-module").then(__webpack_require__.bind(null,
        /*! ./pages/special-news/special-news.module */
        "./src/app/pages/special-news/special-news.module.ts")).then(function (m) {
          return m.SpecialNewsPageModule;
        });
      }
    }, {
      path: 'register',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | pages-register-register-module */
        "pages-register-register-module").then(__webpack_require__.bind(null,
        /*! ./pages/register/register.module */
        "./src/app/pages/register/register.module.ts")).then(function (m) {
          return m.RegisterPageModule;
        });
      }
    }, {
      path: 'new-post',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | pages-new-post-new-post-module */
        "pages-new-post-new-post-module").then(__webpack_require__.bind(null,
        /*! ./pages/new-post/new-post.module */
        "./src/app/pages/new-post/new-post.module.ts")).then(function (m) {
          return m.NewPostPageModule;
        });
      }
    }, {
      path: 'profile',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | pages-profile-profile-module */
        "pages-profile-profile-module").then(__webpack_require__.bind(null,
        /*! ./pages/profile/profile.module */
        "./src/app/pages/profile/profile.module.ts")).then(function (m) {
          return m.ProfilePageModule;
        });
      }
    }, {
      path: 'movie-cat',
      loadChildren: function loadChildren() {
        return Promise.resolve().then(__webpack_require__.bind(null,
        /*! ./pages/movie-cat/movie-cat.module */
        "./src/app/pages/movie-cat/movie-cat.module.ts")).then(function (m) {
          return m.MovieCatPageModule;
        });
      }
    }, {
      path: 'movie-lang',
      loadChildren: function loadChildren() {
        return Promise.resolve().then(__webpack_require__.bind(null,
        /*! ./pages/movie-lang/movie-lang.module */
        "./src/app/pages/movie-lang/movie-lang.module.ts")).then(function (m) {
          return m.MovieLangPageModule;
        });
      }
    }, {
      path: 'movie-rating',
      loadChildren: function loadChildren() {
        return Promise.resolve().then(__webpack_require__.bind(null,
        /*! ./pages/movie-rating/movie-rating.module */
        "./src/app/pages/movie-rating/movie-rating.module.ts")).then(function (m) {
          return m.MovieRatingPageModule;
        });
      }
    }, {
      path: 'movie-ganres',
      loadChildren: function loadChildren() {
        return Promise.resolve().then(__webpack_require__.bind(null,
        /*! ./pages/movie-ganres/movie-ganres.module */
        "./src/app/pages/movie-ganres/movie-ganres.module.ts")).then(function (m) {
          return m.MovieGanresPageModule;
        });
      }
    }, {
      path: 'movie-year',
      loadChildren: function loadChildren() {
        return Promise.resolve().then(__webpack_require__.bind(null,
        /*! ./pages/movie-year/movie-year.module */
        "./src/app/pages/movie-year/movie-year.module.ts")).then(function (m) {
          return m.MovieYearPageModule;
        });
      }
    }, {
      path: 'movie-plarform',
      loadChildren: function loadChildren() {
        return Promise.resolve().then(__webpack_require__.bind(null,
        /*! ./pages/movie-plarform/movie-plarform.module */
        "./src/app/pages/movie-plarform/movie-plarform.module.ts")).then(function (m) {
          return m.MoviePlarformPageModule;
        });
      }
    }, {
      path: 'notification',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | pages-notification-notification-module */
        "notification-notification-module").then(__webpack_require__.bind(null,
        /*! ./pages/notification/notification.module */
        "./src/app/pages/notification/notification.module.ts")).then(function (m) {
          return m.NotificationPageModule;
        });
      }
    }, {
      path: 'notification-modal',
      loadChildren: function loadChildren() {
        return Promise.resolve().then(__webpack_require__.bind(null,
        /*! ./pages/notification-modal/notification-modal.module */
        "./src/app/pages/notification-modal/notification-modal.module.ts")).then(function (m) {
          return m.NotificationModalPageModule;
        });
      }
    }, {
      path: 'maps',
      loadChildren: function loadChildren() {
        return Promise.all(
        /*! import() | pages-maps-maps-module */
        [__webpack_require__.e("common"), __webpack_require__.e("maps-maps-module")]).then(__webpack_require__.bind(null,
        /*! ./pages/maps/maps.module */
        "./src/app/pages/maps/maps.module.ts")).then(function (m) {
          return m.MapsPageModule;
        });
      }
    }, {
      path: 'settings',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | pages-settings-settings-module */
        "pages-settings-settings-module").then(__webpack_require__.bind(null,
        /*! ./pages/settings/settings.module */
        "./src/app/pages/settings/settings.module.ts")).then(function (m) {
          return m.SettingsPageModule;
        });
      }
    }];

    var AppRoutingModule = function AppRoutingModule() {
      _classCallCheck(this, AppRoutingModule);
    };

    AppRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forRoot(routes, {
        preloadingStrategy: _angular_router__WEBPACK_IMPORTED_MODULE_2__["PreloadAllModules"]
      })],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], AppRoutingModule);
    /***/
  },

  /***/
  "./src/app/app.component.scss":
  /*!************************************!*\
    !*** ./src/app/app.component.scss ***!
    \************************************/

  /*! exports provided: default */

  /***/
  function srcAppAppComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "ion-menu {\n  --width: 100%;\n}\n\n.main_menu_div {\n  padding: 16px;\n}\n\n.main_menu_div ion-label {\n  display: block;\n}\n\n.main_menu_div .user_detail_div {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n}\n\n.main_menu_div .user_detail_div .user_per .username {\n  font-weight: 600;\n  margin-bottom: 5px;\n}\n\n.main_menu_div .user_detail_div .user_per .light {\n  font-size: 14px;\n  color: gray;\n}\n\n.main_menu_div .user_detail_div .back_image {\n  height: 50px;\n  width: 50px;\n  border-radius: 100%;\n}\n\n.main_menu_div .chip_div {\n  margin-top: 15px;\n  margin-bottom: 15px;\n}\n\n.main_menu_div .list_div .single_list {\n  display: flex;\n  align-items: center;\n  margin-bottom: 10px;\n  position: relative;\n}\n\n.main_menu_div .list_div .single_list .round_div {\n  height: 35px;\n  width: 35px;\n  border-radius: 100%;\n  border: 1px solid lightgray;\n  position: relative;\n}\n\n.main_menu_div .list_div .single_list .round_div ion-icon {\n  position: absolute;\n  top: 55%;\n  left: 50%;\n  transform: translate(-50%, -59%);\n  font-size: 20px;\n}\n\n.main_menu_div .list_div .single_list .round_div img {\n  position: absolute;\n  top: 55%;\n  left: 50%;\n  transform: translate(-50%, -59%);\n  width: 20px;\n}\n\n.main_menu_div .list_div .single_list ion-label {\n  margin-left: 15px;\n  color: gray;\n  font-size: 14px;\n}\n\n.main_menu_div .list_div .single_list ion-toggle {\n  position: absolute;\n  right: 0;\n}\n\n.main_menu_div .list_div .single_list .abs_lbl {\n  position: absolute;\n  right: 0;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvRTpcXElvbmljIFByb2plY3RzXFxpb25pYy01LXRlbXBsYXRlLWJ1bmRsZS1pb25pYy01LXRoZW1lcy1idW5kbGVzLWlvbmljLTUtdGVtcGxhdGVzLXdpdGgtMTAtYXBwc1xcQXBwX3NvdXJjZV9jb2RlXFxBcHBzX2NvZGVcXE11bHRpX3B1cnBvc2Uvc3JjXFxhcHBcXGFwcC5jb21wb25lbnQuc2NzcyIsInNyYy9hcHAvYXBwLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksYUFBQTtBQ0NKOztBREVBO0VBQ0ksYUFBQTtBQ0NKOztBRENJO0VBQ0ksY0FBQTtBQ0NSOztBREVJO0VBRUksYUFBQTtFQUNBLG1CQUFBO0VBQ0EsOEJBQUE7QUNEUjs7QURLWTtFQUNJLGdCQUFBO0VBQ0Esa0JBQUE7QUNIaEI7O0FETVk7RUFDSSxlQUFBO0VBQ0EsV0FBQTtBQ0poQjs7QURPUTtFQUNJLFlBQUE7RUFDQSxXQUFBO0VBQ0EsbUJBQUE7QUNMWjs7QURTSTtFQUNJLGdCQUFBO0VBQ0EsbUJBQUE7QUNQUjs7QURXUTtFQUNJLGFBQUE7RUFDQSxtQkFBQTtFQUNBLG1CQUFBO0VBQ0Esa0JBQUE7QUNUWjs7QURVWTtFQUNJLFlBQUE7RUFDQSxXQUFBO0VBQ0EsbUJBQUE7RUFDQSwyQkFBQTtFQUNBLGtCQUFBO0FDUmhCOztBRFNnQjtFQUNJLGtCQUFBO0VBQ0EsUUFBQTtFQUNBLFNBQUE7RUFDQSxnQ0FBQTtFQUNBLGVBQUE7QUNQcEI7O0FEU2dCO0VBQ0ksa0JBQUE7RUFDQSxRQUFBO0VBQ0EsU0FBQTtFQUNBLGdDQUFBO0VBQ0EsV0FBQTtBQ1BwQjs7QURXWTtFQUNJLGlCQUFBO0VBQ0EsV0FBQTtFQUNBLGVBQUE7QUNUaEI7O0FEV1k7RUFDSSxrQkFBQTtFQUNBLFFBQUE7QUNUaEI7O0FEWVk7RUFDSSxrQkFBQTtFQUNBLFFBQUE7QUNWaEIiLCJmaWxlIjoic3JjL2FwcC9hcHAuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tbWVudXtcbiAgICAtLXdpZHRoIDogMTAwJTtcbn1cblxuLm1haW5fbWVudV9kaXZ7XG4gICAgcGFkZGluZzogMTZweDtcblxuICAgIGlvbi1sYWJlbCB7XG4gICAgICAgIGRpc3BsYXk6IGJsb2NrO1xuICAgIH1cblxuICAgIC51c2VyX2RldGFpbF9kaXZ7XG5cbiAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICAgICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xuXG4gICAgICAgIC51c2VyX3BlcntcblxuICAgICAgICAgICAgLnVzZXJuYW1le1xuICAgICAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiA2MDA7XG4gICAgICAgICAgICAgICAgbWFyZ2luLWJvdHRvbTogNXB4O1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAubGlnaHR7XG4gICAgICAgICAgICAgICAgZm9udC1zaXplOiAxNHB4O1xuICAgICAgICAgICAgICAgIGNvbG9yOiBncmF5O1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIC5iYWNrX2ltYWdle1xuICAgICAgICAgICAgaGVpZ2h0OiA1MHB4O1xuICAgICAgICAgICAgd2lkdGg6IDUwcHg7XG4gICAgICAgICAgICBib3JkZXItcmFkaXVzOiAxMDAlO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgLmNoaXBfZGl2e1xuICAgICAgICBtYXJnaW4tdG9wOiAxNXB4O1xuICAgICAgICBtYXJnaW4tYm90dG9tOiAxNXB4O1xuICAgIH1cblxuICAgIC5saXN0X2RpdntcbiAgICAgICAgLnNpbmdsZV9saXN0e1xuICAgICAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAgICAgICAgICBtYXJnaW4tYm90dG9tOiAxMHB4O1xuICAgICAgICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xuICAgICAgICAgICAgLnJvdW5kX2RpdntcbiAgICAgICAgICAgICAgICBoZWlnaHQ6IDM1cHg7XG4gICAgICAgICAgICAgICAgd2lkdGg6IDM1cHg7XG4gICAgICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogMTAwJTtcbiAgICAgICAgICAgICAgICBib3JkZXI6IDFweCBzb2xpZCBsaWdodGdyYXk7XG4gICAgICAgICAgICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xuICAgICAgICAgICAgICAgIGlvbi1pY29ue1xuICAgICAgICAgICAgICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgICAgICAgICAgICAgICAgIHRvcDogNTUlO1xuICAgICAgICAgICAgICAgICAgICBsZWZ0OiA1MCU7XG4gICAgICAgICAgICAgICAgICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlKC01MCUsLTU5JSk7XG4gICAgICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMjBweDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgaW1ne1xuICAgICAgICAgICAgICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgICAgICAgICAgICAgICAgIHRvcDogNTUlO1xuICAgICAgICAgICAgICAgICAgICBsZWZ0OiA1MCU7XG4gICAgICAgICAgICAgICAgICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlKC01MCUsLTU5JSk7XG4gICAgICAgICAgICAgICAgICAgIHdpZHRoOiAyMHB4O1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgaW9uLWxhYmVsIHtcbiAgICAgICAgICAgICAgICBtYXJnaW4tbGVmdDogMTVweDtcbiAgICAgICAgICAgICAgICBjb2xvcjogZ3JheTtcbiAgICAgICAgICAgICAgICBmb250LXNpemU6IDE0cHg7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpb24tdG9nZ2xle1xuICAgICAgICAgICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICAgICAgICAgICAgICByaWdodDogMDtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgLmFic19sYmx7XG4gICAgICAgICAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgICAgICAgICAgICAgIHJpZ2h0OiAwO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxufSIsImlvbi1tZW51IHtcbiAgLS13aWR0aDogMTAwJTtcbn1cblxuLm1haW5fbWVudV9kaXYge1xuICBwYWRkaW5nOiAxNnB4O1xufVxuLm1haW5fbWVudV9kaXYgaW9uLWxhYmVsIHtcbiAgZGlzcGxheTogYmxvY2s7XG59XG4ubWFpbl9tZW51X2RpdiAudXNlcl9kZXRhaWxfZGl2IHtcbiAgZGlzcGxheTogZmxleDtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xufVxuLm1haW5fbWVudV9kaXYgLnVzZXJfZGV0YWlsX2RpdiAudXNlcl9wZXIgLnVzZXJuYW1lIHtcbiAgZm9udC13ZWlnaHQ6IDYwMDtcbiAgbWFyZ2luLWJvdHRvbTogNXB4O1xufVxuLm1haW5fbWVudV9kaXYgLnVzZXJfZGV0YWlsX2RpdiAudXNlcl9wZXIgLmxpZ2h0IHtcbiAgZm9udC1zaXplOiAxNHB4O1xuICBjb2xvcjogZ3JheTtcbn1cbi5tYWluX21lbnVfZGl2IC51c2VyX2RldGFpbF9kaXYgLmJhY2tfaW1hZ2Uge1xuICBoZWlnaHQ6IDUwcHg7XG4gIHdpZHRoOiA1MHB4O1xuICBib3JkZXItcmFkaXVzOiAxMDAlO1xufVxuLm1haW5fbWVudV9kaXYgLmNoaXBfZGl2IHtcbiAgbWFyZ2luLXRvcDogMTVweDtcbiAgbWFyZ2luLWJvdHRvbTogMTVweDtcbn1cbi5tYWluX21lbnVfZGl2IC5saXN0X2RpdiAuc2luZ2xlX2xpc3Qge1xuICBkaXNwbGF5OiBmbGV4O1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBtYXJnaW4tYm90dG9tOiAxMHB4O1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG59XG4ubWFpbl9tZW51X2RpdiAubGlzdF9kaXYgLnNpbmdsZV9saXN0IC5yb3VuZF9kaXYge1xuICBoZWlnaHQ6IDM1cHg7XG4gIHdpZHRoOiAzNXB4O1xuICBib3JkZXItcmFkaXVzOiAxMDAlO1xuICBib3JkZXI6IDFweCBzb2xpZCBsaWdodGdyYXk7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbn1cbi5tYWluX21lbnVfZGl2IC5saXN0X2RpdiAuc2luZ2xlX2xpc3QgLnJvdW5kX2RpdiBpb24taWNvbiB7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgdG9wOiA1NSU7XG4gIGxlZnQ6IDUwJTtcbiAgdHJhbnNmb3JtOiB0cmFuc2xhdGUoLTUwJSwgLTU5JSk7XG4gIGZvbnQtc2l6ZTogMjBweDtcbn1cbi5tYWluX21lbnVfZGl2IC5saXN0X2RpdiAuc2luZ2xlX2xpc3QgLnJvdW5kX2RpdiBpbWcge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHRvcDogNTUlO1xuICBsZWZ0OiA1MCU7XG4gIHRyYW5zZm9ybTogdHJhbnNsYXRlKC01MCUsIC01OSUpO1xuICB3aWR0aDogMjBweDtcbn1cbi5tYWluX21lbnVfZGl2IC5saXN0X2RpdiAuc2luZ2xlX2xpc3QgaW9uLWxhYmVsIHtcbiAgbWFyZ2luLWxlZnQ6IDE1cHg7XG4gIGNvbG9yOiBncmF5O1xuICBmb250LXNpemU6IDE0cHg7XG59XG4ubWFpbl9tZW51X2RpdiAubGlzdF9kaXYgLnNpbmdsZV9saXN0IGlvbi10b2dnbGUge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHJpZ2h0OiAwO1xufVxuLm1haW5fbWVudV9kaXYgLmxpc3RfZGl2IC5zaW5nbGVfbGlzdCAuYWJzX2xibCB7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgcmlnaHQ6IDA7XG59Il19 */";
    /***/
  },

  /***/
  "./src/app/app.component.ts":
  /*!**********************************!*\
    !*** ./src/app/app.component.ts ***!
    \**********************************/

  /*! exports provided: AppComponent */

  /***/
  function srcAppAppComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AppComponent", function () {
      return AppComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @ionic-native/splash-screen/ngx */
    "./node_modules/@ionic-native/splash-screen/ngx/index.js");
    /* harmony import */


    var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic-native/status-bar/ngx */
    "./node_modules/@ionic-native/status-bar/ngx/index.js");

    var AppComponent = /*#__PURE__*/function () {
      function AppComponent(platform, splashScreen, statusBar, menuCrtl) {
        _classCallCheck(this, AppComponent);

        this.platform = platform;
        this.splashScreen = splashScreen;
        this.statusBar = statusBar;
        this.menuCrtl = menuCrtl;
        this.initializeApp();
      }

      _createClass(AppComponent, [{
        key: "initializeApp",
        value: function initializeApp() {
          var _this = this;

          this.platform.ready().then(function () {
            if (_this.platform.is('ios')) {
              localStorage.setItem('platform', 'ios');
              _this.plt = localStorage.getItem('platform');
            } else {
              localStorage.setItem('platform', 'android');
              _this.plt = localStorage.getItem('platform');
              console.log(_this.plt);
            }

            _this.statusBar.styleDefault();

            _this.splashScreen.hide();
          });
        }
      }, {
        key: "close",
        value: function close() {
          this.menuCrtl.close();
        }
      }]);

      return AppComponent;
    }();

    AppComponent.ctorParameters = function () {
      return [{
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["Platform"]
      }, {
        type: _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_3__["SplashScreen"]
      }, {
        type: _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_4__["StatusBar"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["MenuController"]
      }];
    };

    AppComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-root',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./app.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html"))["default"],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./app.component.scss */
      "./src/app/app.component.scss"))["default"]]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["Platform"], _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_3__["SplashScreen"], _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_4__["StatusBar"], _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["MenuController"]])], AppComponent);
    /***/
  },

  /***/
  "./src/app/app.module.ts":
  /*!*******************************!*\
    !*** ./src/app/app.module.ts ***!
    \*******************************/

  /*! exports provided: AppModule */

  /***/
  function srcAppAppModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AppModule", function () {
      return AppModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/platform-browser */
    "./node_modules/@angular/platform-browser/fesm2015/platform-browser.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @ionic-native/splash-screen/ngx */
    "./node_modules/@ionic-native/splash-screen/ngx/index.js");
    /* harmony import */


    var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! @ionic-native/status-bar/ngx */
    "./node_modules/@ionic-native/status-bar/ngx/index.js");
    /* harmony import */


    var _app_routing_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! ./app-routing.module */
    "./src/app/app-routing.module.ts");
    /* harmony import */


    var _app_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! ./app.component */
    "./src/app/app.component.ts");
    /* harmony import */


    var ionic_rating__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
    /*! ionic-rating */
    "./node_modules/ionic-rating/fesm2015/ionic-rating.js");
    /* harmony import */


    var _pages_more_modal_more_modal_module__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
    /*! ./pages/more-modal/more-modal.module */
    "./src/app/pages/more-modal/more-modal.module.ts");
    /* harmony import */


    var _pages_choose_language_choose_language_module__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(
    /*! ./pages/choose-language/choose-language.module */
    "./src/app/pages/choose-language/choose-language.module.ts");
    /* harmony import */


    var _pages_movie_cat_movie_cat_module__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(
    /*! ./pages/movie-cat/movie-cat.module */
    "./src/app/pages/movie-cat/movie-cat.module.ts");
    /* harmony import */


    var _pages_movie_lang_movie_lang_module__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(
    /*! ./pages/movie-lang/movie-lang.module */
    "./src/app/pages/movie-lang/movie-lang.module.ts");
    /* harmony import */


    var _pages_movie_rating_movie_rating_module__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(
    /*! ./pages/movie-rating/movie-rating.module */
    "./src/app/pages/movie-rating/movie-rating.module.ts");
    /* harmony import */


    var _pages_movie_ganres_movie_ganres_module__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(
    /*! ./pages/movie-ganres/movie-ganres.module */
    "./src/app/pages/movie-ganres/movie-ganres.module.ts");
    /* harmony import */


    var _pages_movie_year_movie_year_module__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(
    /*! ./pages/movie-year/movie-year.module */
    "./src/app/pages/movie-year/movie-year.module.ts");
    /* harmony import */


    var _pages_movie_plarform_movie_plarform_module__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(
    /*! ./pages/movie-plarform/movie-plarform.module */
    "./src/app/pages/movie-plarform/movie-plarform.module.ts");
    /* harmony import */


    var _pages_notification_modal_notification_modal_module__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(
    /*! ./pages/notification-modal/notification-modal.module */
    "./src/app/pages/notification-modal/notification-modal.module.ts");

    var AppModule = function AppModule() {
      _classCallCheck(this, AppModule);
    };

    AppModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      declarations: [_app_component__WEBPACK_IMPORTED_MODULE_8__["AppComponent"]],
      entryComponents: [],
      imports: [_angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__["BrowserModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"].forRoot(), _app_routing_module__WEBPACK_IMPORTED_MODULE_7__["AppRoutingModule"], _pages_more_modal_more_modal_module__WEBPACK_IMPORTED_MODULE_10__["MoreModalPageModule"], _pages_choose_language_choose_language_module__WEBPACK_IMPORTED_MODULE_11__["ChooseLanguagePageModule"], _pages_movie_cat_movie_cat_module__WEBPACK_IMPORTED_MODULE_12__["MovieCatPageModule"], _pages_movie_lang_movie_lang_module__WEBPACK_IMPORTED_MODULE_13__["MovieLangPageModule"], _pages_movie_rating_movie_rating_module__WEBPACK_IMPORTED_MODULE_14__["MovieRatingPageModule"], _pages_movie_ganres_movie_ganres_module__WEBPACK_IMPORTED_MODULE_15__["MovieGanresPageModule"], _pages_movie_year_movie_year_module__WEBPACK_IMPORTED_MODULE_16__["MovieYearPageModule"], _pages_movie_plarform_movie_plarform_module__WEBPACK_IMPORTED_MODULE_17__["MoviePlarformPageModule"], _pages_notification_modal_notification_modal_module__WEBPACK_IMPORTED_MODULE_18__["NotificationModalPageModule"], ionic_rating__WEBPACK_IMPORTED_MODULE_9__["IonicRatingModule"]],
      providers: [_ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_6__["StatusBar"], _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_5__["SplashScreen"], {
        provide: _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouteReuseStrategy"],
        useClass: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicRouteStrategy"]
      }],
      bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_8__["AppComponent"]]
    })], AppModule);
    /***/
  },

  /***/
  "./src/app/pages/choose-language/choose-language-routing.module.ts":
  /*!*************************************************************************!*\
    !*** ./src/app/pages/choose-language/choose-language-routing.module.ts ***!
    \*************************************************************************/

  /*! exports provided: ChooseLanguagePageRoutingModule */

  /***/
  function srcAppPagesChooseLanguageChooseLanguageRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ChooseLanguagePageRoutingModule", function () {
      return ChooseLanguagePageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _choose_language_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./choose-language.page */
    "./src/app/pages/choose-language/choose-language.page.ts");

    var routes = [{
      path: '',
      component: _choose_language_page__WEBPACK_IMPORTED_MODULE_3__["ChooseLanguagePage"]
    }];

    var ChooseLanguagePageRoutingModule = function ChooseLanguagePageRoutingModule() {
      _classCallCheck(this, ChooseLanguagePageRoutingModule);
    };

    ChooseLanguagePageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], ChooseLanguagePageRoutingModule);
    /***/
  },

  /***/
  "./src/app/pages/choose-language/choose-language.module.ts":
  /*!*****************************************************************!*\
    !*** ./src/app/pages/choose-language/choose-language.module.ts ***!
    \*****************************************************************/

  /*! exports provided: ChooseLanguagePageModule */

  /***/
  function srcAppPagesChooseLanguageChooseLanguageModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ChooseLanguagePageModule", function () {
      return ChooseLanguagePageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _choose_language_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./choose-language-routing.module */
    "./src/app/pages/choose-language/choose-language-routing.module.ts");
    /* harmony import */


    var _choose_language_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./choose-language.page */
    "./src/app/pages/choose-language/choose-language.page.ts");

    var ChooseLanguagePageModule = function ChooseLanguagePageModule() {
      _classCallCheck(this, ChooseLanguagePageModule);
    };

    ChooseLanguagePageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _choose_language_routing_module__WEBPACK_IMPORTED_MODULE_5__["ChooseLanguagePageRoutingModule"]],
      declarations: [_choose_language_page__WEBPACK_IMPORTED_MODULE_6__["ChooseLanguagePage"]]
    })], ChooseLanguagePageModule);
    /***/
  },

  /***/
  "./src/app/pages/choose-language/choose-language.page.scss":
  /*!*****************************************************************!*\
    !*** ./src/app/pages/choose-language/choose-language.page.scss ***!
    \*****************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppPagesChooseLanguageChooseLanguagePageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".main_content_div {\n  width: 100%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvY2hvb3NlLWxhbmd1YWdlL0U6XFxJb25pYyBQcm9qZWN0c1xcaW9uaWMtNS10ZW1wbGF0ZS1idW5kbGUtaW9uaWMtNS10aGVtZXMtYnVuZGxlcy1pb25pYy01LXRlbXBsYXRlcy13aXRoLTEwLWFwcHNcXEFwcF9zb3VyY2VfY29kZVxcQXBwc19jb2RlXFxNdWx0aV9wdXJwb3NlL3NyY1xcYXBwXFxwYWdlc1xcY2hvb3NlLWxhbmd1YWdlXFxjaG9vc2UtbGFuZ3VhZ2UucGFnZS5zY3NzIiwic3JjL2FwcC9wYWdlcy9jaG9vc2UtbGFuZ3VhZ2UvY2hvb3NlLWxhbmd1YWdlLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLFdBQUE7QUNDSiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2Nob29zZS1sYW5ndWFnZS9jaG9vc2UtbGFuZ3VhZ2UucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLm1haW5fY29udGVudF9kaXZ7XG4gICAgd2lkdGg6IDEwMCU7XG59IiwiLm1haW5fY29udGVudF9kaXYge1xuICB3aWR0aDogMTAwJTtcbn0iXX0= */";
    /***/
  },

  /***/
  "./src/app/pages/choose-language/choose-language.page.ts":
  /*!***************************************************************!*\
    !*** ./src/app/pages/choose-language/choose-language.page.ts ***!
    \***************************************************************/

  /*! exports provided: ChooseLanguagePage */

  /***/
  function srcAppPagesChooseLanguageChooseLanguagePageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ChooseLanguagePage", function () {
      return ChooseLanguagePage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");

    var ChooseLanguagePage = /*#__PURE__*/function () {
      function ChooseLanguagePage(modalController) {
        _classCallCheck(this, ChooseLanguagePage);

        this.modalController = modalController;
      }

      _createClass(ChooseLanguagePage, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }, {
        key: "close",
        value: function close() {
          this.modalController.dismiss();
        }
      }]);

      return ChooseLanguagePage;
    }();

    ChooseLanguagePage.ctorParameters = function () {
      return [{
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"]
      }];
    };

    ChooseLanguagePage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-choose-language',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./choose-language.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/choose-language/choose-language.page.html"))["default"],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./choose-language.page.scss */
      "./src/app/pages/choose-language/choose-language.page.scss"))["default"]]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"]])], ChooseLanguagePage);
    /***/
  },

  /***/
  "./src/app/pages/more-modal/more-modal-routing.module.ts":
  /*!***************************************************************!*\
    !*** ./src/app/pages/more-modal/more-modal-routing.module.ts ***!
    \***************************************************************/

  /*! exports provided: MoreModalPageRoutingModule */

  /***/
  function srcAppPagesMoreModalMoreModalRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "MoreModalPageRoutingModule", function () {
      return MoreModalPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _more_modal_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./more-modal.page */
    "./src/app/pages/more-modal/more-modal.page.ts");

    var routes = [{
      path: '',
      component: _more_modal_page__WEBPACK_IMPORTED_MODULE_3__["MoreModalPage"]
    }];

    var MoreModalPageRoutingModule = function MoreModalPageRoutingModule() {
      _classCallCheck(this, MoreModalPageRoutingModule);
    };

    MoreModalPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], MoreModalPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/pages/more-modal/more-modal.module.ts":
  /*!*******************************************************!*\
    !*** ./src/app/pages/more-modal/more-modal.module.ts ***!
    \*******************************************************/

  /*! exports provided: MoreModalPageModule */

  /***/
  function srcAppPagesMoreModalMoreModalModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "MoreModalPageModule", function () {
      return MoreModalPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _more_modal_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./more-modal-routing.module */
    "./src/app/pages/more-modal/more-modal-routing.module.ts");
    /* harmony import */


    var _more_modal_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./more-modal.page */
    "./src/app/pages/more-modal/more-modal.page.ts");

    var MoreModalPageModule = function MoreModalPageModule() {
      _classCallCheck(this, MoreModalPageModule);
    };

    MoreModalPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _more_modal_routing_module__WEBPACK_IMPORTED_MODULE_5__["MoreModalPageRoutingModule"]],
      declarations: [_more_modal_page__WEBPACK_IMPORTED_MODULE_6__["MoreModalPage"]]
    })], MoreModalPageModule);
    /***/
  },

  /***/
  "./src/app/pages/more-modal/more-modal.page.scss":
  /*!*******************************************************!*\
    !*** ./src/app/pages/more-modal/more-modal.page.scss ***!
    \*******************************************************/

  /*! exports provided: default */

  /***/
  function srcAppPagesMoreModalMoreModalPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".main_content_div {\n  width: 100%;\n  padding: 10px;\n}\n.main_content_div .inner_col {\n  text-align: center;\n  height: 60px;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  flex-direction: column;\n}\n.main_content_div .inner_col img {\n  width: 20px;\n}\n.main_content_div .inner_col ion-label {\n  font-size: 13px;\n  display: block;\n  margin-top: 7px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvbW9yZS1tb2RhbC9FOlxcSW9uaWMgUHJvamVjdHNcXGlvbmljLTUtdGVtcGxhdGUtYnVuZGxlLWlvbmljLTUtdGhlbWVzLWJ1bmRsZXMtaW9uaWMtNS10ZW1wbGF0ZXMtd2l0aC0xMC1hcHBzXFxBcHBfc291cmNlX2NvZGVcXEFwcHNfY29kZVxcTXVsdGlfcHVycG9zZS9zcmNcXGFwcFxccGFnZXNcXG1vcmUtbW9kYWxcXG1vcmUtbW9kYWwucGFnZS5zY3NzIiwic3JjL2FwcC9wYWdlcy9tb3JlLW1vZGFsL21vcmUtbW9kYWwucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksV0FBQTtFQUNBLGFBQUE7QUNDSjtBRENJO0VBQ0ksa0JBQUE7RUFDQSxZQUFBO0VBQ0EsYUFBQTtFQUNBLG1CQUFBO0VBQ0EsdUJBQUE7RUFDQSxzQkFBQTtBQ0NSO0FEQ1E7RUFDSSxXQUFBO0FDQ1o7QURDUTtFQUNJLGVBQUE7RUFDQSxjQUFBO0VBQ0EsZUFBQTtBQ0NaIiwiZmlsZSI6InNyYy9hcHAvcGFnZXMvbW9yZS1tb2RhbC9tb3JlLW1vZGFsLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5tYWluX2NvbnRlbnRfZGl2e1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIHBhZGRpbmc6IDEwcHg7XG5cbiAgICAuaW5uZXJfY29se1xuICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgICAgIGhlaWdodDogNjBweDtcbiAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gICAgICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG5cbiAgICAgICAgaW1ne1xuICAgICAgICAgICAgd2lkdGg6IDIwcHg7XG4gICAgICAgIH1cbiAgICAgICAgaW9uLWxhYmVsIHtcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogMTNweDtcbiAgICAgICAgICAgIGRpc3BsYXk6IGJsb2NrO1xuICAgICAgICAgICAgbWFyZ2luLXRvcDogN3B4O1xuICAgICAgICB9XG4gICAgfVxufSIsIi5tYWluX2NvbnRlbnRfZGl2IHtcbiAgd2lkdGg6IDEwMCU7XG4gIHBhZGRpbmc6IDEwcHg7XG59XG4ubWFpbl9jb250ZW50X2RpdiAuaW5uZXJfY29sIHtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBoZWlnaHQ6IDYwcHg7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xufVxuLm1haW5fY29udGVudF9kaXYgLmlubmVyX2NvbCBpbWcge1xuICB3aWR0aDogMjBweDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5pbm5lcl9jb2wgaW9uLWxhYmVsIHtcbiAgZm9udC1zaXplOiAxM3B4O1xuICBkaXNwbGF5OiBibG9jaztcbiAgbWFyZ2luLXRvcDogN3B4O1xufSJdfQ== */";
    /***/
  },

  /***/
  "./src/app/pages/more-modal/more-modal.page.ts":
  /*!*****************************************************!*\
    !*** ./src/app/pages/more-modal/more-modal.page.ts ***!
    \*****************************************************/

  /*! exports provided: MoreModalPage */

  /***/
  function srcAppPagesMoreModalMoreModalPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "MoreModalPage", function () {
      return MoreModalPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var src_app_services_dummy_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! src/app/services/dummy.service */
    "./src/app/services/dummy.service.ts");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");

    var MoreModalPage = /*#__PURE__*/function () {
      function MoreModalPage(dummy, router, modalController) {
        _classCallCheck(this, MoreModalPage);

        this.dummy = dummy;
        this.router = router;
        this.modalController = modalController;
        this.moreCat = this.dummy.moreCat;
      }

      _createClass(MoreModalPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }, {
        key: "dismiss",
        value: function dismiss() {
          this.modalController.dismiss();
        }
      }, {
        key: "goToPage",
        value: function goToPage(val) {
          console.log(val.name);
          var navData = {
            queryParams: {
              id: val.name
            }
          };

          if (val.name === 'Music') {
            this.dismiss();
            this.router.navigate(['/tabs/music']);
            return;
          }

          if (val.name === 'Cricket') {
            this.dismiss();
            this.router.navigate(['/tabs/cricket']);
            return;
          }

          if (val.name === 'Movies') {
            this.dismiss();
            this.router.navigate(['/tabs/movies'], navData);
            return;
          }

          if (val.name === 'Live TV') {
            this.dismiss();
            this.router.navigate(['/tabs/live-tv'], navData);
            return;
          }

          if (val.name === 'Shopping') {
            this.dismiss();
            this.router.navigate(['/tabs/main-page'], navData);
            return;
          }

          if (val.name === 'Images') {
            this.dismiss();
            this.router.navigate(['/tabs/main-page'], navData);
            return;
          }

          if (val.name === 'Maps') {
            this.dismiss();
            this.router.navigate(['/tabs/maps'], navData);
            return;
          }

          if (val.name === 'Settings') {
            this.dismiss();
            this.router.navigate(['/settings'], navData);
            return;
          }
        }
      }]);

      return MoreModalPage;
    }();

    MoreModalPage.ctorParameters = function () {
      return [{
        type: src_app_services_dummy_service__WEBPACK_IMPORTED_MODULE_2__["DummyService"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ModalController"]
      }];
    };

    MoreModalPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-more-modal',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./more-modal.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/more-modal/more-modal.page.html"))["default"],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./more-modal.page.scss */
      "./src/app/pages/more-modal/more-modal.page.scss"))["default"]]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [src_app_services_dummy_service__WEBPACK_IMPORTED_MODULE_2__["DummyService"], _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ModalController"]])], MoreModalPage);
    /***/
  },

  /***/
  "./src/app/pages/movie-cat/movie-cat-routing.module.ts":
  /*!*************************************************************!*\
    !*** ./src/app/pages/movie-cat/movie-cat-routing.module.ts ***!
    \*************************************************************/

  /*! exports provided: MovieCatPageRoutingModule */

  /***/
  function srcAppPagesMovieCatMovieCatRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "MovieCatPageRoutingModule", function () {
      return MovieCatPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _movie_cat_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./movie-cat.page */
    "./src/app/pages/movie-cat/movie-cat.page.ts");

    var routes = [{
      path: '',
      component: _movie_cat_page__WEBPACK_IMPORTED_MODULE_3__["MovieCatPage"]
    }];

    var MovieCatPageRoutingModule = function MovieCatPageRoutingModule() {
      _classCallCheck(this, MovieCatPageRoutingModule);
    };

    MovieCatPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], MovieCatPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/pages/movie-cat/movie-cat.module.ts":
  /*!*****************************************************!*\
    !*** ./src/app/pages/movie-cat/movie-cat.module.ts ***!
    \*****************************************************/

  /*! exports provided: MovieCatPageModule */

  /***/
  function srcAppPagesMovieCatMovieCatModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "MovieCatPageModule", function () {
      return MovieCatPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _movie_cat_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./movie-cat-routing.module */
    "./src/app/pages/movie-cat/movie-cat-routing.module.ts");
    /* harmony import */


    var _movie_cat_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./movie-cat.page */
    "./src/app/pages/movie-cat/movie-cat.page.ts");

    var MovieCatPageModule = function MovieCatPageModule() {
      _classCallCheck(this, MovieCatPageModule);
    };

    MovieCatPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _movie_cat_routing_module__WEBPACK_IMPORTED_MODULE_5__["MovieCatPageRoutingModule"]],
      declarations: [_movie_cat_page__WEBPACK_IMPORTED_MODULE_6__["MovieCatPage"]]
    })], MovieCatPageModule);
    /***/
  },

  /***/
  "./src/app/pages/movie-cat/movie-cat.page.scss":
  /*!*****************************************************!*\
    !*** ./src/app/pages/movie-cat/movie-cat.page.scss ***!
    \*****************************************************/

  /*! exports provided: default */

  /***/
  function srcAppPagesMovieCatMovieCatPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".head_lbl {\n  font-weight: bold;\n  font-size: 22px;\n}\n\nion-button {\n  position: absolute;\n  top: 20px;\n  right: 20px;\n  color: white;\n}\n\nion-button ion-icon {\n  font-size: 28px;\n}\n\nion-label {\n  display: block;\n  text-align: center;\n  color: white;\n  margin-top: 30px;\n  margin-bottom: 30px;\n  font-weight: 500;\n}\n\n.abs_div {\n  padding-top: 60px;\n  height: 90vh;\n  overflow: scroll;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvbW92aWUtY2F0L0U6XFxJb25pYyBQcm9qZWN0c1xcaW9uaWMtNS10ZW1wbGF0ZS1idW5kbGUtaW9uaWMtNS10aGVtZXMtYnVuZGxlcy1pb25pYy01LXRlbXBsYXRlcy13aXRoLTEwLWFwcHNcXEFwcF9zb3VyY2VfY29kZVxcQXBwc19jb2RlXFxNdWx0aV9wdXJwb3NlL3NyY1xcYXBwXFxwYWdlc1xcbW92aWUtY2F0XFxtb3ZpZS1jYXQucGFnZS5zY3NzIiwic3JjL2FwcC9wYWdlcy9tb3ZpZS1jYXQvbW92aWUtY2F0LnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGlCQUFBO0VBQ0EsZUFBQTtBQ0NKOztBREVBO0VBQ0ksa0JBQUE7RUFDQSxTQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7QUNDSjs7QURDSTtFQUNJLGVBQUE7QUNDUjs7QURHQTtFQUNJLGNBQUE7RUFDQSxrQkFBQTtFQUNBLFlBQUE7RUFDQSxnQkFBQTtFQUNBLG1CQUFBO0VBQ0EsZ0JBQUE7QUNBSjs7QURHQTtFQUNJLGlCQUFBO0VBQ0EsWUFBQTtFQUNBLGdCQUFBO0FDQUoiLCJmaWxlIjoic3JjL2FwcC9wYWdlcy9tb3ZpZS1jYXQvbW92aWUtY2F0LnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5oZWFkX2xibHtcbiAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICBmb250LXNpemU6IDIycHg7XG59XG5cbmlvbi1idXR0b257XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgIHRvcDogMjBweDtcbiAgICByaWdodDogMjBweDtcbiAgICBjb2xvcjogd2hpdGU7XG5cbiAgICBpb24taWNvbntcbiAgICAgICAgZm9udC1zaXplOiAyOHB4O1xuICAgIH1cbn1cblxuaW9uLWxhYmVse1xuICAgIGRpc3BsYXk6IGJsb2NrO1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBjb2xvcjogd2hpdGU7XG4gICAgbWFyZ2luLXRvcDogMzBweDtcbiAgICBtYXJnaW4tYm90dG9tOiAzMHB4O1xuICAgIGZvbnQtd2VpZ2h0OiA1MDA7XG59XG5cbi5hYnNfZGl2e1xuICAgIHBhZGRpbmctdG9wOiA2MHB4O1xuICAgIGhlaWdodDogOTB2aDtcbiAgICBvdmVyZmxvdzogc2Nyb2xsO1xufSIsIi5oZWFkX2xibCB7XG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xuICBmb250LXNpemU6IDIycHg7XG59XG5cbmlvbi1idXR0b24ge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHRvcDogMjBweDtcbiAgcmlnaHQ6IDIwcHg7XG4gIGNvbG9yOiB3aGl0ZTtcbn1cbmlvbi1idXR0b24gaW9uLWljb24ge1xuICBmb250LXNpemU6IDI4cHg7XG59XG5cbmlvbi1sYWJlbCB7XG4gIGRpc3BsYXk6IGJsb2NrO1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIGNvbG9yOiB3aGl0ZTtcbiAgbWFyZ2luLXRvcDogMzBweDtcbiAgbWFyZ2luLWJvdHRvbTogMzBweDtcbiAgZm9udC13ZWlnaHQ6IDUwMDtcbn1cblxuLmFic19kaXYge1xuICBwYWRkaW5nLXRvcDogNjBweDtcbiAgaGVpZ2h0OiA5MHZoO1xuICBvdmVyZmxvdzogc2Nyb2xsO1xufSJdfQ== */";
    /***/
  },

  /***/
  "./src/app/pages/movie-cat/movie-cat.page.ts":
  /*!***************************************************!*\
    !*** ./src/app/pages/movie-cat/movie-cat.page.ts ***!
    \***************************************************/

  /*! exports provided: MovieCatPage */

  /***/
  function srcAppPagesMovieCatMovieCatPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "MovieCatPage", function () {
      return MovieCatPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");

    var MovieCatPage = /*#__PURE__*/function () {
      function MovieCatPage(modalCtrl) {
        _classCallCheck(this, MovieCatPage);

        this.modalCtrl = modalCtrl;
        this.allGenres = ['All', 'Movies', 'TV Shows'];
      }

      _createClass(MovieCatPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }, {
        key: "close",
        value: function close() {
          this.modalCtrl.dismiss();
        }
      }]);

      return MovieCatPage;
    }();

    MovieCatPage.ctorParameters = function () {
      return [{
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"]
      }];
    };

    MovieCatPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-movie-cat',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./movie-cat.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/movie-cat/movie-cat.page.html"))["default"],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./movie-cat.page.scss */
      "./src/app/pages/movie-cat/movie-cat.page.scss"))["default"]]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"]])], MovieCatPage);
    /***/
  },

  /***/
  "./src/app/pages/movie-ganres/movie-ganres-routing.module.ts":
  /*!*******************************************************************!*\
    !*** ./src/app/pages/movie-ganres/movie-ganres-routing.module.ts ***!
    \*******************************************************************/

  /*! exports provided: MovieGanresPageRoutingModule */

  /***/
  function srcAppPagesMovieGanresMovieGanresRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "MovieGanresPageRoutingModule", function () {
      return MovieGanresPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _movie_ganres_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./movie-ganres.page */
    "./src/app/pages/movie-ganres/movie-ganres.page.ts");

    var routes = [{
      path: '',
      component: _movie_ganres_page__WEBPACK_IMPORTED_MODULE_3__["MovieGanresPage"]
    }];

    var MovieGanresPageRoutingModule = function MovieGanresPageRoutingModule() {
      _classCallCheck(this, MovieGanresPageRoutingModule);
    };

    MovieGanresPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], MovieGanresPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/pages/movie-ganres/movie-ganres.module.ts":
  /*!***********************************************************!*\
    !*** ./src/app/pages/movie-ganres/movie-ganres.module.ts ***!
    \***********************************************************/

  /*! exports provided: MovieGanresPageModule */

  /***/
  function srcAppPagesMovieGanresMovieGanresModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "MovieGanresPageModule", function () {
      return MovieGanresPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _movie_ganres_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./movie-ganres-routing.module */
    "./src/app/pages/movie-ganres/movie-ganres-routing.module.ts");
    /* harmony import */


    var _movie_ganres_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./movie-ganres.page */
    "./src/app/pages/movie-ganres/movie-ganres.page.ts");

    var MovieGanresPageModule = function MovieGanresPageModule() {
      _classCallCheck(this, MovieGanresPageModule);
    };

    MovieGanresPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _movie_ganres_routing_module__WEBPACK_IMPORTED_MODULE_5__["MovieGanresPageRoutingModule"]],
      declarations: [_movie_ganres_page__WEBPACK_IMPORTED_MODULE_6__["MovieGanresPage"]]
    })], MovieGanresPageModule);
    /***/
  },

  /***/
  "./src/app/pages/movie-ganres/movie-ganres.page.scss":
  /*!***********************************************************!*\
    !*** ./src/app/pages/movie-ganres/movie-ganres.page.scss ***!
    \***********************************************************/

  /*! exports provided: default */

  /***/
  function srcAppPagesMovieGanresMovieGanresPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".head_lbl {\n  font-weight: bold;\n  font-size: 22px;\n}\n\nion-button {\n  position: absolute;\n  top: 20px;\n  right: 20px;\n  color: white;\n}\n\nion-button ion-icon {\n  font-size: 28px;\n}\n\nion-label {\n  display: block;\n  text-align: center;\n  color: white;\n  margin-top: 30px;\n  margin-bottom: 30px;\n}\n\n.abs_div {\n  padding-top: 60px;\n  height: 90vh;\n  overflow: scroll;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvbW92aWUtZ2FucmVzL0U6XFxJb25pYyBQcm9qZWN0c1xcaW9uaWMtNS10ZW1wbGF0ZS1idW5kbGUtaW9uaWMtNS10aGVtZXMtYnVuZGxlcy1pb25pYy01LXRlbXBsYXRlcy13aXRoLTEwLWFwcHNcXEFwcF9zb3VyY2VfY29kZVxcQXBwc19jb2RlXFxNdWx0aV9wdXJwb3NlL3NyY1xcYXBwXFxwYWdlc1xcbW92aWUtZ2FucmVzXFxtb3ZpZS1nYW5yZXMucGFnZS5zY3NzIiwic3JjL2FwcC9wYWdlcy9tb3ZpZS1nYW5yZXMvbW92aWUtZ2FucmVzLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGlCQUFBO0VBQ0EsZUFBQTtBQ0NKOztBREVBO0VBQ0ksa0JBQUE7RUFDQSxTQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7QUNDSjs7QURDSTtFQUNJLGVBQUE7QUNDUjs7QURHQTtFQUNJLGNBQUE7RUFDQSxrQkFBQTtFQUNBLFlBQUE7RUFDQSxnQkFBQTtFQUNBLG1CQUFBO0FDQUo7O0FER0E7RUFDSSxpQkFBQTtFQUNBLFlBQUE7RUFDQSxnQkFBQTtBQ0FKIiwiZmlsZSI6InNyYy9hcHAvcGFnZXMvbW92aWUtZ2FucmVzL21vdmllLWdhbnJlcy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuaGVhZF9sYmx7XG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgZm9udC1zaXplOiAyMnB4O1xufVxuXG5pb24tYnV0dG9ue1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICB0b3A6IDIwcHg7XG4gICAgcmlnaHQ6IDIwcHg7XG4gICAgY29sb3I6IHdoaXRlO1xuXG4gICAgaW9uLWljb257XG4gICAgICAgIGZvbnQtc2l6ZTogMjhweDtcbiAgICB9XG59XG5cbmlvbi1sYWJlbHtcbiAgICBkaXNwbGF5OiBibG9jaztcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgY29sb3I6IHdoaXRlO1xuICAgIG1hcmdpbi10b3A6IDMwcHg7XG4gICAgbWFyZ2luLWJvdHRvbTogMzBweDtcbn1cblxuLmFic19kaXZ7XG4gICAgcGFkZGluZy10b3A6IDYwcHg7XG4gICAgaGVpZ2h0OiA5MHZoO1xuICAgIG92ZXJmbG93OiBzY3JvbGw7XG59IiwiLmhlYWRfbGJsIHtcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gIGZvbnQtc2l6ZTogMjJweDtcbn1cblxuaW9uLWJ1dHRvbiB7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgdG9wOiAyMHB4O1xuICByaWdodDogMjBweDtcbiAgY29sb3I6IHdoaXRlO1xufVxuaW9uLWJ1dHRvbiBpb24taWNvbiB7XG4gIGZvbnQtc2l6ZTogMjhweDtcbn1cblxuaW9uLWxhYmVsIHtcbiAgZGlzcGxheTogYmxvY2s7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgY29sb3I6IHdoaXRlO1xuICBtYXJnaW4tdG9wOiAzMHB4O1xuICBtYXJnaW4tYm90dG9tOiAzMHB4O1xufVxuXG4uYWJzX2RpdiB7XG4gIHBhZGRpbmctdG9wOiA2MHB4O1xuICBoZWlnaHQ6IDkwdmg7XG4gIG92ZXJmbG93OiBzY3JvbGw7XG59Il19 */";
    /***/
  },

  /***/
  "./src/app/pages/movie-ganres/movie-ganres.page.ts":
  /*!*********************************************************!*\
    !*** ./src/app/pages/movie-ganres/movie-ganres.page.ts ***!
    \*********************************************************/

  /*! exports provided: MovieGanresPage */

  /***/
  function srcAppPagesMovieGanresMovieGanresPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "MovieGanresPage", function () {
      return MovieGanresPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");

    var MovieGanresPage = /*#__PURE__*/function () {
      function MovieGanresPage(modalCtrl) {
        _classCallCheck(this, MovieGanresPage);

        this.modalCtrl = modalCtrl;
        this.allGenres = ['Action & Advanture', 'Amination', 'Comedy', 'Crime', 'Drama', 'Fantasy', 'History', 'Horror', 'Kids & Family', 'Music & Musical', 'Mystery & Thriller', 'Romance', 'Science & Fiction', 'Sports & Fitness', 'War & Military', 'Western'];
      }

      _createClass(MovieGanresPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }, {
        key: "close",
        value: function close() {
          this.modalCtrl.dismiss();
        }
      }]);

      return MovieGanresPage;
    }();

    MovieGanresPage.ctorParameters = function () {
      return [{
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"]
      }];
    };

    MovieGanresPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-movie-ganres',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./movie-ganres.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/movie-ganres/movie-ganres.page.html"))["default"],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./movie-ganres.page.scss */
      "./src/app/pages/movie-ganres/movie-ganres.page.scss"))["default"]]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"]])], MovieGanresPage);
    /***/
  },

  /***/
  "./src/app/pages/movie-lang/movie-lang-routing.module.ts":
  /*!***************************************************************!*\
    !*** ./src/app/pages/movie-lang/movie-lang-routing.module.ts ***!
    \***************************************************************/

  /*! exports provided: MovieLangPageRoutingModule */

  /***/
  function srcAppPagesMovieLangMovieLangRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "MovieLangPageRoutingModule", function () {
      return MovieLangPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _movie_lang_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./movie-lang.page */
    "./src/app/pages/movie-lang/movie-lang.page.ts");

    var routes = [{
      path: '',
      component: _movie_lang_page__WEBPACK_IMPORTED_MODULE_3__["MovieLangPage"]
    }];

    var MovieLangPageRoutingModule = function MovieLangPageRoutingModule() {
      _classCallCheck(this, MovieLangPageRoutingModule);
    };

    MovieLangPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], MovieLangPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/pages/movie-lang/movie-lang.module.ts":
  /*!*******************************************************!*\
    !*** ./src/app/pages/movie-lang/movie-lang.module.ts ***!
    \*******************************************************/

  /*! exports provided: MovieLangPageModule */

  /***/
  function srcAppPagesMovieLangMovieLangModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "MovieLangPageModule", function () {
      return MovieLangPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _movie_lang_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./movie-lang-routing.module */
    "./src/app/pages/movie-lang/movie-lang-routing.module.ts");
    /* harmony import */


    var _movie_lang_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./movie-lang.page */
    "./src/app/pages/movie-lang/movie-lang.page.ts");

    var MovieLangPageModule = function MovieLangPageModule() {
      _classCallCheck(this, MovieLangPageModule);
    };

    MovieLangPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _movie_lang_routing_module__WEBPACK_IMPORTED_MODULE_5__["MovieLangPageRoutingModule"]],
      declarations: [_movie_lang_page__WEBPACK_IMPORTED_MODULE_6__["MovieLangPage"]]
    })], MovieLangPageModule);
    /***/
  },

  /***/
  "./src/app/pages/movie-lang/movie-lang.page.scss":
  /*!*******************************************************!*\
    !*** ./src/app/pages/movie-lang/movie-lang.page.scss ***!
    \*******************************************************/

  /*! exports provided: default */

  /***/
  function srcAppPagesMovieLangMovieLangPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".head_lbl {\n  font-weight: bold;\n  font-size: 22px;\n}\n\nion-button {\n  position: absolute;\n  top: 20px;\n  right: 20px;\n  color: white;\n}\n\nion-button ion-icon {\n  font-size: 28px;\n}\n\nion-label {\n  display: block;\n  text-align: center;\n  color: white;\n  margin-top: 30px;\n  margin-bottom: 30px;\n  font-weight: 500;\n}\n\n.abs_div {\n  padding-top: 60px;\n  height: 90vh;\n  overflow: scroll;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvbW92aWUtbGFuZy9FOlxcSW9uaWMgUHJvamVjdHNcXGlvbmljLTUtdGVtcGxhdGUtYnVuZGxlLWlvbmljLTUtdGhlbWVzLWJ1bmRsZXMtaW9uaWMtNS10ZW1wbGF0ZXMtd2l0aC0xMC1hcHBzXFxBcHBfc291cmNlX2NvZGVcXEFwcHNfY29kZVxcTXVsdGlfcHVycG9zZS9zcmNcXGFwcFxccGFnZXNcXG1vdmllLWxhbmdcXG1vdmllLWxhbmcucGFnZS5zY3NzIiwic3JjL2FwcC9wYWdlcy9tb3ZpZS1sYW5nL21vdmllLWxhbmcucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksaUJBQUE7RUFDQSxlQUFBO0FDQ0o7O0FERUE7RUFDSSxrQkFBQTtFQUNBLFNBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtBQ0NKOztBRENJO0VBQ0ksZUFBQTtBQ0NSOztBREdBO0VBQ0ksY0FBQTtFQUNBLGtCQUFBO0VBQ0EsWUFBQTtFQUNBLGdCQUFBO0VBQ0EsbUJBQUE7RUFDQSxnQkFBQTtBQ0FKOztBREdBO0VBQ0ksaUJBQUE7RUFDQSxZQUFBO0VBQ0EsZ0JBQUE7QUNBSiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL21vdmllLWxhbmcvbW92aWUtbGFuZy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuaGVhZF9sYmx7XG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgZm9udC1zaXplOiAyMnB4O1xufVxuXG5pb24tYnV0dG9ue1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICB0b3A6IDIwcHg7XG4gICAgcmlnaHQ6IDIwcHg7XG4gICAgY29sb3I6IHdoaXRlO1xuXG4gICAgaW9uLWljb257XG4gICAgICAgIGZvbnQtc2l6ZTogMjhweDtcbiAgICB9XG59XG5cbmlvbi1sYWJlbHtcbiAgICBkaXNwbGF5OiBibG9jaztcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgY29sb3I6IHdoaXRlO1xuICAgIG1hcmdpbi10b3A6IDMwcHg7XG4gICAgbWFyZ2luLWJvdHRvbTogMzBweDtcbiAgICBmb250LXdlaWdodDogNTAwO1xufVxuXG4uYWJzX2RpdntcbiAgICBwYWRkaW5nLXRvcDogNjBweDtcbiAgICBoZWlnaHQ6IDkwdmg7XG4gICAgb3ZlcmZsb3c6IHNjcm9sbDtcbn0iLCIuaGVhZF9sYmwge1xuICBmb250LXdlaWdodDogYm9sZDtcbiAgZm9udC1zaXplOiAyMnB4O1xufVxuXG5pb24tYnV0dG9uIHtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICB0b3A6IDIwcHg7XG4gIHJpZ2h0OiAyMHB4O1xuICBjb2xvcjogd2hpdGU7XG59XG5pb24tYnV0dG9uIGlvbi1pY29uIHtcbiAgZm9udC1zaXplOiAyOHB4O1xufVxuXG5pb24tbGFiZWwge1xuICBkaXNwbGF5OiBibG9jaztcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBjb2xvcjogd2hpdGU7XG4gIG1hcmdpbi10b3A6IDMwcHg7XG4gIG1hcmdpbi1ib3R0b206IDMwcHg7XG4gIGZvbnQtd2VpZ2h0OiA1MDA7XG59XG5cbi5hYnNfZGl2IHtcbiAgcGFkZGluZy10b3A6IDYwcHg7XG4gIGhlaWdodDogOTB2aDtcbiAgb3ZlcmZsb3c6IHNjcm9sbDtcbn0iXX0= */";
    /***/
  },

  /***/
  "./src/app/pages/movie-lang/movie-lang.page.ts":
  /*!*****************************************************!*\
    !*** ./src/app/pages/movie-lang/movie-lang.page.ts ***!
    \*****************************************************/

  /*! exports provided: MovieLangPage */

  /***/
  function srcAppPagesMovieLangMovieLangPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "MovieLangPage", function () {
      return MovieLangPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");

    var MovieLangPage = /*#__PURE__*/function () {
      function MovieLangPage(modalCtrl) {
        _classCallCheck(this, MovieLangPage);

        this.modalCtrl = modalCtrl;
        this.lang = ['Gujrati', 'Hindi', 'English', 'Marathi', 'Panjabi', 'Nepali', 'Tamil', 'Telugu', 'Bengali', 'Urdu'];
      }

      _createClass(MovieLangPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }, {
        key: "close",
        value: function close() {
          this.modalCtrl.dismiss();
        }
      }]);

      return MovieLangPage;
    }();

    MovieLangPage.ctorParameters = function () {
      return [{
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"]
      }];
    };

    MovieLangPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-movie-lang',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./movie-lang.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/movie-lang/movie-lang.page.html"))["default"],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./movie-lang.page.scss */
      "./src/app/pages/movie-lang/movie-lang.page.scss"))["default"]]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"]])], MovieLangPage);
    /***/
  },

  /***/
  "./src/app/pages/movie-plarform/movie-plarform-routing.module.ts":
  /*!***********************************************************************!*\
    !*** ./src/app/pages/movie-plarform/movie-plarform-routing.module.ts ***!
    \***********************************************************************/

  /*! exports provided: MoviePlarformPageRoutingModule */

  /***/
  function srcAppPagesMoviePlarformMoviePlarformRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "MoviePlarformPageRoutingModule", function () {
      return MoviePlarformPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _movie_plarform_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./movie-plarform.page */
    "./src/app/pages/movie-plarform/movie-plarform.page.ts");

    var routes = [{
      path: '',
      component: _movie_plarform_page__WEBPACK_IMPORTED_MODULE_3__["MoviePlarformPage"]
    }];

    var MoviePlarformPageRoutingModule = function MoviePlarformPageRoutingModule() {
      _classCallCheck(this, MoviePlarformPageRoutingModule);
    };

    MoviePlarformPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], MoviePlarformPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/pages/movie-plarform/movie-plarform.module.ts":
  /*!***************************************************************!*\
    !*** ./src/app/pages/movie-plarform/movie-plarform.module.ts ***!
    \***************************************************************/

  /*! exports provided: MoviePlarformPageModule */

  /***/
  function srcAppPagesMoviePlarformMoviePlarformModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "MoviePlarformPageModule", function () {
      return MoviePlarformPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _movie_plarform_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./movie-plarform-routing.module */
    "./src/app/pages/movie-plarform/movie-plarform-routing.module.ts");
    /* harmony import */


    var _movie_plarform_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./movie-plarform.page */
    "./src/app/pages/movie-plarform/movie-plarform.page.ts");

    var MoviePlarformPageModule = function MoviePlarformPageModule() {
      _classCallCheck(this, MoviePlarformPageModule);
    };

    MoviePlarformPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _movie_plarform_routing_module__WEBPACK_IMPORTED_MODULE_5__["MoviePlarformPageRoutingModule"]],
      declarations: [_movie_plarform_page__WEBPACK_IMPORTED_MODULE_6__["MoviePlarformPage"]]
    })], MoviePlarformPageModule);
    /***/
  },

  /***/
  "./src/app/pages/movie-plarform/movie-plarform.page.scss":
  /*!***************************************************************!*\
    !*** ./src/app/pages/movie-plarform/movie-plarform.page.scss ***!
    \***************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppPagesMoviePlarformMoviePlarformPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".head_lbl {\n  font-weight: bold;\n  font-size: 22px;\n}\n\nion-button {\n  position: absolute;\n  top: 20px;\n  right: 20px;\n  color: white;\n}\n\nion-button ion-icon {\n  font-size: 28px;\n}\n\nion-label {\n  display: block;\n  text-align: center;\n  color: white;\n  margin-top: 30px;\n  margin-bottom: 30px;\n  font-weight: 500;\n}\n\n.abs_div {\n  padding-top: 60px;\n  height: 90vh;\n  overflow: scroll;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvbW92aWUtcGxhcmZvcm0vRTpcXElvbmljIFByb2plY3RzXFxpb25pYy01LXRlbXBsYXRlLWJ1bmRsZS1pb25pYy01LXRoZW1lcy1idW5kbGVzLWlvbmljLTUtdGVtcGxhdGVzLXdpdGgtMTAtYXBwc1xcQXBwX3NvdXJjZV9jb2RlXFxBcHBzX2NvZGVcXE11bHRpX3B1cnBvc2Uvc3JjXFxhcHBcXHBhZ2VzXFxtb3ZpZS1wbGFyZm9ybVxcbW92aWUtcGxhcmZvcm0ucGFnZS5zY3NzIiwic3JjL2FwcC9wYWdlcy9tb3ZpZS1wbGFyZm9ybS9tb3ZpZS1wbGFyZm9ybS5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxpQkFBQTtFQUNBLGVBQUE7QUNDSjs7QURFQTtFQUNJLGtCQUFBO0VBQ0EsU0FBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0FDQ0o7O0FEQ0k7RUFDSSxlQUFBO0FDQ1I7O0FER0E7RUFDSSxjQUFBO0VBQ0Esa0JBQUE7RUFDQSxZQUFBO0VBQ0EsZ0JBQUE7RUFDQSxtQkFBQTtFQUNBLGdCQUFBO0FDQUo7O0FER0E7RUFDSSxpQkFBQTtFQUNBLFlBQUE7RUFDQSxnQkFBQTtBQ0FKIiwiZmlsZSI6InNyYy9hcHAvcGFnZXMvbW92aWUtcGxhcmZvcm0vbW92aWUtcGxhcmZvcm0ucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmhlYWRfbGJse1xuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgIGZvbnQtc2l6ZTogMjJweDtcbn1cblxuaW9uLWJ1dHRvbntcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgdG9wOiAyMHB4O1xuICAgIHJpZ2h0OiAyMHB4O1xuICAgIGNvbG9yOiB3aGl0ZTtcblxuICAgIGlvbi1pY29ue1xuICAgICAgICBmb250LXNpemU6IDI4cHg7XG4gICAgfVxufVxuXG5pb24tbGFiZWx7XG4gICAgZGlzcGxheTogYmxvY2s7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIGNvbG9yOiB3aGl0ZTtcbiAgICBtYXJnaW4tdG9wOiAzMHB4O1xuICAgIG1hcmdpbi1ib3R0b206IDMwcHg7XG4gICAgZm9udC13ZWlnaHQ6IDUwMDtcbn1cblxuLmFic19kaXZ7XG4gICAgcGFkZGluZy10b3A6IDYwcHg7XG4gICAgaGVpZ2h0OiA5MHZoO1xuICAgIG92ZXJmbG93OiBzY3JvbGw7XG59IiwiLmhlYWRfbGJsIHtcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gIGZvbnQtc2l6ZTogMjJweDtcbn1cblxuaW9uLWJ1dHRvbiB7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgdG9wOiAyMHB4O1xuICByaWdodDogMjBweDtcbiAgY29sb3I6IHdoaXRlO1xufVxuaW9uLWJ1dHRvbiBpb24taWNvbiB7XG4gIGZvbnQtc2l6ZTogMjhweDtcbn1cblxuaW9uLWxhYmVsIHtcbiAgZGlzcGxheTogYmxvY2s7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgY29sb3I6IHdoaXRlO1xuICBtYXJnaW4tdG9wOiAzMHB4O1xuICBtYXJnaW4tYm90dG9tOiAzMHB4O1xuICBmb250LXdlaWdodDogNTAwO1xufVxuXG4uYWJzX2RpdiB7XG4gIHBhZGRpbmctdG9wOiA2MHB4O1xuICBoZWlnaHQ6IDkwdmg7XG4gIG92ZXJmbG93OiBzY3JvbGw7XG59Il19 */";
    /***/
  },

  /***/
  "./src/app/pages/movie-plarform/movie-plarform.page.ts":
  /*!*************************************************************!*\
    !*** ./src/app/pages/movie-plarform/movie-plarform.page.ts ***!
    \*************************************************************/

  /*! exports provided: MoviePlarformPage */

  /***/
  function srcAppPagesMoviePlarformMoviePlarformPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "MoviePlarformPage", function () {
      return MoviePlarformPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");

    var MoviePlarformPage = /*#__PURE__*/function () {
      function MoviePlarformPage(modalCtrl) {
        _classCallCheck(this, MoviePlarformPage);

        this.modalCtrl = modalCtrl;
        this.platform = ['Airtel Movies', 'Alt Balaji', 'Amazon Prime Video', 'Apple TV Plus', 'Aplle iTunes', 'Eros Now', 'Google Play Movies', 'Guide Doc', 'Hotstar', 'Jio Cinema', 'Netflix', 'Sony Liv', 'Voot', 'Youtube', 'Zee5'];
      }

      _createClass(MoviePlarformPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }, {
        key: "close",
        value: function close() {
          this.modalCtrl.dismiss();
        }
      }]);

      return MoviePlarformPage;
    }();

    MoviePlarformPage.ctorParameters = function () {
      return [{
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"]
      }];
    };

    MoviePlarformPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-movie-plarform',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./movie-plarform.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/movie-plarform/movie-plarform.page.html"))["default"],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./movie-plarform.page.scss */
      "./src/app/pages/movie-plarform/movie-plarform.page.scss"))["default"]]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"]])], MoviePlarformPage);
    /***/
  },

  /***/
  "./src/app/pages/movie-rating/movie-rating-routing.module.ts":
  /*!*******************************************************************!*\
    !*** ./src/app/pages/movie-rating/movie-rating-routing.module.ts ***!
    \*******************************************************************/

  /*! exports provided: MovieRatingPageRoutingModule */

  /***/
  function srcAppPagesMovieRatingMovieRatingRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "MovieRatingPageRoutingModule", function () {
      return MovieRatingPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _movie_rating_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./movie-rating.page */
    "./src/app/pages/movie-rating/movie-rating.page.ts");

    var routes = [{
      path: '',
      component: _movie_rating_page__WEBPACK_IMPORTED_MODULE_3__["MovieRatingPage"]
    }];

    var MovieRatingPageRoutingModule = function MovieRatingPageRoutingModule() {
      _classCallCheck(this, MovieRatingPageRoutingModule);
    };

    MovieRatingPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], MovieRatingPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/pages/movie-rating/movie-rating.module.ts":
  /*!***********************************************************!*\
    !*** ./src/app/pages/movie-rating/movie-rating.module.ts ***!
    \***********************************************************/

  /*! exports provided: MovieRatingPageModule */

  /***/
  function srcAppPagesMovieRatingMovieRatingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "MovieRatingPageModule", function () {
      return MovieRatingPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _movie_rating_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./movie-rating-routing.module */
    "./src/app/pages/movie-rating/movie-rating-routing.module.ts");
    /* harmony import */


    var _movie_rating_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./movie-rating.page */
    "./src/app/pages/movie-rating/movie-rating.page.ts");

    var MovieRatingPageModule = function MovieRatingPageModule() {
      _classCallCheck(this, MovieRatingPageModule);
    };

    MovieRatingPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _movie_rating_routing_module__WEBPACK_IMPORTED_MODULE_5__["MovieRatingPageRoutingModule"]],
      declarations: [_movie_rating_page__WEBPACK_IMPORTED_MODULE_6__["MovieRatingPage"]]
    })], MovieRatingPageModule);
    /***/
  },

  /***/
  "./src/app/pages/movie-rating/movie-rating.page.scss":
  /*!***********************************************************!*\
    !*** ./src/app/pages/movie-rating/movie-rating.page.scss ***!
    \***********************************************************/

  /*! exports provided: default */

  /***/
  function srcAppPagesMovieRatingMovieRatingPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".head_lbl {\n  font-weight: bold;\n  font-size: 22px;\n}\n\nion-button {\n  position: absolute;\n  top: 20px;\n  right: 20px;\n  color: white;\n}\n\nion-button ion-icon {\n  font-size: 28px;\n}\n\nion-label {\n  display: block;\n  text-align: center;\n  color: white;\n  margin-top: 30px;\n  margin-bottom: 30px;\n  font-weight: 500;\n}\n\n.abs_div {\n  padding-top: 60px;\n  height: 90vh;\n  overflow: scroll;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvbW92aWUtcmF0aW5nL0U6XFxJb25pYyBQcm9qZWN0c1xcaW9uaWMtNS10ZW1wbGF0ZS1idW5kbGUtaW9uaWMtNS10aGVtZXMtYnVuZGxlcy1pb25pYy01LXRlbXBsYXRlcy13aXRoLTEwLWFwcHNcXEFwcF9zb3VyY2VfY29kZVxcQXBwc19jb2RlXFxNdWx0aV9wdXJwb3NlL3NyY1xcYXBwXFxwYWdlc1xcbW92aWUtcmF0aW5nXFxtb3ZpZS1yYXRpbmcucGFnZS5zY3NzIiwic3JjL2FwcC9wYWdlcy9tb3ZpZS1yYXRpbmcvbW92aWUtcmF0aW5nLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGlCQUFBO0VBQ0EsZUFBQTtBQ0NKOztBREVBO0VBQ0ksa0JBQUE7RUFDQSxTQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7QUNDSjs7QURDSTtFQUNJLGVBQUE7QUNDUjs7QURHQTtFQUNJLGNBQUE7RUFDQSxrQkFBQTtFQUNBLFlBQUE7RUFDQSxnQkFBQTtFQUNBLG1CQUFBO0VBQ0EsZ0JBQUE7QUNBSjs7QURHQTtFQUNJLGlCQUFBO0VBQ0EsWUFBQTtFQUNBLGdCQUFBO0FDQUoiLCJmaWxlIjoic3JjL2FwcC9wYWdlcy9tb3ZpZS1yYXRpbmcvbW92aWUtcmF0aW5nLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5oZWFkX2xibHtcbiAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICBmb250LXNpemU6IDIycHg7XG59XG5cbmlvbi1idXR0b257XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgIHRvcDogMjBweDtcbiAgICByaWdodDogMjBweDtcbiAgICBjb2xvcjogd2hpdGU7XG5cbiAgICBpb24taWNvbntcbiAgICAgICAgZm9udC1zaXplOiAyOHB4O1xuICAgIH1cbn1cblxuaW9uLWxhYmVse1xuICAgIGRpc3BsYXk6IGJsb2NrO1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBjb2xvcjogd2hpdGU7XG4gICAgbWFyZ2luLXRvcDogMzBweDtcbiAgICBtYXJnaW4tYm90dG9tOiAzMHB4O1xuICAgIGZvbnQtd2VpZ2h0OiA1MDA7XG59XG5cbi5hYnNfZGl2e1xuICAgIHBhZGRpbmctdG9wOiA2MHB4O1xuICAgIGhlaWdodDogOTB2aDtcbiAgICBvdmVyZmxvdzogc2Nyb2xsO1xufSIsIi5oZWFkX2xibCB7XG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xuICBmb250LXNpemU6IDIycHg7XG59XG5cbmlvbi1idXR0b24ge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHRvcDogMjBweDtcbiAgcmlnaHQ6IDIwcHg7XG4gIGNvbG9yOiB3aGl0ZTtcbn1cbmlvbi1idXR0b24gaW9uLWljb24ge1xuICBmb250LXNpemU6IDI4cHg7XG59XG5cbmlvbi1sYWJlbCB7XG4gIGRpc3BsYXk6IGJsb2NrO1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIGNvbG9yOiB3aGl0ZTtcbiAgbWFyZ2luLXRvcDogMzBweDtcbiAgbWFyZ2luLWJvdHRvbTogMzBweDtcbiAgZm9udC13ZWlnaHQ6IDUwMDtcbn1cblxuLmFic19kaXYge1xuICBwYWRkaW5nLXRvcDogNjBweDtcbiAgaGVpZ2h0OiA5MHZoO1xuICBvdmVyZmxvdzogc2Nyb2xsO1xufSJdfQ== */";
    /***/
  },

  /***/
  "./src/app/pages/movie-rating/movie-rating.page.ts":
  /*!*********************************************************!*\
    !*** ./src/app/pages/movie-rating/movie-rating.page.ts ***!
    \*********************************************************/

  /*! exports provided: MovieRatingPage */

  /***/
  function srcAppPagesMovieRatingMovieRatingPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "MovieRatingPage", function () {
      return MovieRatingPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");

    var MovieRatingPage = /*#__PURE__*/function () {
      function MovieRatingPage(modalCtrl) {
        _classCallCheck(this, MovieRatingPage);

        this.modalCtrl = modalCtrl;
        this.rating = ['Popular', 'Highest to Lowest', '90% and above', '80% and above', '70% and above', '60% and above', '50% and above', 'Bolow 50%', 'Any'];
      }

      _createClass(MovieRatingPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }, {
        key: "close",
        value: function close() {
          this.modalCtrl.dismiss();
        }
      }]);

      return MovieRatingPage;
    }();

    MovieRatingPage.ctorParameters = function () {
      return [{
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"]
      }];
    };

    MovieRatingPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-movie-rating',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./movie-rating.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/movie-rating/movie-rating.page.html"))["default"],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./movie-rating.page.scss */
      "./src/app/pages/movie-rating/movie-rating.page.scss"))["default"]]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"]])], MovieRatingPage);
    /***/
  },

  /***/
  "./src/app/pages/movie-year/movie-year-routing.module.ts":
  /*!***************************************************************!*\
    !*** ./src/app/pages/movie-year/movie-year-routing.module.ts ***!
    \***************************************************************/

  /*! exports provided: MovieYearPageRoutingModule */

  /***/
  function srcAppPagesMovieYearMovieYearRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "MovieYearPageRoutingModule", function () {
      return MovieYearPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _movie_year_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./movie-year.page */
    "./src/app/pages/movie-year/movie-year.page.ts");

    var routes = [{
      path: '',
      component: _movie_year_page__WEBPACK_IMPORTED_MODULE_3__["MovieYearPage"]
    }];

    var MovieYearPageRoutingModule = function MovieYearPageRoutingModule() {
      _classCallCheck(this, MovieYearPageRoutingModule);
    };

    MovieYearPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], MovieYearPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/pages/movie-year/movie-year.module.ts":
  /*!*******************************************************!*\
    !*** ./src/app/pages/movie-year/movie-year.module.ts ***!
    \*******************************************************/

  /*! exports provided: MovieYearPageModule */

  /***/
  function srcAppPagesMovieYearMovieYearModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "MovieYearPageModule", function () {
      return MovieYearPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _movie_year_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./movie-year-routing.module */
    "./src/app/pages/movie-year/movie-year-routing.module.ts");
    /* harmony import */


    var _movie_year_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./movie-year.page */
    "./src/app/pages/movie-year/movie-year.page.ts");

    var MovieYearPageModule = function MovieYearPageModule() {
      _classCallCheck(this, MovieYearPageModule);
    };

    MovieYearPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _movie_year_routing_module__WEBPACK_IMPORTED_MODULE_5__["MovieYearPageRoutingModule"]],
      declarations: [_movie_year_page__WEBPACK_IMPORTED_MODULE_6__["MovieYearPage"]]
    })], MovieYearPageModule);
    /***/
  },

  /***/
  "./src/app/pages/movie-year/movie-year.page.scss":
  /*!*******************************************************!*\
    !*** ./src/app/pages/movie-year/movie-year.page.scss ***!
    \*******************************************************/

  /*! exports provided: default */

  /***/
  function srcAppPagesMovieYearMovieYearPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".head_lbl {\n  font-weight: bold;\n  font-size: 22px;\n}\n\nion-button {\n  position: absolute;\n  top: 20px;\n  right: 20px;\n  color: white;\n}\n\nion-button ion-icon {\n  font-size: 28px;\n}\n\nion-label {\n  display: block;\n  text-align: center;\n  color: white;\n  margin-top: 30px;\n  margin-bottom: 30px;\n  font-weight: 600;\n}\n\n.abs_div {\n  padding-top: 60px;\n  height: 90vh;\n  overflow: scroll;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvbW92aWUteWVhci9FOlxcSW9uaWMgUHJvamVjdHNcXGlvbmljLTUtdGVtcGxhdGUtYnVuZGxlLWlvbmljLTUtdGhlbWVzLWJ1bmRsZXMtaW9uaWMtNS10ZW1wbGF0ZXMtd2l0aC0xMC1hcHBzXFxBcHBfc291cmNlX2NvZGVcXEFwcHNfY29kZVxcTXVsdGlfcHVycG9zZS9zcmNcXGFwcFxccGFnZXNcXG1vdmllLXllYXJcXG1vdmllLXllYXIucGFnZS5zY3NzIiwic3JjL2FwcC9wYWdlcy9tb3ZpZS15ZWFyL21vdmllLXllYXIucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksaUJBQUE7RUFDQSxlQUFBO0FDQ0o7O0FERUE7RUFDSSxrQkFBQTtFQUNBLFNBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtBQ0NKOztBRENJO0VBQ0ksZUFBQTtBQ0NSOztBREdBO0VBQ0ksY0FBQTtFQUNBLGtCQUFBO0VBQ0EsWUFBQTtFQUNBLGdCQUFBO0VBQ0EsbUJBQUE7RUFDQSxnQkFBQTtBQ0FKOztBREdBO0VBQ0ksaUJBQUE7RUFDQSxZQUFBO0VBQ0EsZ0JBQUE7QUNBSiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL21vdmllLXllYXIvbW92aWUteWVhci5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuaGVhZF9sYmx7XG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgZm9udC1zaXplOiAyMnB4O1xufVxuXG5pb24tYnV0dG9ue1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICB0b3A6IDIwcHg7XG4gICAgcmlnaHQ6IDIwcHg7XG4gICAgY29sb3I6IHdoaXRlO1xuXG4gICAgaW9uLWljb257XG4gICAgICAgIGZvbnQtc2l6ZTogMjhweDtcbiAgICB9XG59XG5cbmlvbi1sYWJlbHtcbiAgICBkaXNwbGF5OiBibG9jaztcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgY29sb3I6IHdoaXRlO1xuICAgIG1hcmdpbi10b3A6IDMwcHg7XG4gICAgbWFyZ2luLWJvdHRvbTogMzBweDtcbiAgICBmb250LXdlaWdodDogNjAwO1xufVxuXG4uYWJzX2RpdntcbiAgICBwYWRkaW5nLXRvcDogNjBweDtcbiAgICBoZWlnaHQ6IDkwdmg7XG4gICAgb3ZlcmZsb3c6IHNjcm9sbDtcbn0iLCIuaGVhZF9sYmwge1xuICBmb250LXdlaWdodDogYm9sZDtcbiAgZm9udC1zaXplOiAyMnB4O1xufVxuXG5pb24tYnV0dG9uIHtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICB0b3A6IDIwcHg7XG4gIHJpZ2h0OiAyMHB4O1xuICBjb2xvcjogd2hpdGU7XG59XG5pb24tYnV0dG9uIGlvbi1pY29uIHtcbiAgZm9udC1zaXplOiAyOHB4O1xufVxuXG5pb24tbGFiZWwge1xuICBkaXNwbGF5OiBibG9jaztcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBjb2xvcjogd2hpdGU7XG4gIG1hcmdpbi10b3A6IDMwcHg7XG4gIG1hcmdpbi1ib3R0b206IDMwcHg7XG4gIGZvbnQtd2VpZ2h0OiA2MDA7XG59XG5cbi5hYnNfZGl2IHtcbiAgcGFkZGluZy10b3A6IDYwcHg7XG4gIGhlaWdodDogOTB2aDtcbiAgb3ZlcmZsb3c6IHNjcm9sbDtcbn0iXX0= */";
    /***/
  },

  /***/
  "./src/app/pages/movie-year/movie-year.page.ts":
  /*!*****************************************************!*\
    !*** ./src/app/pages/movie-year/movie-year.page.ts ***!
    \*****************************************************/

  /*! exports provided: MovieYearPage */

  /***/
  function srcAppPagesMovieYearMovieYearPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "MovieYearPage", function () {
      return MovieYearPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");

    var MovieYearPage = /*#__PURE__*/function () {
      function MovieYearPage(modalCtrl) {
        _classCallCheck(this, MovieYearPage);

        this.modalCtrl = modalCtrl;
        this.year = ['2020', '2019', '2018', '2017', '2016', '2015', '2014', '2013', '2012', '2011', '2010', '2009', '2008', '2007', '2006', '2005', '2004', '2003', '2002', '2001'];
      }

      _createClass(MovieYearPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }, {
        key: "close",
        value: function close() {
          this.modalCtrl.dismiss();
        }
      }]);

      return MovieYearPage;
    }();

    MovieYearPage.ctorParameters = function () {
      return [{
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"]
      }];
    };

    MovieYearPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-movie-year',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./movie-year.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/movie-year/movie-year.page.html"))["default"],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./movie-year.page.scss */
      "./src/app/pages/movie-year/movie-year.page.scss"))["default"]]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"]])], MovieYearPage);
    /***/
  },

  /***/
  "./src/app/pages/notification-modal/notification-modal-routing.module.ts":
  /*!*******************************************************************************!*\
    !*** ./src/app/pages/notification-modal/notification-modal-routing.module.ts ***!
    \*******************************************************************************/

  /*! exports provided: NotificationModalPageRoutingModule */

  /***/
  function srcAppPagesNotificationModalNotificationModalRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "NotificationModalPageRoutingModule", function () {
      return NotificationModalPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _notification_modal_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./notification-modal.page */
    "./src/app/pages/notification-modal/notification-modal.page.ts");

    var routes = [{
      path: '',
      component: _notification_modal_page__WEBPACK_IMPORTED_MODULE_3__["NotificationModalPage"]
    }];

    var NotificationModalPageRoutingModule = function NotificationModalPageRoutingModule() {
      _classCallCheck(this, NotificationModalPageRoutingModule);
    };

    NotificationModalPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], NotificationModalPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/pages/notification-modal/notification-modal.module.ts":
  /*!***********************************************************************!*\
    !*** ./src/app/pages/notification-modal/notification-modal.module.ts ***!
    \***********************************************************************/

  /*! exports provided: NotificationModalPageModule */

  /***/
  function srcAppPagesNotificationModalNotificationModalModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "NotificationModalPageModule", function () {
      return NotificationModalPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _notification_modal_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./notification-modal-routing.module */
    "./src/app/pages/notification-modal/notification-modal-routing.module.ts");
    /* harmony import */


    var _notification_modal_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./notification-modal.page */
    "./src/app/pages/notification-modal/notification-modal.page.ts");

    var NotificationModalPageModule = function NotificationModalPageModule() {
      _classCallCheck(this, NotificationModalPageModule);
    };

    NotificationModalPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _notification_modal_routing_module__WEBPACK_IMPORTED_MODULE_5__["NotificationModalPageRoutingModule"]],
      declarations: [_notification_modal_page__WEBPACK_IMPORTED_MODULE_6__["NotificationModalPage"]]
    })], NotificationModalPageModule);
    /***/
  },

  /***/
  "./src/app/pages/notification-modal/notification-modal.page.scss":
  /*!***********************************************************************!*\
    !*** ./src/app/pages/notification-modal/notification-modal.page.scss ***!
    \***********************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppPagesNotificationModalNotificationModalPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".main_content_modal {\n  width: 100%;\n}\n.main_content_modal .white_div {\n  background: white;\n  height: 170px;\n  margin-top: 30px;\n  padding-top: 40px;\n}\n.main_content_modal .back_image {\n  width: 60px;\n  height: 60px;\n  border-radius: 100%;\n  display: block;\n  margin: auto;\n  position: absolute;\n  top: 5px;\n  left: 50%;\n  transform: translate(-50%);\n  border: 4px solid white;\n}\n.main_content_modal .lbl_div {\n  padding-left: 30px;\n  padding-right: 30px;\n  padding-bottom: 20px;\n  border-bottom: 1px solid lightgray;\n}\n.main_content_modal .lbl_div .head_lbl {\n  text-align: center;\n}\n.main_content_modal .flex_div {\n  padding: 20px;\n  display: flex;\n  align-items: center;\n  color: gray;\n}\n.main_content_modal .flex_div ion-icon {\n  font-size: 27px;\n  margin-right: 15px;\n  color: gray;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvbm90aWZpY2F0aW9uLW1vZGFsL0U6XFxJb25pYyBQcm9qZWN0c1xcaW9uaWMtNS10ZW1wbGF0ZS1idW5kbGUtaW9uaWMtNS10aGVtZXMtYnVuZGxlcy1pb25pYy01LXRlbXBsYXRlcy13aXRoLTEwLWFwcHNcXEFwcF9zb3VyY2VfY29kZVxcQXBwc19jb2RlXFxNdWx0aV9wdXJwb3NlL3NyY1xcYXBwXFxwYWdlc1xcbm90aWZpY2F0aW9uLW1vZGFsXFxub3RpZmljYXRpb24tbW9kYWwucGFnZS5zY3NzIiwic3JjL2FwcC9wYWdlcy9ub3RpZmljYXRpb24tbW9kYWwvbm90aWZpY2F0aW9uLW1vZGFsLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLFdBQUE7QUNDSjtBRENJO0VBQ0ksaUJBQUE7RUFDQSxhQUFBO0VBQ0EsZ0JBQUE7RUFDQSxpQkFBQTtBQ0NSO0FERUk7RUFDSSxXQUFBO0VBQ0EsWUFBQTtFQUNBLG1CQUFBO0VBQ0EsY0FBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLFFBQUE7RUFDQSxTQUFBO0VBQ0EsMEJBQUE7RUFDQSx1QkFBQTtBQ0FSO0FER0k7RUFDSSxrQkFBQTtFQUNBLG1CQUFBO0VBQ0Esb0JBQUE7RUFDQSxrQ0FBQTtBQ0RSO0FERVE7RUFDSSxrQkFBQTtBQ0FaO0FES0k7RUFDSSxhQUFBO0VBQ0EsYUFBQTtFQUNBLG1CQUFBO0VBQ0EsV0FBQTtBQ0hSO0FESVE7RUFDSSxlQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0FDRloiLCJmaWxlIjoic3JjL2FwcC9wYWdlcy9ub3RpZmljYXRpb24tbW9kYWwvbm90aWZpY2F0aW9uLW1vZGFsLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5tYWluX2NvbnRlbnRfbW9kYWx7XG4gICAgd2lkdGg6IDEwMCU7XG5cbiAgICAud2hpdGVfZGl2e1xuICAgICAgICBiYWNrZ3JvdW5kOiB3aGl0ZTtcbiAgICAgICAgaGVpZ2h0OiAxNzBweDtcbiAgICAgICAgbWFyZ2luLXRvcDogMzBweDtcbiAgICAgICAgcGFkZGluZy10b3A6IDQwcHg7XG4gICAgfVxuXG4gICAgLmJhY2tfaW1hZ2V7XG4gICAgICAgIHdpZHRoOiA2MHB4O1xuICAgICAgICBoZWlnaHQ6IDYwcHg7XG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDEwMCU7XG4gICAgICAgIGRpc3BsYXk6IGJsb2NrO1xuICAgICAgICBtYXJnaW46IGF1dG87XG4gICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICAgICAgdG9wOiA1cHg7XG4gICAgICAgIGxlZnQ6IDUwJTtcbiAgICAgICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUoLTUwJSk7XG4gICAgICAgIGJvcmRlcjogNHB4IHNvbGlkIHdoaXRlO1xuICAgIH1cblxuICAgIC5sYmxfZGl2e1xuICAgICAgICBwYWRkaW5nLWxlZnQ6IDMwcHg7XG4gICAgICAgIHBhZGRpbmctcmlnaHQ6IDMwcHg7XG4gICAgICAgIHBhZGRpbmctYm90dG9tOiAyMHB4O1xuICAgICAgICBib3JkZXItYm90dG9tOiAxcHggc29saWQgbGlnaHRncmF5O1xuICAgICAgICAuaGVhZF9sYmx7XG4gICAgICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgICAgICAgICBcbiAgICAgICAgfVxuICAgIH1cblxuICAgIC5mbGV4X2RpdntcbiAgICAgICAgcGFkZGluZzogMjBweDtcbiAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICAgICAgY29sb3I6IGdyYXk7XG4gICAgICAgIGlvbi1pY29ue1xuICAgICAgICAgICAgZm9udC1zaXplOiAyN3B4O1xuICAgICAgICAgICAgbWFyZ2luLXJpZ2h0OiAxNXB4O1xuICAgICAgICAgICAgY29sb3I6IGdyYXk7XG4gICAgICAgIH1cbiAgICB9XG59IiwiLm1haW5fY29udGVudF9tb2RhbCB7XG4gIHdpZHRoOiAxMDAlO1xufVxuLm1haW5fY29udGVudF9tb2RhbCAud2hpdGVfZGl2IHtcbiAgYmFja2dyb3VuZDogd2hpdGU7XG4gIGhlaWdodDogMTcwcHg7XG4gIG1hcmdpbi10b3A6IDMwcHg7XG4gIHBhZGRpbmctdG9wOiA0MHB4O1xufVxuLm1haW5fY29udGVudF9tb2RhbCAuYmFja19pbWFnZSB7XG4gIHdpZHRoOiA2MHB4O1xuICBoZWlnaHQ6IDYwcHg7XG4gIGJvcmRlci1yYWRpdXM6IDEwMCU7XG4gIGRpc3BsYXk6IGJsb2NrO1xuICBtYXJnaW46IGF1dG87XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgdG9wOiA1cHg7XG4gIGxlZnQ6IDUwJTtcbiAgdHJhbnNmb3JtOiB0cmFuc2xhdGUoLTUwJSk7XG4gIGJvcmRlcjogNHB4IHNvbGlkIHdoaXRlO1xufVxuLm1haW5fY29udGVudF9tb2RhbCAubGJsX2RpdiB7XG4gIHBhZGRpbmctbGVmdDogMzBweDtcbiAgcGFkZGluZy1yaWdodDogMzBweDtcbiAgcGFkZGluZy1ib3R0b206IDIwcHg7XG4gIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCBsaWdodGdyYXk7XG59XG4ubWFpbl9jb250ZW50X21vZGFsIC5sYmxfZGl2IC5oZWFkX2xibCB7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cbi5tYWluX2NvbnRlbnRfbW9kYWwgLmZsZXhfZGl2IHtcbiAgcGFkZGluZzogMjBweDtcbiAgZGlzcGxheTogZmxleDtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgY29sb3I6IGdyYXk7XG59XG4ubWFpbl9jb250ZW50X21vZGFsIC5mbGV4X2RpdiBpb24taWNvbiB7XG4gIGZvbnQtc2l6ZTogMjdweDtcbiAgbWFyZ2luLXJpZ2h0OiAxNXB4O1xuICBjb2xvcjogZ3JheTtcbn0iXX0= */";
    /***/
  },

  /***/
  "./src/app/pages/notification-modal/notification-modal.page.ts":
  /*!*********************************************************************!*\
    !*** ./src/app/pages/notification-modal/notification-modal.page.ts ***!
    \*********************************************************************/

  /*! exports provided: NotificationModalPage */

  /***/
  function srcAppPagesNotificationModalNotificationModalPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "NotificationModalPage", function () {
      return NotificationModalPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");

    var NotificationModalPage = /*#__PURE__*/function () {
      function NotificationModalPage() {
        _classCallCheck(this, NotificationModalPage);
      }

      _createClass(NotificationModalPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }]);

      return NotificationModalPage;
    }();

    NotificationModalPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-notification-modal',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./notification-modal.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/notification-modal/notification-modal.page.html"))["default"],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./notification-modal.page.scss */
      "./src/app/pages/notification-modal/notification-modal.page.scss"))["default"]]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])], NotificationModalPage);
    /***/
  },

  /***/
  "./src/app/services/dummy.service.ts":
  /*!*******************************************!*\
    !*** ./src/app/services/dummy.service.ts ***!
    \*******************************************/

  /*! exports provided: DummyService */

  /***/
  function srcAppServicesDummyServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "DummyService", function () {
      return DummyService;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");

    var DummyService = function DummyService() {
      _classCallCheck(this, DummyService);

      this.slider = [{
        img: 'assets/imgs/all.png',
        name: 'All Categories'
      }, {
        img: 'assets/imgs/shop.png',
        name: 'Shopping'
      }, {
        img: 'assets/imgs/cake.png',
        name: 'Cake Shop'
      }, {
        img: 'assets/imgs/rest.png',
        name: 'Restautants'
      }, {
        img: 'assets/imgs/science.png',
        name: 'Diagnostic Center'
      }, {
        img: 'assets/imgs/doctor.png',
        name: 'Doctors'
      }, {
        img: 'assets/imgs/repair.png',
        name: 'Repair'
      }, {
        img: 'assets/imgs/auto.png',
        name: 'Automobile'
      }];
      this.news = [{
        logo: 'assets/imgs/news_icn1.png',
        img: 'assets/imgs/news1.jpg',
        video: 'assets/imgs/video.mp4',
        headline: 'What is Lorem Ipsum, Lorem Ipsum is simply dummy text of the printing',
        detail: ' Lorem ipsum dolor sit amet consectetur adipisicing elit. At sint quia aperiam corrupti molestias earum, quasi modi laboriosam placeat qui maiores autem non impedit dignissimos suscipit, illo consectetur eos doloremque?'
      }, {
        logo: 'assets/imgs/news_icn2.png',
        // img : 'assets/imgs/news2.jpg',
        video: 'assets/imgs/video1.mp4',
        headline: 'What is Lorem Ipsum, Lorem Ipsum is simply dummy text of the printing',
        detail: ' Lorem ipsum dolor sit amet consectetur adipisicing elit. At sint quia aperiam corrupti molestias earum, quasi modi laboriosam placeat qui maiores autem non impedit dignissimos suscipit, illo consectetur eos doloremque?'
      }, {
        logo: 'assets/imgs/news_icn3.png',
        img: 'assets/imgs/news3.jpg',
        video: 'assets/imgs/video2.mp4',
        headline: 'What is Lorem Ipsum, Lorem Ipsum is simply dummy text of the printing',
        detail: ' Lorem ipsum dolor sit amet consectetur adipisicing elit. At sint quia aperiam corrupti molestias earum, quasi modi laboriosam placeat qui maiores autem non impedit dignissimos suscipit, illo consectetur eos doloremque?'
      }, {
        logo: 'assets/imgs/news_icn4.png',
        img: 'assets/imgs/news4.jpg',
        video: 'assets/imgs/video.mp4',
        headline: 'What is Lorem Ipsum, Lorem Ipsum is simply dummy text of the printing',
        detail: ' Lorem ipsum dolor sit amet consectetur adipisicing elit. At sint quia aperiam corrupti molestias earum, quasi modi laboriosam placeat qui maiores autem non impedit dignissimos suscipit, illo consectetur eos doloremque?'
      }, {
        logo: 'assets/imgs/news_icn5.png',
        // img : 'assets/imgs/news5.jpg',
        video: 'assets/imgs/video1.mp4',
        headline: 'What is Lorem Ipsum, Lorem Ipsum is simply dummy text of the printing',
        detail: ' Lorem ipsum dolor sit amet consectetur adipisicing elit. At sint quia aperiam corrupti molestias earum, quasi modi laboriosam placeat qui maiores autem non impedit dignissimos suscipit, illo consectetur eos doloremque?'
      }, {
        logo: 'assets/imgs/news_icn6.png',
        img: 'assets/imgs/news6.jpg',
        video: 'assets/imgs/video2.mp4',
        headline: 'What is Lorem Ipsum, Lorem Ipsum is simply dummy text of the printing',
        detail: ' Lorem ipsum dolor sit amet consectetur adipisicing elit. At sint quia aperiam corrupti molestias earum, quasi modi laboriosam placeat qui maiores autem non impedit dignissimos suscipit, illo consectetur eos doloremque?'
      }];
      this.story = [{
        img: 'assets/imgs/story1.jpg',
        name: 'Business'
      }, {
        img: 'assets/imgs/story2.jpg',
        name: 'Music World'
      }, {
        img: 'assets/imgs/story3.jpg',
        name: 'Stay Fit'
      }, {
        img: 'assets/imgs/story4.jpg',
        name: 'World'
      }, {
        img: 'assets/imgs/story5.jpg',
        name: 'Covid-19'
      }, {
        img: 'assets/imgs/story6.jpg',
        name: 'Health'
      }, {
        img: 'assets/imgs/story7.jpg',
        name: 'Science World'
      }];
      this.lang = ['Gujrati', 'Hindi', 'English', 'Marathi', 'Panjabi', 'Nepali', 'Tamil', 'Telugu', 'Bengali', 'Urdu'];
      this.movies = [{
        img: 'assets/imgs/image1.jpeg',
        name: 'Stranger Things',
        per: '60'
      }, {
        img: 'assets/imgs/image2.jpeg',
        name: 'Lucifer',
        per: '55'
      }, {
        img: 'assets/imgs/image3.jpeg',
        name: 'Dangal',
        per: '80'
      }, {
        img: 'assets/imgs/image4.jpeg',
        name: 'Kabir Singh',
        per: '70'
      }, {
        img: 'assets/imgs/image5.jpeg',
        name: 'Phanton',
        per: '50'
      }, {
        img: 'assets/imgs/image6.jpeg',
        name: 'Saaho',
        per: '50'
      }, {
        img: 'assets/imgs/image7.jpeg',
        name: 'Bard of Blood',
        per: '65'
      }, {
        img: 'assets/imgs/image8.jpeg',
        name: 'Panipat',
        per: '55'
      }, {
        img: 'assets/imgs/image9.jpeg',
        name: 'Raees',
        per: '70'
      }, {
        img: 'assets/imgs/image10.jpeg',
        name: 'Bahubali',
        per: '70'
      }, {
        img: 'assets/imgs/image11.jpeg',
        name: 'Another Life',
        per: '72'
      }, {
        img: 'assets/imgs/image12.jpeg',
        name: 'THE 100',
        per: '60'
      }, {
        img: 'assets/imgs/image13.jpeg',
        name: 'The Vampire Diaries',
        per: '66'
      }, {
        img: 'assets/imgs/image14.jpeg',
        name: 'Titans',
        per: '68'
      }, {
        img: 'assets/imgs/image15.jpeg',
        name: 'Lock & Key',
        per: '57'
      }, {
        img: 'assets/imgs/image16.jpeg',
        name: 'The Witcher',
        per: '50'
      }];
      this.users = [{
        user: 'assets/imgs/users/user1.jpg',
        name: 'John Doe',
        desc: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. At sint quia aperiam corrupti molestias earum, quasi modi laboriosam placeat qui maiores autem non impedit dignissimos suscipit, illo consectetur eos doloremque?',
        review: '3.0'
      }, {
        user: 'assets/imgs/users/user2.jpg',
        name: 'Rahul Jograna',
        desc: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. At sint quia aperiam corrupti molestias earum, quasi modi laboriosam placeat qui maiores autem non impedit dignissimos suscipit, illo consectetur eos doloremque?',
        review: '2.0'
      }, {
        user: 'assets/imgs/users/user3.jpg',
        name: 'John Doe',
        desc: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. At sint quia aperiam corrupti molestias earum, quasi modi laboriosam placeat qui maiores autem non impedit dignissimos suscipit, illo consectetur eos doloremque?',
        review: '4.0'
      }, {
        user: 'assets/imgs/users/user4.jpg',
        name: 'John Doe',
        desc: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. At sint quia aperiam corrupti molestias earum, quasi modi laboriosam placeat qui maiores autem non impedit dignissimos suscipit, illo consectetur eos doloremque?',
        review: '3.0'
      }];
      this.moreCat = [{
        img: 'assets/imgs/chart.png',
        name: 'Stock'
      }, {
        img: 'assets/imgs/tv.png',
        name: 'Live TV'
      }, {
        img: 'assets/imgs/music.png',
        name: 'Music'
      }, {
        img: 'assets/imgs/map.png',
        name: 'Maps'
      }, {
        img: 'assets/imgs/radio.png',
        name: 'Radio'
      }, {
        img: 'assets/imgs/ball.png',
        name: 'Cricket'
      }, {
        img: 'assets/imgs/cart.png',
        name: 'Shopping'
      }, {
        img: 'assets/imgs/image.png',
        name: 'Images'
      }, {
        img: 'assets/imgs/covid.png',
        name: 'Covid-19'
      }, {
        img: 'assets/imgs/setting.png',
        name: 'Settings'
      }, {
        img: 'assets/imgs/clapper.png',
        name: 'Movies'
      }];
      this.repoters = [{
        img: 'assets/imgs/news/reporter1.jpg',
        name: 'English'
      }, {
        img: 'assets/imgs/news/reporter2.jpg',
        name: 'Hindi'
      }, {
        img: 'assets/imgs/news/reporter3.jpg',
        name: 'Gujrati'
      }, {
        img: 'assets/imgs/news/reporter4.jpg',
        name: 'Marathi'
      }, {
        img: 'assets/imgs/news/reporter5.jpg',
        name: 'Telugu'
      }, {
        img: 'assets/imgs/news/reporter6.jpg',
        name: 'Kannada'
      }, {
        img: 'assets/imgs/news/reporter7.jpg',
        name: 'Malayalam'
      }];
      this.channelList = [{
        img: 'assets/imgs/news/channel1.png',
        name: 'India Today',
        logo: 'assets/imgs/news/c1.png'
      }, {
        img: 'assets/imgs/news/channel2.jpeg',
        name: 'Mirror Now',
        logo: 'assets/imgs/news/c2.jpg'
      }, {
        img: 'assets/imgs/news/channel3.jpeg',
        name: 'Times Now',
        logo: 'assets/imgs/news/c3.jpg'
      }, {
        img: 'assets/imgs/news/channel4.png',
        name: 'NDTV 24X7',
        logo: 'assets/imgs/news/c4.png'
      }, {
        img: 'assets/imgs/news/channel5.png',
        name: 'News 18',
        logo: 'assets/imgs/news/c5.png'
      }];
      this.notification = [{
        img: 'assets/imgs/news_icn1.png',
        head: 'Lorem ipsum dolor sit amet consectetur adipisicing elit',
        sub: 'At sint quia aperiam corrupti molestias earum, quasi modi laboriosam placeat qui maiores autem non impedit dignissimos suscipit'
      }, {
        img: 'assets/imgs/news_icn10.png',
        head: 'Lorem ipsum dolor sit amet consectetur adipisicing elit',
        sub: 'At sint quia aperiam corrupti molestias earum, quasi modi laboriosam placeat qui maiores autem non impedit dignissimos suscipit'
      }, {
        img: 'assets/imgs/story5.jpg',
        head: 'Lorem ipsum dolor sit amet consectetur adipisicing elit',
        sub: 'At sint quia aperiam corrupti molestias earum, quasi modi laboriosam placeat qui maiores autem non impedit dignissimos suscipit'
      }, {
        img: 'assets/imgs/news4.jpg',
        head: 'Lorem ipsum dolor sit amet consectetur adipisicing elit',
        sub: 'At sint quia aperiam corrupti molestias earum, quasi modi laboriosam placeat qui maiores autem non impedit dignissimos suscipit'
      }, {
        img: 'assets/imgs/news/channel5.png',
        head: 'Lorem ipsum dolor sit amet consectetur adipisicing elit',
        sub: 'At sint quia aperiam corrupti molestias earum, quasi modi laboriosam placeat qui maiores autem non impedit dignissimos suscipit'
      }, {
        img: 'assets/imgs/news/channel1.png',
        head: 'Lorem ipsum dolor sit amet consectetur adipisicing elit',
        sub: 'At sint quia aperiam corrupti molestias earum, quasi modi laboriosam placeat qui maiores autem non impedit dignissimos suscipit'
      }];
    };

    DummyService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
      providedIn: 'root'
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])], DummyService);
    /***/
  },

  /***/
  "./src/environments/environment.ts":
  /*!*****************************************!*\
    !*** ./src/environments/environment.ts ***!
    \*****************************************/

  /*! exports provided: environment */

  /***/
  function srcEnvironmentsEnvironmentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "environment", function () {
      return environment;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js"); // This file can be replaced during build by using the `fileReplacements` array.
    // `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
    // The list of file replacements can be found in `angular.json`.


    var environment = {
      production: false
    };
    /*
     * For easier debugging in development mode, you can import the following file
     * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
     *
     * This import should be commented out in production mode because it will have a negative impact
     * on performance if an error is thrown.
     */
    // import 'zone.js/dist/zone-error';  // Included with Angular CLI.

    /***/
  },

  /***/
  "./src/main.ts":
  /*!*********************!*\
    !*** ./src/main.ts ***!
    \*********************/

  /*! no exports provided */

  /***/
  function srcMainTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/platform-browser-dynamic */
    "./node_modules/@angular/platform-browser-dynamic/fesm2015/platform-browser-dynamic.js");
    /* harmony import */


    var _app_app_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./app/app.module */
    "./src/app/app.module.ts");
    /* harmony import */


    var _environments_environment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ./environments/environment */
    "./src/environments/environment.ts");

    if (_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].production) {
      Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["enableProdMode"])();
    }

    Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_2__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_3__["AppModule"])["catch"](function (err) {
      return console.log(err);
    });
    /***/
  },

  /***/
  0:
  /*!***************************!*\
    !*** multi ./src/main.ts ***!
    \***************************/

  /*! no static exports found */

  /***/
  function _(module, exports, __webpack_require__) {
    module.exports = __webpack_require__(
    /*! E:\Ionic Projects\ionic-5-template-bundle-ionic-5-themes-bundles-ionic-5-templates-with-10-apps\App_source_code\Apps_code\Multi_purpose\src\main.ts */
    "./src/main.ts");
    /***/
  }
}, [[0, "runtime", "vendor"]]]);
//# sourceMappingURL=main-es5.js.map