(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["music-video-music-video-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/music-video/music-video.page.html":
/*!***********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/music-video/music-video.page.html ***!
  \***********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar>\n   <!-- <ion-buttons slot=\"start\">\n     <ion-back-button mode=\"md\"></ion-back-button>\n   </ion-buttons> -->\n\n   <ion-icon class=\"back\" name=\"arrow-back-outline\" (click)=\"goBack()\"></ion-icon>\n\n    <ion-title>Music</ion-title>\n\n    <ion-button slot=\"end\" size=\"small\" fill=\"clear\">\n      <ion-icon name=\"arrow-redo-outline\"></ion-icon>\n    </ion-button>\n\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div class=\"main_content_div\">\n\n    <video playsinline webkit-playsinline autoplay controls>\n      <source src=\"assets/imgs/video.mp4\" type=\"video/mp4\">\n    </video>\n\n    <div class=\"detail_div\">\n      <ion-label class=\"head_lbl\">Bekhayali</ion-label>\n      \n      <ion-label class=\"album_detail\">Album - <span>Kabir Singh</span></ion-label>\n\n      <ion-label class=\"album_detail\">Artist - <span>Arijit Singh</span></ion-label>\n\n      <ion-label class=\"album_detail\">Duration - 04:20</ion-label>\n\n    </div>\n\n    <div class=\"autoplay_div\">\n        <ion-label>AutoPlay</ion-label>\n        <div class=\"tog_div\">\n          <ion-label>Similar</ion-label>\n          <ion-toggle mode=\"md\"></ion-toggle>\n          <ion-label>Album</ion-label>\n        </div>\n    </div>\n\n    <div class=\"btn_div\">\n      <ion-button expand=\"block\" color=\"danger\">\n        <ion-icon name=\"caret-forward-outline\"></ion-icon>\n        Play\n      </ion-button>\n\n      <ion-button class=\"icn_btn\">\n        <ion-icon name=\"chevron-down-outline\"></ion-icon>\n      </ion-button>\n    </div>\n\n    <div class=\"line_div\"></div>\n\n    <div class=\"btn_div\">\n      \n      <div class=\"flex_div\">\n        <ion-label class=\"lyrics_lbl\">Lyrics</ion-label>\n        <div class=\"zoom_div\">\n          <div class=\"b1\">\n            <ion-label>A+</ion-label>\n          </div>\n          <div class=\"b1\">\n            <ion-label>A-</ion-label>\n          </div>\n        </div>\n      </div>\n\n      <ion-label class=\"lyrics_detail\">\n        Lorem ipsum dolor sit amet consectetur adipisicing elit. Enim aliquid voluptas nulla ea!\n        Ad, tempore? Voluptatibus, veniam eveniet architecto velit enim dignissimos iure? Quaerat,\n        reiciendis rerum quia commodi suscipit quod!\n        <!-- Lorem ipsum dolor sit amet consectetur adipisicing elit. \n        Minima mollitia neque voluptates sint ratione officiis ex est nesciunt,\n        ea quas modi repellat repudiandae similique at, sit quisquam voluptate cupiditate. Vero.        \n        Lorem ipsum dolor sit amet consectetur adipisicing elit. Id commodi odit, maiores inventore \n        temporibus dicta quos, nostrum, repudiandae error architecto deserunt laborum autem quod? \n        Consectetur repellat explicabo eos libero qui. -->\n      </ion-label>\n\n      <ion-label class=\"show_lbl\">Show More...</ion-label>\n    </div>\n\n    <div class=\"line_div\"></div>\n\n    <div class=\"slider_div\">\n\n      <ion-label class=\"similar_lbl\">Similar songs</ion-label>\n\n      <div class=\"slider_class\">\n        <ion-slides mode=\"ios\" [options]=\"slideOpts\">\n          <ion-slide *ngFor=\"let item of (songs | slice : 0 : 7)\">\n            <div class=\"inner_slider\">\n              <div class=\"image_div bg_image\" [style.backgroundImage]=\"'url( '+ item.img +' )'\" ></div>\n              <ion-label class=\"name\">{{item.name | slice: 0: 15}}</ion-label>\n            </div>\n          </ion-slide>\n        </ion-slides>\n      </div>\n\n    </div>\n\n    <div class=\"line_div\"></div>\n\n    <div class=\"album_list\">\n      <ion-label class=\"similar_lbl\">More from the album</ion-label>\n\n      <div class=\"list_div\" *ngFor=\"let item of albumList\">\n        <ion-label class=\"name\">{{item.name}}</ion-label>\n        <ion-label class=\"art\">{{item.artist}}</ion-label>\n        <ion-label class=\"time\">{{item.time}}</ion-label>\n      </div>\n\n    </div>\n\n  </div>\n</ion-content>\n");

/***/ }),

/***/ "./src/app/pages/music-video/music-video-routing.module.ts":
/*!*****************************************************************!*\
  !*** ./src/app/pages/music-video/music-video-routing.module.ts ***!
  \*****************************************************************/
/*! exports provided: MusicVideoPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MusicVideoPageRoutingModule", function() { return MusicVideoPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _music_video_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./music-video.page */ "./src/app/pages/music-video/music-video.page.ts");




const routes = [
    {
        path: '',
        component: _music_video_page__WEBPACK_IMPORTED_MODULE_3__["MusicVideoPage"]
    }
];
let MusicVideoPageRoutingModule = class MusicVideoPageRoutingModule {
};
MusicVideoPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], MusicVideoPageRoutingModule);



/***/ }),

/***/ "./src/app/pages/music-video/music-video.module.ts":
/*!*********************************************************!*\
  !*** ./src/app/pages/music-video/music-video.module.ts ***!
  \*********************************************************/
/*! exports provided: MusicVideoPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MusicVideoPageModule", function() { return MusicVideoPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _music_video_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./music-video-routing.module */ "./src/app/pages/music-video/music-video-routing.module.ts");
/* harmony import */ var _music_video_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./music-video.page */ "./src/app/pages/music-video/music-video.page.ts");







let MusicVideoPageModule = class MusicVideoPageModule {
};
MusicVideoPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _music_video_routing_module__WEBPACK_IMPORTED_MODULE_5__["MusicVideoPageRoutingModule"]
        ],
        declarations: [_music_video_page__WEBPACK_IMPORTED_MODULE_6__["MusicVideoPage"]]
    })
], MusicVideoPageModule);



/***/ }),

/***/ "./src/app/pages/music-video/music-video.page.scss":
/*!*********************************************************!*\
  !*** ./src/app/pages/music-video/music-video.page.scss ***!
  \*********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-header .back {\n  font-size: 27px;\n  margin-left: 10px;\n}\nion-header ion-button {\n  margin: 0;\n}\nion-header ion-button ion-icon {\n  color: black;\n  font-size: 20px;\n}\n.main_content_div {\n  width: 100%;\n}\n.main_content_div ion-label {\n  display: block;\n}\n.main_content_div video {\n  width: 100%;\n}\n.main_content_div .detail_div {\n  padding: 10px 16px;\n  border-bottom: 1px solid lightgray;\n}\n.main_content_div .detail_div .head_lbl {\n  font-weight: 600;\n  font-size: 22px;\n}\n.main_content_div .detail_div .album_detail {\n  color: #707070;\n  font-weight: 600;\n  font-size: 14px;\n  margin-top: 7px;\n}\n.main_content_div .detail_div .album_detail span {\n  color: var(--ion-color-primary);\n}\n.main_content_div .autoplay_div {\n  padding: 10px 16px;\n  border-bottom: 1px solid lightgray;\n  display: flex;\n  flex-direction: row;\n  align-items: center;\n  justify-content: space-between;\n}\n.main_content_div .autoplay_div ion-label {\n  color: #707070;\n  font-size: 14px;\n  font-weight: 600;\n}\n.main_content_div .autoplay_div .tog_div {\n  display: flex;\n  align-items: center;\n}\n.main_content_div .autoplay_div .tog_div ion-toggle {\n  --background: var(--ion-color-success);\n  --background-checked: var(--ion-color-success);\n  --handle-background: white;\n  --handle-background-checked: white;\n  --handle-height: 10px ;\n}\n.main_content_div .autoplay_div .tog_div ion-label {\n  font-size: 12px;\n  font-weight: normal;\n}\n.main_content_div .btn_div {\n  padding: 10px 16px;\n  position: relative;\n}\n.main_content_div .btn_div ion-button {\n  --border-radius: 0px;\n  height: 40px;\n}\n.main_content_div .btn_div .icn_btn {\n  --background: #b83d3d;\n  height: 40px;\n  --border-radius: 0px;\n  position: absolute;\n  right: 16px;\n  top: 10px;\n}\n.main_content_div .btn_div .icn_btn ion-icon {\n  font-size: 20px;\n}\n.main_content_div .btn_div .flex_div {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n}\n.main_content_div .btn_div .flex_div .lyrics_lbl {\n  font-weight: 500;\n  font-size: 14px;\n}\n.main_content_div .btn_div .flex_div .zoom_div {\n  display: flex;\n}\n.main_content_div .btn_div .flex_div .zoom_div .b1 {\n  border: 1px solid lightgray;\n  border-radius: 100%;\n  height: 35px;\n  width: 35px;\n  position: relative;\n  margin-left: 10px;\n}\n.main_content_div .btn_div .flex_div .zoom_div .b1 ion-label {\n  font-weight: 700;\n  color: #707007;\n  font-size: 14px;\n  position: absolute;\n  top: 45%;\n  left: 50%;\n  transform: translate(-50%, -50%);\n}\n.main_content_div .btn_div .lyrics_detail {\n  margin-top: 5px;\n  font-size: 14px;\n  font-weight: 500;\n  color: #707070;\n}\n.main_content_div .btn_div .show_lbl {\n  color: var(--ion-color-primary);\n  font-size: 14px;\n  font-weight: 500;\n}\n.main_content_div .line_div {\n  width: 100%;\n  height: 5px;\n  background: #f3f3f3;\n}\n.main_content_div .slider_div {\n  padding: 10px 16px;\n}\n.main_content_div .slider_div .similar_lbl {\n  font-size: 14px;\n  font-weight: 500;\n  margin-bottom: 5px;\n}\n.main_content_div .slider_div .slider_class ion-slide {\n  height: 170px;\n  margin-right: 10px;\n  margin-left: 5px;\n}\n.main_content_div .slider_div .slider_class .inner_slider {\n  width: 100%;\n  height: 150px;\n  box-shadow: 0px 3px 6px rgba(0, 0, 0, 0.3);\n  border-radius: 5px;\n}\n.main_content_div .slider_div .slider_class .image_div {\n  width: 100%;\n  height: 120px;\n  border-top-left-radius: 5px;\n  border-top-right-radius: 5px;\n  position: relative;\n}\n.main_content_div .slider_div .slider_class .name {\n  padding: 5px;\n  font-size: 13px;\n  text-align: left;\n}\n.main_content_div .album_list {\n  padding: 10px 16px;\n}\n.main_content_div .album_list ion-label {\n  font-size: 14px;\n  font-weight: 500;\n}\n.main_content_div .album_list .list_div {\n  position: relative;\n  padding-top: 10px;\n  padding-bottom: 10px;\n  border-bottom: 1px solid lightgray;\n}\n.main_content_div .album_list .list_div .similar_lbl {\n  margin-bottom: 5px;\n  font-weight: normal !important;\n}\n.main_content_div .album_list .list_div .art {\n  color: #707070;\n}\n.main_content_div .album_list .list_div .time {\n  position: absolute;\n  right: 0;\n  top: 50%;\n  color: #707070;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvbXVzaWMtdmlkZW8vRTpcXElvbmljIFByb2plY3RzXFxpb25pYy01LXRlbXBsYXRlLWJ1bmRsZS1pb25pYy01LXRoZW1lcy1idW5kbGVzLWlvbmljLTUtdGVtcGxhdGVzLXdpdGgtMTAtYXBwc1xcQXBwX3NvdXJjZV9jb2RlXFxBcHBzX2NvZGVcXE11bHRpX3B1cnBvc2Uvc3JjXFxhcHBcXHBhZ2VzXFxtdXNpYy12aWRlb1xcbXVzaWMtdmlkZW8ucGFnZS5zY3NzIiwic3JjL2FwcC9wYWdlcy9tdXNpYy12aWRlby9tdXNpYy12aWRlby5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0k7RUFDSSxlQUFBO0VBQ0EsaUJBQUE7QUNBUjtBREVJO0VBQ0ksU0FBQTtBQ0FSO0FERVE7RUFDSSxZQUFBO0VBQ0EsZUFBQTtBQ0FaO0FEU0E7RUFDSSxXQUFBO0FDTko7QURRSTtFQUNJLGNBQUE7QUNOUjtBRFNJO0VBQ0ksV0FBQTtBQ1BSO0FEVUk7RUFDSSxrQkFBQTtFQUNBLGtDQUFBO0FDUlI7QURVUTtFQUNJLGdCQUFBO0VBQ0EsZUFBQTtBQ1JaO0FEV1E7RUFDSSxjQUFBO0VBQ0EsZ0JBQUE7RUFDQSxlQUFBO0VBQ0EsZUFBQTtBQ1RaO0FEV1k7RUFDSSwrQkFBQTtBQ1RoQjtBRGNJO0VBQ0ksa0JBQUE7RUFDQSxrQ0FBQTtFQUNBLGFBQUE7RUFDQSxtQkFBQTtFQUNBLG1CQUFBO0VBQ0EsOEJBQUE7QUNaUjtBRGNRO0VBQ0ksY0FBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtBQ1paO0FEZVE7RUFDSSxhQUFBO0VBQ0EsbUJBQUE7QUNiWjtBRGVZO0VBQ0ksc0NBQUE7RUFDQSw4Q0FBQTtFQUNBLDBCQUFBO0VBQ0Esa0NBQUE7RUFDQSxzQkFBQTtBQ2JoQjtBRGdCWTtFQUNJLGVBQUE7RUFDQSxtQkFBQTtBQ2RoQjtBRG1CSTtFQUNJLGtCQUFBO0VBQ0Esa0JBQUE7QUNqQlI7QURtQlE7RUFDSSxvQkFBQTtFQUNBLFlBQUE7QUNqQlo7QURvQlE7RUFDSSxxQkFBQTtFQUNBLFlBQUE7RUFDQSxvQkFBQTtFQUNBLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLFNBQUE7QUNsQlo7QURvQlk7RUFDSSxlQUFBO0FDbEJoQjtBRHNCUTtFQUNJLGFBQUE7RUFDQSxtQkFBQTtFQUNBLDhCQUFBO0FDcEJaO0FEc0JZO0VBQ0ksZ0JBQUE7RUFDQSxlQUFBO0FDcEJoQjtBRHVCWTtFQUNJLGFBQUE7QUNyQmhCO0FEdUJnQjtFQUNJLDJCQUFBO0VBQ0EsbUJBQUE7RUFDQSxZQUFBO0VBQ0EsV0FBQTtFQUNBLGtCQUFBO0VBQ0EsaUJBQUE7QUNyQnBCO0FEdUJvQjtFQUNJLGdCQUFBO0VBQ0EsY0FBQTtFQUNBLGVBQUE7RUFDQSxrQkFBQTtFQUNBLFFBQUE7RUFDQSxTQUFBO0VBQ0EsZ0NBQUE7QUNyQnhCO0FEMEJRO0VBQ0ksZUFBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7QUN4Qlo7QUQyQlE7RUFDSSwrQkFBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtBQ3pCWjtBRDRCSTtFQUNJLFdBQUE7RUFDQSxXQUFBO0VBQ0EsbUJBQUE7QUMxQlI7QUQ2Qkk7RUFDSSxrQkFBQTtBQzNCUjtBRDZCUTtFQUNJLGVBQUE7RUFDQSxnQkFBQTtFQUNBLGtCQUFBO0FDM0JaO0FEZ0NZO0VBQ0ksYUFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7QUM5QmhCO0FEaUNZO0VBQ0ksV0FBQTtFQUNBLGFBQUE7RUFDQSwwQ0FBQTtFQUNBLGtCQUFBO0FDL0JoQjtBRGtDWTtFQUNJLFdBQUE7RUFDQSxhQUFBO0VBQ0EsMkJBQUE7RUFDQSw0QkFBQTtFQUNBLGtCQUFBO0FDaENoQjtBRGtDWTtFQUNJLFlBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7QUNoQ2hCO0FEcUNJO0VBQ0ksa0JBQUE7QUNuQ1I7QURxQ1E7RUFDSSxlQUFBO0VBQ0EsZ0JBQUE7QUNuQ1o7QURzQ1E7RUFDSSxrQkFBQTtFQUNBLGlCQUFBO0VBQ0Esb0JBQUE7RUFDQSxrQ0FBQTtBQ3BDWjtBRHFDWTtFQUNJLGtCQUFBO0VBQ0EsOEJBQUE7QUNuQ2hCO0FEc0NZO0VBQ0ksY0FBQTtBQ3BDaEI7QURzQ1k7RUFDSSxrQkFBQTtFQUNBLFFBQUE7RUFDQSxRQUFBO0VBQ0EsY0FBQTtBQ3BDaEIiLCJmaWxlIjoic3JjL2FwcC9wYWdlcy9tdXNpYy12aWRlby9tdXNpYy12aWRlby5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24taGVhZGVye1xuICAgIC5iYWNre1xuICAgICAgICBmb250LXNpemU6IDI3cHg7XG4gICAgICAgIG1hcmdpbi1sZWZ0OiAxMHB4O1xuICAgIH1cbiAgICBpb24tYnV0dG9ue1xuICAgICAgICBtYXJnaW46IDA7XG5cbiAgICAgICAgaW9uLWljb257XG4gICAgICAgICAgICBjb2xvcjogYmxhY2s7XG4gICAgICAgICAgICBmb250LXNpemU6IDIwcHg7XG4gICAgICAgIH1cbiAgICB9XG59XG5cbi8vIGlvbi1jb250ZW50e1xuLy8gICAgIC0tYmFja2dyb3VuZDogI2YzZjNmMztcbi8vIH1cblxuLm1haW5fY29udGVudF9kaXZ7XG4gICAgd2lkdGg6IDEwMCU7XG5cbiAgICBpb24tbGFiZWwge1xuICAgICAgICBkaXNwbGF5OiBibG9jaztcbiAgICB9XG5cbiAgICB2aWRlb3tcbiAgICAgICAgd2lkdGg6IDEwMCU7XG4gICAgfVxuXG4gICAgLmRldGFpbF9kaXZ7XG4gICAgICAgIHBhZGRpbmc6IDEwcHggMTZweDtcbiAgICAgICAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkIGxpZ2h0Z3JheTtcblxuICAgICAgICAuaGVhZF9sYmx7XG4gICAgICAgICAgICBmb250LXdlaWdodDogNjAwO1xuICAgICAgICAgICAgZm9udC1zaXplOiAyMnB4O1xuICAgICAgICB9XG5cbiAgICAgICAgLmFsYnVtX2RldGFpbHtcbiAgICAgICAgICAgIGNvbG9yOiAjNzA3MDcwO1xuICAgICAgICAgICAgZm9udC13ZWlnaHQ6IDYwMDtcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogMTRweDtcbiAgICAgICAgICAgIG1hcmdpbi10b3A6IDdweDtcblxuICAgICAgICAgICAgc3BhbntcbiAgICAgICAgICAgICAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuXG4gICAgLmF1dG9wbGF5X2RpdntcbiAgICAgICAgcGFkZGluZzogMTBweCAxNnB4O1xuICAgICAgICBib3JkZXItYm90dG9tOiAxcHggc29saWQgbGlnaHRncmF5O1xuICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICBmbGV4LWRpcmVjdGlvbjogcm93O1xuICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XG5cbiAgICAgICAgaW9uLWxhYmVsIHtcbiAgICAgICAgICAgIGNvbG9yOiAjNzA3MDcwO1xuICAgICAgICAgICAgZm9udC1zaXplOiAxNHB4O1xuICAgICAgICAgICAgZm9udC13ZWlnaHQ6IDYwMDtcbiAgICAgICAgfVxuXG4gICAgICAgIC50b2dfZGl2e1xuICAgICAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG5cbiAgICAgICAgICAgIGlvbi10b2dnbGV7XG4gICAgICAgICAgICAgICAgLS1iYWNrZ3JvdW5kIDogdmFyKC0taW9uLWNvbG9yLXN1Y2Nlc3MpO1xuICAgICAgICAgICAgICAgIC0tYmFja2dyb3VuZC1jaGVja2VkIDogdmFyKC0taW9uLWNvbG9yLXN1Y2Nlc3MpO1xuICAgICAgICAgICAgICAgIC0taGFuZGxlLWJhY2tncm91bmQgOiB3aGl0ZTtcbiAgICAgICAgICAgICAgICAtLWhhbmRsZS1iYWNrZ3JvdW5kLWNoZWNrZWQgOiAgd2hpdGU7XG4gICAgICAgICAgICAgICAgLS1oYW5kbGUtaGVpZ2h0IDogMTBweFxuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBpb24tbGFiZWwge1xuICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMTJweDtcbiAgICAgICAgICAgICAgICBmb250LXdlaWdodDogbm9ybWFsO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuXG4gICAgLmJ0bl9kaXZ7XG4gICAgICAgIHBhZGRpbmc6IDEwcHggMTZweDtcbiAgICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xuXG4gICAgICAgIGlvbi1idXR0b257XG4gICAgICAgICAgICAtLWJvcmRlci1yYWRpdXM6IDBweDtcbiAgICAgICAgICAgIGhlaWdodDogNDBweDtcbiAgICAgICAgfVxuXG4gICAgICAgIC5pY25fYnRue1xuICAgICAgICAgICAgLS1iYWNrZ3JvdW5kOiAjYjgzZDNkO1xuICAgICAgICAgICAgaGVpZ2h0OiA0MHB4O1xuICAgICAgICAgICAgLS1ib3JkZXItcmFkaXVzOiAwcHg7XG4gICAgICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgICAgICAgICByaWdodDogMTZweDtcbiAgICAgICAgICAgIHRvcDogMTBweDtcblxuICAgICAgICAgICAgaW9uLWljb257XG4gICAgICAgICAgICAgICAgZm9udC1zaXplOiAyMHB4O1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgLmZsZXhfZGl2e1xuICAgICAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAgICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XG5cbiAgICAgICAgICAgIC5seXJpY3NfbGJse1xuICAgICAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiA1MDA7XG4gICAgICAgICAgICAgICAgZm9udC1zaXplOiAxNHB4O1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAuem9vbV9kaXZ7XG4gICAgICAgICAgICAgICAgZGlzcGxheTogZmxleDtcblxuICAgICAgICAgICAgICAgIC5iMXtcbiAgICAgICAgICAgICAgICAgICAgYm9yZGVyOiAxcHggc29saWQgbGlnaHRncmF5O1xuICAgICAgICAgICAgICAgICAgICBib3JkZXItcmFkaXVzOiAxMDAlO1xuICAgICAgICAgICAgICAgICAgICBoZWlnaHQ6IDM1cHg7XG4gICAgICAgICAgICAgICAgICAgIHdpZHRoOiAzNXB4O1xuICAgICAgICAgICAgICAgICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gICAgICAgICAgICAgICAgICAgIG1hcmdpbi1sZWZ0OiAxMHB4O1xuXG4gICAgICAgICAgICAgICAgICAgIGlvbi1sYWJlbCB7XG4gICAgICAgICAgICAgICAgICAgICAgICBmb250LXdlaWdodDogNzAwO1xuICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I6ICM3MDcwMDc7XG4gICAgICAgICAgICAgICAgICAgICAgICBmb250LXNpemU6IDE0cHg7XG4gICAgICAgICAgICAgICAgICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgICAgICAgICAgICAgICAgICAgICB0b3A6IDQ1JTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGxlZnQ6IDUwJTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlKC01MCUsLTUwJSk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9ICAgXG4gICAgICAgIH1cbiAgICAgICAgLmx5cmljc19kZXRhaWx7XG4gICAgICAgICAgICBtYXJnaW4tdG9wOiA1cHg7XG4gICAgICAgICAgICBmb250LXNpemU6IDE0cHg7XG4gICAgICAgICAgICBmb250LXdlaWdodDogNTAwO1xuICAgICAgICAgICAgY29sb3I6ICM3MDcwNzA7XG4gICAgICAgIH1cblxuICAgICAgICAuc2hvd19sYmx7XG4gICAgICAgICAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xuICAgICAgICAgICAgZm9udC1zaXplOiAxNHB4O1xuICAgICAgICAgICAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgICAgICAgfVxuICAgIH1cbiAgICAubGluZV9kaXZ7XG4gICAgICAgIHdpZHRoOiAxMDAlO1xuICAgICAgICBoZWlnaHQ6IDVweDtcbiAgICAgICAgYmFja2dyb3VuZDogI2YzZjNmMztcbiAgICB9XG5cbiAgICAuc2xpZGVyX2RpdntcbiAgICAgICAgcGFkZGluZzogMTBweCAxNnB4O1xuXG4gICAgICAgIC5zaW1pbGFyX2xibHtcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogMTRweDtcbiAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiA1MDA7XG4gICAgICAgICAgICBtYXJnaW4tYm90dG9tOiA1cHg7XG4gICAgICAgIH1cblxuICAgICAgICAuc2xpZGVyX2NsYXNze1xuXG4gICAgICAgICAgICBpb24tc2xpZGV7XG4gICAgICAgICAgICAgICAgaGVpZ2h0OiAxNzBweDtcbiAgICAgICAgICAgICAgICBtYXJnaW4tcmlnaHQ6IDEwcHg7XG4gICAgICAgICAgICAgICAgbWFyZ2luLWxlZnQ6IDVweDtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgLmlubmVyX3NsaWRlcntcbiAgICAgICAgICAgICAgICB3aWR0aDogMTAwJTtcbiAgICAgICAgICAgICAgICBoZWlnaHQ6IDE1MHB4O1xuICAgICAgICAgICAgICAgIGJveC1zaGFkb3c6IDBweCAzcHggNnB4IHJnYmEoMCwwLDAsMC4zKTtcbiAgICAgICAgICAgICAgICBib3JkZXItcmFkaXVzOiA1cHg7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIC5pbWFnZV9kaXZ7XG4gICAgICAgICAgICAgICAgd2lkdGg6IDEwMCU7XG4gICAgICAgICAgICAgICAgaGVpZ2h0OiAxMjBweDtcbiAgICAgICAgICAgICAgICBib3JkZXItdG9wLWxlZnQtcmFkaXVzOiA1cHg7XG4gICAgICAgICAgICAgICAgYm9yZGVyLXRvcC1yaWdodC1yYWRpdXM6IDVweDtcbiAgICAgICAgICAgICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICAubmFtZXtcbiAgICAgICAgICAgICAgICBwYWRkaW5nOiA1cHg7XG4gICAgICAgICAgICAgICAgZm9udC1zaXplOiAxM3B4O1xuICAgICAgICAgICAgICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAuYWxidW1fbGlzdHtcbiAgICAgICAgcGFkZGluZzogMTBweCAxNnB4O1xuXG4gICAgICAgIGlvbi1sYWJlbCB7XG4gICAgICAgICAgICBmb250LXNpemU6IDE0cHg7XG4gICAgICAgICAgICBmb250LXdlaWdodDogNTAwO1xuICAgICAgICB9XG5cbiAgICAgICAgLmxpc3RfZGl2e1xuICAgICAgICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xuICAgICAgICAgICAgcGFkZGluZy10b3A6IDEwcHg7XG4gICAgICAgICAgICBwYWRkaW5nLWJvdHRvbTogMTBweDtcbiAgICAgICAgICAgIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCBsaWdodGdyYXk7XG4gICAgICAgICAgICAuc2ltaWxhcl9sYmx7XG4gICAgICAgICAgICAgICAgbWFyZ2luLWJvdHRvbTogNXB4O1xuICAgICAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiBub3JtYWwgIWltcG9ydGFudCA7XG4gICAgICAgICAgICB9XG4gICAgXG4gICAgICAgICAgICAuYXJ0e1xuICAgICAgICAgICAgICAgIGNvbG9yOiAjNzA3MDcwO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgLnRpbWV7XG4gICAgICAgICAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgICAgICAgICAgICAgIHJpZ2h0OiAwO1xuICAgICAgICAgICAgICAgIHRvcDogNTAlO1xuICAgICAgICAgICAgICAgIGNvbG9yOiAjNzA3MDcwO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxufSIsImlvbi1oZWFkZXIgLmJhY2sge1xuICBmb250LXNpemU6IDI3cHg7XG4gIG1hcmdpbi1sZWZ0OiAxMHB4O1xufVxuaW9uLWhlYWRlciBpb24tYnV0dG9uIHtcbiAgbWFyZ2luOiAwO1xufVxuaW9uLWhlYWRlciBpb24tYnV0dG9uIGlvbi1pY29uIHtcbiAgY29sb3I6IGJsYWNrO1xuICBmb250LXNpemU6IDIwcHg7XG59XG5cbi5tYWluX2NvbnRlbnRfZGl2IHtcbiAgd2lkdGg6IDEwMCU7XG59XG4ubWFpbl9jb250ZW50X2RpdiBpb24tbGFiZWwge1xuICBkaXNwbGF5OiBibG9jaztcbn1cbi5tYWluX2NvbnRlbnRfZGl2IHZpZGVvIHtcbiAgd2lkdGg6IDEwMCU7XG59XG4ubWFpbl9jb250ZW50X2RpdiAuZGV0YWlsX2RpdiB7XG4gIHBhZGRpbmc6IDEwcHggMTZweDtcbiAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkIGxpZ2h0Z3JheTtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5kZXRhaWxfZGl2IC5oZWFkX2xibCB7XG4gIGZvbnQtd2VpZ2h0OiA2MDA7XG4gIGZvbnQtc2l6ZTogMjJweDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5kZXRhaWxfZGl2IC5hbGJ1bV9kZXRhaWwge1xuICBjb2xvcjogIzcwNzA3MDtcbiAgZm9udC13ZWlnaHQ6IDYwMDtcbiAgZm9udC1zaXplOiAxNHB4O1xuICBtYXJnaW4tdG9wOiA3cHg7XG59XG4ubWFpbl9jb250ZW50X2RpdiAuZGV0YWlsX2RpdiAuYWxidW1fZGV0YWlsIHNwYW4ge1xuICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xufVxuLm1haW5fY29udGVudF9kaXYgLmF1dG9wbGF5X2RpdiB7XG4gIHBhZGRpbmc6IDEwcHggMTZweDtcbiAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkIGxpZ2h0Z3JheTtcbiAgZGlzcGxheTogZmxleDtcbiAgZmxleC1kaXJlY3Rpb246IHJvdztcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xufVxuLm1haW5fY29udGVudF9kaXYgLmF1dG9wbGF5X2RpdiBpb24tbGFiZWwge1xuICBjb2xvcjogIzcwNzA3MDtcbiAgZm9udC1zaXplOiAxNHB4O1xuICBmb250LXdlaWdodDogNjAwO1xufVxuLm1haW5fY29udGVudF9kaXYgLmF1dG9wbGF5X2RpdiAudG9nX2RpdiB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG59XG4ubWFpbl9jb250ZW50X2RpdiAuYXV0b3BsYXlfZGl2IC50b2dfZGl2IGlvbi10b2dnbGUge1xuICAtLWJhY2tncm91bmQ6IHZhcigtLWlvbi1jb2xvci1zdWNjZXNzKTtcbiAgLS1iYWNrZ3JvdW5kLWNoZWNrZWQ6IHZhcigtLWlvbi1jb2xvci1zdWNjZXNzKTtcbiAgLS1oYW5kbGUtYmFja2dyb3VuZDogd2hpdGU7XG4gIC0taGFuZGxlLWJhY2tncm91bmQtY2hlY2tlZDogd2hpdGU7XG4gIC0taGFuZGxlLWhlaWdodDogMTBweCA7XG59XG4ubWFpbl9jb250ZW50X2RpdiAuYXV0b3BsYXlfZGl2IC50b2dfZGl2IGlvbi1sYWJlbCB7XG4gIGZvbnQtc2l6ZTogMTJweDtcbiAgZm9udC13ZWlnaHQ6IG5vcm1hbDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5idG5fZGl2IHtcbiAgcGFkZGluZzogMTBweCAxNnB4O1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG59XG4ubWFpbl9jb250ZW50X2RpdiAuYnRuX2RpdiBpb24tYnV0dG9uIHtcbiAgLS1ib3JkZXItcmFkaXVzOiAwcHg7XG4gIGhlaWdodDogNDBweDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5idG5fZGl2IC5pY25fYnRuIHtcbiAgLS1iYWNrZ3JvdW5kOiAjYjgzZDNkO1xuICBoZWlnaHQ6IDQwcHg7XG4gIC0tYm9yZGVyLXJhZGl1czogMHB4O1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHJpZ2h0OiAxNnB4O1xuICB0b3A6IDEwcHg7XG59XG4ubWFpbl9jb250ZW50X2RpdiAuYnRuX2RpdiAuaWNuX2J0biBpb24taWNvbiB7XG4gIGZvbnQtc2l6ZTogMjBweDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5idG5fZGl2IC5mbGV4X2RpdiB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2Vlbjtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5idG5fZGl2IC5mbGV4X2RpdiAubHlyaWNzX2xibCB7XG4gIGZvbnQtd2VpZ2h0OiA1MDA7XG4gIGZvbnQtc2l6ZTogMTRweDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5idG5fZGl2IC5mbGV4X2RpdiAuem9vbV9kaXYge1xuICBkaXNwbGF5OiBmbGV4O1xufVxuLm1haW5fY29udGVudF9kaXYgLmJ0bl9kaXYgLmZsZXhfZGl2IC56b29tX2RpdiAuYjEge1xuICBib3JkZXI6IDFweCBzb2xpZCBsaWdodGdyYXk7XG4gIGJvcmRlci1yYWRpdXM6IDEwMCU7XG4gIGhlaWdodDogMzVweDtcbiAgd2lkdGg6IDM1cHg7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgbWFyZ2luLWxlZnQ6IDEwcHg7XG59XG4ubWFpbl9jb250ZW50X2RpdiAuYnRuX2RpdiAuZmxleF9kaXYgLnpvb21fZGl2IC5iMSBpb24tbGFiZWwge1xuICBmb250LXdlaWdodDogNzAwO1xuICBjb2xvcjogIzcwNzAwNztcbiAgZm9udC1zaXplOiAxNHB4O1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHRvcDogNDUlO1xuICBsZWZ0OiA1MCU7XG4gIHRyYW5zZm9ybTogdHJhbnNsYXRlKC01MCUsIC01MCUpO1xufVxuLm1haW5fY29udGVudF9kaXYgLmJ0bl9kaXYgLmx5cmljc19kZXRhaWwge1xuICBtYXJnaW4tdG9wOiA1cHg7XG4gIGZvbnQtc2l6ZTogMTRweDtcbiAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgY29sb3I6ICM3MDcwNzA7XG59XG4ubWFpbl9jb250ZW50X2RpdiAuYnRuX2RpdiAuc2hvd19sYmwge1xuICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xuICBmb250LXNpemU6IDE0cHg7XG4gIGZvbnQtd2VpZ2h0OiA1MDA7XG59XG4ubWFpbl9jb250ZW50X2RpdiAubGluZV9kaXYge1xuICB3aWR0aDogMTAwJTtcbiAgaGVpZ2h0OiA1cHg7XG4gIGJhY2tncm91bmQ6ICNmM2YzZjM7XG59XG4ubWFpbl9jb250ZW50X2RpdiAuc2xpZGVyX2RpdiB7XG4gIHBhZGRpbmc6IDEwcHggMTZweDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5zbGlkZXJfZGl2IC5zaW1pbGFyX2xibCB7XG4gIGZvbnQtc2l6ZTogMTRweDtcbiAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgbWFyZ2luLWJvdHRvbTogNXB4O1xufVxuLm1haW5fY29udGVudF9kaXYgLnNsaWRlcl9kaXYgLnNsaWRlcl9jbGFzcyBpb24tc2xpZGUge1xuICBoZWlnaHQ6IDE3MHB4O1xuICBtYXJnaW4tcmlnaHQ6IDEwcHg7XG4gIG1hcmdpbi1sZWZ0OiA1cHg7XG59XG4ubWFpbl9jb250ZW50X2RpdiAuc2xpZGVyX2RpdiAuc2xpZGVyX2NsYXNzIC5pbm5lcl9zbGlkZXIge1xuICB3aWR0aDogMTAwJTtcbiAgaGVpZ2h0OiAxNTBweDtcbiAgYm94LXNoYWRvdzogMHB4IDNweCA2cHggcmdiYSgwLCAwLCAwLCAwLjMpO1xuICBib3JkZXItcmFkaXVzOiA1cHg7XG59XG4ubWFpbl9jb250ZW50X2RpdiAuc2xpZGVyX2RpdiAuc2xpZGVyX2NsYXNzIC5pbWFnZV9kaXYge1xuICB3aWR0aDogMTAwJTtcbiAgaGVpZ2h0OiAxMjBweDtcbiAgYm9yZGVyLXRvcC1sZWZ0LXJhZGl1czogNXB4O1xuICBib3JkZXItdG9wLXJpZ2h0LXJhZGl1czogNXB4O1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG59XG4ubWFpbl9jb250ZW50X2RpdiAuc2xpZGVyX2RpdiAuc2xpZGVyX2NsYXNzIC5uYW1lIHtcbiAgcGFkZGluZzogNXB4O1xuICBmb250LXNpemU6IDEzcHg7XG4gIHRleHQtYWxpZ246IGxlZnQ7XG59XG4ubWFpbl9jb250ZW50X2RpdiAuYWxidW1fbGlzdCB7XG4gIHBhZGRpbmc6IDEwcHggMTZweDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5hbGJ1bV9saXN0IGlvbi1sYWJlbCB7XG4gIGZvbnQtc2l6ZTogMTRweDtcbiAgZm9udC13ZWlnaHQ6IDUwMDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5hbGJ1bV9saXN0IC5saXN0X2RpdiB7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgcGFkZGluZy10b3A6IDEwcHg7XG4gIHBhZGRpbmctYm90dG9tOiAxMHB4O1xuICBib3JkZXItYm90dG9tOiAxcHggc29saWQgbGlnaHRncmF5O1xufVxuLm1haW5fY29udGVudF9kaXYgLmFsYnVtX2xpc3QgLmxpc3RfZGl2IC5zaW1pbGFyX2xibCB7XG4gIG1hcmdpbi1ib3R0b206IDVweDtcbiAgZm9udC13ZWlnaHQ6IG5vcm1hbCAhaW1wb3J0YW50O1xufVxuLm1haW5fY29udGVudF9kaXYgLmFsYnVtX2xpc3QgLmxpc3RfZGl2IC5hcnQge1xuICBjb2xvcjogIzcwNzA3MDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5hbGJ1bV9saXN0IC5saXN0X2RpdiAudGltZSB7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgcmlnaHQ6IDA7XG4gIHRvcDogNTAlO1xuICBjb2xvcjogIzcwNzA3MDtcbn0iXX0= */");

/***/ }),

/***/ "./src/app/pages/music-video/music-video.page.ts":
/*!*******************************************************!*\
  !*** ./src/app/pages/music-video/music-video.page.ts ***!
  \*******************************************************/
/*! exports provided: MusicVideoPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MusicVideoPage", function() { return MusicVideoPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var src_app_services_music_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/music.service */ "./src/app/services/music.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");




let MusicVideoPage = class MusicVideoPage {
    constructor(music, navCtrl) {
        this.music = music;
        this.navCtrl = navCtrl;
        this.slideOpts = {
            slidesPerView: 3,
        };
        this.albumList = [
            {
                name: 'Kaise Hua',
                artist: 'Vishal Mishra',
                time: '3:55'
            },
            {
                name: 'Tuje kitna chahne lage',
                artist: 'Arijit Singh',
                time: '4:45'
            },
            {
                name: 'Mere Sonheya',
                artist: 'Parampara Thakur, Sachet Tandon',
                time: '3:13'
            },
            {
                name: 'Tera Ban Jaunga',
                artist: 'Tulsi Kumar, Akhil Sachdeva',
                time: '3:57'
            },
            {
                name: 'Pehla Pyaar',
                artist: 'Armaan Malik',
                time: '4:33'
            },
        ];
        this.songs = this.music.songs;
    }
    ngOnInit() {
    }
    goBack() {
        this.navCtrl.back();
    }
};
MusicVideoPage.ctorParameters = () => [
    { type: src_app_services_music_service__WEBPACK_IMPORTED_MODULE_2__["MusicService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["NavController"] }
];
MusicVideoPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-music-video',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./music-video.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/music-video/music-video.page.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./music-video.page.scss */ "./src/app/pages/music-video/music-video.page.scss")).default]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [src_app_services_music_service__WEBPACK_IMPORTED_MODULE_2__["MusicService"], _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["NavController"]])
], MusicVideoPage);



/***/ })

}]);
//# sourceMappingURL=music-video-music-video-module-es2015.js.map