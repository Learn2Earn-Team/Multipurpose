(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["live-tv-live-tv-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/live-tv/live-tv.page.html":
/*!***************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/live-tv/live-tv.page.html ***!
  \***************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-menu-button color=\"dark\"></ion-menu-button>\n    </ion-buttons>\n    <ion-title>Live TV</ion-title>\n\n    <ion-button slot=\"end\" size=\"small\" fill=\"clear\">\n      <ion-icon name=\"search-outline\"></ion-icon>\n    </ion-button>\n\n    <ion-button slot=\"end\" size=\"small\" fill=\"clear\">\n      <ion-icon name=\"notifications-outline\"></ion-icon>\n    </ion-button>\n\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div class=\"main_content_div\">\n        \n    <div class=\"story_div\">\n      \n      <div class=\"chips_div\">\n        <div class=\"inner_div\" *ngFor=\"let item of repoters\" (click)=\"selectLang(item.name)\">\n          <div class=\"story_img_main\" [class.story]=\"repoter == item.name\">\n            <div class=\"story_img bg_image\" [style.backgroundImage]=\"'url('+ item.img +')'\"></div>\n          </div>\n          <ion-label class=\"chip\">{{item.name | slice : 0: 10}}</ion-label>\n        </div>\n      </div>\n\n    </div>\n\n    <div class=\"video_div\">\n      <video playsinline webkit-playsinline autoplay>\n        <source src=\"assets/imgs/video.mp4\" type=\"video/mp4\">\n      </video>\n      <div class=\"channel_detail\">\n        <img src=\"assets/imgs/news_icn3.png\">\n        <ion-label class=\"channel_name\">The Times of India</ion-label>\n      </div>\n\n      <ion-label class=\"head_line\">Watch Republic Live | {{repoter}} News 24X7</ion-label>\n    </div>\n\n    <div class=\"lower_div\">\n\n      <div class=\"news_card\" *ngFor=\"let item of channelList\">\n\n        <div class=\"flex_div\">\n          <div class=\"detail_div\">\n            <div class=\"channel_detail2\">\n              <img src=\"{{item.logo}}\">\n              <ion-label class=\"channel_name\">The Times of India</ion-label> \n            </div>\n            <ion-label class=\"head_line2\">Watch Republic Live | {{repoter}} News 24X7</ion-label>\n          </div>\n          <div class=\"back_image2 bg_image\" [style.backgroundImage]=\"'url('+ item.img +')'\"></div>\n        </div>\n\n      </div>\n\n    </div>\n\n  </div>\n</ion-content>\n");

/***/ }),

/***/ "./src/app/pages/live-tv/live-tv-routing.module.ts":
/*!*********************************************************!*\
  !*** ./src/app/pages/live-tv/live-tv-routing.module.ts ***!
  \*********************************************************/
/*! exports provided: LiveTvPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LiveTvPageRoutingModule", function() { return LiveTvPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _live_tv_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./live-tv.page */ "./src/app/pages/live-tv/live-tv.page.ts");




const routes = [
    {
        path: '',
        component: _live_tv_page__WEBPACK_IMPORTED_MODULE_3__["LiveTvPage"]
    }
];
let LiveTvPageRoutingModule = class LiveTvPageRoutingModule {
};
LiveTvPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], LiveTvPageRoutingModule);



/***/ }),

/***/ "./src/app/pages/live-tv/live-tv.module.ts":
/*!*************************************************!*\
  !*** ./src/app/pages/live-tv/live-tv.module.ts ***!
  \*************************************************/
/*! exports provided: LiveTvPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LiveTvPageModule", function() { return LiveTvPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _live_tv_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./live-tv-routing.module */ "./src/app/pages/live-tv/live-tv-routing.module.ts");
/* harmony import */ var _live_tv_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./live-tv.page */ "./src/app/pages/live-tv/live-tv.page.ts");







let LiveTvPageModule = class LiveTvPageModule {
};
LiveTvPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _live_tv_routing_module__WEBPACK_IMPORTED_MODULE_5__["LiveTvPageRoutingModule"]
        ],
        declarations: [_live_tv_page__WEBPACK_IMPORTED_MODULE_6__["LiveTvPage"]]
    })
], LiveTvPageModule);



/***/ }),

/***/ "./src/app/pages/live-tv/live-tv.page.scss":
/*!*************************************************!*\
  !*** ./src/app/pages/live-tv/live-tv.page.scss ***!
  \*************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-header ion-button {\n  margin: 0;\n}\nion-header ion-button ion-icon {\n  color: black;\n  font-size: 20px;\n}\n.main_content_div .story_div {\n  padding: 16px;\n  border-bottom: 1px solid lightgray;\n}\n.main_content_div .story_div .chips_div {\n  display: flex;\n  flex-direction: row;\n  overflow: scroll;\n}\n.main_content_div .story_div .chips_div .inner_div {\n  display: flex;\n  align-items: center;\n  flex-direction: column;\n  margin-right: 15px;\n  align-items: center;\n  justify-content: space-between;\n}\n.main_content_div .story_div .chips_div .inner_div .story {\n  border: 2px solid red;\n}\n.main_content_div .story_div .chips_div .inner_div .story_img_main {\n  width: 60px;\n  height: 60px;\n  border-radius: 100%;\n  position: relative;\n}\n.main_content_div .story_div .chips_div .inner_div .story_img {\n  position: absolute;\n  top: 50%;\n  left: 50%;\n  transform: translate(-50%, -50%);\n  width: 50px;\n  height: 50px;\n  border-radius: 100%;\n}\n.main_content_div .story_div .chips_div .chip {\n  white-space: nowrap;\n  color: #505050;\n  font-size: 12px;\n  margin-top: 7px;\n}\n.main_content_div .video_div {\n  padding: 20px;\n  border-bottom: 1px solid lightgray;\n}\n.main_content_div .video_div video {\n  width: 100%;\n  border-radius: 10px;\n}\n.main_content_div .video_div .channel_detail {\n  display: flex;\n  margin-top: 15px;\n  align-items: center;\n  margin-bottom: 10px;\n}\n.main_content_div .video_div .channel_detail img {\n  width: 25px;\n}\n.main_content_div .video_div .channel_detail .channel_name {\n  font-weight: 600;\n  font-size: 15px;\n  margin-left: 10px;\n  margin-right: 10px;\n}\n.main_content_div .video_div .head_line {\n  font-weight: 500;\n  font-size: 18px;\n}\n.main_content_div .lower_div .news_card {\n  padding: 16px;\n  border-bottom: 1px solid lightgray;\n}\n.main_content_div .lower_div .news_card video {\n  width: 100%;\n  border-radius: 10px;\n}\n.main_content_div .lower_div .news_card .channel_detail {\n  display: flex;\n  margin-top: 1px;\n  align-items: center;\n  margin-bottom: 10px;\n}\n.main_content_div .lower_div .news_card .channel_detail img {\n  width: 25px;\n}\n.main_content_div .lower_div .news_card .channel_detail .channel_name {\n  font-size: 15px;\n  margin-left: 10px;\n  margin-right: 10px;\n}\n.main_content_div .lower_div .news_card .head_line {\n  font-weight: 500;\n  color: gray;\n  font-size: 18px;\n}\n.main_content_div .lower_div .news_card .flex_div {\n  display: flex;\n}\n.main_content_div .lower_div .news_card .flex_div .back_image2 {\n  height: 80px;\n  width: 80px;\n  border-radius: 5px;\n  min-width: 80px;\n}\n.main_content_div .lower_div .news_card .flex_div .detail_div {\n  padding-right: 10px;\n}\n.main_content_div .lower_div .news_card .flex_div .detail_div .channel_detail2 {\n  display: flex;\n  align-items: center;\n  margin-bottom: 10px;\n}\n.main_content_div .lower_div .news_card .flex_div .detail_div .channel_detail2 img {\n  width: 25px;\n}\n.main_content_div .lower_div .news_card .flex_div .detail_div .channel_detail2 .channel_name {\n  font-size: 14px;\n  margin-left: 10px;\n  margin-right: 10px;\n}\n.main_content_div .lower_div .news_card .flex_div .detail_div .head_line2 {\n  font-weight: 500;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvbGl2ZS10di9FOlxcSW9uaWMgUHJvamVjdHNcXGlvbmljLTUtdGVtcGxhdGUtYnVuZGxlLWlvbmljLTUtdGhlbWVzLWJ1bmRsZXMtaW9uaWMtNS10ZW1wbGF0ZXMtd2l0aC0xMC1hcHBzXFxBcHBfc291cmNlX2NvZGVcXEFwcHNfY29kZVxcTXVsdGlfcHVycG9zZS9zcmNcXGFwcFxccGFnZXNcXGxpdmUtdHZcXGxpdmUtdHYucGFnZS5zY3NzIiwic3JjL2FwcC9wYWdlcy9saXZlLXR2L2xpdmUtdHYucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNJO0VBQ0ksU0FBQTtBQ0FSO0FERVE7RUFDSSxZQUFBO0VBQ0EsZUFBQTtBQ0FaO0FES0k7RUFDSSxhQUFBO0VBQ0Esa0NBQUE7QUNGUjtBRElRO0VBQ0ksYUFBQTtFQUNBLG1CQUFBO0VBQ0EsZ0JBQUE7QUNGWjtBRElZO0VBQ0ksYUFBQTtFQUNBLG1CQUFBO0VBQ0Esc0JBQUE7RUFDQSxrQkFBQTtFQUNBLG1CQUFBO0VBQ0EsOEJBQUE7QUNGaEI7QURJZ0I7RUFDSSxxQkFBQTtBQ0ZwQjtBREtnQjtFQUNJLFdBQUE7RUFDQSxZQUFBO0VBQ0EsbUJBQUE7RUFDQSxrQkFBQTtBQ0hwQjtBREtnQjtFQUNJLGtCQUFBO0VBQ0EsUUFBQTtFQUNBLFNBQUE7RUFDQSxnQ0FBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0VBQ0EsbUJBQUE7QUNIcEI7QURPWTtFQUNJLG1CQUFBO0VBQ0EsY0FBQTtFQUNBLGVBQUE7RUFDQSxlQUFBO0FDTGhCO0FEVUk7RUFDSSxhQUFBO0VBQ0Esa0NBQUE7QUNSUjtBRFVRO0VBQ0ksV0FBQTtFQUNBLG1CQUFBO0FDUlo7QURXUTtFQUNJLGFBQUE7RUFDQSxnQkFBQTtFQUNBLG1CQUFBO0VBQ0EsbUJBQUE7QUNUWjtBRFVZO0VBQ0ksV0FBQTtBQ1JoQjtBRFVZO0VBQ0ksZ0JBQUE7RUFDQSxlQUFBO0VBQ0EsaUJBQUE7RUFDQSxrQkFBQTtBQ1JoQjtBRFlRO0VBQ0ksZ0JBQUE7RUFDQSxlQUFBO0FDVlo7QURjUTtFQUNJLGFBQUE7RUFDQSxrQ0FBQTtBQ1paO0FEY1k7RUFDSSxXQUFBO0VBQ0EsbUJBQUE7QUNaaEI7QURlWTtFQUNJLGFBQUE7RUFDQSxlQUFBO0VBQ0EsbUJBQUE7RUFDQSxtQkFBQTtBQ2JoQjtBRGNnQjtFQUNJLFdBQUE7QUNacEI7QURjZ0I7RUFDSSxlQUFBO0VBQ0EsaUJBQUE7RUFDQSxrQkFBQTtBQ1pwQjtBRGdCWTtFQUNJLGdCQUFBO0VBQ0EsV0FBQTtFQUNBLGVBQUE7QUNkaEI7QURpQlk7RUFDSSxhQUFBO0FDZmhCO0FEaUJnQjtFQUNJLFlBQUE7RUFDQSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxlQUFBO0FDZnBCO0FEa0JnQjtFQUNJLG1CQUFBO0FDaEJwQjtBRGlCb0I7RUFDSSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSxtQkFBQTtBQ2Z4QjtBRGdCd0I7RUFDSSxXQUFBO0FDZDVCO0FEZ0J3QjtFQUNJLGVBQUE7RUFDQSxpQkFBQTtFQUNBLGtCQUFBO0FDZDVCO0FEaUJvQjtFQUNJLGdCQUFBO0FDZnhCIiwiZmlsZSI6InNyYy9hcHAvcGFnZXMvbGl2ZS10di9saXZlLXR2LnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1oZWFkZXJ7XG4gICAgaW9uLWJ1dHRvbntcbiAgICAgICAgbWFyZ2luOiAwO1xuXG4gICAgICAgIGlvbi1pY29ue1xuICAgICAgICAgICAgY29sb3I6IGJsYWNrO1xuICAgICAgICAgICAgZm9udC1zaXplOiAyMHB4O1xuICAgICAgICB9XG4gICAgfVxufVxuLm1haW5fY29udGVudF9kaXZ7XG4gICAgLnN0b3J5X2RpdntcbiAgICAgICAgcGFkZGluZzogMTZweDtcbiAgICAgICAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkIGxpZ2h0Z3JheTtcbiAgICAgICAgXG4gICAgICAgIC5jaGlwc19kaXZ7XG4gICAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICAgICAgZmxleC1kaXJlY3Rpb246IHJvdztcbiAgICAgICAgICAgIG92ZXJmbG93OiBzY3JvbGw7XG5cbiAgICAgICAgICAgIC5pbm5lcl9kaXZ7XG4gICAgICAgICAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAgICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgICAgICAgICAgICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG4gICAgICAgICAgICAgICAgbWFyZ2luLXJpZ2h0OiAxNXB4O1xuICAgICAgICAgICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAgICAgICAgICAgICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xuXG4gICAgICAgICAgICAgICAgLnN0b3J5e1xuICAgICAgICAgICAgICAgICAgICBib3JkZXI6IDJweCBzb2xpZCByZWQ7XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgLnN0b3J5X2ltZ19tYWlue1xuICAgICAgICAgICAgICAgICAgICB3aWR0aDogNjBweDtcbiAgICAgICAgICAgICAgICAgICAgaGVpZ2h0OiA2MHB4O1xuICAgICAgICAgICAgICAgICAgICBib3JkZXItcmFkaXVzOiAxMDAlO1xuICAgICAgICAgICAgICAgICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIC5zdG9yeV9pbWd7XG4gICAgICAgICAgICAgICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICAgICAgICAgICAgICAgICAgdG9wOiA1MCU7XG4gICAgICAgICAgICAgICAgICAgIGxlZnQ6IDUwJTtcbiAgICAgICAgICAgICAgICAgICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUoLTUwJSwtNTAlKTtcbiAgICAgICAgICAgICAgICAgICAgd2lkdGg6IDUwcHg7XG4gICAgICAgICAgICAgICAgICAgIGhlaWdodDogNTBweDtcbiAgICAgICAgICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogMTAwJTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIC5jaGlwe1xuICAgICAgICAgICAgICAgIHdoaXRlLXNwYWNlOiBub3dyYXA7XG4gICAgICAgICAgICAgICAgY29sb3I6ICM1MDUwNTA7XG4gICAgICAgICAgICAgICAgZm9udC1zaXplOiAxMnB4O1xuICAgICAgICAgICAgICAgIG1hcmdpbi10b3A6IDdweDtcbiAgICAgICAgICAgIH0gIFxuICAgICAgICB9XG4gICAgfVxuXG4gICAgLnZpZGVvX2RpdntcbiAgICAgICAgcGFkZGluZzogMjBweDtcbiAgICAgICAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkIGxpZ2h0Z3JheTtcblxuICAgICAgICB2aWRlb3tcbiAgICAgICAgICAgIHdpZHRoOiAxMDAlO1xuICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogMTBweDtcbiAgICAgICAgfVxuXG4gICAgICAgIC5jaGFubmVsX2RldGFpbHtcbiAgICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgICAgICBtYXJnaW4tdG9wOiAxNXB4O1xuICAgICAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICAgICAgICAgIG1hcmdpbi1ib3R0b206IDEwcHg7XG4gICAgICAgICAgICBpbWd7XG4gICAgICAgICAgICAgICAgd2lkdGg6IDI1cHg7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICAuY2hhbm5lbF9uYW1le1xuICAgICAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiA2MDA7XG4gICAgICAgICAgICAgICAgZm9udC1zaXplOiAxNXB4O1xuICAgICAgICAgICAgICAgIG1hcmdpbi1sZWZ0OiAxMHB4O1xuICAgICAgICAgICAgICAgIG1hcmdpbi1yaWdodDogMTBweDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIC5oZWFkX2xpbmV7XG4gICAgICAgICAgICBmb250LXdlaWdodDogNTAwO1xuICAgICAgICAgICAgZm9udC1zaXplOiAxOHB4O1xuICAgICAgICB9XG4gICAgfVxuICAgIC5sb3dlcl9kaXZ7XG4gICAgICAgIC5uZXdzX2NhcmR7XG4gICAgICAgICAgICBwYWRkaW5nOiAxNnB4O1xuICAgICAgICAgICAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkIGxpZ2h0Z3JheTtcblxuICAgICAgICAgICAgdmlkZW97XG4gICAgICAgICAgICAgICAgd2lkdGg6IDEwMCU7XG4gICAgICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogMTBweDtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgLmNoYW5uZWxfZGV0YWlse1xuICAgICAgICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgICAgICAgICAgbWFyZ2luLXRvcDogMXB4O1xuICAgICAgICAgICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAgICAgICAgICAgICAgbWFyZ2luLWJvdHRvbTogMTBweDtcbiAgICAgICAgICAgICAgICBpbWd7XG4gICAgICAgICAgICAgICAgICAgIHdpZHRoOiAyNXB4O1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAuY2hhbm5lbF9uYW1le1xuICAgICAgICAgICAgICAgICAgICBmb250LXNpemU6IDE1cHg7XG4gICAgICAgICAgICAgICAgICAgIG1hcmdpbi1sZWZ0OiAxMHB4O1xuICAgICAgICAgICAgICAgICAgICBtYXJnaW4tcmlnaHQ6IDEwcHg7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAuaGVhZF9saW5le1xuICAgICAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiA1MDA7XG4gICAgICAgICAgICAgICAgY29sb3I6IGdyYXk7XG4gICAgICAgICAgICAgICAgZm9udC1zaXplOiAxOHB4O1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAuZmxleF9kaXZ7XG4gICAgICAgICAgICAgICAgZGlzcGxheTogZmxleDtcblxuICAgICAgICAgICAgICAgIC5iYWNrX2ltYWdlMntcbiAgICAgICAgICAgICAgICAgICAgaGVpZ2h0OiA4MHB4O1xuICAgICAgICAgICAgICAgICAgICB3aWR0aDogODBweDtcbiAgICAgICAgICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogNXB4O1xuICAgICAgICAgICAgICAgICAgICBtaW4td2lkdGg6IDgwcHg7XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgLmRldGFpbF9kaXZ7XG4gICAgICAgICAgICAgICAgICAgIHBhZGRpbmctcmlnaHQ6IDEwcHg7XG4gICAgICAgICAgICAgICAgICAgIC5jaGFubmVsX2RldGFpbDJ7XG4gICAgICAgICAgICAgICAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICAgICAgICAgICAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICAgICAgICAgICAgICAgICAgICAgIG1hcmdpbi1ib3R0b206IDEwcHg7XG4gICAgICAgICAgICAgICAgICAgICAgICBpbWd7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgd2lkdGg6IDI1cHg7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAuY2hhbm5lbF9uYW1le1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMTRweDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtYXJnaW4tbGVmdDogMTBweDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtYXJnaW4tcmlnaHQ6IDEwcHg7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgLmhlYWRfbGluZTJ7XG4gICAgICAgICAgICAgICAgICAgICAgICBmb250LXdlaWdodDogNTAwO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxufSIsImlvbi1oZWFkZXIgaW9uLWJ1dHRvbiB7XG4gIG1hcmdpbjogMDtcbn1cbmlvbi1oZWFkZXIgaW9uLWJ1dHRvbiBpb24taWNvbiB7XG4gIGNvbG9yOiBibGFjaztcbiAgZm9udC1zaXplOiAyMHB4O1xufVxuXG4ubWFpbl9jb250ZW50X2RpdiAuc3RvcnlfZGl2IHtcbiAgcGFkZGluZzogMTZweDtcbiAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkIGxpZ2h0Z3JheTtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5zdG9yeV9kaXYgLmNoaXBzX2RpdiB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGZsZXgtZGlyZWN0aW9uOiByb3c7XG4gIG92ZXJmbG93OiBzY3JvbGw7XG59XG4ubWFpbl9jb250ZW50X2RpdiAuc3RvcnlfZGl2IC5jaGlwc19kaXYgLmlubmVyX2RpdiB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG4gIG1hcmdpbi1yaWdodDogMTVweDtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xufVxuLm1haW5fY29udGVudF9kaXYgLnN0b3J5X2RpdiAuY2hpcHNfZGl2IC5pbm5lcl9kaXYgLnN0b3J5IHtcbiAgYm9yZGVyOiAycHggc29saWQgcmVkO1xufVxuLm1haW5fY29udGVudF9kaXYgLnN0b3J5X2RpdiAuY2hpcHNfZGl2IC5pbm5lcl9kaXYgLnN0b3J5X2ltZ19tYWluIHtcbiAgd2lkdGg6IDYwcHg7XG4gIGhlaWdodDogNjBweDtcbiAgYm9yZGVyLXJhZGl1czogMTAwJTtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xufVxuLm1haW5fY29udGVudF9kaXYgLnN0b3J5X2RpdiAuY2hpcHNfZGl2IC5pbm5lcl9kaXYgLnN0b3J5X2ltZyB7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgdG9wOiA1MCU7XG4gIGxlZnQ6IDUwJTtcbiAgdHJhbnNmb3JtOiB0cmFuc2xhdGUoLTUwJSwgLTUwJSk7XG4gIHdpZHRoOiA1MHB4O1xuICBoZWlnaHQ6IDUwcHg7XG4gIGJvcmRlci1yYWRpdXM6IDEwMCU7XG59XG4ubWFpbl9jb250ZW50X2RpdiAuc3RvcnlfZGl2IC5jaGlwc19kaXYgLmNoaXAge1xuICB3aGl0ZS1zcGFjZTogbm93cmFwO1xuICBjb2xvcjogIzUwNTA1MDtcbiAgZm9udC1zaXplOiAxMnB4O1xuICBtYXJnaW4tdG9wOiA3cHg7XG59XG4ubWFpbl9jb250ZW50X2RpdiAudmlkZW9fZGl2IHtcbiAgcGFkZGluZzogMjBweDtcbiAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkIGxpZ2h0Z3JheTtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC52aWRlb19kaXYgdmlkZW8ge1xuICB3aWR0aDogMTAwJTtcbiAgYm9yZGVyLXJhZGl1czogMTBweDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC52aWRlb19kaXYgLmNoYW5uZWxfZGV0YWlsIHtcbiAgZGlzcGxheTogZmxleDtcbiAgbWFyZ2luLXRvcDogMTVweDtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgbWFyZ2luLWJvdHRvbTogMTBweDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC52aWRlb19kaXYgLmNoYW5uZWxfZGV0YWlsIGltZyB7XG4gIHdpZHRoOiAyNXB4O1xufVxuLm1haW5fY29udGVudF9kaXYgLnZpZGVvX2RpdiAuY2hhbm5lbF9kZXRhaWwgLmNoYW5uZWxfbmFtZSB7XG4gIGZvbnQtd2VpZ2h0OiA2MDA7XG4gIGZvbnQtc2l6ZTogMTVweDtcbiAgbWFyZ2luLWxlZnQ6IDEwcHg7XG4gIG1hcmdpbi1yaWdodDogMTBweDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC52aWRlb19kaXYgLmhlYWRfbGluZSB7XG4gIGZvbnQtd2VpZ2h0OiA1MDA7XG4gIGZvbnQtc2l6ZTogMThweDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5sb3dlcl9kaXYgLm5ld3NfY2FyZCB7XG4gIHBhZGRpbmc6IDE2cHg7XG4gIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCBsaWdodGdyYXk7XG59XG4ubWFpbl9jb250ZW50X2RpdiAubG93ZXJfZGl2IC5uZXdzX2NhcmQgdmlkZW8ge1xuICB3aWR0aDogMTAwJTtcbiAgYm9yZGVyLXJhZGl1czogMTBweDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5sb3dlcl9kaXYgLm5ld3NfY2FyZCAuY2hhbm5lbF9kZXRhaWwge1xuICBkaXNwbGF5OiBmbGV4O1xuICBtYXJnaW4tdG9wOiAxcHg7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIG1hcmdpbi1ib3R0b206IDEwcHg7XG59XG4ubWFpbl9jb250ZW50X2RpdiAubG93ZXJfZGl2IC5uZXdzX2NhcmQgLmNoYW5uZWxfZGV0YWlsIGltZyB7XG4gIHdpZHRoOiAyNXB4O1xufVxuLm1haW5fY29udGVudF9kaXYgLmxvd2VyX2RpdiAubmV3c19jYXJkIC5jaGFubmVsX2RldGFpbCAuY2hhbm5lbF9uYW1lIHtcbiAgZm9udC1zaXplOiAxNXB4O1xuICBtYXJnaW4tbGVmdDogMTBweDtcbiAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xufVxuLm1haW5fY29udGVudF9kaXYgLmxvd2VyX2RpdiAubmV3c19jYXJkIC5oZWFkX2xpbmUge1xuICBmb250LXdlaWdodDogNTAwO1xuICBjb2xvcjogZ3JheTtcbiAgZm9udC1zaXplOiAxOHB4O1xufVxuLm1haW5fY29udGVudF9kaXYgLmxvd2VyX2RpdiAubmV3c19jYXJkIC5mbGV4X2RpdiB7XG4gIGRpc3BsYXk6IGZsZXg7XG59XG4ubWFpbl9jb250ZW50X2RpdiAubG93ZXJfZGl2IC5uZXdzX2NhcmQgLmZsZXhfZGl2IC5iYWNrX2ltYWdlMiB7XG4gIGhlaWdodDogODBweDtcbiAgd2lkdGg6IDgwcHg7XG4gIGJvcmRlci1yYWRpdXM6IDVweDtcbiAgbWluLXdpZHRoOiA4MHB4O1xufVxuLm1haW5fY29udGVudF9kaXYgLmxvd2VyX2RpdiAubmV3c19jYXJkIC5mbGV4X2RpdiAuZGV0YWlsX2RpdiB7XG4gIHBhZGRpbmctcmlnaHQ6IDEwcHg7XG59XG4ubWFpbl9jb250ZW50X2RpdiAubG93ZXJfZGl2IC5uZXdzX2NhcmQgLmZsZXhfZGl2IC5kZXRhaWxfZGl2IC5jaGFubmVsX2RldGFpbDIge1xuICBkaXNwbGF5OiBmbGV4O1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBtYXJnaW4tYm90dG9tOiAxMHB4O1xufVxuLm1haW5fY29udGVudF9kaXYgLmxvd2VyX2RpdiAubmV3c19jYXJkIC5mbGV4X2RpdiAuZGV0YWlsX2RpdiAuY2hhbm5lbF9kZXRhaWwyIGltZyB7XG4gIHdpZHRoOiAyNXB4O1xufVxuLm1haW5fY29udGVudF9kaXYgLmxvd2VyX2RpdiAubmV3c19jYXJkIC5mbGV4X2RpdiAuZGV0YWlsX2RpdiAuY2hhbm5lbF9kZXRhaWwyIC5jaGFubmVsX25hbWUge1xuICBmb250LXNpemU6IDE0cHg7XG4gIG1hcmdpbi1sZWZ0OiAxMHB4O1xuICBtYXJnaW4tcmlnaHQ6IDEwcHg7XG59XG4ubWFpbl9jb250ZW50X2RpdiAubG93ZXJfZGl2IC5uZXdzX2NhcmQgLmZsZXhfZGl2IC5kZXRhaWxfZGl2IC5oZWFkX2xpbmUyIHtcbiAgZm9udC13ZWlnaHQ6IDUwMDtcbn0iXX0= */");

/***/ }),

/***/ "./src/app/pages/live-tv/live-tv.page.ts":
/*!***********************************************!*\
  !*** ./src/app/pages/live-tv/live-tv.page.ts ***!
  \***********************************************/
/*! exports provided: LiveTvPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LiveTvPage", function() { return LiveTvPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var src_app_services_dummy_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/dummy.service */ "./src/app/services/dummy.service.ts");



let LiveTvPage = class LiveTvPage {
    constructor(dummy) {
        this.dummy = dummy;
        this.repoter = 'English';
        this.repoters = this.dummy.repoters;
        this.channelList = this.dummy.channelList;
    }
    ngOnInit() {
    }
    selectLang(val) {
        this.repoter = val;
    }
};
LiveTvPage.ctorParameters = () => [
    { type: src_app_services_dummy_service__WEBPACK_IMPORTED_MODULE_2__["DummyService"] }
];
LiveTvPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-live-tv',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./live-tv.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/live-tv/live-tv.page.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./live-tv.page.scss */ "./src/app/pages/live-tv/live-tv.page.scss")).default]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [src_app_services_dummy_service__WEBPACK_IMPORTED_MODULE_2__["DummyService"]])
], LiveTvPage);



/***/ })

}]);
//# sourceMappingURL=live-tv-live-tv-module-es2015.js.map