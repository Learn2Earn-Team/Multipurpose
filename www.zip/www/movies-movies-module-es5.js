function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["movies-movies-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/movies/movies.page.html":
  /*!*************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/movies/movies.page.html ***!
    \*************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppPagesMoviesMoviesPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar>\n    <!-- <ion-buttons slot=\"start\">\n      <ion-menu-button color=\"dark\"></ion-menu-button>\n    </ion-buttons> -->\n\n    <ion-icon class=\"back\" name=\"arrow-back-outline\" (click)=\"goBack()\"></ion-icon>\n\n    <ion-title>Movies Online</ion-title>\n\n    <ion-button (click)=\"openActionSheet()\" slot=\"end\" size=\"small\" fill=\"clear\">\n      <ion-icon name=\"ellipsis-vertical\"></ion-icon>\n    </ion-button>\n\n    <ion-button slot=\"end\" size=\"small\" fill=\"clear\">\n      <ion-icon name=\"arrow-redo-outline\"></ion-icon>\n    </ion-button>\n\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div class=\"main_content_div\">\n\n    <div class=\"search_div\">\n      <ion-input type=\"text\" placeholder=\"Search\">\n        <ion-icon name=\"search-outline\"></ion-icon>\n      </ion-input>\n    </div>\n\n    <div class=\"search_div\">\n      <div class=\"chips_div\">\n        <div class=\"test\">\n          <ion-icon name=\"funnel-outline\"></ion-icon>\n        </div>\n        <div class=\"test\" [class.active]=\"currentCat == item\" *ngFor=\"let item of moviesCat; let i = index\">\n          <ion-label class=\"chip\" (click)=\"selectCat(item)\">{{item}}</ion-label>\n          <ion-icon name=\"caret-down-outline\"></ion-icon>\n        </div>\n      </div>\n    </div>\n\n    <div class=\"lower_div\">\n\n      <div class=\"main_slider\">\n        <div class=\"head_flex\">\n          <ion-label class=\"head_lbl\">Popular</ion-label>\n          <ion-label class=\"small_lbl\" (click)=\"goToPopular()\">View More</ion-label>\n        </div>\n\n        <div class=\"slider_class\">\n          <ion-slides mode=\"ios\" [options]=\"slideOpts\">\n            <ion-slide *ngFor=\"let item of (movies | slice : 0: 7)\" (click)=\"goToMovieDetail()\">\n              <div class=\"image_div bg_image\" [style.backgroundImage]=\"'url( '+ item.img +' )'\">\n\n                <div class=\"white_div\">\n                  <ion-icon name=\"thumbs-up-sharp\"></ion-icon>\n                  <ion-label>{{item.per}}%</ion-label>\n                </div>\n\n              </div>\n            </ion-slide>\n          </ion-slides>\n        </div>\n      </div>\n\n      <div class=\"main_slider\">\n        <div class=\"head_flex\">\n          <ion-label class=\"head_lbl\">Hindi</ion-label>\n          <ion-label class=\"small_lbl\" (click)=\"goToPopular()\">View More</ion-label>\n        </div>\n\n        <div class=\"slider_class\">\n          <ion-slides mode=\"ios\" [options]=\"slideOpts\">\n            <ion-slide *ngFor=\"let item of (movies | slice : 7: 15)\" (click)=\"goToMovieDetail()\">\n              <div class=\"image_div bg_image\" [style.backgroundImage]=\"'url( '+ item.img +' )'\">\n\n                <div class=\"white_div\">\n                  <ion-icon name=\"thumbs-up-sharp\"></ion-icon>\n                  <ion-label>{{item.per}}%</ion-label>\n                </div>\n\n              </div>\n            </ion-slide>\n          </ion-slides>\n        </div>\n      </div>\n\n      <div class=\"main_slider\">\n        <div class=\"head_flex\">\n          <ion-label class=\"head_lbl\">English</ion-label>\n          <ion-label class=\"small_lbl\" (click)=\"goToPopular()\">View More</ion-label>\n        </div>\n\n        <div class=\"slider_class\">\n          <ion-slides mode=\"ios\" [options]=\"slideOpts\">\n            <ion-slide *ngFor=\"let item of (movies | slice : 11)\" (click)=\"goToMovieDetail()\">\n              <div class=\"image_div bg_image\" [style.backgroundImage]=\"'url( '+ item.img +' )'\">\n\n                <div class=\"white_div\">\n                  <ion-icon name=\"thumbs-up-sharp\"></ion-icon>\n                  <ion-label>{{item.per}}%</ion-label>\n                </div>\n\n              </div>\n            </ion-slide>\n          </ion-slides>\n        </div>\n      </div>\n\n      <div class=\"main_slider\">\n        <div class=\"head_flex\">\n          <ion-label class=\"head_lbl\">Marathi</ion-label>\n          <ion-label class=\"small_lbl\" (click)=\"goToPopular()\">View More</ion-label>\n        </div>\n\n        <div class=\"slider_class\">\n          <ion-slides mode=\"ios\" [options]=\"slideOpts\">\n            <ion-slide *ngFor=\"let item of (movies | slice : 5: 14)\" (click)=\"goToMovieDetail()\">\n              <div class=\"image_div bg_image\" [style.backgroundImage]=\"'url( '+ item.img +' )'\">\n\n                <div class=\"white_div\">\n                  <ion-icon name=\"thumbs-up-sharp\"></ion-icon>\n                  <ion-label>{{item.per}} %</ion-label>\n                </div>\n\n              </div>\n            </ion-slide>\n          </ion-slides>\n        </div>\n      </div>\n    </div>\n\n  </div>\n</ion-content>";
    /***/
  },

  /***/
  "./src/app/pages/movies/movies-routing.module.ts":
  /*!*******************************************************!*\
    !*** ./src/app/pages/movies/movies-routing.module.ts ***!
    \*******************************************************/

  /*! exports provided: MoviesPageRoutingModule */

  /***/
  function srcAppPagesMoviesMoviesRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "MoviesPageRoutingModule", function () {
      return MoviesPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _movies_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./movies.page */
    "./src/app/pages/movies/movies.page.ts");

    var routes = [{
      path: '',
      component: _movies_page__WEBPACK_IMPORTED_MODULE_3__["MoviesPage"]
    }];

    var MoviesPageRoutingModule = function MoviesPageRoutingModule() {
      _classCallCheck(this, MoviesPageRoutingModule);
    };

    MoviesPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], MoviesPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/pages/movies/movies.module.ts":
  /*!***********************************************!*\
    !*** ./src/app/pages/movies/movies.module.ts ***!
    \***********************************************/

  /*! exports provided: MoviesPageModule */

  /***/
  function srcAppPagesMoviesMoviesModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "MoviesPageModule", function () {
      return MoviesPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _movies_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./movies-routing.module */
    "./src/app/pages/movies/movies-routing.module.ts");
    /* harmony import */


    var _movies_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./movies.page */
    "./src/app/pages/movies/movies.page.ts");

    var MoviesPageModule = function MoviesPageModule() {
      _classCallCheck(this, MoviesPageModule);
    };

    MoviesPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _movies_routing_module__WEBPACK_IMPORTED_MODULE_5__["MoviesPageRoutingModule"]],
      declarations: [_movies_page__WEBPACK_IMPORTED_MODULE_6__["MoviesPage"]]
    })], MoviesPageModule);
    /***/
  },

  /***/
  "./src/app/pages/movies/movies.page.scss":
  /*!***********************************************!*\
    !*** ./src/app/pages/movies/movies.page.scss ***!
    \***********************************************/

  /*! exports provided: default */

  /***/
  function srcAppPagesMoviesMoviesPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "ion-header .back {\n  font-size: 27px;\n  margin-left: 10px;\n}\nion-header ion-button {\n  margin: 0;\n}\nion-header ion-button ion-icon {\n  color: black;\n  font-size: 20px;\n}\n.main_content_div {\n  width: 100%;\n}\n.main_content_div ion-label {\n  display: block;\n}\n.main_content_div .search_div {\n  padding: 10px 16px;\n  border-bottom: 1px solid lightgray;\n}\n.main_content_div .search_div ion-input {\n  border: 1px solid black;\n  border-radius: 25px;\n}\n.main_content_div .search_div ion-input ion-icon {\n  font-size: 20px;\n  padding-left: 10px;\n  padding-right: 5px;\n}\n.main_content_div .search_div .test {\n  display: flex;\n  align-items: center;\n  margin-right: 10px;\n  border: 1px solid lightgray;\n  background: whitesmoke;\n  border-radius: 25px;\n  padding: 5px 15px;\n}\n.main_content_div .search_div .test ion-icon {\n  font-size: 13px;\n}\n.main_content_div .search_div .active {\n  border: 1px solid var(--ion-color-primary);\n  background: rgba(17, 116, 192, 0.2);\n}\n.main_content_div .search_div .active ion-label {\n  color: var(--ion-color-primary) !important;\n}\n.main_content_div .search_div .active ion-icon {\n  color: var(--ion-color-primary);\n}\n.main_content_div .search_div .chips_div {\n  display: flex;\n  flex-direction: row;\n  overflow: scroll;\n}\n.main_content_div .search_div .chips_div .chip {\n  white-space: nowrap;\n  color: black;\n  font-size: 13px;\n  margin-right: 7px;\n}\n.main_content_div .lower_div {\n  padding: 16px;\n}\n.main_content_div .lower_div .main_slider {\n  padding-top: 10px;\n  padding-bottom: 10px;\n}\n.main_content_div .lower_div .main_slider .head_flex {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  padding-bottom: 20px;\n}\n.main_content_div .lower_div .main_slider .head_flex .head_lbl {\n  font-weight: 600;\n}\n.main_content_div .lower_div .main_slider .head_flex .small_lbl {\n  font-size: 13px;\n  color: gray;\n}\n.main_content_div .lower_div .main_slider .slider_class ion-slide {\n  height: 150px;\n  margin-right: 10px;\n}\n.main_content_div .lower_div .main_slider .slider_class .image_div {\n  width: 100%;\n  height: 150px;\n  border-radius: 5px;\n  position: relative;\n}\n.main_content_div .lower_div .main_slider .slider_class .image_div .white_div {\n  background: white;\n  border-radius: 25px;\n  display: flex;\n  position: absolute;\n  bottom: 10px;\n  right: 10px;\n  padding: 3px 6px;\n}\n.main_content_div .lower_div .main_slider .slider_class .image_div .white_div ion-icon {\n  color: #FF6B01;\n  font-size: 15px;\n  margin-right: 5px;\n}\n.main_content_div .lower_div .main_slider .slider_class .image_div .white_div ion-label {\n  font-size: 12px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvbW92aWVzL0U6XFxJb25pYyBQcm9qZWN0c1xcaW9uaWMtNS10ZW1wbGF0ZS1idW5kbGUtaW9uaWMtNS10aGVtZXMtYnVuZGxlcy1pb25pYy01LXRlbXBsYXRlcy13aXRoLTEwLWFwcHNcXEFwcF9zb3VyY2VfY29kZVxcQXBwc19jb2RlXFxNdWx0aV9wdXJwb3NlL3NyY1xcYXBwXFxwYWdlc1xcbW92aWVzXFxtb3ZpZXMucGFnZS5zY3NzIiwic3JjL2FwcC9wYWdlcy9tb3ZpZXMvbW92aWVzLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDSTtFQUNJLGVBQUE7RUFDQSxpQkFBQTtBQ0FSO0FERUk7RUFDSSxTQUFBO0FDQVI7QURFUTtFQUNJLFlBQUE7RUFDQSxlQUFBO0FDQVo7QURLQTtFQUNJLFdBQUE7QUNGSjtBRElJO0VBQ0ksY0FBQTtBQ0ZSO0FES0k7RUFDSSxrQkFBQTtFQUNBLGtDQUFBO0FDSFI7QURLUTtFQUNJLHVCQUFBO0VBQ0EsbUJBQUE7QUNIWjtBRElZO0VBQ0ksZUFBQTtFQUNBLGtCQUFBO0VBQ0Esa0JBQUE7QUNGaEI7QURNUTtFQUNJLGFBQUE7RUFDQSxtQkFBQTtFQUNBLGtCQUFBO0VBQ0EsMkJBQUE7RUFDQSxzQkFBQTtFQUNBLG1CQUFBO0VBQ0EsaUJBQUE7QUNKWjtBRE1ZO0VBQ0ksZUFBQTtBQ0poQjtBRFFRO0VBQ0ksMENBQUE7RUFDQSxtQ0FBQTtBQ05aO0FEUVk7RUFDSSwwQ0FBQTtBQ05oQjtBRFNZO0VBQ0ksK0JBQUE7QUNQaEI7QURXUTtFQUNJLGFBQUE7RUFDQSxtQkFBQTtFQUNBLGdCQUFBO0FDVFo7QURVWTtFQUNJLG1CQUFBO0VBQ0EsWUFBQTtFQUNBLGVBQUE7RUFDQSxpQkFBQTtBQ1JoQjtBRGFJO0VBQ0ksYUFBQTtBQ1hSO0FEZVE7RUFFSSxpQkFBQTtFQUNBLG9CQUFBO0FDZFo7QURnQlk7RUFDSSxhQUFBO0VBQ0EsOEJBQUE7RUFDQSxtQkFBQTtFQUNBLG9CQUFBO0FDZGhCO0FEZ0JnQjtFQUNJLGdCQUFBO0FDZHBCO0FEaUJnQjtFQUNJLGVBQUE7RUFDQSxXQUFBO0FDZnBCO0FEcUJnQjtFQUNJLGFBQUE7RUFDQSxrQkFBQTtBQ25CcEI7QURzQmdCO0VBQ0ksV0FBQTtFQUNBLGFBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0FDcEJwQjtBRHNCb0I7RUFDSSxpQkFBQTtFQUNBLG1CQUFBO0VBQ0EsYUFBQTtFQUNBLGtCQUFBO0VBQ0EsWUFBQTtFQUNBLFdBQUE7RUFDQSxnQkFBQTtBQ3BCeEI7QURxQndCO0VBQ0ksY0FBQTtFQUNBLGVBQUE7RUFDQSxpQkFBQTtBQ25CNUI7QURzQndCO0VBQ0ksZUFBQTtBQ3BCNUIiLCJmaWxlIjoic3JjL2FwcC9wYWdlcy9tb3ZpZXMvbW92aWVzLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1oZWFkZXJ7XG4gICAgLmJhY2t7XG4gICAgICAgIGZvbnQtc2l6ZTogMjdweDtcbiAgICAgICAgbWFyZ2luLWxlZnQ6IDEwcHg7XG4gICAgfVxuICAgIGlvbi1idXR0b257XG4gICAgICAgIG1hcmdpbjogMDtcblxuICAgICAgICBpb24taWNvbntcbiAgICAgICAgICAgIGNvbG9yOiBibGFjaztcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogMjBweDtcbiAgICAgICAgfVxuICAgIH1cbn1cblxuLm1haW5fY29udGVudF9kaXZ7XG4gICAgd2lkdGg6IDEwMCU7XG5cbiAgICBpb24tbGFiZWwge1xuICAgICAgICBkaXNwbGF5OiBibG9jaztcbiAgICB9XG5cbiAgICAuc2VhcmNoX2RpdntcbiAgICAgICAgcGFkZGluZzogMTBweCAxNnB4O1xuICAgICAgICBib3JkZXItYm90dG9tOiAxcHggc29saWQgbGlnaHRncmF5O1xuICAgIFxuICAgICAgICBpb24taW5wdXR7XG4gICAgICAgICAgICBib3JkZXI6IDFweCBzb2xpZCBibGFjaztcbiAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDI1cHg7XG4gICAgICAgICAgICBpb24taWNvbntcbiAgICAgICAgICAgICAgICBmb250LXNpemU6IDIwcHg7XG4gICAgICAgICAgICAgICAgcGFkZGluZy1sZWZ0OiAxMHB4O1xuICAgICAgICAgICAgICAgIHBhZGRpbmctcmlnaHQ6IDVweDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIC50ZXN0e1xuICAgICAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAgICAgICAgICBtYXJnaW4tcmlnaHQ6IDEwcHg7XG4gICAgICAgICAgICBib3JkZXI6IDFweCBzb2xpZCBsaWdodGdyYXk7XG4gICAgICAgICAgICBiYWNrZ3JvdW5kOiB3aGl0ZXNtb2tlO1xuICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogMjVweDtcbiAgICAgICAgICAgIHBhZGRpbmc6IDVweCAxNXB4O1xuXG4gICAgICAgICAgICBpb24taWNvbntcbiAgICAgICAgICAgICAgICBmb250LXNpemU6IDEzcHg7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICBcbiAgICAgICAgLmFjdGl2ZXtcbiAgICAgICAgICAgIGJvcmRlcjogMXB4IHNvbGlkIHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcbiAgICAgICAgICAgIGJhY2tncm91bmQ6IHJnYmEoMTcsMTE2LDE5MiwwLjIpO1xuICAgICAgICAgICAgXG4gICAgICAgICAgICBpb24tbGFiZWwge1xuICAgICAgICAgICAgICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSkgIWltcG9ydGFudDtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgaW9uLWljb257XG4gICAgICAgICAgICAgICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIFxuICAgICAgICAuY2hpcHNfZGl2e1xuICAgICAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAgICAgIGZsZXgtZGlyZWN0aW9uOiByb3c7XG4gICAgICAgICAgICBvdmVyZmxvdzogc2Nyb2xsO1xuICAgICAgICAgICAgLmNoaXB7XG4gICAgICAgICAgICAgICAgd2hpdGUtc3BhY2U6IG5vd3JhcDtcbiAgICAgICAgICAgICAgICBjb2xvcjogYmxhY2s7XG4gICAgICAgICAgICAgICAgZm9udC1zaXplOiAxM3B4O1xuICAgICAgICAgICAgICAgIG1hcmdpbi1yaWdodDogN3B4O1xuICAgICAgICAgICAgfSAgXG4gICAgICAgIH0gIFxuICAgIH1cblxuICAgIC5sb3dlcl9kaXZ7XG4gICAgICAgIHBhZGRpbmc6IDE2cHg7XG5cbiAgICAgICAgXG5cbiAgICAgICAgLm1haW5fc2xpZGVye1xuXG4gICAgICAgICAgICBwYWRkaW5nLXRvcDogMTBweDtcbiAgICAgICAgICAgIHBhZGRpbmctYm90dG9tOiAxMHB4O1xuICAgICAgICAgICAgXG4gICAgICAgICAgICAuaGVhZF9mbGV4e1xuICAgICAgICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgICAgICAgICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xuICAgICAgICAgICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAgICAgICAgICAgICAgcGFkZGluZy1ib3R0b206IDIwcHg7XG5cbiAgICAgICAgICAgICAgICAuaGVhZF9sYmx7XG4gICAgICAgICAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiA2MDA7XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgLnNtYWxsX2xibHtcbiAgICAgICAgICAgICAgICAgICAgZm9udC1zaXplOiAxM3B4O1xuICAgICAgICAgICAgICAgICAgICBjb2xvcjogZ3JheTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIC5zbGlkZXJfY2xhc3N7XG5cbiAgICAgICAgICAgICAgICBpb24tc2xpZGV7XG4gICAgICAgICAgICAgICAgICAgIGhlaWdodDogMTUwcHg7XG4gICAgICAgICAgICAgICAgICAgIG1hcmdpbi1yaWdodDogMTBweDtcbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAuaW1hZ2VfZGl2e1xuICAgICAgICAgICAgICAgICAgICB3aWR0aDogMTAwJTtcbiAgICAgICAgICAgICAgICAgICAgaGVpZ2h0OiAxNTBweDtcbiAgICAgICAgICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogNXB4O1xuICAgICAgICAgICAgICAgICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XG5cbiAgICAgICAgICAgICAgICAgICAgLndoaXRlX2RpdntcbiAgICAgICAgICAgICAgICAgICAgICAgIGJhY2tncm91bmQ6IHdoaXRlO1xuICAgICAgICAgICAgICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogMjVweDtcbiAgICAgICAgICAgICAgICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgICAgICAgICAgICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgICAgICAgICAgICAgICAgICAgICBib3R0b206IDEwcHg7XG4gICAgICAgICAgICAgICAgICAgICAgICByaWdodDogMTBweDtcbiAgICAgICAgICAgICAgICAgICAgICAgIHBhZGRpbmc6IDNweCA2cHg7XG4gICAgICAgICAgICAgICAgICAgICAgICBpb24taWNvbntcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2xvcjogI0ZGNkIwMTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250LXNpemU6IDE1cHg7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbWFyZ2luLXJpZ2h0OiA1cHg7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIGlvbi1sYWJlbCB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udC1zaXplOiAxMnB4O1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxufSIsImlvbi1oZWFkZXIgLmJhY2sge1xuICBmb250LXNpemU6IDI3cHg7XG4gIG1hcmdpbi1sZWZ0OiAxMHB4O1xufVxuaW9uLWhlYWRlciBpb24tYnV0dG9uIHtcbiAgbWFyZ2luOiAwO1xufVxuaW9uLWhlYWRlciBpb24tYnV0dG9uIGlvbi1pY29uIHtcbiAgY29sb3I6IGJsYWNrO1xuICBmb250LXNpemU6IDIwcHg7XG59XG5cbi5tYWluX2NvbnRlbnRfZGl2IHtcbiAgd2lkdGg6IDEwMCU7XG59XG4ubWFpbl9jb250ZW50X2RpdiBpb24tbGFiZWwge1xuICBkaXNwbGF5OiBibG9jaztcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5zZWFyY2hfZGl2IHtcbiAgcGFkZGluZzogMTBweCAxNnB4O1xuICBib3JkZXItYm90dG9tOiAxcHggc29saWQgbGlnaHRncmF5O1xufVxuLm1haW5fY29udGVudF9kaXYgLnNlYXJjaF9kaXYgaW9uLWlucHV0IHtcbiAgYm9yZGVyOiAxcHggc29saWQgYmxhY2s7XG4gIGJvcmRlci1yYWRpdXM6IDI1cHg7XG59XG4ubWFpbl9jb250ZW50X2RpdiAuc2VhcmNoX2RpdiBpb24taW5wdXQgaW9uLWljb24ge1xuICBmb250LXNpemU6IDIwcHg7XG4gIHBhZGRpbmctbGVmdDogMTBweDtcbiAgcGFkZGluZy1yaWdodDogNXB4O1xufVxuLm1haW5fY29udGVudF9kaXYgLnNlYXJjaF9kaXYgLnRlc3Qge1xuICBkaXNwbGF5OiBmbGV4O1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBtYXJnaW4tcmlnaHQ6IDEwcHg7XG4gIGJvcmRlcjogMXB4IHNvbGlkIGxpZ2h0Z3JheTtcbiAgYmFja2dyb3VuZDogd2hpdGVzbW9rZTtcbiAgYm9yZGVyLXJhZGl1czogMjVweDtcbiAgcGFkZGluZzogNXB4IDE1cHg7XG59XG4ubWFpbl9jb250ZW50X2RpdiAuc2VhcmNoX2RpdiAudGVzdCBpb24taWNvbiB7XG4gIGZvbnQtc2l6ZTogMTNweDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5zZWFyY2hfZGl2IC5hY3RpdmUge1xuICBib3JkZXI6IDFweCBzb2xpZCB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XG4gIGJhY2tncm91bmQ6IHJnYmEoMTcsIDExNiwgMTkyLCAwLjIpO1xufVxuLm1haW5fY29udGVudF9kaXYgLnNlYXJjaF9kaXYgLmFjdGl2ZSBpb24tbGFiZWwge1xuICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpICFpbXBvcnRhbnQ7XG59XG4ubWFpbl9jb250ZW50X2RpdiAuc2VhcmNoX2RpdiAuYWN0aXZlIGlvbi1pY29uIHtcbiAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5zZWFyY2hfZGl2IC5jaGlwc19kaXYge1xuICBkaXNwbGF5OiBmbGV4O1xuICBmbGV4LWRpcmVjdGlvbjogcm93O1xuICBvdmVyZmxvdzogc2Nyb2xsO1xufVxuLm1haW5fY29udGVudF9kaXYgLnNlYXJjaF9kaXYgLmNoaXBzX2RpdiAuY2hpcCB7XG4gIHdoaXRlLXNwYWNlOiBub3dyYXA7XG4gIGNvbG9yOiBibGFjaztcbiAgZm9udC1zaXplOiAxM3B4O1xuICBtYXJnaW4tcmlnaHQ6IDdweDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5sb3dlcl9kaXYge1xuICBwYWRkaW5nOiAxNnB4O1xufVxuLm1haW5fY29udGVudF9kaXYgLmxvd2VyX2RpdiAubWFpbl9zbGlkZXIge1xuICBwYWRkaW5nLXRvcDogMTBweDtcbiAgcGFkZGluZy1ib3R0b206IDEwcHg7XG59XG4ubWFpbl9jb250ZW50X2RpdiAubG93ZXJfZGl2IC5tYWluX3NsaWRlciAuaGVhZF9mbGV4IHtcbiAgZGlzcGxheTogZmxleDtcbiAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBwYWRkaW5nLWJvdHRvbTogMjBweDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5sb3dlcl9kaXYgLm1haW5fc2xpZGVyIC5oZWFkX2ZsZXggLmhlYWRfbGJsIHtcbiAgZm9udC13ZWlnaHQ6IDYwMDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5sb3dlcl9kaXYgLm1haW5fc2xpZGVyIC5oZWFkX2ZsZXggLnNtYWxsX2xibCB7XG4gIGZvbnQtc2l6ZTogMTNweDtcbiAgY29sb3I6IGdyYXk7XG59XG4ubWFpbl9jb250ZW50X2RpdiAubG93ZXJfZGl2IC5tYWluX3NsaWRlciAuc2xpZGVyX2NsYXNzIGlvbi1zbGlkZSB7XG4gIGhlaWdodDogMTUwcHg7XG4gIG1hcmdpbi1yaWdodDogMTBweDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5sb3dlcl9kaXYgLm1haW5fc2xpZGVyIC5zbGlkZXJfY2xhc3MgLmltYWdlX2RpdiB7XG4gIHdpZHRoOiAxMDAlO1xuICBoZWlnaHQ6IDE1MHB4O1xuICBib3JkZXItcmFkaXVzOiA1cHg7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5sb3dlcl9kaXYgLm1haW5fc2xpZGVyIC5zbGlkZXJfY2xhc3MgLmltYWdlX2RpdiAud2hpdGVfZGl2IHtcbiAgYmFja2dyb3VuZDogd2hpdGU7XG4gIGJvcmRlci1yYWRpdXM6IDI1cHg7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgYm90dG9tOiAxMHB4O1xuICByaWdodDogMTBweDtcbiAgcGFkZGluZzogM3B4IDZweDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5sb3dlcl9kaXYgLm1haW5fc2xpZGVyIC5zbGlkZXJfY2xhc3MgLmltYWdlX2RpdiAud2hpdGVfZGl2IGlvbi1pY29uIHtcbiAgY29sb3I6ICNGRjZCMDE7XG4gIGZvbnQtc2l6ZTogMTVweDtcbiAgbWFyZ2luLXJpZ2h0OiA1cHg7XG59XG4ubWFpbl9jb250ZW50X2RpdiAubG93ZXJfZGl2IC5tYWluX3NsaWRlciAuc2xpZGVyX2NsYXNzIC5pbWFnZV9kaXYgLndoaXRlX2RpdiBpb24tbGFiZWwge1xuICBmb250LXNpemU6IDEycHg7XG59Il19 */";
    /***/
  },

  /***/
  "./src/app/pages/movies/movies.page.ts":
  /*!*********************************************!*\
    !*** ./src/app/pages/movies/movies.page.ts ***!
    \*********************************************/

  /*! exports provided: MoviesPage */

  /***/
  function srcAppPagesMoviesMoviesPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "MoviesPage", function () {
      return MoviesPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var src_app_services_dummy_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! src/app/services/dummy.service */
    "./src/app/services/dummy.service.ts");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _movie_cat_movie_cat_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ../movie-cat/movie-cat.page */
    "./src/app/pages/movie-cat/movie-cat.page.ts");
    /* harmony import */


    var _movie_lang_movie_lang_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ../movie-lang/movie-lang.page */
    "./src/app/pages/movie-lang/movie-lang.page.ts");
    /* harmony import */


    var _movie_rating_movie_rating_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! ../movie-rating/movie-rating.page */
    "./src/app/pages/movie-rating/movie-rating.page.ts");
    /* harmony import */


    var _movie_ganres_movie_ganres_page__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! ../movie-ganres/movie-ganres.page */
    "./src/app/pages/movie-ganres/movie-ganres.page.ts");
    /* harmony import */


    var _movie_year_movie_year_page__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
    /*! ../movie-year/movie-year.page */
    "./src/app/pages/movie-year/movie-year.page.ts");
    /* harmony import */


    var _movie_plarform_movie_plarform_page__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
    /*! ../movie-plarform/movie-plarform.page */
    "./src/app/pages/movie-plarform/movie-plarform.page.ts");

    var MoviesPage = /*#__PURE__*/function () {
      function MoviesPage(dummy, router, actionSheetController, navCtrl, modalController) {
        _classCallCheck(this, MoviesPage);

        this.dummy = dummy;
        this.router = router;
        this.actionSheetController = actionSheetController;
        this.navCtrl = navCtrl;
        this.modalController = modalController;
        this.moviesCat = ['Movies', 'Languages', 'Ratings', 'Genre', 'Year', 'Platform'];
        this.slideOpts = {
          slidesPerView: 3
        };
        this.movies = this.dummy.movies;
      }

      _createClass(MoviesPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }, {
        key: "selectCat",
        value: function selectCat(val) {
          this.currentCat = val;
          console.log(this.currentCat);

          if (this.currentCat === 'Movies') {
            this.openMovieCat();
          }

          if (this.currentCat === 'Languages') {
            this.openMovieLang();
          }

          if (this.currentCat === 'Ratings') {
            this.openMovieRate();
          }

          if (this.currentCat === 'Genre') {
            this.openMovieGenre();
          }

          if (this.currentCat === 'Year') {
            this.openMovieYear();
          }

          if (this.currentCat === 'Platform') {
            this.openMoviePlat();
          }
        }
      }, {
        key: "openActionSheet",
        value: function openActionSheet() {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
            var actionSheet;
            return regeneratorRuntime.wrap(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    _context.next = 2;
                    return this.actionSheetController.create({
                      mode: 'md',
                      buttons: [{
                        text: 'About Movies Online',
                        icon: 'caret-forward-circle-outline'
                      }, {
                        text: 'How to Use',
                        icon: 'help-circle-outline'
                      }, {
                        text: 'FAQs',
                        icon: 'alert-circle-outline'
                      }, {
                        text: 'Blogs',
                        icon: 'document-text-outline'
                      }]
                    });

                  case 2:
                    actionSheet = _context.sent;
                    _context.next = 5;
                    return actionSheet.present();

                  case 5:
                  case "end":
                    return _context.stop();
                }
              }
            }, _callee, this);
          }));
        }
      }, {
        key: "goToPopular",
        value: function goToPopular() {
          this.router.navigate(['/tabs/popular']);
        }
      }, {
        key: "goToMovieDetail",
        value: function goToMovieDetail() {
          this.router.navigate(['/tabs/movie-details']);
        }
      }, {
        key: "goBack",
        value: function goBack() {
          this.navCtrl.back();
        }
      }, {
        key: "openMovieCat",
        value: function openMovieCat() {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
            var modal;
            return regeneratorRuntime.wrap(function _callee2$(_context2) {
              while (1) {
                switch (_context2.prev = _context2.next) {
                  case 0:
                    _context2.next = 2;
                    return this.modalController.create({
                      component: _movie_cat_movie_cat_page__WEBPACK_IMPORTED_MODULE_5__["MovieCatPage"],
                      cssClass: 'transparent_modal'
                    });

                  case 2:
                    modal = _context2.sent;
                    _context2.next = 5;
                    return modal.present();

                  case 5:
                    return _context2.abrupt("return", _context2.sent);

                  case 6:
                  case "end":
                    return _context2.stop();
                }
              }
            }, _callee2, this);
          }));
        }
      }, {
        key: "openMovieLang",
        value: function openMovieLang() {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
            var modal;
            return regeneratorRuntime.wrap(function _callee3$(_context3) {
              while (1) {
                switch (_context3.prev = _context3.next) {
                  case 0:
                    _context3.next = 2;
                    return this.modalController.create({
                      component: _movie_lang_movie_lang_page__WEBPACK_IMPORTED_MODULE_6__["MovieLangPage"],
                      cssClass: 'transparent_modal'
                    });

                  case 2:
                    modal = _context3.sent;
                    _context3.next = 5;
                    return modal.present();

                  case 5:
                    return _context3.abrupt("return", _context3.sent);

                  case 6:
                  case "end":
                    return _context3.stop();
                }
              }
            }, _callee3, this);
          }));
        }
      }, {
        key: "openMovieRate",
        value: function openMovieRate() {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee4() {
            var modal;
            return regeneratorRuntime.wrap(function _callee4$(_context4) {
              while (1) {
                switch (_context4.prev = _context4.next) {
                  case 0:
                    _context4.next = 2;
                    return this.modalController.create({
                      component: _movie_rating_movie_rating_page__WEBPACK_IMPORTED_MODULE_7__["MovieRatingPage"],
                      cssClass: 'transparent_modal'
                    });

                  case 2:
                    modal = _context4.sent;
                    _context4.next = 5;
                    return modal.present();

                  case 5:
                    return _context4.abrupt("return", _context4.sent);

                  case 6:
                  case "end":
                    return _context4.stop();
                }
              }
            }, _callee4, this);
          }));
        }
      }, {
        key: "openMovieGenre",
        value: function openMovieGenre() {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee5() {
            var modal;
            return regeneratorRuntime.wrap(function _callee5$(_context5) {
              while (1) {
                switch (_context5.prev = _context5.next) {
                  case 0:
                    _context5.next = 2;
                    return this.modalController.create({
                      component: _movie_ganres_movie_ganres_page__WEBPACK_IMPORTED_MODULE_8__["MovieGanresPage"],
                      cssClass: 'transparent_modal'
                    });

                  case 2:
                    modal = _context5.sent;
                    _context5.next = 5;
                    return modal.present();

                  case 5:
                    return _context5.abrupt("return", _context5.sent);

                  case 6:
                  case "end":
                    return _context5.stop();
                }
              }
            }, _callee5, this);
          }));
        }
      }, {
        key: "openMovieYear",
        value: function openMovieYear() {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee6() {
            var modal;
            return regeneratorRuntime.wrap(function _callee6$(_context6) {
              while (1) {
                switch (_context6.prev = _context6.next) {
                  case 0:
                    _context6.next = 2;
                    return this.modalController.create({
                      component: _movie_year_movie_year_page__WEBPACK_IMPORTED_MODULE_9__["MovieYearPage"],
                      cssClass: 'transparent_modal'
                    });

                  case 2:
                    modal = _context6.sent;
                    _context6.next = 5;
                    return modal.present();

                  case 5:
                    return _context6.abrupt("return", _context6.sent);

                  case 6:
                  case "end":
                    return _context6.stop();
                }
              }
            }, _callee6, this);
          }));
        }
      }, {
        key: "openMoviePlat",
        value: function openMoviePlat() {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee7() {
            var modal;
            return regeneratorRuntime.wrap(function _callee7$(_context7) {
              while (1) {
                switch (_context7.prev = _context7.next) {
                  case 0:
                    _context7.next = 2;
                    return this.modalController.create({
                      component: _movie_plarform_movie_plarform_page__WEBPACK_IMPORTED_MODULE_10__["MoviePlarformPage"],
                      cssClass: 'transparent_modal'
                    });

                  case 2:
                    modal = _context7.sent;
                    _context7.next = 5;
                    return modal.present();

                  case 5:
                    return _context7.abrupt("return", _context7.sent);

                  case 6:
                  case "end":
                    return _context7.stop();
                }
              }
            }, _callee7, this);
          }));
        }
      }]);

      return MoviesPage;
    }();

    MoviesPage.ctorParameters = function () {
      return [{
        type: src_app_services_dummy_service__WEBPACK_IMPORTED_MODULE_2__["DummyService"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ActionSheetController"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["NavController"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ModalController"]
      }];
    };

    MoviesPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-movies',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./movies.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/movies/movies.page.html"))["default"],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./movies.page.scss */
      "./src/app/pages/movies/movies.page.scss"))["default"]]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [src_app_services_dummy_service__WEBPACK_IMPORTED_MODULE_2__["DummyService"], _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ActionSheetController"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["NavController"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ModalController"]])], MoviesPage);
    /***/
  }
}]);
//# sourceMappingURL=movies-movies-module-es5.js.map