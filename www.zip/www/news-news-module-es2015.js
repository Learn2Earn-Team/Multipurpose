(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["news-news-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/news/news.page.html":
/*!*********************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/news/news.page.html ***!
  \*********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar *ngIf=\"category != 'News'\">\n    <ion-buttons slot=\"start\">\n      <ion-menu-button color=\"dark\"></ion-menu-button>\n    </ion-buttons>\n    <ion-title>News</ion-title>\n\n    <ion-button slot=\"end\" size=\"small\" fill=\"clear\">\n      <ion-icon name=\"search-outline\"></ion-icon>\n    </ion-button>\n\n    <ion-button (click)=\"goToNotification()\" slot=\"end\" size=\"small\" fill=\"clear\">\n      <ion-icon name=\"notifications-outline\"></ion-icon>\n    </ion-button>\n\n  </ion-toolbar>\n\n  <div class=\"header_div\" *ngIf=\"category == 'News'\" [class.ios_pad]=\"plt == 'ios'\">\n\n    <ion-buttons slot=\"start\">\n      <ion-menu-button></ion-menu-button>\n    </ion-buttons>\n    <img src=\"assets/imgs/logo.png\" alt=\"\">\n\n    <div class=\"btn_div\">\n\n      <ion-button size=\"small\" fill=\"clear\">\n        <ion-icon name=\"arrow-redo-outline\"></ion-icon>\n      </ion-button>\n\n      <ion-button size=\"small\" fill=\"clear\">\n        <ion-icon name=\"notifications-outline\"></ion-icon>\n      </ion-button>\n\n    </div>\n\n  </div>\n\n</ion-header>\n\n<ion-content>\n\n  <div class=\"add_icon\" (click)=\"goToLiveTv()\">\n    <ion-label>Live TV</ion-label>\n  </div>\n\n  <div class=\"main_content_div\">\n\n    <div class=\"search_div\" *ngIf=\"category == 'News'\">\n      <ion-input type=\"text\" placeholder=\"Search\">\n        <ion-icon name=\"search-outline\"></ion-icon>\n      </ion-input>\n    </div>\n\n    <div class=\"search_div\" *ngIf=\"category == 'News'\">\n      <div class=\"chips_div\">\n        <div class=\"test\" [class.active]=\"currentCat == i\" *ngFor=\"let item of moviesCat; let i = index\">\n          <ion-label class=\"chip\" (click)=\"selectCat(item)\">{{item}}</ion-label>\n          <span class=\"line_span\" *ngIf=\"currentCat == item\"></span>\n        </div>\n      </div>\n    </div>\n\n    <div class=\"story_div\" *ngIf=\"category != 'News'\">\n      <div class=\"chips_div\">\n\n        <div class=\"inner_div\">\n          <div class=\"story_img_main\">\n            <div class=\"fill_div\">\n              <img src=\"assets/imgs/mystory.png\" alt=\"\">\n            </div>\n          </div>\n          <ion-label class=\"chip\">For You</ion-label>\n        </div>\n\n        <div class=\"inner_div\" *ngFor=\"let item of stories\">\n          <div class=\"story_img bg_image\" [style.backgroundImage]=\"'url('+ item.img +')'\"></div>\n          <ion-label class=\"chip\">{{item.name | slice : 0: 10}}</ion-label>\n        </div>\n      </div>\n    </div>\n\n    <div class=\"lang_div\" *ngIf=\"category != 'News'\">\n      <div class=\"chips_div\">\n        <div class=\"test\" [class.active]=\"currentLang == i\" *ngFor=\"let item of lang; let i = index\">\n          <ion-label class=\"chip\" (click)=\"selectLang(i)\">{{item}}</ion-label>\n        </div>\n      </div>\n    </div>\n\n    <div class=\"lower_div\">\n\n      <div class=\"news_card\">\n\n        <div class=\"back_image bg_image\" [style.backgroundImage]=\"'url(assets/imgs/news3.jpg)'\"></div>\n\n        <div class=\"channel_detail\">\n          <img src=\"assets/imgs/news_icn2.png\">\n          <ion-label class=\"channel_name\">The Times of India</ion-label>\n        </div>\n\n        <ion-label class=\"head_line\">What is Lorem Ipsum, Lorem Ipsum is simply dummy text of the printing</ion-label>\n\n        <div class=\"share_div\">\n          <div class=\"left_div\">\n            <ion-label class=\"link_lbl\">10 minutes</ion-label>\n          </div>\n          <div class=\"right_div\">\n            <div class=\"round_div\" style=\"margin-right: 0px;\" (click)=\"shareActionSheet()\">\n              <ion-icon name=\"arrow-redo-outline\"></ion-icon>\n            </div>\n            <div class=\"round_div\" style=\"margin-right: 0px;\">\n              <ion-icon name=\"headset-outline\"></ion-icon>\n            </div>\n            <div class=\"round_div\" style=\"margin-right: 0px;\">\n              <ion-icon name=\"document-text-outline\" class=\"cpy\"></ion-icon>\n            </div>\n            <div class=\"round_div\" style=\"margin-right: 0px;\" (click)=\"presentActionSheet()\">\n              <ion-icon name=\"ellipsis-vertical\"></ion-icon>\n            </div>\n          </div>\n        </div>\n\n      </div>\n\n      <div class=\"news_card\" *ngFor=\"let item of allNews\">\n\n        <div class=\"flex_div\">\n\n          <div class=\"detail_div\">\n            <div class=\"channel_detail2\">\n              <img src=\"{{item.logo}}\">\n              <ion-label class=\"channel_name\">The Times of India</ion-label>\n            </div>\n            <ion-label class=\"head_line2\">{{item.headline}}</ion-label>\n          </div>\n\n          <div class=\"back_image2 bg_image\" [style.backgroundImage]=\"'url('+ item.img +')'\"></div>\n\n        </div>\n\n        <div class=\"share_div\">\n          <div class=\"left_div\">\n            <ion-label class=\"link_lbl\">20 minutes</ion-label>\n          </div>\n          <div class=\"right_div\">\n            <div class=\"round_div\" style=\"margin-right: 0px;\" (click)=\"shareActionSheet()\">\n              <ion-icon name=\"arrow-redo-outline\"></ion-icon>\n            </div>\n            <div class=\"round_div\" style=\"margin-right: 0px;\">\n              <ion-icon name=\"headset-outline\"></ion-icon>\n            </div>\n            <div class=\"round_div\" style=\"margin-right: 0px;\">\n              <ion-icon name=\"document-text-outline\" class=\"cpy\"></ion-icon>\n            </div>\n            <div class=\"round_div\" style=\"margin-right: 0px;\" (click)=\"presentActionSheet()\">\n              <ion-icon name=\"ellipsis-vertical\"></ion-icon>\n            </div>\n          </div>\n        </div>\n\n      </div>\n\n    </div>\n\n  </div>\n</ion-content>");

/***/ }),

/***/ "./src/app/pages/news/news-routing.module.ts":
/*!***************************************************!*\
  !*** ./src/app/pages/news/news-routing.module.ts ***!
  \***************************************************/
/*! exports provided: NewsPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NewsPageRoutingModule", function() { return NewsPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _news_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./news.page */ "./src/app/pages/news/news.page.ts");




const routes = [
    {
        path: '',
        component: _news_page__WEBPACK_IMPORTED_MODULE_3__["NewsPage"]
    }
];
let NewsPageRoutingModule = class NewsPageRoutingModule {
};
NewsPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], NewsPageRoutingModule);



/***/ }),

/***/ "./src/app/pages/news/news.module.ts":
/*!*******************************************!*\
  !*** ./src/app/pages/news/news.module.ts ***!
  \*******************************************/
/*! exports provided: NewsPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NewsPageModule", function() { return NewsPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _news_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./news-routing.module */ "./src/app/pages/news/news-routing.module.ts");
/* harmony import */ var _news_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./news.page */ "./src/app/pages/news/news.page.ts");







let NewsPageModule = class NewsPageModule {
};
NewsPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _news_routing_module__WEBPACK_IMPORTED_MODULE_5__["NewsPageRoutingModule"]
        ],
        declarations: [_news_page__WEBPACK_IMPORTED_MODULE_6__["NewsPage"]]
    })
], NewsPageModule);



/***/ }),

/***/ "./src/app/pages/news/news.page.scss":
/*!*******************************************!*\
  !*** ./src/app/pages/news/news.page.scss ***!
  \*******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-header ion-button {\n  margin: 0;\n}\nion-header ion-button ion-icon {\n  color: black;\n  font-size: 20px;\n}\n.header_div {\n  width: 100%;\n  display: flex;\n  justify-content: space-between;\n  position: relative;\n  padding: 5px;\n}\n.header_div img {\n  width: 100px;\n  position: absolute;\n  left: 50%;\n  transform: translate(-50%);\n}\n.header_div .btn_div {\n  display: flex;\n}\n.header_div ion-button {\n  color: black;\n}\n.add_icon {\n  background: #ff6b01;\n  height: 50px;\n  width: 50px;\n  z-index: 999;\n  border-radius: 100%;\n  position: fixed;\n  bottom: 90px;\n  right: 20px;\n}\n.add_icon ion-label {\n  color: white;\n  font-size: 11px;\n  position: absolute;\n  top: 50%;\n  left: 50%;\n  transform: translate(-50%, -50%);\n  font-weight: 600;\n  width: 100%;\n  text-align: center;\n}\n.main_content_div .search_div {\n  padding: 10px 16px;\n  border-bottom: 1px solid lightgray;\n}\n.main_content_div .search_div ion-input {\n  border: 1px solid black;\n  border-radius: 25px;\n}\n.main_content_div .search_div ion-input ion-icon {\n  font-size: 20px;\n  padding-left: 10px;\n  padding-right: 5px;\n}\n.main_content_div .search_div .test {\n  display: flex;\n  align-items: center;\n  margin-right: 10px;\n  border-radius: 25px;\n  padding: 5px 15px;\n  flex-direction: column;\n}\n.main_content_div .search_div .test ion-icon {\n  font-size: 26px;\n  color: var(--ion-color-primary);\n}\n.main_content_div .search_div .active ion-label {\n  color: var(--ion-color-primary) !important;\n}\n.main_content_div .search_div .chips_div {\n  display: flex;\n  flex-direction: row;\n  overflow: scroll;\n}\n.main_content_div .search_div .chips_div .chip {\n  white-space: nowrap;\n  color: black;\n  font-size: 13px;\n  font-weight: 500;\n}\n.main_content_div .search_div .chips_div .line_span {\n  margin-top: 7px;\n  width: 20px;\n  height: 2px;\n  background: var(--ion-color-primary);\n}\n.main_content_div .story_div {\n  padding: 16px;\n  border-bottom: 1px solid lightgray;\n}\n.main_content_div .story_div .chips_div {\n  display: flex;\n  flex-direction: row;\n  overflow: scroll;\n}\n.main_content_div .story_div .chips_div .inner_div {\n  display: flex;\n  align-items: center;\n  flex-direction: column;\n  margin-right: 15px;\n  align-items: center;\n  justify-content: space-between;\n}\n.main_content_div .story_div .chips_div .inner_div .story_img_main {\n  width: 60px;\n  height: 60px;\n  border-radius: 100%;\n  border: 2px solid red;\n  position: relative;\n}\n.main_content_div .story_div .chips_div .inner_div .story_img_main .fill_div {\n  width: 50px;\n  height: 50px;\n  border-radius: 100%;\n  background: #3b2a52;\n  position: absolute;\n  top: 50%;\n  left: 50%;\n  transform: translate(-50%, -50%);\n}\n.main_content_div .story_div .chips_div .inner_div .story_img_main .fill_div img {\n  width: 25px;\n  position: absolute;\n  top: 50%;\n  left: 50%;\n  transform: translate(-50%, -50%);\n}\n.main_content_div .story_div .chips_div .inner_div .story_img {\n  width: 60px;\n  height: 60px;\n  border-radius: 100%;\n}\n.main_content_div .story_div .chips_div .chip {\n  white-space: nowrap;\n  color: #505050;\n  font-size: 12px;\n  margin-top: 10px;\n}\n.main_content_div .lang_div {\n  padding: 10px 16px;\n  border-bottom: 1px solid lightgray;\n}\n.main_content_div .lang_div .test {\n  display: flex;\n  align-items: center;\n  margin-right: 10px;\n  border: 1px solid lightgray;\n  background: whitesmoke;\n  border-radius: 25px;\n  padding: 5px 15px;\n}\n.main_content_div .lang_div .active {\n  border: 1px solid var(--ion-color-primary);\n  background: rgba(17, 116, 192, 0.2);\n}\n.main_content_div .lang_div .active ion-label {\n  color: var(--ion-color-primary) !important;\n}\n.main_content_div .lang_div .chips_div {\n  display: flex;\n  flex-direction: row;\n  overflow: scroll;\n}\n.main_content_div .lang_div .chips_div .chip {\n  white-space: nowrap;\n  color: black;\n  font-size: 13px;\n}\n.main_content_div .lower_div .news_card {\n  padding: 16px;\n  border-bottom: 1px solid lightgray;\n}\n.main_content_div .lower_div .news_card .back_image {\n  width: 100%;\n  height: 180px;\n  border-radius: 10px;\n}\n.main_content_div .lower_div .news_card video {\n  width: 100%;\n  border-radius: 10px;\n}\n.main_content_div .lower_div .news_card .channel_detail {\n  display: flex;\n  margin-top: 1px;\n  align-items: center;\n  margin-bottom: 10px;\n}\n.main_content_div .lower_div .news_card .channel_detail img {\n  width: 25px;\n}\n.main_content_div .lower_div .news_card .channel_detail .channel_name {\n  font-size: 15px;\n  margin-left: 10px;\n  margin-right: 10px;\n}\n.main_content_div .lower_div .news_card .head_line {\n  font-weight: 500;\n  color: gray;\n  font-size: 18px;\n}\n.main_content_div .lower_div .news_card .share_div {\n  display: flex;\n  width: 100%;\n  justify-content: space-between;\n  align-items: center;\n}\n.main_content_div .lower_div .news_card .share_div .left_div .link_lbl {\n  font-size: 13px;\n  color: gray;\n}\n.main_content_div .lower_div .news_card .share_div .right_div {\n  display: flex;\n  align-items: center;\n}\n.main_content_div .lower_div .news_card .share_div .right_div ion-button {\n  margin: 0;\n}\n.main_content_div .lower_div .news_card .share_div .right_div ion-button ion-icon {\n  color: #505050;\n}\n.main_content_div .lower_div .news_card .share_div .round_div {\n  height: 40px;\n  width: 40px;\n  border-radius: 100%;\n  position: relative;\n  margin-right: 10px;\n}\n.main_content_div .lower_div .news_card .share_div .round_div ion-icon {\n  position: absolute;\n  top: 50%;\n  left: 50%;\n  transform: translate(-50%, -50%);\n  font-size: 18px;\n  color: #505050;\n}\n.main_content_div .lower_div .news_card .share_div .round_div .cpy {\n  color: #FF6B01;\n}\n.main_content_div .lower_div .news_card .flex_div {\n  display: flex;\n}\n.main_content_div .lower_div .news_card .flex_div .back_image2 {\n  height: 100px;\n  width: 100px;\n  border-radius: 5px;\n  min-width: 100px;\n}\n.main_content_div .lower_div .news_card .flex_div .detail_div .channel_detail2 {\n  display: flex;\n  align-items: center;\n  margin-bottom: 10px;\n}\n.main_content_div .lower_div .news_card .flex_div .detail_div .channel_detail2 img {\n  width: 25px;\n}\n.main_content_div .lower_div .news_card .flex_div .detail_div .channel_detail2 .channel_name {\n  font-size: 14px;\n  margin-left: 10px;\n  margin-right: 10px;\n}\n.main_content_div .lower_div .news_card .flex_div .detail_div .head_line2 {\n  font-weight: 500;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvbmV3cy9FOlxcSW9uaWMgUHJvamVjdHNcXGlvbmljLTUtdGVtcGxhdGUtYnVuZGxlLWlvbmljLTUtdGhlbWVzLWJ1bmRsZXMtaW9uaWMtNS10ZW1wbGF0ZXMtd2l0aC0xMC1hcHBzXFxBcHBfc291cmNlX2NvZGVcXEFwcHNfY29kZVxcTXVsdGlfcHVycG9zZS9zcmNcXGFwcFxccGFnZXNcXG5ld3NcXG5ld3MucGFnZS5zY3NzIiwic3JjL2FwcC9wYWdlcy9uZXdzL25ld3MucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNJO0VBQ0ksU0FBQTtBQ0FSO0FERVE7RUFDSSxZQUFBO0VBQ0EsZUFBQTtBQ0FaO0FES0E7RUFDSSxXQUFBO0VBQ0EsYUFBQTtFQUNBLDhCQUFBO0VBQ0Esa0JBQUE7RUFDQSxZQUFBO0FDRko7QURHSTtFQUNJLFlBQUE7RUFDQSxrQkFBQTtFQUNBLFNBQUE7RUFDQSwwQkFBQTtBQ0RSO0FER0k7RUFDSSxhQUFBO0FDRFI7QURHSTtFQUNJLFlBQUE7QUNEUjtBREtBO0VBQ0ksbUJBQUE7RUFDQSxZQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7RUFDQSxtQkFBQTtFQUNBLGVBQUE7RUFDQSxZQUFBO0VBQ0EsV0FBQTtBQ0ZKO0FESUk7RUFDSSxZQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0VBQ0EsUUFBQTtFQUNBLFNBQUE7RUFDQSxnQ0FBQTtFQUNBLGdCQUFBO0VBQ0EsV0FBQTtFQUNBLGtCQUFBO0FDRlI7QURRSTtFQUNJLGtCQUFBO0VBQ0Esa0NBQUE7QUNMUjtBRE9RO0VBQ0ksdUJBQUE7RUFDQSxtQkFBQTtBQ0xaO0FETVk7RUFDSSxlQUFBO0VBQ0Esa0JBQUE7RUFDQSxrQkFBQTtBQ0poQjtBRFFRO0VBQ0ksYUFBQTtFQUNBLG1CQUFBO0VBQ0Esa0JBQUE7RUFDQSxtQkFBQTtFQUNBLGlCQUFBO0VBQ0Esc0JBQUE7QUNOWjtBRFFZO0VBQ0ksZUFBQTtFQUNBLCtCQUFBO0FDTmhCO0FEV1k7RUFDSSwwQ0FBQTtBQ1RoQjtBRGFRO0VBQ0ksYUFBQTtFQUNBLG1CQUFBO0VBQ0EsZ0JBQUE7QUNYWjtBRFlZO0VBQ0ksbUJBQUE7RUFDQSxZQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0FDVmhCO0FEYVk7RUFDSSxlQUFBO0VBQ0EsV0FBQTtFQUNBLFdBQUE7RUFDQSxvQ0FBQTtBQ1hoQjtBRGdCSTtFQUNJLGFBQUE7RUFDQSxrQ0FBQTtBQ2RSO0FEZ0JRO0VBQ0ksYUFBQTtFQUNBLG1CQUFBO0VBQ0EsZ0JBQUE7QUNkWjtBRGdCWTtFQUNJLGFBQUE7RUFDQSxtQkFBQTtFQUNBLHNCQUFBO0VBQ0Esa0JBQUE7RUFDQSxtQkFBQTtFQUNBLDhCQUFBO0FDZGhCO0FEZWdCO0VBQ0ksV0FBQTtFQUNBLFlBQUE7RUFDQSxtQkFBQTtFQUNBLHFCQUFBO0VBQ0Esa0JBQUE7QUNicEI7QURlb0I7RUFDSSxXQUFBO0VBQ0EsWUFBQTtFQUNBLG1CQUFBO0VBQ0EsbUJBQUE7RUFDQSxrQkFBQTtFQUNBLFFBQUE7RUFDQSxTQUFBO0VBQ0EsZ0NBQUE7QUNieEI7QURld0I7RUFDSSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxRQUFBO0VBQ0EsU0FBQTtFQUNBLGdDQUFBO0FDYjVCO0FEaUJnQjtFQUNJLFdBQUE7RUFDQSxZQUFBO0VBQ0EsbUJBQUE7QUNmcEI7QURtQlk7RUFDSSxtQkFBQTtFQUNBLGNBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7QUNqQmhCO0FEc0JJO0VBQ0ksa0JBQUE7RUFDQSxrQ0FBQTtBQ3BCUjtBRHNCUTtFQUNJLGFBQUE7RUFDQSxtQkFBQTtFQUNBLGtCQUFBO0VBQ0EsMkJBQUE7RUFDQSxzQkFBQTtFQUNBLG1CQUFBO0VBQ0EsaUJBQUE7QUNwQlo7QUR1QlE7RUFDSSwwQ0FBQTtFQUNBLG1DQUFBO0FDckJaO0FEdUJZO0VBQ0ksMENBQUE7QUNyQmhCO0FEeUJRO0VBQ0ksYUFBQTtFQUNBLG1CQUFBO0VBQ0EsZ0JBQUE7QUN2Qlo7QUR3Qlk7RUFDSSxtQkFBQTtFQUNBLFlBQUE7RUFDQSxlQUFBO0FDdEJoQjtBRDRCUTtFQUNJLGFBQUE7RUFDQSxrQ0FBQTtBQzFCWjtBRDRCWTtFQUNJLFdBQUE7RUFDQSxhQUFBO0VBQ0EsbUJBQUE7QUMxQmhCO0FENkJZO0VBQ0ksV0FBQTtFQUNBLG1CQUFBO0FDM0JoQjtBRDhCWTtFQUNJLGFBQUE7RUFDQSxlQUFBO0VBQ0EsbUJBQUE7RUFDQSxtQkFBQTtBQzVCaEI7QUQ2QmdCO0VBQ0ksV0FBQTtBQzNCcEI7QUQ2QmdCO0VBQ0ksZUFBQTtFQUNBLGlCQUFBO0VBQ0Esa0JBQUE7QUMzQnBCO0FEK0JZO0VBQ0ksZ0JBQUE7RUFDQSxXQUFBO0VBQ0EsZUFBQTtBQzdCaEI7QURnQ1k7RUFDSSxhQUFBO0VBQ0EsV0FBQTtFQUNBLDhCQUFBO0VBQ0EsbUJBQUE7QUM5QmhCO0FEa0NvQjtFQUNJLGVBQUE7RUFDQSxXQUFBO0FDaEN4QjtBRG9DZ0I7RUFDSSxhQUFBO0VBQ0EsbUJBQUE7QUNsQ3BCO0FEbUNvQjtFQUNJLFNBQUE7QUNqQ3hCO0FEbUN3QjtFQUNJLGNBQUE7QUNqQzVCO0FEc0NnQjtFQUVJLFlBQUE7RUFDQSxXQUFBO0VBQ0EsbUJBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0FDckNwQjtBRHNDb0I7RUFDSSxrQkFBQTtFQUNBLFFBQUE7RUFDQSxTQUFBO0VBQ0EsZ0NBQUE7RUFDQSxlQUFBO0VBQ0EsY0FBQTtBQ3BDeEI7QURzQ29CO0VBQ0ksY0FBQTtBQ3BDeEI7QUR5Q1k7RUFDSSxhQUFBO0FDdkNoQjtBRHlDZ0I7RUFDSSxhQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7QUN2Q3BCO0FEMkNvQjtFQUNJLGFBQUE7RUFDQSxtQkFBQTtFQUNBLG1CQUFBO0FDekN4QjtBRDBDd0I7RUFDSSxXQUFBO0FDeEM1QjtBRDBDd0I7RUFDSSxlQUFBO0VBQ0EsaUJBQUE7RUFDQSxrQkFBQTtBQ3hDNUI7QUQyQ29CO0VBQ0ksZ0JBQUE7QUN6Q3hCIiwiZmlsZSI6InNyYy9hcHAvcGFnZXMvbmV3cy9uZXdzLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1oZWFkZXJ7XG4gICAgaW9uLWJ1dHRvbntcbiAgICAgICAgbWFyZ2luOiAwO1xuXG4gICAgICAgIGlvbi1pY29ue1xuICAgICAgICAgICAgY29sb3I6IGJsYWNrO1xuICAgICAgICAgICAgZm9udC1zaXplOiAyMHB4O1xuICAgICAgICB9XG4gICAgfVxufVxuXG4uaGVhZGVyX2RpdntcbiAgICB3aWR0aDogMTAwJTtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gICAgcGFkZGluZzogNXB4O1xuICAgIGltZ3tcbiAgICAgICAgd2lkdGg6IDEwMHB4O1xuICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgICAgIGxlZnQ6IDUwJTtcbiAgICAgICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUoLTUwJSk7XG4gICAgfVxuICAgIC5idG5fZGl2e1xuICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgIH1cbiAgICBpb24tYnV0dG9ue1xuICAgICAgICBjb2xvcjogYmxhY2s7XG4gICAgfVxufVxuXG4uYWRkX2ljb257XG4gICAgYmFja2dyb3VuZDogI2ZmNmIwMTtcbiAgICBoZWlnaHQ6IDUwcHg7XG4gICAgd2lkdGg6IDUwcHg7XG4gICAgei1pbmRleDogOTk5O1xuICAgIGJvcmRlci1yYWRpdXM6IDEwMCU7XG4gICAgcG9zaXRpb246IGZpeGVkO1xuICAgIGJvdHRvbTogOTBweDtcbiAgICByaWdodDogMjBweDtcblxuICAgIGlvbi1sYWJlbCB7XG4gICAgICAgIGNvbG9yOiB3aGl0ZTtcbiAgICAgICAgZm9udC1zaXplOiAxMXB4O1xuICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgICAgIHRvcDogNTAlO1xuICAgICAgICBsZWZ0OiA1MCU7XG4gICAgICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlKC01MCUsLTUwJSk7XG4gICAgICAgIGZvbnQtd2VpZ2h0OiA2MDA7XG4gICAgICAgIHdpZHRoOiAxMDAlO1xuICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgfVxufVxuXG4ubWFpbl9jb250ZW50X2RpdntcblxuICAgIC5zZWFyY2hfZGl2e1xuICAgICAgICBwYWRkaW5nOiAxMHB4IDE2cHg7XG4gICAgICAgIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCBsaWdodGdyYXk7XG4gICAgXG4gICAgICAgIGlvbi1pbnB1dHtcbiAgICAgICAgICAgIGJvcmRlcjogMXB4IHNvbGlkIGJsYWNrO1xuICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogMjVweDtcbiAgICAgICAgICAgIGlvbi1pY29ue1xuICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMjBweDtcbiAgICAgICAgICAgICAgICBwYWRkaW5nLWxlZnQ6IDEwcHg7XG4gICAgICAgICAgICAgICAgcGFkZGluZy1yaWdodDogNXB4O1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgLnRlc3R7XG4gICAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICAgICAgICAgIG1hcmdpbi1yaWdodDogMTBweDtcbiAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDI1cHg7XG4gICAgICAgICAgICBwYWRkaW5nOiA1cHggMTVweDtcbiAgICAgICAgICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG5cbiAgICAgICAgICAgIGlvbi1pY29ue1xuICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMjZweDtcbiAgICAgICAgICAgICAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgXG4gICAgICAgIC5hY3RpdmV7IFxuICAgICAgICAgICAgaW9uLWxhYmVsIHtcbiAgICAgICAgICAgICAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpICFpbXBvcnRhbnQ7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICBcbiAgICAgICAgLmNoaXBzX2RpdntcbiAgICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgICAgICBmbGV4LWRpcmVjdGlvbjogcm93O1xuICAgICAgICAgICAgb3ZlcmZsb3c6IHNjcm9sbDtcbiAgICAgICAgICAgIC5jaGlwe1xuICAgICAgICAgICAgICAgIHdoaXRlLXNwYWNlOiBub3dyYXA7XG4gICAgICAgICAgICAgICAgY29sb3I6IGJsYWNrO1xuICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMTNweDtcbiAgICAgICAgICAgICAgICBmb250LXdlaWdodDogNTAwO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAubGluZV9zcGFue1xuICAgICAgICAgICAgICAgIG1hcmdpbi10b3A6IDdweDtcbiAgICAgICAgICAgICAgICB3aWR0aDogMjBweDtcbiAgICAgICAgICAgICAgICBoZWlnaHQ6IDJweDtcbiAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0gIFxuICAgIH1cbiAgICBcbiAgICAuc3RvcnlfZGl2e1xuICAgICAgICBwYWRkaW5nOiAxNnB4O1xuICAgICAgICBib3JkZXItYm90dG9tOiAxcHggc29saWQgbGlnaHRncmF5O1xuICAgICAgICBcbiAgICAgICAgLmNoaXBzX2RpdntcbiAgICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgICAgICBmbGV4LWRpcmVjdGlvbjogcm93O1xuICAgICAgICAgICAgb3ZlcmZsb3c6IHNjcm9sbDtcblxuICAgICAgICAgICAgLmlubmVyX2RpdntcbiAgICAgICAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICAgICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAgICAgICAgICAgICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbiAgICAgICAgICAgICAgICBtYXJnaW4tcmlnaHQ6IDE1cHg7XG4gICAgICAgICAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICAgICAgICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XG4gICAgICAgICAgICAgICAgLnN0b3J5X2ltZ19tYWlue1xuICAgICAgICAgICAgICAgICAgICB3aWR0aDogNjBweDtcbiAgICAgICAgICAgICAgICAgICAgaGVpZ2h0OiA2MHB4O1xuICAgICAgICAgICAgICAgICAgICBib3JkZXItcmFkaXVzOiAxMDAlO1xuICAgICAgICAgICAgICAgICAgICBib3JkZXI6IDJweCBzb2xpZCByZWQ7XG4gICAgICAgICAgICAgICAgICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcblxuICAgICAgICAgICAgICAgICAgICAuZmlsbF9kaXZ7XG4gICAgICAgICAgICAgICAgICAgICAgICB3aWR0aDogNTBweDtcbiAgICAgICAgICAgICAgICAgICAgICAgIGhlaWdodDogNTBweDtcbiAgICAgICAgICAgICAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDEwMCU7XG4gICAgICAgICAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiAjM2IyYTUyO1xuICAgICAgICAgICAgICAgICAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgICAgICAgICAgICAgICAgICAgICAgdG9wOiA1MCU7XG4gICAgICAgICAgICAgICAgICAgICAgICBsZWZ0OiA1MCU7XG4gICAgICAgICAgICAgICAgICAgICAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZSgtNTAlLC01MCUpO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICBpbWd7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgd2lkdGg6IDI1cHg7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvcDogNTAlO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxlZnQ6IDUwJTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZSgtNTAlLC01MCUpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIC5zdG9yeV9pbWd7XG4gICAgICAgICAgICAgICAgICAgIHdpZHRoOiA2MHB4O1xuICAgICAgICAgICAgICAgICAgICBoZWlnaHQ6IDYwcHg7XG4gICAgICAgICAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDEwMCU7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAuY2hpcHtcbiAgICAgICAgICAgICAgICB3aGl0ZS1zcGFjZTogbm93cmFwO1xuICAgICAgICAgICAgICAgIGNvbG9yOiAjNTA1MDUwO1xuICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMTJweDtcbiAgICAgICAgICAgICAgICBtYXJnaW4tdG9wOiAxMHB4O1xuICAgICAgICAgICAgfSAgXG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAubGFuZ19kaXZ7XG4gICAgICAgIHBhZGRpbmc6IDEwcHggMTZweDtcbiAgICAgICAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkIGxpZ2h0Z3JheTtcblxuICAgICAgICAudGVzdHtcbiAgICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgICAgICAgICAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xuICAgICAgICAgICAgYm9yZGVyOiAxcHggc29saWQgbGlnaHRncmF5O1xuICAgICAgICAgICAgYmFja2dyb3VuZDogd2hpdGVzbW9rZTtcbiAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDI1cHg7XG4gICAgICAgICAgICBwYWRkaW5nOiA1cHggMTVweDtcbiAgICAgICAgfVxuICAgIFxuICAgICAgICAuYWN0aXZle1xuICAgICAgICAgICAgYm9yZGVyOiAxcHggc29saWQgdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xuICAgICAgICAgICAgYmFja2dyb3VuZDogcmdiYSgxNywxMTYsMTkyLDAuMik7XG4gICAgICAgICAgICBcbiAgICAgICAgICAgIGlvbi1sYWJlbCB7XG4gICAgICAgICAgICAgICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KSAhaW1wb3J0YW50O1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgXG4gICAgICAgIC5jaGlwc19kaXZ7XG4gICAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICAgICAgZmxleC1kaXJlY3Rpb246IHJvdztcbiAgICAgICAgICAgIG92ZXJmbG93OiBzY3JvbGw7XG4gICAgICAgICAgICAuY2hpcHtcbiAgICAgICAgICAgICAgICB3aGl0ZS1zcGFjZTogbm93cmFwO1xuICAgICAgICAgICAgICAgIGNvbG9yOiBibGFjaztcbiAgICAgICAgICAgICAgICBmb250LXNpemU6IDEzcHg7XG4gICAgICAgICAgICB9ICBcbiAgICAgICAgfSAgIFxuICAgIH1cblxuICAgIC5sb3dlcl9kaXZ7XG4gICAgICAgIC5uZXdzX2NhcmR7XG4gICAgICAgICAgICBwYWRkaW5nOiAxNnB4O1xuICAgICAgICAgICAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkIGxpZ2h0Z3JheTtcblxuICAgICAgICAgICAgLmJhY2tfaW1hZ2V7XG4gICAgICAgICAgICAgICAgd2lkdGg6IDEwMCU7XG4gICAgICAgICAgICAgICAgaGVpZ2h0OiAxODBweDtcbiAgICAgICAgICAgICAgICBib3JkZXItcmFkaXVzOiAxMHB4O1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICB2aWRlb3tcbiAgICAgICAgICAgICAgICB3aWR0aDogMTAwJTtcbiAgICAgICAgICAgICAgICBib3JkZXItcmFkaXVzOiAxMHB4O1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAuY2hhbm5lbF9kZXRhaWx7XG4gICAgICAgICAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAgICAgICAgICBtYXJnaW4tdG9wOiAxcHg7XG4gICAgICAgICAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICAgICAgICAgICAgICBtYXJnaW4tYm90dG9tOiAxMHB4O1xuICAgICAgICAgICAgICAgIGltZ3tcbiAgICAgICAgICAgICAgICAgICAgd2lkdGg6IDI1cHg7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIC5jaGFubmVsX25hbWV7XG4gICAgICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMTVweDtcbiAgICAgICAgICAgICAgICAgICAgbWFyZ2luLWxlZnQ6IDEwcHg7XG4gICAgICAgICAgICAgICAgICAgIG1hcmdpbi1yaWdodDogMTBweDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIC5oZWFkX2xpbmV7XG4gICAgICAgICAgICAgICAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgICAgICAgICAgICAgICBjb2xvcjogZ3JheTtcbiAgICAgICAgICAgICAgICBmb250LXNpemU6IDE4cHg7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIC5zaGFyZV9kaXZ7XG4gICAgICAgICAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAgICAgICAgICB3aWR0aDogMTAwJTtcbiAgICAgICAgICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XG4gICAgICAgICAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcblxuICAgICAgICAgICAgICAgIC5sZWZ0X2RpdntcblxuICAgICAgICAgICAgICAgICAgICAubGlua19sYmx7XG4gICAgICAgICAgICAgICAgICAgICAgICBmb250LXNpemU6IDEzcHg7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb2xvcjogZ3JheTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIC5yaWdodF9kaXZ7XG4gICAgICAgICAgICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgICAgICAgICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAgICAgICAgICAgICAgICAgIGlvbi1idXR0b257XG4gICAgICAgICAgICAgICAgICAgICAgICBtYXJnaW46IDA7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIGlvbi1pY29ue1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yOiAjNTA1MDUwO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgLnJvdW5kX2RpdntcbiAgICAgICAgICAgICAgICAgICAgLy8gYm9yZGVyOiAxcHggc29saWQgbGlnaHRncmF5O1xuICAgICAgICAgICAgICAgICAgICBoZWlnaHQ6IDQwcHg7XG4gICAgICAgICAgICAgICAgICAgIHdpZHRoOiA0MHB4O1xuICAgICAgICAgICAgICAgICAgICBib3JkZXItcmFkaXVzOiAxMDAlO1xuICAgICAgICAgICAgICAgICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gICAgICAgICAgICAgICAgICAgIG1hcmdpbi1yaWdodDogMTBweDtcbiAgICAgICAgICAgICAgICAgICAgaW9uLWljb257XG4gICAgICAgICAgICAgICAgICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgICAgICAgICAgICAgICAgICAgICB0b3A6IDUwJTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGxlZnQ6IDUwJTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlKC01MCUsLTUwJSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBmb250LXNpemU6IDE4cHg7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb2xvcjogIzUwNTA1MDtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAuY3B5e1xuICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I6ICNGRjZCMDE7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIC5mbGV4X2RpdntcbiAgICAgICAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xuXG4gICAgICAgICAgICAgICAgLmJhY2tfaW1hZ2Uye1xuICAgICAgICAgICAgICAgICAgICBoZWlnaHQ6IDEwMHB4O1xuICAgICAgICAgICAgICAgICAgICB3aWR0aDogMTAwcHg7XG4gICAgICAgICAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDVweDtcbiAgICAgICAgICAgICAgICAgICAgbWluLXdpZHRoOiAxMDBweDtcbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAuZGV0YWlsX2RpdntcbiAgICAgICAgICAgICAgICAgICAgLmNoYW5uZWxfZGV0YWlsMntcbiAgICAgICAgICAgICAgICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgICAgICAgICAgICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgICAgICAgICAgICAgICAgICAgICAgbWFyZ2luLWJvdHRvbTogMTBweDtcbiAgICAgICAgICAgICAgICAgICAgICAgIGltZ3tcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB3aWR0aDogMjVweDtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIC5jaGFubmVsX25hbWV7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udC1zaXplOiAxNHB4O1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1hcmdpbi1sZWZ0OiAxMHB4O1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1hcmdpbi1yaWdodDogMTBweDtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAuaGVhZF9saW5lMntcbiAgICAgICAgICAgICAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiA1MDA7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG59IiwiaW9uLWhlYWRlciBpb24tYnV0dG9uIHtcbiAgbWFyZ2luOiAwO1xufVxuaW9uLWhlYWRlciBpb24tYnV0dG9uIGlvbi1pY29uIHtcbiAgY29sb3I6IGJsYWNrO1xuICBmb250LXNpemU6IDIwcHg7XG59XG5cbi5oZWFkZXJfZGl2IHtcbiAgd2lkdGg6IDEwMCU7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICBwYWRkaW5nOiA1cHg7XG59XG4uaGVhZGVyX2RpdiBpbWcge1xuICB3aWR0aDogMTAwcHg7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgbGVmdDogNTAlO1xuICB0cmFuc2Zvcm06IHRyYW5zbGF0ZSgtNTAlKTtcbn1cbi5oZWFkZXJfZGl2IC5idG5fZGl2IHtcbiAgZGlzcGxheTogZmxleDtcbn1cbi5oZWFkZXJfZGl2IGlvbi1idXR0b24ge1xuICBjb2xvcjogYmxhY2s7XG59XG5cbi5hZGRfaWNvbiB7XG4gIGJhY2tncm91bmQ6ICNmZjZiMDE7XG4gIGhlaWdodDogNTBweDtcbiAgd2lkdGg6IDUwcHg7XG4gIHotaW5kZXg6IDk5OTtcbiAgYm9yZGVyLXJhZGl1czogMTAwJTtcbiAgcG9zaXRpb246IGZpeGVkO1xuICBib3R0b206IDkwcHg7XG4gIHJpZ2h0OiAyMHB4O1xufVxuLmFkZF9pY29uIGlvbi1sYWJlbCB7XG4gIGNvbG9yOiB3aGl0ZTtcbiAgZm9udC1zaXplOiAxMXB4O1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHRvcDogNTAlO1xuICBsZWZ0OiA1MCU7XG4gIHRyYW5zZm9ybTogdHJhbnNsYXRlKC01MCUsIC01MCUpO1xuICBmb250LXdlaWdodDogNjAwO1xuICB3aWR0aDogMTAwJTtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xufVxuXG4ubWFpbl9jb250ZW50X2RpdiAuc2VhcmNoX2RpdiB7XG4gIHBhZGRpbmc6IDEwcHggMTZweDtcbiAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkIGxpZ2h0Z3JheTtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5zZWFyY2hfZGl2IGlvbi1pbnB1dCB7XG4gIGJvcmRlcjogMXB4IHNvbGlkIGJsYWNrO1xuICBib3JkZXItcmFkaXVzOiAyNXB4O1xufVxuLm1haW5fY29udGVudF9kaXYgLnNlYXJjaF9kaXYgaW9uLWlucHV0IGlvbi1pY29uIHtcbiAgZm9udC1zaXplOiAyMHB4O1xuICBwYWRkaW5nLWxlZnQ6IDEwcHg7XG4gIHBhZGRpbmctcmlnaHQ6IDVweDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5zZWFyY2hfZGl2IC50ZXN0IHtcbiAgZGlzcGxheTogZmxleDtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xuICBib3JkZXItcmFkaXVzOiAyNXB4O1xuICBwYWRkaW5nOiA1cHggMTVweDtcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5zZWFyY2hfZGl2IC50ZXN0IGlvbi1pY29uIHtcbiAgZm9udC1zaXplOiAyNnB4O1xuICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xufVxuLm1haW5fY29udGVudF9kaXYgLnNlYXJjaF9kaXYgLmFjdGl2ZSBpb24tbGFiZWwge1xuICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpICFpbXBvcnRhbnQ7XG59XG4ubWFpbl9jb250ZW50X2RpdiAuc2VhcmNoX2RpdiAuY2hpcHNfZGl2IHtcbiAgZGlzcGxheTogZmxleDtcbiAgZmxleC1kaXJlY3Rpb246IHJvdztcbiAgb3ZlcmZsb3c6IHNjcm9sbDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5zZWFyY2hfZGl2IC5jaGlwc19kaXYgLmNoaXAge1xuICB3aGl0ZS1zcGFjZTogbm93cmFwO1xuICBjb2xvcjogYmxhY2s7XG4gIGZvbnQtc2l6ZTogMTNweDtcbiAgZm9udC13ZWlnaHQ6IDUwMDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5zZWFyY2hfZGl2IC5jaGlwc19kaXYgLmxpbmVfc3BhbiB7XG4gIG1hcmdpbi10b3A6IDdweDtcbiAgd2lkdGg6IDIwcHg7XG4gIGhlaWdodDogMnB4O1xuICBiYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XG59XG4ubWFpbl9jb250ZW50X2RpdiAuc3RvcnlfZGl2IHtcbiAgcGFkZGluZzogMTZweDtcbiAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkIGxpZ2h0Z3JheTtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5zdG9yeV9kaXYgLmNoaXBzX2RpdiB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGZsZXgtZGlyZWN0aW9uOiByb3c7XG4gIG92ZXJmbG93OiBzY3JvbGw7XG59XG4ubWFpbl9jb250ZW50X2RpdiAuc3RvcnlfZGl2IC5jaGlwc19kaXYgLmlubmVyX2RpdiB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG4gIG1hcmdpbi1yaWdodDogMTVweDtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xufVxuLm1haW5fY29udGVudF9kaXYgLnN0b3J5X2RpdiAuY2hpcHNfZGl2IC5pbm5lcl9kaXYgLnN0b3J5X2ltZ19tYWluIHtcbiAgd2lkdGg6IDYwcHg7XG4gIGhlaWdodDogNjBweDtcbiAgYm9yZGVyLXJhZGl1czogMTAwJTtcbiAgYm9yZGVyOiAycHggc29saWQgcmVkO1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG59XG4ubWFpbl9jb250ZW50X2RpdiAuc3RvcnlfZGl2IC5jaGlwc19kaXYgLmlubmVyX2RpdiAuc3RvcnlfaW1nX21haW4gLmZpbGxfZGl2IHtcbiAgd2lkdGg6IDUwcHg7XG4gIGhlaWdodDogNTBweDtcbiAgYm9yZGVyLXJhZGl1czogMTAwJTtcbiAgYmFja2dyb3VuZDogIzNiMmE1MjtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICB0b3A6IDUwJTtcbiAgbGVmdDogNTAlO1xuICB0cmFuc2Zvcm06IHRyYW5zbGF0ZSgtNTAlLCAtNTAlKTtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5zdG9yeV9kaXYgLmNoaXBzX2RpdiAuaW5uZXJfZGl2IC5zdG9yeV9pbWdfbWFpbiAuZmlsbF9kaXYgaW1nIHtcbiAgd2lkdGg6IDI1cHg7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgdG9wOiA1MCU7XG4gIGxlZnQ6IDUwJTtcbiAgdHJhbnNmb3JtOiB0cmFuc2xhdGUoLTUwJSwgLTUwJSk7XG59XG4ubWFpbl9jb250ZW50X2RpdiAuc3RvcnlfZGl2IC5jaGlwc19kaXYgLmlubmVyX2RpdiAuc3RvcnlfaW1nIHtcbiAgd2lkdGg6IDYwcHg7XG4gIGhlaWdodDogNjBweDtcbiAgYm9yZGVyLXJhZGl1czogMTAwJTtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5zdG9yeV9kaXYgLmNoaXBzX2RpdiAuY2hpcCB7XG4gIHdoaXRlLXNwYWNlOiBub3dyYXA7XG4gIGNvbG9yOiAjNTA1MDUwO1xuICBmb250LXNpemU6IDEycHg7XG4gIG1hcmdpbi10b3A6IDEwcHg7XG59XG4ubWFpbl9jb250ZW50X2RpdiAubGFuZ19kaXYge1xuICBwYWRkaW5nOiAxMHB4IDE2cHg7XG4gIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCBsaWdodGdyYXk7XG59XG4ubWFpbl9jb250ZW50X2RpdiAubGFuZ19kaXYgLnRlc3Qge1xuICBkaXNwbGF5OiBmbGV4O1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBtYXJnaW4tcmlnaHQ6IDEwcHg7XG4gIGJvcmRlcjogMXB4IHNvbGlkIGxpZ2h0Z3JheTtcbiAgYmFja2dyb3VuZDogd2hpdGVzbW9rZTtcbiAgYm9yZGVyLXJhZGl1czogMjVweDtcbiAgcGFkZGluZzogNXB4IDE1cHg7XG59XG4ubWFpbl9jb250ZW50X2RpdiAubGFuZ19kaXYgLmFjdGl2ZSB7XG4gIGJvcmRlcjogMXB4IHNvbGlkIHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcbiAgYmFja2dyb3VuZDogcmdiYSgxNywgMTE2LCAxOTIsIDAuMik7XG59XG4ubWFpbl9jb250ZW50X2RpdiAubGFuZ19kaXYgLmFjdGl2ZSBpb24tbGFiZWwge1xuICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpICFpbXBvcnRhbnQ7XG59XG4ubWFpbl9jb250ZW50X2RpdiAubGFuZ19kaXYgLmNoaXBzX2RpdiB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGZsZXgtZGlyZWN0aW9uOiByb3c7XG4gIG92ZXJmbG93OiBzY3JvbGw7XG59XG4ubWFpbl9jb250ZW50X2RpdiAubGFuZ19kaXYgLmNoaXBzX2RpdiAuY2hpcCB7XG4gIHdoaXRlLXNwYWNlOiBub3dyYXA7XG4gIGNvbG9yOiBibGFjaztcbiAgZm9udC1zaXplOiAxM3B4O1xufVxuLm1haW5fY29udGVudF9kaXYgLmxvd2VyX2RpdiAubmV3c19jYXJkIHtcbiAgcGFkZGluZzogMTZweDtcbiAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkIGxpZ2h0Z3JheTtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5sb3dlcl9kaXYgLm5ld3NfY2FyZCAuYmFja19pbWFnZSB7XG4gIHdpZHRoOiAxMDAlO1xuICBoZWlnaHQ6IDE4MHB4O1xuICBib3JkZXItcmFkaXVzOiAxMHB4O1xufVxuLm1haW5fY29udGVudF9kaXYgLmxvd2VyX2RpdiAubmV3c19jYXJkIHZpZGVvIHtcbiAgd2lkdGg6IDEwMCU7XG4gIGJvcmRlci1yYWRpdXM6IDEwcHg7XG59XG4ubWFpbl9jb250ZW50X2RpdiAubG93ZXJfZGl2IC5uZXdzX2NhcmQgLmNoYW5uZWxfZGV0YWlsIHtcbiAgZGlzcGxheTogZmxleDtcbiAgbWFyZ2luLXRvcDogMXB4O1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBtYXJnaW4tYm90dG9tOiAxMHB4O1xufVxuLm1haW5fY29udGVudF9kaXYgLmxvd2VyX2RpdiAubmV3c19jYXJkIC5jaGFubmVsX2RldGFpbCBpbWcge1xuICB3aWR0aDogMjVweDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5sb3dlcl9kaXYgLm5ld3NfY2FyZCAuY2hhbm5lbF9kZXRhaWwgLmNoYW5uZWxfbmFtZSB7XG4gIGZvbnQtc2l6ZTogMTVweDtcbiAgbWFyZ2luLWxlZnQ6IDEwcHg7XG4gIG1hcmdpbi1yaWdodDogMTBweDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5sb3dlcl9kaXYgLm5ld3NfY2FyZCAuaGVhZF9saW5lIHtcbiAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgY29sb3I6IGdyYXk7XG4gIGZvbnQtc2l6ZTogMThweDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5sb3dlcl9kaXYgLm5ld3NfY2FyZCAuc2hhcmVfZGl2IHtcbiAgZGlzcGxheTogZmxleDtcbiAgd2lkdGg6IDEwMCU7XG4gIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5sb3dlcl9kaXYgLm5ld3NfY2FyZCAuc2hhcmVfZGl2IC5sZWZ0X2RpdiAubGlua19sYmwge1xuICBmb250LXNpemU6IDEzcHg7XG4gIGNvbG9yOiBncmF5O1xufVxuLm1haW5fY29udGVudF9kaXYgLmxvd2VyX2RpdiAubmV3c19jYXJkIC5zaGFyZV9kaXYgLnJpZ2h0X2RpdiB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG59XG4ubWFpbl9jb250ZW50X2RpdiAubG93ZXJfZGl2IC5uZXdzX2NhcmQgLnNoYXJlX2RpdiAucmlnaHRfZGl2IGlvbi1idXR0b24ge1xuICBtYXJnaW46IDA7XG59XG4ubWFpbl9jb250ZW50X2RpdiAubG93ZXJfZGl2IC5uZXdzX2NhcmQgLnNoYXJlX2RpdiAucmlnaHRfZGl2IGlvbi1idXR0b24gaW9uLWljb24ge1xuICBjb2xvcjogIzUwNTA1MDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5sb3dlcl9kaXYgLm5ld3NfY2FyZCAuc2hhcmVfZGl2IC5yb3VuZF9kaXYge1xuICBoZWlnaHQ6IDQwcHg7XG4gIHdpZHRoOiA0MHB4O1xuICBib3JkZXItcmFkaXVzOiAxMDAlO1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIG1hcmdpbi1yaWdodDogMTBweDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5sb3dlcl9kaXYgLm5ld3NfY2FyZCAuc2hhcmVfZGl2IC5yb3VuZF9kaXYgaW9uLWljb24ge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHRvcDogNTAlO1xuICBsZWZ0OiA1MCU7XG4gIHRyYW5zZm9ybTogdHJhbnNsYXRlKC01MCUsIC01MCUpO1xuICBmb250LXNpemU6IDE4cHg7XG4gIGNvbG9yOiAjNTA1MDUwO1xufVxuLm1haW5fY29udGVudF9kaXYgLmxvd2VyX2RpdiAubmV3c19jYXJkIC5zaGFyZV9kaXYgLnJvdW5kX2RpdiAuY3B5IHtcbiAgY29sb3I6ICNGRjZCMDE7XG59XG4ubWFpbl9jb250ZW50X2RpdiAubG93ZXJfZGl2IC5uZXdzX2NhcmQgLmZsZXhfZGl2IHtcbiAgZGlzcGxheTogZmxleDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5sb3dlcl9kaXYgLm5ld3NfY2FyZCAuZmxleF9kaXYgLmJhY2tfaW1hZ2UyIHtcbiAgaGVpZ2h0OiAxMDBweDtcbiAgd2lkdGg6IDEwMHB4O1xuICBib3JkZXItcmFkaXVzOiA1cHg7XG4gIG1pbi13aWR0aDogMTAwcHg7XG59XG4ubWFpbl9jb250ZW50X2RpdiAubG93ZXJfZGl2IC5uZXdzX2NhcmQgLmZsZXhfZGl2IC5kZXRhaWxfZGl2IC5jaGFubmVsX2RldGFpbDIge1xuICBkaXNwbGF5OiBmbGV4O1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBtYXJnaW4tYm90dG9tOiAxMHB4O1xufVxuLm1haW5fY29udGVudF9kaXYgLmxvd2VyX2RpdiAubmV3c19jYXJkIC5mbGV4X2RpdiAuZGV0YWlsX2RpdiAuY2hhbm5lbF9kZXRhaWwyIGltZyB7XG4gIHdpZHRoOiAyNXB4O1xufVxuLm1haW5fY29udGVudF9kaXYgLmxvd2VyX2RpdiAubmV3c19jYXJkIC5mbGV4X2RpdiAuZGV0YWlsX2RpdiAuY2hhbm5lbF9kZXRhaWwyIC5jaGFubmVsX25hbWUge1xuICBmb250LXNpemU6IDE0cHg7XG4gIG1hcmdpbi1sZWZ0OiAxMHB4O1xuICBtYXJnaW4tcmlnaHQ6IDEwcHg7XG59XG4ubWFpbl9jb250ZW50X2RpdiAubG93ZXJfZGl2IC5uZXdzX2NhcmQgLmZsZXhfZGl2IC5kZXRhaWxfZGl2IC5oZWFkX2xpbmUyIHtcbiAgZm9udC13ZWlnaHQ6IDUwMDtcbn0iXX0= */");

/***/ }),

/***/ "./src/app/pages/news/news.page.ts":
/*!*****************************************!*\
  !*** ./src/app/pages/news/news.page.ts ***!
  \*****************************************/
/*! exports provided: NewsPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NewsPage", function() { return NewsPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var src_app_services_dummy_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/dummy.service */ "./src/app/services/dummy.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var src_app_services_news_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/news.service */ "./src/app/services/news.service.ts");
/* harmony import */ var src_app_services_games_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/games.service */ "./src/app/services/games.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");







let NewsPage = class NewsPage {
    constructor(dummy, router, news, route, game, actionSheetController) {
        this.dummy = dummy;
        this.router = router;
        this.news = news;
        this.route = route;
        this.game = game;
        this.actionSheetController = actionSheetController;
        this.moviesCat = ['Search', 'Shopping', 'Maps', 'Images', 'News', 'Videos', 'Social'];
        this.plt = localStorage.getItem('platform');
        this.stories = this.dummy.story;
        this.lang = this.dummy.lang;
        this.allNews = this.news.news;
        this.route.queryParams.subscribe(data => {
            console.log(data.id);
            this.category = data.id;
            this.currentCat = data.id;
            if (this.category === 'Cricket') {
                this.allNews = this.game.games;
                return;
            }
        });
    }
    ngOnInit() {
    }
    selectLang(val) {
        this.currentLang = val;
    }
    goToLiveTv() {
        this.router.navigate(['/tabs/live-tv']);
    }
    presentActionSheet() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const actionSheet = yield this.actionSheetController.create({
                mode: 'md',
                buttons: [
                    {
                        text: 'Save',
                        icon: 'bookmark-outline',
                    },
                    {
                        text: 'View full coverage',
                        icon: 'document-text-outline',
                    },
                    {
                        text: 'Like this stoty',
                        icon: 'thumbs-up-sharp',
                    },
                    {
                        text: 'Follow the Times Of India',
                        icon: 'person-add-outline',
                    },
                    {
                        text: 'More stories like this',
                        icon: 'checkmark-circle-outline',
                    },
                    {
                        text: 'Fewer stories like this',
                        icon: 'remove-circle-outline',
                    },
                    {
                        text: 'Comment',
                        icon: 'chatbox-outline',
                    },
                    {
                        text: 'Copy Link',
                        icon: 'copy-outline',
                    }
                ]
            });
            yield actionSheet.present();
        });
    }
    shareActionSheet() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const actionSheet = yield this.actionSheetController.create({
                mode: 'md',
                buttons: [
                    {
                        text: 'Post on JdSocial',
                        icon: 'sync-circle-outline',
                    },
                    {
                        text: 'Share on facebook',
                        icon: 'logo-facebook',
                    },
                    {
                        text: 'Send on WhatsApp',
                        icon: 'logo-whatsapp',
                    },
                    {
                        text: 'Copy Link',
                        icon: 'copy-outline',
                    },
                    {
                        text: 'More Options..',
                        icon: 'ellipsis-horizontal-circle-outline',
                    }
                ]
            });
            yield actionSheet.present();
        });
    }
    selectCat(val) {
        const navData = {
            queryParams: {
                id: val
            }
        };
        console.log(val);
        this.currentCat = val;
        if (this.currentCat === 'News') {
            this.router.navigate(['/tabs/news'], navData);
        }
        if (this.currentCat === 'Videos') {
            this.router.navigate(['/tabs/videos'], navData);
        }
        if (this.currentCat === 'Social') {
            this.router.navigate(['/tabs/social'], navData);
        }
    }
    goToNotification() {
        this.router.navigate(['/tabs/notification']);
    }
};
NewsPage.ctorParameters = () => [
    { type: src_app_services_dummy_service__WEBPACK_IMPORTED_MODULE_2__["DummyService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"] },
    { type: src_app_services_news_service__WEBPACK_IMPORTED_MODULE_4__["NewsService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"] },
    { type: src_app_services_games_service__WEBPACK_IMPORTED_MODULE_5__["GamesService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["ActionSheetController"] }
];
NewsPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-news',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./news.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/news/news.page.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./news.page.scss */ "./src/app/pages/news/news.page.scss")).default]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [src_app_services_dummy_service__WEBPACK_IMPORTED_MODULE_2__["DummyService"],
        _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"],
        src_app_services_news_service__WEBPACK_IMPORTED_MODULE_4__["NewsService"],
        _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"],
        src_app_services_games_service__WEBPACK_IMPORTED_MODULE_5__["GamesService"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["ActionSheetController"]])
], NewsPage);



/***/ }),

/***/ "./src/app/services/news.service.ts":
/*!******************************************!*\
  !*** ./src/app/services/news.service.ts ***!
  \******************************************/
/*! exports provided: NewsService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NewsService", function() { return NewsService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let NewsService = class NewsService {
    constructor() {
        this.news = [
            {
                logo: 'assets/imgs/news_icn1.png',
                img: 'assets/imgs/news1.jpg',
                headline: 'What is Lorem Ipsum, Lorem Ipsum is simply dummy text of the printing',
                detail: ' Lorem ipsum dolor sit amet consectetur adipisicing elit. At sint quia aperiam corrupti molestias earum, quasi modi laboriosam placeat qui maiores autem non impedit dignissimos suscipit, illo consectetur eos doloremque?'
            },
            {
                logo: 'assets/imgs/news_icn2.png',
                img: 'assets/imgs/news2.jpg',
                headline: 'What is Lorem Ipsum, Lorem Ipsum is simply dummy text of the printing',
                detail: ' Lorem ipsum dolor sit amet consectetur adipisicing elit. At sint quia aperiam corrupti molestias earum, quasi modi laboriosam placeat qui maiores autem non impedit dignissimos suscipit, illo consectetur eos doloremque?'
            },
            {
                logo: 'assets/imgs/news_icn3.png',
                img: 'assets/imgs/news3.jpg',
                headline: 'What is Lorem Ipsum, Lorem Ipsum is simply dummy text of the printing',
                detail: ' Lorem ipsum dolor sit amet consectetur adipisicing elit. At sint quia aperiam corrupti molestias earum, quasi modi laboriosam placeat qui maiores autem non impedit dignissimos suscipit, illo consectetur eos doloremque?'
            },
            {
                logo: 'assets/imgs/news_icn4.png',
                img: 'assets/imgs/news4.jpg',
                headline: 'What is Lorem Ipsum, Lorem Ipsum is simply dummy text of the printing',
                detail: ' Lorem ipsum dolor sit amet consectetur adipisicing elit. At sint quia aperiam corrupti molestias earum, quasi modi laboriosam placeat qui maiores autem non impedit dignissimos suscipit, illo consectetur eos doloremque?'
            },
            {
                logo: 'assets/imgs/news_icn5.png',
                img: 'assets/imgs/news5.jpg',
                headline: 'What is Lorem Ipsum, Lorem Ipsum is simply dummy text of the printing',
                detail: ' Lorem ipsum dolor sit amet consectetur adipisicing elit. At sint quia aperiam corrupti molestias earum, quasi modi laboriosam placeat qui maiores autem non impedit dignissimos suscipit, illo consectetur eos doloremque?'
            },
            {
                logo: 'assets/imgs/news_icn6.png',
                img: 'assets/imgs/news6.jpg',
                headline: 'What is Lorem Ipsum, Lorem Ipsum is simply dummy text of the printing',
                detail: ' Lorem ipsum dolor sit amet consectetur adipisicing elit. At sint quia aperiam corrupti molestias earum, quasi modi laboriosam placeat qui maiores autem non impedit dignissimos suscipit, illo consectetur eos doloremque?'
            },
        ];
    }
};
NewsService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
], NewsService);



/***/ })

}]);
//# sourceMappingURL=news-news-module-es2015.js.map