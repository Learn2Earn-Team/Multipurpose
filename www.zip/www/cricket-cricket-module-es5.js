function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["cricket-cricket-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/cricket/cricket.page.html":
  /*!***************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/cricket/cricket.page.html ***!
    \***************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppPagesCricketCricketPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar>\n    \n    <ion-icon class=\"back\" name=\"arrow-back-outline\" (click)=\"goBack()\"></ion-icon>\n\n    <ion-title>Cricket</ion-title>\n\n    <ion-button slot=\"end\" size=\"small\" fill=\"clear\">\n      <ion-icon name=\"arrow-redo-outline\"></ion-icon>\n    </ion-button>\n\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div class=\"main_content_div\">\n\n    <div class=\"slider_div\">\n      <ion-label class=\"head_lbl\">Featured Videos</ion-label>\n\n      <ion-slides mode=\"ios\" [options]=\"slideOpts\">\n\n        <ion-slide *ngFor=\"let item of games\" (click)=\"goToCricketVideo()\">\n          <div class=\"main_div\">\n            <div class=\"image_div bg_image\" [style.backgroundImage]=\"'url( '+ item.img +' )'\">\n              <ion-icon name=\"caret-forward-circle-outline\"></ion-icon>\n            </div>\n            <ion-label class=\"name\">{{item.headline}}</ion-label>\n          </div>\n        </ion-slide>\n\n      </ion-slides>\n    </div>\n\n    <div class=\"lower_div\">\n\n      <ion-label class=\"head_lbl\" style=\"margin-left: 16px;\">News</ion-label>\n\n      <div class=\"news_card\" *ngFor=\"let item of games\" (click)=\"goToNews('Cricket')\">\n\n        <div class=\"flex_div\">\n          <div class=\"detail_div\">\n            <ion-label class=\"head_line2\">{{item.headline}}</ion-label>\n\n            <div class=\"share_div\">\n              <ion-label>Cric Tracker </ion-label>\n\n              <ion-button size=\"small\" fill=\"clear\">\n                <ion-icon name=\"arrow-redo-outline\"></ion-icon>\n                Share\n              </ion-button>\n            </div>\n          </div>\n          <div class=\"back_image2 bg_image\" [style.backgroundImage]=\"'url('+ item.img +')'\"></div>\n\n        </div>\n\n      </div>\n\n    </div>\n\n  </div>\n</ion-content>";
    /***/
  },

  /***/
  "./src/app/pages/cricket/cricket-routing.module.ts":
  /*!*********************************************************!*\
    !*** ./src/app/pages/cricket/cricket-routing.module.ts ***!
    \*********************************************************/

  /*! exports provided: CricketPageRoutingModule */

  /***/
  function srcAppPagesCricketCricketRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "CricketPageRoutingModule", function () {
      return CricketPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _cricket_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./cricket.page */
    "./src/app/pages/cricket/cricket.page.ts");

    var routes = [{
      path: '',
      component: _cricket_page__WEBPACK_IMPORTED_MODULE_3__["CricketPage"]
    }];

    var CricketPageRoutingModule = function CricketPageRoutingModule() {
      _classCallCheck(this, CricketPageRoutingModule);
    };

    CricketPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], CricketPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/pages/cricket/cricket.module.ts":
  /*!*************************************************!*\
    !*** ./src/app/pages/cricket/cricket.module.ts ***!
    \*************************************************/

  /*! exports provided: CricketPageModule */

  /***/
  function srcAppPagesCricketCricketModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "CricketPageModule", function () {
      return CricketPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _cricket_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./cricket-routing.module */
    "./src/app/pages/cricket/cricket-routing.module.ts");
    /* harmony import */


    var _cricket_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./cricket.page */
    "./src/app/pages/cricket/cricket.page.ts");

    var CricketPageModule = function CricketPageModule() {
      _classCallCheck(this, CricketPageModule);
    };

    CricketPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _cricket_routing_module__WEBPACK_IMPORTED_MODULE_5__["CricketPageRoutingModule"]],
      declarations: [_cricket_page__WEBPACK_IMPORTED_MODULE_6__["CricketPage"]]
    })], CricketPageModule);
    /***/
  },

  /***/
  "./src/app/pages/cricket/cricket.page.scss":
  /*!*************************************************!*\
    !*** ./src/app/pages/cricket/cricket.page.scss ***!
    \*************************************************/

  /*! exports provided: default */

  /***/
  function srcAppPagesCricketCricketPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "ion-header .back {\n  font-size: 27px;\n  margin-left: 10px;\n}\nion-header ion-button {\n  margin: 0;\n}\nion-header ion-button ion-icon {\n  color: black;\n  font-size: 20px;\n}\n.main_content_div {\n  width: 100%;\n}\n.main_content_div ion-label {\n  display: block;\n}\n.main_content_div .head_lbl {\n  font-weight: 600;\n}\n.main_content_div .slider_div {\n  padding: 16px;\n  border-bottom: 1px solid lightgray;\n}\n.main_content_div .slider_div ion-slides {\n  padding-bottom: 5px;\n  padding-top: 15px;\n}\n.main_content_div .slider_div ion-slides ion-slide {\n  margin-right: 10px;\n  margin-left: 5px;\n}\n.main_content_div .slider_div ion-slides ion-slide .main_div {\n  width: 100%;\n  box-shadow: 0px 3px 6px rgba(0, 0, 0, 0.3);\n  border-radius: 5px;\n}\n.main_content_div .slider_div ion-slides ion-slide .main_div .image_div {\n  width: 100%;\n  height: 100px;\n  border-top-left-radius: 5px;\n  border-top-right-radius: 5px;\n  position: relative;\n}\n.main_content_div .slider_div ion-slides ion-slide .main_div .image_div ion-icon {\n  position: absolute;\n  bottom: 5px;\n  left: 5px;\n  font-size: 25px;\n  color: white;\n}\n.main_content_div .slider_div ion-slides ion-slide .main_div .name {\n  padding: 10px;\n  font-size: 13px;\n  text-align: left;\n  font-weight: 500;\n}\n.main_content_div .lower_div {\n  padding: 16px 0px;\n}\n.main_content_div .lower_div .news_card {\n  padding: 16px;\n  border-bottom: 1px solid lightgray;\n}\n.main_content_div .lower_div .news_card .flex_div {\n  display: flex;\n}\n.main_content_div .lower_div .news_card .flex_div .back_image2 {\n  height: 80px;\n  width: 90px;\n  border-radius: 5px;\n  min-width: 90px;\n}\n.main_content_div .lower_div .news_card .flex_div .detail_div {\n  padding-right: 10px;\n}\n.main_content_div .lower_div .news_card .flex_div .detail_div .head_line2 {\n  font-size: 15px;\n}\n.main_content_div .lower_div .news_card .flex_div .detail_div .share_div {\n  display: flex;\n  align-items: center;\n}\n.main_content_div .lower_div .news_card .flex_div .detail_div .share_div ion-label {\n  font-size: 13px;\n}\n.main_content_div .lower_div .news_card .flex_div .detail_div .share_div ion-button {\n  color: gray;\n  margin: 0;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvY3JpY2tldC9FOlxcSW9uaWMgUHJvamVjdHNcXGlvbmljLTUtdGVtcGxhdGUtYnVuZGxlLWlvbmljLTUtdGhlbWVzLWJ1bmRsZXMtaW9uaWMtNS10ZW1wbGF0ZXMtd2l0aC0xMC1hcHBzXFxBcHBfc291cmNlX2NvZGVcXEFwcHNfY29kZVxcTXVsdGlfcHVycG9zZS9zcmNcXGFwcFxccGFnZXNcXGNyaWNrZXRcXGNyaWNrZXQucGFnZS5zY3NzIiwic3JjL2FwcC9wYWdlcy9jcmlja2V0L2NyaWNrZXQucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUVJO0VBQ0ksZUFBQTtFQUNBLGlCQUFBO0FDRFI7QURHSTtFQUNJLFNBQUE7QUNEUjtBREdRO0VBQ0ksWUFBQTtFQUNBLGVBQUE7QUNEWjtBRE1BO0VBQ0ksV0FBQTtBQ0hKO0FES0k7RUFDSSxjQUFBO0FDSFI7QURNSTtFQUNJLGdCQUFBO0FDSlI7QURPSTtFQUNJLGFBQUE7RUFDQSxrQ0FBQTtBQ0xSO0FET1E7RUFDSSxtQkFBQTtFQUNBLGlCQUFBO0FDTFo7QURPWTtFQUNJLGtCQUFBO0VBQ0EsZ0JBQUE7QUNMaEI7QURPZ0I7RUFDSSxXQUFBO0VBQ0EsMENBQUE7RUFDQSxrQkFBQTtBQ0xwQjtBRE1vQjtFQUNJLFdBQUE7RUFDQSxhQUFBO0VBQ0EsMkJBQUE7RUFDQSw0QkFBQTtFQUNBLGtCQUFBO0FDSnhCO0FETXdCO0VBQ0ksa0JBQUE7RUFDQSxXQUFBO0VBQ0EsU0FBQTtFQUNBLGVBQUE7RUFDQSxZQUFBO0FDSjVCO0FEUW9CO0VBQ0ksYUFBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtFQUNBLGdCQUFBO0FDTnhCO0FEYUk7RUFDSSxpQkFBQTtBQ1hSO0FEWVE7RUFDSSxhQUFBO0VBQ0Esa0NBQUE7QUNWWjtBRFlZO0VBQ0ksYUFBQTtBQ1ZoQjtBRFlnQjtFQUNJLFlBQUE7RUFDQSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxlQUFBO0FDVnBCO0FEYWdCO0VBQ0ksbUJBQUE7QUNYcEI7QURZb0I7RUFDSSxlQUFBO0FDVnhCO0FEWW9CO0VBQ0ksYUFBQTtFQUNBLG1CQUFBO0FDVnhCO0FEWXdCO0VBQ0ksZUFBQTtBQ1Y1QjtBRFl3QjtFQUNJLFdBQUE7RUFDQSxTQUFBO0FDVjVCIiwiZmlsZSI6InNyYy9hcHAvcGFnZXMvY3JpY2tldC9jcmlja2V0LnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1oZWFkZXJ7XG5cbiAgICAuYmFja3tcbiAgICAgICAgZm9udC1zaXplOiAyN3B4O1xuICAgICAgICBtYXJnaW4tbGVmdDogMTBweDtcbiAgICB9XG4gICAgaW9uLWJ1dHRvbntcbiAgICAgICAgbWFyZ2luOiAwO1xuXG4gICAgICAgIGlvbi1pY29ue1xuICAgICAgICAgICAgY29sb3I6IGJsYWNrO1xuICAgICAgICAgICAgZm9udC1zaXplOiAyMHB4O1xuICAgICAgICB9XG4gICAgfVxufVxuXG4ubWFpbl9jb250ZW50X2RpdntcbiAgICB3aWR0aDogMTAwJTtcblxuICAgIGlvbi1sYWJlbCB7XG4gICAgICAgIGRpc3BsYXk6IGJsb2NrO1xuICAgIH1cblxuICAgIC5oZWFkX2xibHtcbiAgICAgICAgZm9udC13ZWlnaHQ6IDYwMDtcbiAgICB9XG5cbiAgICAuc2xpZGVyX2RpdntcbiAgICAgICAgcGFkZGluZzogMTZweDtcbiAgICAgICAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkIGxpZ2h0Z3JheTtcblxuICAgICAgICBpb24tc2xpZGVze1xuICAgICAgICAgICAgcGFkZGluZy1ib3R0b206IDVweDtcbiAgICAgICAgICAgIHBhZGRpbmctdG9wOiAxNXB4O1xuXG4gICAgICAgICAgICBpb24tc2xpZGV7XG4gICAgICAgICAgICAgICAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xuICAgICAgICAgICAgICAgIG1hcmdpbi1sZWZ0OiA1cHg7XG5cbiAgICAgICAgICAgICAgICAubWFpbl9kaXZ7XG4gICAgICAgICAgICAgICAgICAgIHdpZHRoOiAxMDAlO1xuICAgICAgICAgICAgICAgICAgICBib3gtc2hhZG93OiAwcHggM3B4IDZweCByZ2JhKDAsMCwwLDAuMyk7XG4gICAgICAgICAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDVweDtcbiAgICAgICAgICAgICAgICAgICAgLmltYWdlX2RpdntcbiAgICAgICAgICAgICAgICAgICAgICAgIHdpZHRoOiAxMDAlO1xuICAgICAgICAgICAgICAgICAgICAgICAgaGVpZ2h0OiAxMDBweDtcbiAgICAgICAgICAgICAgICAgICAgICAgIGJvcmRlci10b3AtbGVmdC1yYWRpdXM6IDVweDtcbiAgICAgICAgICAgICAgICAgICAgICAgIGJvcmRlci10b3AtcmlnaHQtcmFkaXVzOiA1cHg7XG4gICAgICAgICAgICAgICAgICAgICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIGlvbi1pY29ue1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBib3R0b206IDVweDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZWZ0OiA1cHg7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udC1zaXplOiAyNXB4O1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yOiB3aGl0ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICBcbiAgICAgICAgICAgICAgICAgICAgLm5hbWV7XG4gICAgICAgICAgICAgICAgICAgICAgICBwYWRkaW5nOiAxMHB4O1xuICAgICAgICAgICAgICAgICAgICAgICAgZm9udC1zaXplOiAxM3B4O1xuICAgICAgICAgICAgICAgICAgICAgICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgICAgICAgICAgICAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiA1MDA7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAubG93ZXJfZGl2e1xuICAgICAgICBwYWRkaW5nOiAxNnB4IDBweDtcbiAgICAgICAgLm5ld3NfY2FyZHtcbiAgICAgICAgICAgIHBhZGRpbmc6IDE2cHg7XG4gICAgICAgICAgICBib3JkZXItYm90dG9tOiAxcHggc29saWQgbGlnaHRncmF5O1xuXG4gICAgICAgICAgICAuZmxleF9kaXZ7XG4gICAgICAgICAgICAgICAgZGlzcGxheTogZmxleDtcblxuICAgICAgICAgICAgICAgIC5iYWNrX2ltYWdlMntcbiAgICAgICAgICAgICAgICAgICAgaGVpZ2h0OiA4MHB4O1xuICAgICAgICAgICAgICAgICAgICB3aWR0aDogOTBweDtcbiAgICAgICAgICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogNXB4O1xuICAgICAgICAgICAgICAgICAgICBtaW4td2lkdGg6IDkwcHg7XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgLmRldGFpbF9kaXZ7XG4gICAgICAgICAgICAgICAgICAgIHBhZGRpbmctcmlnaHQ6IDEwcHg7XG4gICAgICAgICAgICAgICAgICAgIC5oZWFkX2xpbmUye1xuICAgICAgICAgICAgICAgICAgICAgICAgZm9udC1zaXplOiAxNXB4O1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIC5zaGFyZV9kaXZ7XG4gICAgICAgICAgICAgICAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICAgICAgICAgICAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcblxuICAgICAgICAgICAgICAgICAgICAgICAgaW9uLWxhYmVsIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250LXNpemU6IDEzcHg7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICBpb24tYnV0dG9ue1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yOiBncmF5O1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1hcmdpbjogMDtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cbn0iLCJpb24taGVhZGVyIC5iYWNrIHtcbiAgZm9udC1zaXplOiAyN3B4O1xuICBtYXJnaW4tbGVmdDogMTBweDtcbn1cbmlvbi1oZWFkZXIgaW9uLWJ1dHRvbiB7XG4gIG1hcmdpbjogMDtcbn1cbmlvbi1oZWFkZXIgaW9uLWJ1dHRvbiBpb24taWNvbiB7XG4gIGNvbG9yOiBibGFjaztcbiAgZm9udC1zaXplOiAyMHB4O1xufVxuXG4ubWFpbl9jb250ZW50X2RpdiB7XG4gIHdpZHRoOiAxMDAlO1xufVxuLm1haW5fY29udGVudF9kaXYgaW9uLWxhYmVsIHtcbiAgZGlzcGxheTogYmxvY2s7XG59XG4ubWFpbl9jb250ZW50X2RpdiAuaGVhZF9sYmwge1xuICBmb250LXdlaWdodDogNjAwO1xufVxuLm1haW5fY29udGVudF9kaXYgLnNsaWRlcl9kaXYge1xuICBwYWRkaW5nOiAxNnB4O1xuICBib3JkZXItYm90dG9tOiAxcHggc29saWQgbGlnaHRncmF5O1xufVxuLm1haW5fY29udGVudF9kaXYgLnNsaWRlcl9kaXYgaW9uLXNsaWRlcyB7XG4gIHBhZGRpbmctYm90dG9tOiA1cHg7XG4gIHBhZGRpbmctdG9wOiAxNXB4O1xufVxuLm1haW5fY29udGVudF9kaXYgLnNsaWRlcl9kaXYgaW9uLXNsaWRlcyBpb24tc2xpZGUge1xuICBtYXJnaW4tcmlnaHQ6IDEwcHg7XG4gIG1hcmdpbi1sZWZ0OiA1cHg7XG59XG4ubWFpbl9jb250ZW50X2RpdiAuc2xpZGVyX2RpdiBpb24tc2xpZGVzIGlvbi1zbGlkZSAubWFpbl9kaXYge1xuICB3aWR0aDogMTAwJTtcbiAgYm94LXNoYWRvdzogMHB4IDNweCA2cHggcmdiYSgwLCAwLCAwLCAwLjMpO1xuICBib3JkZXItcmFkaXVzOiA1cHg7XG59XG4ubWFpbl9jb250ZW50X2RpdiAuc2xpZGVyX2RpdiBpb24tc2xpZGVzIGlvbi1zbGlkZSAubWFpbl9kaXYgLmltYWdlX2RpdiB7XG4gIHdpZHRoOiAxMDAlO1xuICBoZWlnaHQ6IDEwMHB4O1xuICBib3JkZXItdG9wLWxlZnQtcmFkaXVzOiA1cHg7XG4gIGJvcmRlci10b3AtcmlnaHQtcmFkaXVzOiA1cHg7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5zbGlkZXJfZGl2IGlvbi1zbGlkZXMgaW9uLXNsaWRlIC5tYWluX2RpdiAuaW1hZ2VfZGl2IGlvbi1pY29uIHtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICBib3R0b206IDVweDtcbiAgbGVmdDogNXB4O1xuICBmb250LXNpemU6IDI1cHg7XG4gIGNvbG9yOiB3aGl0ZTtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5zbGlkZXJfZGl2IGlvbi1zbGlkZXMgaW9uLXNsaWRlIC5tYWluX2RpdiAubmFtZSB7XG4gIHBhZGRpbmc6IDEwcHg7XG4gIGZvbnQtc2l6ZTogMTNweDtcbiAgdGV4dC1hbGlnbjogbGVmdDtcbiAgZm9udC13ZWlnaHQ6IDUwMDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5sb3dlcl9kaXYge1xuICBwYWRkaW5nOiAxNnB4IDBweDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5sb3dlcl9kaXYgLm5ld3NfY2FyZCB7XG4gIHBhZGRpbmc6IDE2cHg7XG4gIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCBsaWdodGdyYXk7XG59XG4ubWFpbl9jb250ZW50X2RpdiAubG93ZXJfZGl2IC5uZXdzX2NhcmQgLmZsZXhfZGl2IHtcbiAgZGlzcGxheTogZmxleDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5sb3dlcl9kaXYgLm5ld3NfY2FyZCAuZmxleF9kaXYgLmJhY2tfaW1hZ2UyIHtcbiAgaGVpZ2h0OiA4MHB4O1xuICB3aWR0aDogOTBweDtcbiAgYm9yZGVyLXJhZGl1czogNXB4O1xuICBtaW4td2lkdGg6IDkwcHg7XG59XG4ubWFpbl9jb250ZW50X2RpdiAubG93ZXJfZGl2IC5uZXdzX2NhcmQgLmZsZXhfZGl2IC5kZXRhaWxfZGl2IHtcbiAgcGFkZGluZy1yaWdodDogMTBweDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5sb3dlcl9kaXYgLm5ld3NfY2FyZCAuZmxleF9kaXYgLmRldGFpbF9kaXYgLmhlYWRfbGluZTIge1xuICBmb250LXNpemU6IDE1cHg7XG59XG4ubWFpbl9jb250ZW50X2RpdiAubG93ZXJfZGl2IC5uZXdzX2NhcmQgLmZsZXhfZGl2IC5kZXRhaWxfZGl2IC5zaGFyZV9kaXYge1xuICBkaXNwbGF5OiBmbGV4O1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xufVxuLm1haW5fY29udGVudF9kaXYgLmxvd2VyX2RpdiAubmV3c19jYXJkIC5mbGV4X2RpdiAuZGV0YWlsX2RpdiAuc2hhcmVfZGl2IGlvbi1sYWJlbCB7XG4gIGZvbnQtc2l6ZTogMTNweDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5sb3dlcl9kaXYgLm5ld3NfY2FyZCAuZmxleF9kaXYgLmRldGFpbF9kaXYgLnNoYXJlX2RpdiBpb24tYnV0dG9uIHtcbiAgY29sb3I6IGdyYXk7XG4gIG1hcmdpbjogMDtcbn0iXX0= */";
    /***/
  },

  /***/
  "./src/app/pages/cricket/cricket.page.ts":
  /*!***********************************************!*\
    !*** ./src/app/pages/cricket/cricket.page.ts ***!
    \***********************************************/

  /*! exports provided: CricketPage */

  /***/
  function srcAppPagesCricketCricketPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "CricketPage", function () {
      return CricketPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var src_app_services_games_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! src/app/services/games.service */
    "./src/app/services/games.service.ts");
    /* harmony import */


    var src_app_services_dummy_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! src/app/services/dummy.service */
    "./src/app/services/dummy.service.ts");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");

    var CricketPage = /*#__PURE__*/function () {
      function CricketPage(game, dummy, router, navCtrl) {
        _classCallCheck(this, CricketPage);

        this.game = game;
        this.dummy = dummy;
        this.router = router;
        this.navCtrl = navCtrl;
        this.slideOpts = {
          slidesPerView: 1.3
        };
        this.games = this.game.games;
        this.allNews = this.dummy.news;
      }

      _createClass(CricketPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }, {
        key: "goToNews",
        value: function goToNews(val) {
          var navData = {
            queryParams: {
              id: val
            }
          };
          this.router.navigate(['/tabs/news'], navData);
        }
      }, {
        key: "goToCricketVideo",
        value: function goToCricketVideo() {
          this.router.navigate(['/cricket-news']);
        }
      }, {
        key: "goBack",
        value: function goBack() {
          this.navCtrl.back();
        }
      }]);

      return CricketPage;
    }();

    CricketPage.ctorParameters = function () {
      return [{
        type: src_app_services_games_service__WEBPACK_IMPORTED_MODULE_2__["GamesService"]
      }, {
        type: src_app_services_dummy_service__WEBPACK_IMPORTED_MODULE_3__["DummyService"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["NavController"]
      }];
    };

    CricketPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-cricket',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./cricket.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/cricket/cricket.page.html"))["default"],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./cricket.page.scss */
      "./src/app/pages/cricket/cricket.page.scss"))["default"]]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [src_app_services_games_service__WEBPACK_IMPORTED_MODULE_2__["GamesService"], src_app_services_dummy_service__WEBPACK_IMPORTED_MODULE_3__["DummyService"], _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"], _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["NavController"]])], CricketPage);
    /***/
  }
}]);
//# sourceMappingURL=cricket-cricket-module-es5.js.map