function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["home-home-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/home/home.page.html":
  /*!*********************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/home/home.page.html ***!
    \*********************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppPagesHomeHomePageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n  <div class=\"header_div\" [class.ios_pad]=\"plt == 'ios'\">\n\n    <div class=\"left_div\">\n      <ion-buttons slot=\"start\">\n        <ion-menu-button color=\"dark\"></ion-menu-button>\n        <div style=\"display: flex;align-items: center;\" (click)=\"goToChooseLanguage()\">\n          <ion-label>English</ion-label>\n          <ion-icon name=\"caret-down-outline\"></ion-icon>\n        </div>\n      </ion-buttons>\n    </div>\n\n    <div class=\"right_div\">\n      <ion-icon name=\"notifications-outline\" (click)=\"goToNotification()\"></ion-icon>\n      <ion-button (click)=\"goToRegister()\" fill=\"outline\" size=\"small\" *ngIf=\"!isSignIn\">\n        Sign In\n      </ion-button>\n      <div class=\"user_image bg_image\" *ngIf=\"isSignIn\" [style.backgroundImage]=\"'url(assets/imgs/users/user1.jpg)'\"\n        (click)=\"goToProfile()\"></div>\n    </div>\n\n  </div>\n</ion-header>\n\n<ion-content>\n  <div class=\"main_content_div\">\n\n    <div class=\"upper_div\">\n      <img src=\"assets/imgs/logo.png\" class=\"logo\">\n      <ion-input type=\"text\">\n        <ion-icon name=\"search-outline\"></ion-icon>\n      </ion-input>\n\n      <div class=\"slider_div\">\n\n        <ion-slides mode=\"ios\" pager=\"ios\">\n\n          <ion-slide>\n            <ion-grid>\n              <ion-row>\n                <ion-col size=\"3\" *ngFor=\"let item of sliderImage\" (click)=\"goToMain(item)\">\n                  <div class=\"col_div\">\n                    <img src=\"{{item.img}}\">\n                    <ion-label>{{item.name}}</ion-label>\n                  </div>\n                </ion-col>\n              </ion-row>\n            </ion-grid>\n          </ion-slide>\n\n          <ion-slide>\n            <ion-grid>\n              <ion-row>\n                <ion-col size=\"3\" *ngFor=\"let item of sliderImage\">\n                  <div class=\"col_div\">\n                    <img src=\"{{item.img}}\">\n                    <ion-label>{{item.name}}</ion-label>\n                  </div>\n                </ion-col>\n              </ion-row>\n            </ion-grid>\n          </ion-slide>\n\n          <ion-slide>\n            <ion-grid>\n              <ion-row>\n                <ion-col size=\"3\" *ngFor=\"let item of sliderImage\">\n                  <div class=\"col_div\">\n                    <img src=\"{{item.img}}\">\n                    <ion-label>{{item.name}}</ion-label>\n                  </div>\n                </ion-col>\n              </ion-row>\n            </ion-grid>\n          </ion-slide>\n\n        </ion-slides>\n\n      </div>\n    </div>\n\n    <div class=\"lower_div\">\n\n      <div class=\"news_card\" *ngFor=\"let item of allNews\">\n\n        <div class=\"chip_div\">\n          <div class=\"chip\">\n            <div class=\"round\"></div>\n            <ion-label>New News</ion-label>\n          </div>\n        </div>\n\n        <div class=\"back_image bg_image\" *ngIf=\"item.img\" [style.backgroundImage]=\"'url('+ item.img+')'\"></div>\n\n        <video playsinline webkit-playsinline autoplay *ngIf=\"!item.img\">\n          <source src=\"assets/imgs/video.mp4\" type=\"video/mp4\">\n        </video>\n\n        <div class=\"channel_detail\">\n          <img src=\"{{item.logo}}\">\n          <ion-label class=\"channel_name\">The Times of India</ion-label> •\n          <ion-label class=\"follow_lbl\">Follow</ion-label>\n        </div>\n\n        <ion-label class=\"head_line\">{{item.headline}}</ion-label>\n\n        <ion-label class=\"detail\">{{item.detail}}</ion-label>\n\n        <ion-label class=\"link_lbl\">https://initappz.com/</ion-label>\n\n        <div class=\"like_div\">\n          <img src=\"assets/imgs/like.png\">\n          <ion-label>12</ion-label>\n          <ion-label class=\"share_lbl\">2 Share</ion-label>\n          <ion-label class=\"share_lbl\">222 Views</ion-label>\n        </div>\n\n        <div class=\"share_div\">\n          <div class=\"left_div\">\n            <div class=\"round_div\">\n              <ion-icon name=\"thumbs-up-outline\"></ion-icon>\n            </div>\n            <div class=\"round_div\">\n              <ion-icon name=\"chatbubble-outline\"></ion-icon>\n            </div>\n            <div class=\"round_div\" (click)=\"shareActionSheet()\">\n              <ion-icon name=\"arrow-redo-outline\"></ion-icon>\n            </div>\n          </div>\n          <div class=\"right_div\">\n            <div class=\"round_div\" style=\"margin-right: 0px;\">\n              <ion-icon name=\"bookmark-outline\"></ion-icon>\n            </div>\n            <ion-button (click)=\"presentActionSheet()\" fill=\"clear\" size=\"small\">\n              <ion-icon name=\"ellipsis-vertical\"></ion-icon>\n            </ion-button>\n          </div>\n        </div>\n\n        <ion-label class=\"link_lbl\">10 minutes</ion-label>\n\n      </div>\n\n    </div>\n\n  </div>\n</ion-content>";
    /***/
  },

  /***/
  "./src/app/pages/home/home-routing.module.ts":
  /*!***************************************************!*\
    !*** ./src/app/pages/home/home-routing.module.ts ***!
    \***************************************************/

  /*! exports provided: HomePageRoutingModule */

  /***/
  function srcAppPagesHomeHomeRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "HomePageRoutingModule", function () {
      return HomePageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _home_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./home.page */
    "./src/app/pages/home/home.page.ts");

    var routes = [{
      path: '',
      component: _home_page__WEBPACK_IMPORTED_MODULE_3__["HomePage"]
    }];

    var HomePageRoutingModule = function HomePageRoutingModule() {
      _classCallCheck(this, HomePageRoutingModule);
    };

    HomePageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], HomePageRoutingModule);
    /***/
  },

  /***/
  "./src/app/pages/home/home.module.ts":
  /*!*******************************************!*\
    !*** ./src/app/pages/home/home.module.ts ***!
    \*******************************************/

  /*! exports provided: HomePageModule */

  /***/
  function srcAppPagesHomeHomeModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "HomePageModule", function () {
      return HomePageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _home_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./home-routing.module */
    "./src/app/pages/home/home-routing.module.ts");
    /* harmony import */


    var _home_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./home.page */
    "./src/app/pages/home/home.page.ts");

    var HomePageModule = function HomePageModule() {
      _classCallCheck(this, HomePageModule);
    };

    HomePageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _home_routing_module__WEBPACK_IMPORTED_MODULE_5__["HomePageRoutingModule"]],
      declarations: [_home_page__WEBPACK_IMPORTED_MODULE_6__["HomePage"]]
    })], HomePageModule);
    /***/
  },

  /***/
  "./src/app/pages/home/home.page.scss":
  /*!*******************************************!*\
    !*** ./src/app/pages/home/home.page.scss ***!
    \*******************************************/

  /*! exports provided: default */

  /***/
  function srcAppPagesHomeHomePageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".header_div {\n  width: 100%;\n  display: flex;\n  justify-content: space-between;\n  padding-left: 8px;\n  padding-right: 12px;\n  padding-top: 8px;\n  padding-bottom: 8px;\n}\n.header_div .right_div {\n  display: flex;\n  align-items: center;\n}\n.header_div .right_div ion-icon {\n  font-size: 22px;\n  margin-right: 10px;\n}\n.header_div .right_div ion-button {\n  --border-radius: 3px;\n}\n.header_div .right_div .user_image {\n  height: 35px;\n  width: 35px;\n  border-radius: 100%;\n}\n.main_content_div {\n  width: 100%;\n}\n.main_content_div ion-label {\n  display: block;\n}\n.main_content_div .upper_div {\n  padding: 10px;\n}\n.main_content_div .upper_div .logo {\n  width: 130px;\n  margin: auto;\n  display: block;\n  margin-bottom: 20px;\n}\n.main_content_div .upper_div ion-input {\n  border: 1px solid black;\n  border-radius: 25px;\n}\n.main_content_div .upper_div ion-input ion-icon {\n  font-size: 20px;\n  padding-left: 10px;\n  padding-right: 5px;\n}\n.main_content_div .upper_div .slider_div ion-grid {\n  padding: 0;\n}\n.main_content_div .upper_div .slider_div ion-grid ion-col {\n  padding: 0;\n}\n.main_content_div .upper_div .slider_div .col_div {\n  text-align: center;\n  width: 100%;\n  height: 80px;\n  display: flex;\n  flex-direction: column;\n  justify-content: center;\n  align-items: center;\n}\n.main_content_div .upper_div .slider_div .col_div img {\n  width: 20px;\n}\n.main_content_div .upper_div .slider_div .col_div ion-label {\n  margin-top: 5px;\n  font-size: 12px;\n}\n.main_content_div .lower_div .news_card {\n  padding: 16px;\n  border-bottom: 1px solid lightgray;\n}\n.main_content_div .lower_div .news_card .chip_div {\n  text-align: center;\n  margin-bottom: 15px;\n}\n.main_content_div .lower_div .news_card .chip_div .round {\n  width: 15px;\n  height: 15px;\n  background: white;\n  border-radius: 100%;\n  border: 4px solid var(--ion-color-primary);\n}\n.main_content_div .lower_div .news_card .chip_div .chip {\n  border-radius: 25px;\n  border: 1px solid lightgray;\n  width: -webkit-fit-content;\n  width: -moz-fit-content;\n  width: fit-content;\n  padding: 10px;\n  display: flex;\n  align-items: center;\n  margin: auto;\n}\n.main_content_div .lower_div .news_card .chip_div .chip ion-label {\n  font-size: 14px;\n  margin-left: 10px;\n}\n.main_content_div .lower_div .news_card .back_image {\n  width: 100%;\n  height: 180px;\n  border-radius: 10px;\n}\n.main_content_div .lower_div .news_card video {\n  width: 100%;\n  border-radius: 10px;\n}\n.main_content_div .lower_div .news_card .channel_detail {\n  display: flex;\n  margin-top: 15px;\n  align-items: center;\n  margin-bottom: 10px;\n}\n.main_content_div .lower_div .news_card .channel_detail img {\n  width: 25px;\n}\n.main_content_div .lower_div .news_card .channel_detail .channel_name {\n  font-weight: 600;\n  font-size: 15px;\n  margin-left: 10px;\n  margin-right: 10px;\n}\n.main_content_div .lower_div .news_card .channel_detail .follow_lbl {\n  color: var(--ion-color-primary);\n  font-size: 13px;\n  margin-left: 10px;\n}\n.main_content_div .lower_div .news_card .head_line {\n  font-weight: 500;\n}\n.main_content_div .lower_div .news_card .detail {\n  margin-top: 10px;\n  color: gray;\n  font-size: 15px;\n}\n.main_content_div .lower_div .news_card .link_lbl {\n  margin-top: 10px;\n  font-size: 13px;\n  color: gray;\n}\n.main_content_div .lower_div .news_card .like_div {\n  display: flex;\n  font-size: 13px;\n  color: #505050;\n  margin-top: 10px;\n  margin-bottom: 10px;\n}\n.main_content_div .lower_div .news_card .like_div img {\n  width: 20px;\n  height: 20px;\n  margin-right: 10px;\n}\n.main_content_div .lower_div .news_card .like_div .share_lbl {\n  margin-left: 15px;\n}\n.main_content_div .lower_div .news_card .share_div {\n  display: flex;\n  width: 100%;\n  justify-content: space-between;\n}\n.main_content_div .lower_div .news_card .share_div .left_div {\n  display: flex;\n}\n.main_content_div .lower_div .news_card .share_div .right_div {\n  display: flex;\n  align-items: center;\n}\n.main_content_div .lower_div .news_card .share_div .right_div ion-button {\n  margin: 0;\n}\n.main_content_div .lower_div .news_card .share_div .right_div ion-button ion-icon {\n  color: #505050;\n}\n.main_content_div .lower_div .news_card .share_div .round_div {\n  border: 1px solid lightgray;\n  height: 40px;\n  width: 40px;\n  border-radius: 100%;\n  position: relative;\n  margin-right: 10px;\n}\n.main_content_div .lower_div .news_card .share_div .round_div ion-icon {\n  position: absolute;\n  top: 50%;\n  left: 50%;\n  transform: translate(-50%, -50%);\n  font-size: 18px;\n  color: #505050;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvaG9tZS9FOlxcSW9uaWMgUHJvamVjdHNcXGlvbmljLTUtdGVtcGxhdGUtYnVuZGxlLWlvbmljLTUtdGhlbWVzLWJ1bmRsZXMtaW9uaWMtNS10ZW1wbGF0ZXMtd2l0aC0xMC1hcHBzXFxBcHBfc291cmNlX2NvZGVcXEFwcHNfY29kZVxcTXVsdGlfcHVycG9zZS9zcmNcXGFwcFxccGFnZXNcXGhvbWVcXGhvbWUucGFnZS5zY3NzIiwic3JjL2FwcC9wYWdlcy9ob21lL2hvbWUucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksV0FBQTtFQUNBLGFBQUE7RUFDQSw4QkFBQTtFQUNBLGlCQUFBO0VBQ0EsbUJBQUE7RUFDQSxnQkFBQTtFQUNBLG1CQUFBO0FDQ0o7QURFSTtFQUNJLGFBQUE7RUFDQSxtQkFBQTtBQ0FSO0FEQ1E7RUFDSSxlQUFBO0VBQ0Esa0JBQUE7QUNDWjtBREVRO0VBQ0ksb0JBQUE7QUNBWjtBREdRO0VBQ0ksWUFBQTtFQUNBLFdBQUE7RUFDQSxtQkFBQTtBQ0RaO0FETUE7RUFDSSxXQUFBO0FDSEo7QURLSTtFQUNJLGNBQUE7QUNIUjtBRE1JO0VBQ0ksYUFBQTtBQ0pSO0FETVE7RUFDSSxZQUFBO0VBQ0EsWUFBQTtFQUNBLGNBQUE7RUFDQSxtQkFBQTtBQ0paO0FET1E7RUFDSSx1QkFBQTtFQUNBLG1CQUFBO0FDTFo7QURNWTtFQUNJLGVBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0FDSmhCO0FEU1k7RUFDSSxVQUFBO0FDUGhCO0FEU2dCO0VBQ0ksVUFBQTtBQ1BwQjtBRFVZO0VBQ0ksa0JBQUE7RUFFQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGFBQUE7RUFDQSxzQkFBQTtFQUNBLHVCQUFBO0VBQ0EsbUJBQUE7QUNUaEI7QURXZ0I7RUFDSSxXQUFBO0FDVHBCO0FEV2dCO0VBQ0ksZUFBQTtFQUNBLGVBQUE7QUNUcEI7QURnQlE7RUFDSSxhQUFBO0VBQ0Esa0NBQUE7QUNkWjtBRGdCWTtFQUNJLGtCQUFBO0VBQ0EsbUJBQUE7QUNkaEI7QURnQmdCO0VBQ0ksV0FBQTtFQUNBLFlBQUE7RUFDQSxpQkFBQTtFQUNBLG1CQUFBO0VBQ0EsMENBQUE7QUNkcEI7QURnQmdCO0VBQ0ksbUJBQUE7RUFDQSwyQkFBQTtFQUNBLDBCQUFBO0VBQUEsdUJBQUE7RUFBQSxrQkFBQTtFQUNBLGFBQUE7RUFDQSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSxZQUFBO0FDZHBCO0FEZ0JvQjtFQUNJLGVBQUE7RUFDQSxpQkFBQTtBQ2R4QjtBRGtCWTtFQUNJLFdBQUE7RUFDQSxhQUFBO0VBQ0EsbUJBQUE7QUNoQmhCO0FEbUJZO0VBQ0ksV0FBQTtFQUNBLG1CQUFBO0FDakJoQjtBRG9CWTtFQUNJLGFBQUE7RUFDQSxnQkFBQTtFQUNBLG1CQUFBO0VBQ0EsbUJBQUE7QUNsQmhCO0FEbUJnQjtFQUNJLFdBQUE7QUNqQnBCO0FEbUJnQjtFQUNJLGdCQUFBO0VBQ0EsZUFBQTtFQUNBLGlCQUFBO0VBQ0Esa0JBQUE7QUNqQnBCO0FEbUJnQjtFQUNJLCtCQUFBO0VBQ0EsZUFBQTtFQUNBLGlCQUFBO0FDakJwQjtBRHFCWTtFQUNJLGdCQUFBO0FDbkJoQjtBRHFCWTtFQUNJLGdCQUFBO0VBQ0EsV0FBQTtFQUNBLGVBQUE7QUNuQmhCO0FEMkJZO0VBQ0ksZ0JBQUE7RUFDQSxlQUFBO0VBQ0EsV0FBQTtBQ3pCaEI7QUQ0Qlk7RUFDSSxhQUFBO0VBQ0EsZUFBQTtFQUNBLGNBQUE7RUFDQSxnQkFBQTtFQUNBLG1CQUFBO0FDMUJoQjtBRDJCZ0I7RUFDSSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0FDekJwQjtBRDJCZ0I7RUFDSSxpQkFBQTtBQ3pCcEI7QUQ2Qlk7RUFDSSxhQUFBO0VBQ0EsV0FBQTtFQUNBLDhCQUFBO0FDM0JoQjtBRDZCZ0I7RUFDSSxhQUFBO0FDM0JwQjtBRDhCZ0I7RUFDSSxhQUFBO0VBQ0EsbUJBQUE7QUM1QnBCO0FENkJvQjtFQUNJLFNBQUE7QUMzQnhCO0FENkJ3QjtFQUNJLGNBQUE7QUMzQjVCO0FEZ0NnQjtFQUNJLDJCQUFBO0VBQ0EsWUFBQTtFQUNBLFdBQUE7RUFDQSxtQkFBQTtFQUNBLGtCQUFBO0VBQ0Esa0JBQUE7QUM5QnBCO0FEK0JvQjtFQUNJLGtCQUFBO0VBQ0EsUUFBQTtFQUNBLFNBQUE7RUFDQSxnQ0FBQTtFQUNBLGVBQUE7RUFDQSxjQUFBO0FDN0J4QiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2hvbWUvaG9tZS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuaGVhZGVyX2RpdiB7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XG4gICAgcGFkZGluZy1sZWZ0OiA4cHg7XG4gICAgcGFkZGluZy1yaWdodDogMTJweDtcbiAgICBwYWRkaW5nLXRvcDogOHB4O1xuICAgIHBhZGRpbmctYm90dG9tOiA4cHg7XG4gICAgLmxlZnRfZGl2IHtcbiAgICB9XG4gICAgLnJpZ2h0X2RpdiB7XG4gICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAgICAgIGlvbi1pY29uIHtcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogMjJweDtcbiAgICAgICAgICAgIG1hcmdpbi1yaWdodDogMTBweDtcbiAgICAgICAgfVxuXG4gICAgICAgIGlvbi1idXR0b24ge1xuICAgICAgICAgICAgLS1ib3JkZXItcmFkaXVzOiAzcHg7XG4gICAgICAgIH1cblxuICAgICAgICAudXNlcl9pbWFnZSB7XG4gICAgICAgICAgICBoZWlnaHQ6IDM1cHg7XG4gICAgICAgICAgICB3aWR0aDogMzVweDtcbiAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDEwMCU7XG4gICAgICAgIH1cbiAgICB9XG59XG5cbi5tYWluX2NvbnRlbnRfZGl2IHtcbiAgICB3aWR0aDogMTAwJTtcblxuICAgIGlvbi1sYWJlbCB7XG4gICAgICAgIGRpc3BsYXk6IGJsb2NrO1xuICAgIH1cblxuICAgIC51cHBlcl9kaXYge1xuICAgICAgICBwYWRkaW5nOiAxMHB4O1xuXG4gICAgICAgIC5sb2dvIHtcbiAgICAgICAgICAgIHdpZHRoOiAxMzBweDtcbiAgICAgICAgICAgIG1hcmdpbjogYXV0bztcbiAgICAgICAgICAgIGRpc3BsYXk6IGJsb2NrO1xuICAgICAgICAgICAgbWFyZ2luLWJvdHRvbTogMjBweDtcbiAgICAgICAgfVxuXG4gICAgICAgIGlvbi1pbnB1dCB7XG4gICAgICAgICAgICBib3JkZXI6IDFweCBzb2xpZCBibGFjaztcbiAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDI1cHg7XG4gICAgICAgICAgICBpb24taWNvbiB7XG4gICAgICAgICAgICAgICAgZm9udC1zaXplOiAyMHB4O1xuICAgICAgICAgICAgICAgIHBhZGRpbmctbGVmdDogMTBweDtcbiAgICAgICAgICAgICAgICBwYWRkaW5nLXJpZ2h0OiA1cHg7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICAuc2xpZGVyX2RpdiB7XG4gICAgICAgICAgICBpb24tZ3JpZCB7XG4gICAgICAgICAgICAgICAgcGFkZGluZzogMDtcblxuICAgICAgICAgICAgICAgIGlvbi1jb2wge1xuICAgICAgICAgICAgICAgICAgICBwYWRkaW5nOiAwO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIC5jb2xfZGl2IHtcbiAgICAgICAgICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgICAgICAgICAgICAgLy8gYm9yZGVyOiAxcHggc29saWQ7XG4gICAgICAgICAgICAgICAgd2lkdGg6IDEwMCU7XG4gICAgICAgICAgICAgICAgaGVpZ2h0OiA4MHB4O1xuICAgICAgICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgICAgICAgICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbiAgICAgICAgICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgICAgICAgICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuXG4gICAgICAgICAgICAgICAgaW1nIHtcbiAgICAgICAgICAgICAgICAgICAgd2lkdGg6IDIwcHg7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGlvbi1sYWJlbCB7XG4gICAgICAgICAgICAgICAgICAgIG1hcmdpbi10b3A6IDVweDtcbiAgICAgICAgICAgICAgICAgICAgZm9udC1zaXplOiAxMnB4O1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cblxuICAgIC5sb3dlcl9kaXYge1xuICAgICAgICAubmV3c19jYXJkIHtcbiAgICAgICAgICAgIHBhZGRpbmc6IDE2cHg7XG4gICAgICAgICAgICBib3JkZXItYm90dG9tOiAxcHggc29saWQgbGlnaHRncmF5O1xuXG4gICAgICAgICAgICAuY2hpcF9kaXYge1xuICAgICAgICAgICAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICAgICAgICAgICAgICBtYXJnaW4tYm90dG9tOiAxNXB4O1xuXG4gICAgICAgICAgICAgICAgLnJvdW5kIHtcbiAgICAgICAgICAgICAgICAgICAgd2lkdGg6IDE1cHg7XG4gICAgICAgICAgICAgICAgICAgIGhlaWdodDogMTVweDtcbiAgICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZDogd2hpdGU7XG4gICAgICAgICAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDEwMCU7XG4gICAgICAgICAgICAgICAgICAgIGJvcmRlcjogNHB4IHNvbGlkIHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgLmNoaXAge1xuICAgICAgICAgICAgICAgICAgICBib3JkZXItcmFkaXVzOiAyNXB4O1xuICAgICAgICAgICAgICAgICAgICBib3JkZXI6IDFweCBzb2xpZCBsaWdodGdyYXk7XG4gICAgICAgICAgICAgICAgICAgIHdpZHRoOiBmaXQtY29udGVudDtcbiAgICAgICAgICAgICAgICAgICAgcGFkZGluZzogMTBweDtcbiAgICAgICAgICAgICAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAgICAgICAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICAgICAgICAgICAgICAgICAgbWFyZ2luOiBhdXRvO1xuXG4gICAgICAgICAgICAgICAgICAgIGlvbi1sYWJlbCB7XG4gICAgICAgICAgICAgICAgICAgICAgICBmb250LXNpemU6IDE0cHg7XG4gICAgICAgICAgICAgICAgICAgICAgICBtYXJnaW4tbGVmdDogMTBweDtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIC5iYWNrX2ltYWdlIHtcbiAgICAgICAgICAgICAgICB3aWR0aDogMTAwJTtcbiAgICAgICAgICAgICAgICBoZWlnaHQ6IDE4MHB4O1xuICAgICAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDEwcHg7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIHZpZGVvIHtcbiAgICAgICAgICAgICAgICB3aWR0aDogMTAwJTtcbiAgICAgICAgICAgICAgICBib3JkZXItcmFkaXVzOiAxMHB4O1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAuY2hhbm5lbF9kZXRhaWwge1xuICAgICAgICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgICAgICAgICAgbWFyZ2luLXRvcDogMTVweDtcbiAgICAgICAgICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgICAgICAgICAgICAgIG1hcmdpbi1ib3R0b206IDEwcHg7XG4gICAgICAgICAgICAgICAgaW1nIHtcbiAgICAgICAgICAgICAgICAgICAgd2lkdGg6IDI1cHg7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIC5jaGFubmVsX25hbWUge1xuICAgICAgICAgICAgICAgICAgICBmb250LXdlaWdodDogNjAwO1xuICAgICAgICAgICAgICAgICAgICBmb250LXNpemU6IDE1cHg7XG4gICAgICAgICAgICAgICAgICAgIG1hcmdpbi1sZWZ0OiAxMHB4O1xuICAgICAgICAgICAgICAgICAgICBtYXJnaW4tcmlnaHQ6IDEwcHg7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIC5mb2xsb3dfbGJsIHtcbiAgICAgICAgICAgICAgICAgICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcbiAgICAgICAgICAgICAgICAgICAgZm9udC1zaXplOiAxM3B4O1xuICAgICAgICAgICAgICAgICAgICBtYXJnaW4tbGVmdDogMTBweDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIC5oZWFkX2xpbmUge1xuICAgICAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiA1MDA7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICAuZGV0YWlsIHtcbiAgICAgICAgICAgICAgICBtYXJnaW4tdG9wOiAxMHB4O1xuICAgICAgICAgICAgICAgIGNvbG9yOiBncmF5O1xuICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMTVweDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIC8vIC50aW1lX2xibHtcbiAgICAgICAgICAgIC8vICAgICBtYXJnaW4tdG9wOiAxMHB4O1xuICAgICAgICAgICAgLy8gICAgIGZvbnQtc2l6ZTogMTJweDtcbiAgICAgICAgICAgIC8vICAgICBjb2xvcjogZ3JheTtcbiAgICAgICAgICAgIC8vIH1cblxuICAgICAgICAgICAgLmxpbmtfbGJsIHtcbiAgICAgICAgICAgICAgICBtYXJnaW4tdG9wOiAxMHB4O1xuICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMTNweDtcbiAgICAgICAgICAgICAgICBjb2xvcjogZ3JheTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgLmxpa2VfZGl2IHtcbiAgICAgICAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMTNweDtcbiAgICAgICAgICAgICAgICBjb2xvcjogIzUwNTA1MDtcbiAgICAgICAgICAgICAgICBtYXJnaW4tdG9wOiAxMHB4O1xuICAgICAgICAgICAgICAgIG1hcmdpbi1ib3R0b206IDEwcHg7XG4gICAgICAgICAgICAgICAgaW1nIHtcbiAgICAgICAgICAgICAgICAgICAgd2lkdGg6IDIwcHg7XG4gICAgICAgICAgICAgICAgICAgIGhlaWdodDogMjBweDtcbiAgICAgICAgICAgICAgICAgICAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAuc2hhcmVfbGJsIHtcbiAgICAgICAgICAgICAgICAgICAgbWFyZ2luLWxlZnQ6IDE1cHg7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAuc2hhcmVfZGl2IHtcbiAgICAgICAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICAgICAgICAgIHdpZHRoOiAxMDAlO1xuICAgICAgICAgICAgICAgIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcblxuICAgICAgICAgICAgICAgIC5sZWZ0X2RpdiB7XG4gICAgICAgICAgICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgLnJpZ2h0X2RpdiB7XG4gICAgICAgICAgICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgICAgICAgICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAgICAgICAgICAgICAgICAgIGlvbi1idXR0b24ge1xuICAgICAgICAgICAgICAgICAgICAgICAgbWFyZ2luOiAwO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICBpb24taWNvbiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I6ICM1MDUwNTA7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAucm91bmRfZGl2IHtcbiAgICAgICAgICAgICAgICAgICAgYm9yZGVyOiAxcHggc29saWQgbGlnaHRncmF5O1xuICAgICAgICAgICAgICAgICAgICBoZWlnaHQ6IDQwcHg7XG4gICAgICAgICAgICAgICAgICAgIHdpZHRoOiA0MHB4O1xuICAgICAgICAgICAgICAgICAgICBib3JkZXItcmFkaXVzOiAxMDAlO1xuICAgICAgICAgICAgICAgICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gICAgICAgICAgICAgICAgICAgIG1hcmdpbi1yaWdodDogMTBweDtcbiAgICAgICAgICAgICAgICAgICAgaW9uLWljb24ge1xuICAgICAgICAgICAgICAgICAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgICAgICAgICAgICAgICAgICAgICAgdG9wOiA1MCU7XG4gICAgICAgICAgICAgICAgICAgICAgICBsZWZ0OiA1MCU7XG4gICAgICAgICAgICAgICAgICAgICAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZSgtNTAlLCAtNTAlKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMThweDtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yOiAjNTA1MDUwO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxufVxuIiwiLmhlYWRlcl9kaXYge1xuICB3aWR0aDogMTAwJTtcbiAgZGlzcGxheTogZmxleDtcbiAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xuICBwYWRkaW5nLWxlZnQ6IDhweDtcbiAgcGFkZGluZy1yaWdodDogMTJweDtcbiAgcGFkZGluZy10b3A6IDhweDtcbiAgcGFkZGluZy1ib3R0b206IDhweDtcbn1cbi5oZWFkZXJfZGl2IC5yaWdodF9kaXYge1xuICBkaXNwbGF5OiBmbGV4O1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xufVxuLmhlYWRlcl9kaXYgLnJpZ2h0X2RpdiBpb24taWNvbiB7XG4gIGZvbnQtc2l6ZTogMjJweDtcbiAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xufVxuLmhlYWRlcl9kaXYgLnJpZ2h0X2RpdiBpb24tYnV0dG9uIHtcbiAgLS1ib3JkZXItcmFkaXVzOiAzcHg7XG59XG4uaGVhZGVyX2RpdiAucmlnaHRfZGl2IC51c2VyX2ltYWdlIHtcbiAgaGVpZ2h0OiAzNXB4O1xuICB3aWR0aDogMzVweDtcbiAgYm9yZGVyLXJhZGl1czogMTAwJTtcbn1cblxuLm1haW5fY29udGVudF9kaXYge1xuICB3aWR0aDogMTAwJTtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IGlvbi1sYWJlbCB7XG4gIGRpc3BsYXk6IGJsb2NrO1xufVxuLm1haW5fY29udGVudF9kaXYgLnVwcGVyX2RpdiB7XG4gIHBhZGRpbmc6IDEwcHg7XG59XG4ubWFpbl9jb250ZW50X2RpdiAudXBwZXJfZGl2IC5sb2dvIHtcbiAgd2lkdGg6IDEzMHB4O1xuICBtYXJnaW46IGF1dG87XG4gIGRpc3BsYXk6IGJsb2NrO1xuICBtYXJnaW4tYm90dG9tOiAyMHB4O1xufVxuLm1haW5fY29udGVudF9kaXYgLnVwcGVyX2RpdiBpb24taW5wdXQge1xuICBib3JkZXI6IDFweCBzb2xpZCBibGFjaztcbiAgYm9yZGVyLXJhZGl1czogMjVweDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC51cHBlcl9kaXYgaW9uLWlucHV0IGlvbi1pY29uIHtcbiAgZm9udC1zaXplOiAyMHB4O1xuICBwYWRkaW5nLWxlZnQ6IDEwcHg7XG4gIHBhZGRpbmctcmlnaHQ6IDVweDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC51cHBlcl9kaXYgLnNsaWRlcl9kaXYgaW9uLWdyaWQge1xuICBwYWRkaW5nOiAwO1xufVxuLm1haW5fY29udGVudF9kaXYgLnVwcGVyX2RpdiAuc2xpZGVyX2RpdiBpb24tZ3JpZCBpb24tY29sIHtcbiAgcGFkZGluZzogMDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC51cHBlcl9kaXYgLnNsaWRlcl9kaXYgLmNvbF9kaXYge1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIHdpZHRoOiAxMDAlO1xuICBoZWlnaHQ6IDgwcHg7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xufVxuLm1haW5fY29udGVudF9kaXYgLnVwcGVyX2RpdiAuc2xpZGVyX2RpdiAuY29sX2RpdiBpbWcge1xuICB3aWR0aDogMjBweDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC51cHBlcl9kaXYgLnNsaWRlcl9kaXYgLmNvbF9kaXYgaW9uLWxhYmVsIHtcbiAgbWFyZ2luLXRvcDogNXB4O1xuICBmb250LXNpemU6IDEycHg7XG59XG4ubWFpbl9jb250ZW50X2RpdiAubG93ZXJfZGl2IC5uZXdzX2NhcmQge1xuICBwYWRkaW5nOiAxNnB4O1xuICBib3JkZXItYm90dG9tOiAxcHggc29saWQgbGlnaHRncmF5O1xufVxuLm1haW5fY29udGVudF9kaXYgLmxvd2VyX2RpdiAubmV3c19jYXJkIC5jaGlwX2RpdiB7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgbWFyZ2luLWJvdHRvbTogMTVweDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5sb3dlcl9kaXYgLm5ld3NfY2FyZCAuY2hpcF9kaXYgLnJvdW5kIHtcbiAgd2lkdGg6IDE1cHg7XG4gIGhlaWdodDogMTVweDtcbiAgYmFja2dyb3VuZDogd2hpdGU7XG4gIGJvcmRlci1yYWRpdXM6IDEwMCU7XG4gIGJvcmRlcjogNHB4IHNvbGlkIHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5sb3dlcl9kaXYgLm5ld3NfY2FyZCAuY2hpcF9kaXYgLmNoaXAge1xuICBib3JkZXItcmFkaXVzOiAyNXB4O1xuICBib3JkZXI6IDFweCBzb2xpZCBsaWdodGdyYXk7XG4gIHdpZHRoOiBmaXQtY29udGVudDtcbiAgcGFkZGluZzogMTBweDtcbiAgZGlzcGxheTogZmxleDtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgbWFyZ2luOiBhdXRvO1xufVxuLm1haW5fY29udGVudF9kaXYgLmxvd2VyX2RpdiAubmV3c19jYXJkIC5jaGlwX2RpdiAuY2hpcCBpb24tbGFiZWwge1xuICBmb250LXNpemU6IDE0cHg7XG4gIG1hcmdpbi1sZWZ0OiAxMHB4O1xufVxuLm1haW5fY29udGVudF9kaXYgLmxvd2VyX2RpdiAubmV3c19jYXJkIC5iYWNrX2ltYWdlIHtcbiAgd2lkdGg6IDEwMCU7XG4gIGhlaWdodDogMTgwcHg7XG4gIGJvcmRlci1yYWRpdXM6IDEwcHg7XG59XG4ubWFpbl9jb250ZW50X2RpdiAubG93ZXJfZGl2IC5uZXdzX2NhcmQgdmlkZW8ge1xuICB3aWR0aDogMTAwJTtcbiAgYm9yZGVyLXJhZGl1czogMTBweDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5sb3dlcl9kaXYgLm5ld3NfY2FyZCAuY2hhbm5lbF9kZXRhaWwge1xuICBkaXNwbGF5OiBmbGV4O1xuICBtYXJnaW4tdG9wOiAxNXB4O1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBtYXJnaW4tYm90dG9tOiAxMHB4O1xufVxuLm1haW5fY29udGVudF9kaXYgLmxvd2VyX2RpdiAubmV3c19jYXJkIC5jaGFubmVsX2RldGFpbCBpbWcge1xuICB3aWR0aDogMjVweDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5sb3dlcl9kaXYgLm5ld3NfY2FyZCAuY2hhbm5lbF9kZXRhaWwgLmNoYW5uZWxfbmFtZSB7XG4gIGZvbnQtd2VpZ2h0OiA2MDA7XG4gIGZvbnQtc2l6ZTogMTVweDtcbiAgbWFyZ2luLWxlZnQ6IDEwcHg7XG4gIG1hcmdpbi1yaWdodDogMTBweDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5sb3dlcl9kaXYgLm5ld3NfY2FyZCAuY2hhbm5lbF9kZXRhaWwgLmZvbGxvd19sYmwge1xuICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xuICBmb250LXNpemU6IDEzcHg7XG4gIG1hcmdpbi1sZWZ0OiAxMHB4O1xufVxuLm1haW5fY29udGVudF9kaXYgLmxvd2VyX2RpdiAubmV3c19jYXJkIC5oZWFkX2xpbmUge1xuICBmb250LXdlaWdodDogNTAwO1xufVxuLm1haW5fY29udGVudF9kaXYgLmxvd2VyX2RpdiAubmV3c19jYXJkIC5kZXRhaWwge1xuICBtYXJnaW4tdG9wOiAxMHB4O1xuICBjb2xvcjogZ3JheTtcbiAgZm9udC1zaXplOiAxNXB4O1xufVxuLm1haW5fY29udGVudF9kaXYgLmxvd2VyX2RpdiAubmV3c19jYXJkIC5saW5rX2xibCB7XG4gIG1hcmdpbi10b3A6IDEwcHg7XG4gIGZvbnQtc2l6ZTogMTNweDtcbiAgY29sb3I6IGdyYXk7XG59XG4ubWFpbl9jb250ZW50X2RpdiAubG93ZXJfZGl2IC5uZXdzX2NhcmQgLmxpa2VfZGl2IHtcbiAgZGlzcGxheTogZmxleDtcbiAgZm9udC1zaXplOiAxM3B4O1xuICBjb2xvcjogIzUwNTA1MDtcbiAgbWFyZ2luLXRvcDogMTBweDtcbiAgbWFyZ2luLWJvdHRvbTogMTBweDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5sb3dlcl9kaXYgLm5ld3NfY2FyZCAubGlrZV9kaXYgaW1nIHtcbiAgd2lkdGg6IDIwcHg7XG4gIGhlaWdodDogMjBweDtcbiAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xufVxuLm1haW5fY29udGVudF9kaXYgLmxvd2VyX2RpdiAubmV3c19jYXJkIC5saWtlX2RpdiAuc2hhcmVfbGJsIHtcbiAgbWFyZ2luLWxlZnQ6IDE1cHg7XG59XG4ubWFpbl9jb250ZW50X2RpdiAubG93ZXJfZGl2IC5uZXdzX2NhcmQgLnNoYXJlX2RpdiB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIHdpZHRoOiAxMDAlO1xuICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XG59XG4ubWFpbl9jb250ZW50X2RpdiAubG93ZXJfZGl2IC5uZXdzX2NhcmQgLnNoYXJlX2RpdiAubGVmdF9kaXYge1xuICBkaXNwbGF5OiBmbGV4O1xufVxuLm1haW5fY29udGVudF9kaXYgLmxvd2VyX2RpdiAubmV3c19jYXJkIC5zaGFyZV9kaXYgLnJpZ2h0X2RpdiB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG59XG4ubWFpbl9jb250ZW50X2RpdiAubG93ZXJfZGl2IC5uZXdzX2NhcmQgLnNoYXJlX2RpdiAucmlnaHRfZGl2IGlvbi1idXR0b24ge1xuICBtYXJnaW46IDA7XG59XG4ubWFpbl9jb250ZW50X2RpdiAubG93ZXJfZGl2IC5uZXdzX2NhcmQgLnNoYXJlX2RpdiAucmlnaHRfZGl2IGlvbi1idXR0b24gaW9uLWljb24ge1xuICBjb2xvcjogIzUwNTA1MDtcbn1cbi5tYWluX2NvbnRlbnRfZGl2IC5sb3dlcl9kaXYgLm5ld3NfY2FyZCAuc2hhcmVfZGl2IC5yb3VuZF9kaXYge1xuICBib3JkZXI6IDFweCBzb2xpZCBsaWdodGdyYXk7XG4gIGhlaWdodDogNDBweDtcbiAgd2lkdGg6IDQwcHg7XG4gIGJvcmRlci1yYWRpdXM6IDEwMCU7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xufVxuLm1haW5fY29udGVudF9kaXYgLmxvd2VyX2RpdiAubmV3c19jYXJkIC5zaGFyZV9kaXYgLnJvdW5kX2RpdiBpb24taWNvbiB7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgdG9wOiA1MCU7XG4gIGxlZnQ6IDUwJTtcbiAgdHJhbnNmb3JtOiB0cmFuc2xhdGUoLTUwJSwgLTUwJSk7XG4gIGZvbnQtc2l6ZTogMThweDtcbiAgY29sb3I6ICM1MDUwNTA7XG59Il19 */";
    /***/
  },

  /***/
  "./src/app/pages/home/home.page.ts":
  /*!*****************************************!*\
    !*** ./src/app/pages/home/home.page.ts ***!
    \*****************************************/

  /*! exports provided: HomePage */

  /***/
  function srcAppPagesHomeHomePageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "HomePage", function () {
      return HomePage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var src_app_services_dummy_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! src/app/services/dummy.service */
    "./src/app/services/dummy.service.ts");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _choose_language_choose_language_page__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ../choose-language/choose-language.page */
    "./src/app/pages/choose-language/choose-language.page.ts");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");

    var HomePage = /*#__PURE__*/function () {
      function HomePage(dummy, modalController, actionSheetController, router) {
        _classCallCheck(this, HomePage);

        this.dummy = dummy;
        this.modalController = modalController;
        this.actionSheetController = actionSheetController;
        this.router = router;
        this.plt = localStorage.getItem('platform');
        this.sliderImage = this.dummy.slider;
        this.allNews = this.dummy.news;
        console.log(this.sliderImage);
      }

      _createClass(HomePage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          if (localStorage.getItem('username') && localStorage.getItem('username') !== 'null') {
            this.isSignIn = true;
          } else {
            this.isSignIn = false;
          }
        }
      }, {
        key: "goToChooseLanguage",
        value: function goToChooseLanguage() {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
            var modal;
            return regeneratorRuntime.wrap(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    _context.next = 2;
                    return this.modalController.create({
                      component: _choose_language_choose_language_page__WEBPACK_IMPORTED_MODULE_4__["ChooseLanguagePage"]
                    });

                  case 2:
                    modal = _context.sent;
                    _context.next = 5;
                    return modal.present();

                  case 5:
                    return _context.abrupt("return", _context.sent);

                  case 6:
                  case "end":
                    return _context.stop();
                }
              }
            }, _callee, this);
          }));
        }
      }, {
        key: "presentActionSheet",
        value: function presentActionSheet() {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
            var actionSheet;
            return regeneratorRuntime.wrap(function _callee2$(_context2) {
              while (1) {
                switch (_context2.prev = _context2.next) {
                  case 0:
                    _context2.next = 2;
                    return this.actionSheetController.create({
                      mode: 'md',
                      buttons: [{
                        text: 'Hide Post',
                        icon: 'eye-off-outline'
                      }, {
                        text: 'Follow South China Morning Post',
                        icon: 'person-add-outline'
                      }, {
                        text: 'Report Post',
                        icon: 'alert-circle-outline'
                      }]
                    });

                  case 2:
                    actionSheet = _context2.sent;
                    _context2.next = 5;
                    return actionSheet.present();

                  case 5:
                  case "end":
                    return _context2.stop();
                }
              }
            }, _callee2, this);
          }));
        }
      }, {
        key: "shareActionSheet",
        value: function shareActionSheet() {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
            var actionSheet;
            return regeneratorRuntime.wrap(function _callee3$(_context3) {
              while (1) {
                switch (_context3.prev = _context3.next) {
                  case 0:
                    _context3.next = 2;
                    return this.actionSheetController.create({
                      mode: 'md',
                      buttons: [{
                        text: 'Post on JdSocial',
                        icon: 'sync-circle-outline'
                      }, {
                        text: 'Share on facebook',
                        icon: 'logo-facebook'
                      }, {
                        text: 'Send on WhatsApp',
                        icon: 'logo-whatsapp'
                      }, {
                        text: 'Copy Link',
                        icon: 'copy-outline'
                      }, {
                        text: 'More Options..',
                        icon: 'ellipsis-horizontal-circle-outline'
                      }]
                    });

                  case 2:
                    actionSheet = _context3.sent;
                    _context3.next = 5;
                    return actionSheet.present();

                  case 5:
                  case "end":
                    return _context3.stop();
                }
              }
            }, _callee3, this);
          }));
        }
      }, {
        key: "goToRegister",
        value: function goToRegister() {
          this.router.navigate(['/register']);
        }
      }, {
        key: "goToProfile",
        value: function goToProfile() {
          this.router.navigate(['/profile']);
        }
      }, {
        key: "goToNotification",
        value: function goToNotification() {
          this.router.navigate(['/tabs/notification']);
        }
      }, {
        key: "goToMain",
        value: function goToMain(val) {
          var myid;
          var mydesc;

          if (val.name === 'Shopping') {
            myid = 'Shopping';
            mydesc = '';
          } else {
            myid = 'Search';
            mydesc = val.name;
          }

          var navData = {
            queryParams: {
              id: myid,
              desc: mydesc
            }
          };
          this.router.navigate(['/tabs/main-page'], navData);
        }
      }]);

      return HomePage;
    }();

    HomePage.ctorParameters = function () {
      return [{
        type: src_app_services_dummy_service__WEBPACK_IMPORTED_MODULE_2__["DummyService"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ModalController"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ActionSheetController"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"]
      }];
    };

    HomePage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-home',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./home.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/home/home.page.html"))["default"],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./home.page.scss */
      "./src/app/pages/home/home.page.scss"))["default"]]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [src_app_services_dummy_service__WEBPACK_IMPORTED_MODULE_2__["DummyService"], _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ModalController"], _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ActionSheetController"], _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"]])], HomePage);
    /***/
  }
}]);
//# sourceMappingURL=home-home-module-es5.js.map