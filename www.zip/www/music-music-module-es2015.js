(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["music-music-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/music/music.page.html":
/*!***********************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/music/music.page.html ***!
  \***********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar>\n    \n    <ion-icon class=\"back\" name=\"arrow-back-outline\" (click)=\"goBack()\"></ion-icon>\n\n    <ion-title>Select Language</ion-title>\n    <ion-button fill=\"clear\" slot=\"end\" size=\"small\">\n      Skip\n    </ion-button>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div class=\"main_content_div\">\n\n    <ion-grid>\n      <ion-row *ngFor=\"let item of [1,2,3]\">\n        <ion-col size=\"6\" *ngFor=\"let item of lang\" (click)=\"selectLang(item.name)\">\n          <div class=\"back_image bg_image\" [style.backgroundImage]=\"'url( '+ item.img +' )'\">\n            <ion-icon name=\"checkmark-circle-sharp\" *ngIf=\"sel == item.name\"></ion-icon>\n          </div>\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n\n  </div>\n</ion-content>\n<ion-footer>\n  <div class=\"footer_div\">\n    <ion-button (click)=\"goToMusicList()\" expand=\"block\">\n      Apply\n    </ion-button>\n  </div>\n</ion-footer>\n");

/***/ }),

/***/ "./src/app/pages/music/music-routing.module.ts":
/*!*****************************************************!*\
  !*** ./src/app/pages/music/music-routing.module.ts ***!
  \*****************************************************/
/*! exports provided: MusicPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MusicPageRoutingModule", function() { return MusicPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _music_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./music.page */ "./src/app/pages/music/music.page.ts");




const routes = [
    {
        path: '',
        component: _music_page__WEBPACK_IMPORTED_MODULE_3__["MusicPage"]
    }
];
let MusicPageRoutingModule = class MusicPageRoutingModule {
};
MusicPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], MusicPageRoutingModule);



/***/ }),

/***/ "./src/app/pages/music/music.module.ts":
/*!*********************************************!*\
  !*** ./src/app/pages/music/music.module.ts ***!
  \*********************************************/
/*! exports provided: MusicPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MusicPageModule", function() { return MusicPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _music_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./music-routing.module */ "./src/app/pages/music/music-routing.module.ts");
/* harmony import */ var _music_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./music.page */ "./src/app/pages/music/music.page.ts");







let MusicPageModule = class MusicPageModule {
};
MusicPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _music_routing_module__WEBPACK_IMPORTED_MODULE_5__["MusicPageRoutingModule"]
        ],
        declarations: [_music_page__WEBPACK_IMPORTED_MODULE_6__["MusicPage"]]
    })
], MusicPageModule);



/***/ }),

/***/ "./src/app/pages/music/music.page.scss":
/*!*********************************************!*\
  !*** ./src/app/pages/music/music.page.scss ***!
  \*********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-toolbar .back {\n  font-size: 27px;\n  margin-left: 10px;\n}\nion-toolbar ion-button {\n  color: black;\n  margin: 0;\n  font-size: 14px;\n}\n.main_content_div {\n  padding: 8px;\n}\n.main_content_div ion-grid {\n  padding: 0;\n}\n.main_content_div ion-grid ion-col {\n  padding: 10px;\n}\n.main_content_div .back_image {\n  width: 100%;\n  height: 100px;\n  border-radius: 10px;\n  position: relative;\n}\n.main_content_div .back_image ion-icon {\n  position: absolute;\n  top: 5px;\n  right: 5px;\n  font-size: 25px;\n  color: white;\n}\n.footer_div {\n  padding: 10px;\n}\n.footer_div ion-button {\n  --border-radius: 5px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvbXVzaWMvRTpcXElvbmljIFByb2plY3RzXFxpb25pYy01LXRlbXBsYXRlLWJ1bmRsZS1pb25pYy01LXRoZW1lcy1idW5kbGVzLWlvbmljLTUtdGVtcGxhdGVzLXdpdGgtMTAtYXBwc1xcQXBwX3NvdXJjZV9jb2RlXFxBcHBzX2NvZGVcXE11bHRpX3B1cnBvc2Uvc3JjXFxhcHBcXHBhZ2VzXFxtdXNpY1xcbXVzaWMucGFnZS5zY3NzIiwic3JjL2FwcC9wYWdlcy9tdXNpYy9tdXNpYy5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0k7RUFDSSxlQUFBO0VBQ0EsaUJBQUE7QUNBUjtBREVJO0VBQ0ksWUFBQTtFQUNBLFNBQUE7RUFDQSxlQUFBO0FDQVI7QURHQTtFQUNJLFlBQUE7QUNBSjtBREVJO0VBQ0ksVUFBQTtBQ0FSO0FERVE7RUFDSSxhQUFBO0FDQVo7QURJSTtFQUNJLFdBQUE7RUFDQSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSxrQkFBQTtBQ0ZSO0FESVE7RUFDSSxrQkFBQTtFQUNBLFFBQUE7RUFDQSxVQUFBO0VBQ0EsZUFBQTtFQUNBLFlBQUE7QUNGWjtBRE9BO0VBQ0ksYUFBQTtBQ0pKO0FES0k7RUFDSSxvQkFBQTtBQ0hSIiwiZmlsZSI6InNyYy9hcHAvcGFnZXMvbXVzaWMvbXVzaWMucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLXRvb2xiYXJ7XG4gICAgLmJhY2t7XG4gICAgICAgIGZvbnQtc2l6ZTogMjdweDtcbiAgICAgICAgbWFyZ2luLWxlZnQ6IDEwcHg7XG4gICAgfVxuICAgIGlvbi1idXR0b257XG4gICAgICAgIGNvbG9yOiBibGFjaztcbiAgICAgICAgbWFyZ2luOiAwO1xuICAgICAgICBmb250LXNpemU6IDE0cHg7XG4gICAgfVxufVxuLm1haW5fY29udGVudF9kaXZ7XG4gICAgcGFkZGluZzogOHB4O1xuXG4gICAgaW9uLWdyaWR7XG4gICAgICAgIHBhZGRpbmc6IDA7XG5cbiAgICAgICAgaW9uLWNvbHtcbiAgICAgICAgICAgIHBhZGRpbmc6IDEwcHg7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAuYmFja19pbWFnZXtcbiAgICAgICAgd2lkdGg6IDEwMCU7XG4gICAgICAgIGhlaWdodDogMTAwcHg7XG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDEwcHg7XG4gICAgICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcblxuICAgICAgICBpb24taWNvbntcbiAgICAgICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICAgICAgICAgIHRvcDogNXB4O1xuICAgICAgICAgICAgcmlnaHQ6IDVweDtcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogMjVweDtcbiAgICAgICAgICAgIGNvbG9yOiB3aGl0ZTtcbiAgICAgICAgfVxuICAgIH1cbn1cblxuLmZvb3Rlcl9kaXZ7XG4gICAgcGFkZGluZzogMTBweDtcbiAgICBpb24tYnV0dG9ue1xuICAgICAgICAtLWJvcmRlci1yYWRpdXM6IDVweDtcbiAgICB9XG59IiwiaW9uLXRvb2xiYXIgLmJhY2sge1xuICBmb250LXNpemU6IDI3cHg7XG4gIG1hcmdpbi1sZWZ0OiAxMHB4O1xufVxuaW9uLXRvb2xiYXIgaW9uLWJ1dHRvbiB7XG4gIGNvbG9yOiBibGFjaztcbiAgbWFyZ2luOiAwO1xuICBmb250LXNpemU6IDE0cHg7XG59XG5cbi5tYWluX2NvbnRlbnRfZGl2IHtcbiAgcGFkZGluZzogOHB4O1xufVxuLm1haW5fY29udGVudF9kaXYgaW9uLWdyaWQge1xuICBwYWRkaW5nOiAwO1xufVxuLm1haW5fY29udGVudF9kaXYgaW9uLWdyaWQgaW9uLWNvbCB7XG4gIHBhZGRpbmc6IDEwcHg7XG59XG4ubWFpbl9jb250ZW50X2RpdiAuYmFja19pbWFnZSB7XG4gIHdpZHRoOiAxMDAlO1xuICBoZWlnaHQ6IDEwMHB4O1xuICBib3JkZXItcmFkaXVzOiAxMHB4O1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG59XG4ubWFpbl9jb250ZW50X2RpdiAuYmFja19pbWFnZSBpb24taWNvbiB7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgdG9wOiA1cHg7XG4gIHJpZ2h0OiA1cHg7XG4gIGZvbnQtc2l6ZTogMjVweDtcbiAgY29sb3I6IHdoaXRlO1xufVxuXG4uZm9vdGVyX2RpdiB7XG4gIHBhZGRpbmc6IDEwcHg7XG59XG4uZm9vdGVyX2RpdiBpb24tYnV0dG9uIHtcbiAgLS1ib3JkZXItcmFkaXVzOiA1cHg7XG59Il19 */");

/***/ }),

/***/ "./src/app/pages/music/music.page.ts":
/*!*******************************************!*\
  !*** ./src/app/pages/music/music.page.ts ***!
  \*******************************************/
/*! exports provided: MusicPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MusicPage", function() { return MusicPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var src_app_services_music_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/music.service */ "./src/app/services/music.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");





let MusicPage = class MusicPage {
    constructor(music, router, navCtrl) {
        this.music = music;
        this.router = router;
        this.navCtrl = navCtrl;
        this.lang = this.music.singers;
    }
    ngOnInit() {
    }
    selectLang(val) {
        this.sel = val;
    }
    goToMusicList() {
        this.router.navigate(['/tabs/music-list']);
    }
    goBack() {
        this.navCtrl.back();
    }
};
MusicPage.ctorParameters = () => [
    { type: src_app_services_music_service__WEBPACK_IMPORTED_MODULE_2__["MusicService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["NavController"] }
];
MusicPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-music',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./music.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/music/music.page.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./music.page.scss */ "./src/app/pages/music/music.page.scss")).default]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [src_app_services_music_service__WEBPACK_IMPORTED_MODULE_2__["MusicService"], _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["NavController"]])
], MusicPage);



/***/ })

}]);
//# sourceMappingURL=music-music-module-es2015.js.map